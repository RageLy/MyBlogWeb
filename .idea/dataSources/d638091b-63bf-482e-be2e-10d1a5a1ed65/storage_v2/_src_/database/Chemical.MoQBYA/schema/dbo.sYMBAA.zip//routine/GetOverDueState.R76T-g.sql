






-- =============================================                  
-- Author:  <刘轶>                  
-- Create date: <2014-3-21>                  
-- Description: <获取预计下次回访时间>                 
-- =============================================                  
CREATE function [dbo].[GetOverDueState](@FrameNum varchar(500))--获取预计下次回访时间
returns datetime 
as
begin
declare @NextFollowTime datetime
declare @CarSalesTime datetime =(select CarSalesTime from Tbl_Sales_CarSales where FrameNum=@FrameNum)
declare @FollowCount int = (select COUNT(FrameNum) from Tbl_Sale_FollowSale where FrameNum=@FrameNum)
	select @NextFollowTime = case when @FollowCount=0 then DATEADD(DAY,2,(@CarSalesTime))
			when @FollowCount=1 then DATEADD(DAY,15,(@CarSalesTime))	
			when @FollowCount=2 then DATEADD(DAY,60,(@CarSalesTime))
			when @FollowCount=3 then DATEADD(DAY,90,(@CarSalesTime))
			when @FollowCount=4 then DATEADD(MONTH,6,(@CarSalesTime))
			when @FollowCount=5 then DATEADD(MONTH,12,(@CarSalesTime))
			else  DATEADD(year,1,GETDATE()) end
			
	return  @NextFollowTime
end
go

