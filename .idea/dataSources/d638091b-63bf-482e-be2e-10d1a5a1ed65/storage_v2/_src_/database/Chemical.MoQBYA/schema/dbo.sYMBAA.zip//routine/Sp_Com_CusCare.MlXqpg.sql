        
/*        
刘轶  2014-7-1 售后客户关怀 默认未关怀        
*/        
CREATE proc [dbo].[Sp_Com_CusCare]  
@Type varchar(100) = '空'        
as          
BEGIN 
if(@Type = '空')      
begin      
 select 'BeginDate' BeginDate                              
 ,'EndDate' EndDate                                
 union all                                
 select 'varchar 200'                             
 ,'varchar 200'                                 
 union all        
 select '',''      
end 
else if(@Type = '')         
begin
select 'AftsCusCareState' AftsCusCareState                
,'BeginDate' BeginDate    
,'EndDate' EndDate                  
union all                  
select 'varchar 200'               
,'varchar 200'    
,'varchar 200'                  
union all                     
select  '未关怀' AS AftsCusCareState    
,CONVERT(VARCHAR(10),GETDATE(),23) AS BeginDate         
,CONVERT(VARCHAR(10),GETDATE(),23) AS EndDate  
end
END
go

