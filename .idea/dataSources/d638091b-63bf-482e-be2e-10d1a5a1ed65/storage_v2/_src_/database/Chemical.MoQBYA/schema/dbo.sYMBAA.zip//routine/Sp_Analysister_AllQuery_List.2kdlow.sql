

-- exec [Sp_Analysister_ClickDetail_hmw] 'Dim7:Y:this10%DimMpCode:-1%DimMpLotCode:-1%DimMpSeries:-1%DimSDJAvg:-1%DimSDJSqt:-1%DimNhjPH:-1%DimZcjND:-1%DimMsFsjUse:-1%DimMsLpjCode:-1%DimMsLpjUse:-1%DimMsNhjType:-1%DimMsNhjUse:-1%DimMsZcjUse:-1%DimMsCapsulePH:-1%DimMsWaterType:-1%DimMsWaterPH:-1%DimMsWaterDDlps:-1%DimMsLPH:-1%DimMsOverPH:-1%DimMsOverND:-1%DimMsOverGHL:-1%DimMsOverZL:-1%DimMsNdBe:-1%DimMsGhlBe:-1%DimJsCode:-1%DimJsType:-1%DimJsNdBe:-1%DimJsGhlBe:-1%DimMsTtTemp:-1%DimMsTtSd:-1%DimMsTtGTemp:-1%DimMsTtGSd:-1%DimMsTtITOhd:-1%DimMsTtSpeed:-1%DimMsHxFpTemp1:-1%DimMsHxFpTemp2:-1%DimMsHxFpTemp3:-1%DimMsHxFpTemp4:-1%DimMsHxFpTemp5:-1%DimMsHxFpTemp6:-1%DimMsHxFpTemp7:-1%DimMsCjTemp:-1%DimMsCjSd:-1%DimMsCjSpeed:-1%DimMsCjMshd:-1%DimJsTtTemp:-1%DimJsTtSd:-1%DimJsTtSpeed:-1%DimJsTtJx:-1%DimJsCjTemp:-1%DimJsCjSpeed:-1%DimJsCjJshd:-1%DimJsDs:-1%DimMsDs:-1%DimMpTbLv:-1%DimMpFdLv:-1%DimLineSW:-1%DimScJP:-1%DimZcZK:-1%DimSYJudge:-1%DimOEDJudge:-1%Dim0minLBK:-1%Dim2minLBK:-1%Dim0minLW:-1%Dim2minLW:-1%Dim2mindetaLBK:-1%Dim2mindetaLW:-1%DimDbd:-1%DimWBdata:-1%DimQddl:-1','%时间%水电导率%水滴角均值%line%平均值%水滴角均值%数量','图','','Coating',1,'1','15','全部集合[0.00-100000.00)','全部集合[0.00-10.00)'
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年6月28日
-- Edit Date: 2016年6月28日                                                
-- Descript: 全数据查询

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_AllQuery_List]
    @CodeType VARCHAR(50) = 'PigmentBK',    -- 编号类型      
    @CodeValue VARCHAR(50) = '1506MW3005',  -- 编号取值  
    @ResultType VARCHAR(50) = 'SinCapsule', -- 结果类型   
    @PageIndex VARCHAR(5) = '1',
    @PageSize VARCHAR(5) = '10',
    @OrderFields VARCHAR(50) = '',
    @EmpID VARCHAR(50) = '1'

--------------------定义字符串变量----------------------------------------------------------------------------------------------------------------------
AS
BEGIN
    DECLARE @sql NVARCHAR(MAX) = ' ';
    DECLARE @InnerSql NVARCHAR(MAX) = ' ';
    DECLARE @InnerTopSql NVARCHAR(MAX) = ' ';
    DECLARE @InnerMiddleSql NVARCHAR(MAX) = ' ';
    DECLARE @InnerBottomSql NVARCHAR(MAX) = ' ';
    DECLARE @WhereSql NVARCHAR(200) = ' ';
    DECLARE @counts INT = 0;
    DECLARE @tempType NVARCHAR(20); --取每次递归后的sptype
    DECLARE @FromSql NVARCHAR(MAX) = ' ';
    DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段  
    ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            
    SET @CodeValue = RTRIM(@CodeValue);
    IF (@CodeValue = '')
    BEGIN
        SET @InnerSql +=
        (
            SELECT CHAR(10) + ' ' + JoinTable + ' ' + BigTable + ' ' + BaseTable
            FROM dbo.AllQuaryPara
            WHERE SpType = @ResultType
        );
        PRINT @InnerSql;
    END;
    ELSE
    BEGIN

        ----------------------------------------------结果集ID大于条件ID时处理方案------------------------------------------------------------           

        --如果结果集ID>条件ID,则执行下面语句               
        IF (
           (
               SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
           ) >
           (
               SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @CodeType
           )
           )
        BEGIN
            IF (
                   (
                       @CodeType = 'PigmentBK'
                       AND (
                               @ResultType = 'PigmentW'
                               OR @ResultType = 'ParticalW'
                           )
                   )
                   OR (
                          @CodeType = 'PigmentW'
                          AND (
                                  @ResultType = 'PigmentBK'
                                  OR @ResultType = 'ParticalBK'
                              )
                      )
                   OR (
                          @CodeType = 'SinCapsule'
                          AND @ResultType = 'DouCapsule'
                      )
                   OR (
                          @CodeType = 'SinCapsule'
                          AND @ResultType = 'TestPiece'
                      )
                   OR (
                          @CodeType = 'DouCapsule'
                          AND @ResultType = 'SinCapsule'
                      )
                   OR (
                          @CodeType = 'Coating'
                          AND @ResultType = 'SinCapsule'
                      )
                   OR (
                          @CodeType = 'Coating'
                          AND @ResultType = 'TestPiece'
                      )
                   OR (
                          @CodeType = 'SinCapsule'
                          AND @ResultType = 'Coating'
                      )
               )
                SET @InnerSql = ' ';
            ELSE
            BEGIN
                --初始化counts,以便后续开始递归拼接
                SET @counts =
                (
                    SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
                );
                SET @InnerTopSql +=
                (
                    SELECT CHAR(10) + JoinTable + ' '
                    FROM dbo.AllQuaryPara
                    WHERE SpType = @ResultType
                );
                SET @tempType = @ResultType;
                WHILE (@counts <> (SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @CodeType))
                BEGIN
                    --PRINT '执行吧';
                    --PRINT @counts;
                    --遇到颜料为条件油相以上为数据结果集时处理方式
                    IF (
                           (
                               @CodeType = 'PigmentBK'
                               OR @CodeType = 'PigmentW'
                               OR @CodeType = 'ParticalBK'
                               OR @CodeType = 'ParticalW'
                           --OR @CodeType = 'Oil'
                           )
                           AND
                           (
                               SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
                           ) >= 5
                       )
                    BEGIN
                        SET @InnerMiddleSql +=
                        (
                            SELECT CHAR(10) + ' ' + MiddleTable + CHAR(10)
                            FROM dbo.AllQuaryPara
                            WHERE ID = @counts
                        );
                        IF (@tempType <> 'Oil')
                        BEGIN
                            SET @counts =
                            (
                                SELECT Last FROM AllQuaryPara WHERE ID = @counts
                            );
                        END;
                        ELSE
                        --单独判断颜料黑和颜料白对于的递归关系
                        BEGIN
                            IF (@CodeType = 'PigmentBK' OR @CodeType = 'ParticalBK')
                                SET @counts =
                            (
                                SELECT ID
                                FROM AllQuaryPara
                                WHERE Next LIKE '%' + CONVERT(NVARCHAR(10), @counts) + '%'
                                      AND SpType = 'ParticalBK'
                            )   ;
                            ELSE IF (@CodeType = 'PigmentW' OR @CodeType = 'ParticalW')
                                SET @counts =
                            (
                                SELECT ID
                                FROM AllQuaryPara
                                WHERE Next LIKE '%' + CONVERT(NVARCHAR(10), @counts) + '%'
                                      AND SpType = 'ParticalW'
                            )   ;
                        END;
                    END;
                    ELSE
                    BEGIN
                        SET @InnerMiddleSql +=
                        (
                            SELECT CHAR(10) + ' ' + MiddleTableES + CHAR(10)
                            FROM dbo.AllQuaryPara
                            WHERE ID = @counts
                        );
                        IF (@tempType <> 'Oil')
                        BEGIN
                            SET @counts =
                            (
                                SELECT Last FROM AllQuaryPara WHERE ID = @counts
                            );
                        END;
                        ELSE
                        BEGIN
                            IF (@CodeType = 'PigmentBK' OR @CodeType = 'ParticalBK')
                                SET @counts =
                            (
                                SELECT ID
                                FROM AllQuaryPara
                                WHERE Next LIKE '%' + CONVERT(NVARCHAR(10), @counts) + '%'
                                      AND SpType = 'ParticalBK'
                            )   ;
                            ELSE IF (@CodeType = 'PigmentW' OR @CodeType = 'ParticalW')
                                SET @counts =
                            (
                                SELECT ID
                                FROM AllQuaryPara
                                WHERE Next LIKE '%' + CONVERT(NVARCHAR(10), @counts) + '%'
                                      AND SpType = 'ParticalW'
                            )   ;

                        END;
                    END;

                    SET @tempType =
                    (
                        SELECT SpType FROM dbo.AllQuaryPara WHERE ID = @counts
                    );

                    PRINT '@InnerMiddleSql' + @InnerMiddleSql;
                END;

                SET @InnerBottomSql =
                (
                    SELECT CHAR(10) + ' ' + BaseTable
                    FROM dbo.AllQuaryPara
                    WHERE SpType = @ResultType
                );
                PRINT '@InnerBottomSql' + @InnerBottomSql;
                SET @InnerSql += @InnerTopSql + @InnerMiddleSql + @InnerBottomSql;
            END;
        END;
        ELSE
        ------------------------------------------------------结果集ID小于条件ID时处理方案--------------------------------------------------
        IF (
           (
               SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
           ) <
           (
               SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @CodeType
           )
           )
        BEGIN
            IF (
                   (
                       @CodeType = 'PigmentBK'
                       AND (
                               @ResultType = 'PigmentW'
                               OR @ResultType = 'ParticalW'
                           )
                   )
                   OR (
                          @CodeType = 'PigmentW'
                          AND (
                                  @ResultType = 'PigmentBK'
                                  OR @ResultType = 'ParticalBK'
                              )
                      )
                   OR (
                          @CodeType = 'SinCapsule'
                          AND @ResultType = 'DouCapsule'
                      )
                   OR (
                          @CodeType = 'SinCapsule'
                          AND @ResultType = 'TestPiece'
                      )
                   OR (
                          @CodeType = 'DouCapsule'
                          AND @ResultType = 'SinCapsule'
                      )
                   OR (
                          @CodeType = 'Coating'
                          AND @ResultType = 'SinCapsule'
                      )
                   OR (
                          @CodeType = 'Coating'
                          AND @ResultType = 'TestPiece'
                      )
                   OR (
                          @CodeType = 'SinCapsule'
                          AND @ResultType = 'Coating'
                      )
               )
                SET @InnerSql = ' ';
            ELSE
            BEGIN
                PRINT '处理数据的方式：结果集ID<条件ID时处理方式';
                SET @InnerTopSql +=
                (
                    SELECT +' ' + JoinTable FROM dbo.AllQuaryPara WHERE SpType = @CodeType
                );
                SET @counts =
                (
                    SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @CodeType
                );

                --PRINT @counts;
                --PRINT @MaxType;
                --判断当ID<>最大ID时，递归式的关联
                SET @tempType = @CodeType;
                WHILE (@counts <>
                      (
                          SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
                      )
                      )
                BEGIN --开始递归关联 

                    SET @InnerMiddleSql +=
                    (
                        SELECT +' ' + MiddleTable
                        FROM dbo.AllQuaryPara
                        WHERE SpType =
                        (
                            SELECT SpType FROM dbo.AllQuaryPara WHERE ID = @counts
                        )
                    );

                    --PRINT '中间语句：' + @InnerMiddleSql + '完毕';
                    --油相特殊处理
                    IF (@tempType <> 'Oil')
                    BEGIN
                        SET @counts =
                        (
                            SELECT Last FROM AllQuaryPara WHERE ID = @counts
                        );
                    END;
                    ELSE
                    BEGIN
                        IF (@ResultType = 'PigmentBK' OR @ResultType = 'ParticalBK')
                            SET @counts =
                        (
                            SELECT ID
                            FROM AllQuaryPara
                            WHERE Next LIKE '%' + CONVERT(NVARCHAR(10), @counts) + '%'
                                  AND SpType = 'ParticalBK'
                        )   ;
                        ELSE IF (@ResultType = 'PigmentW' OR @ResultType = 'ParticalW')
                            SET @counts =
                        (
                            SELECT ID
                            FROM AllQuaryPara
                            WHERE Next LIKE '%' + CONVERT(NVARCHAR(10), @counts) + '%'
                                  AND SpType = 'ParticalW'
                        )   ;
                    --ELSE IF(@ResultType='')
                    --BEGIN

                    --END


                    END;

                    SET @tempType =
                    (
                        SELECT SpType FROM dbo.AllQuaryPara WHERE ID = @counts
                    );
                END;
                --设置@InnerBottomSql
                SET @InnerBottomSql =
                (
                    SELECT CHAR(10) + ' ' + MiddleTableES + ' ' + BaseTable
                    FROM dbo.AllQuaryPara
                    WHERE SpType = @ResultType
                );
                SET @InnerSql += @InnerTopSql + @InnerMiddleSql + @InnerBottomSql;
            END;
        END;
        ELSE
        ------------------------------------------------------结果集ID等于条件ID时处理方案--------------------------------------------------                  
        IF (@ResultType = @CodeType)
        --BEGIN
        --    IF ( @CodeType = 'Oil' )
        --        SET @InnerSql += ( SELECT ' ' + JoinTable
        --                                  + ' '
        --                                  + MiddleTable
        --                                  + ' '
        --                                  + BaseTable
        --                           FROM   dbo.AllQuaryPara
        --                           WHERE  SpType = @CodeType
        --                         );
        --    ELSE
        BEGIN
            SET @InnerSql +=
            (
                SELECT ' ' + JoinTable + ' ' + MiddleTableES + ' ' + BaseTable
                FROM dbo.AllQuaryPara
                WHERE SpType = @CodeType
            );
        END;
        --SET @InnerSql = REPLACE(@InnerSql, 'inner',
        --                        'LEFT');
        --SET @InnerSql = REPLACE(@InnerSql, 'INNER ', 'LEFT ');
        PRINT 'INNERSQL:' + @InnerSql;
        --END;


        --设置Where语句
        SET @WhereSql +=
        (
            SELECT ' where ' + SpType + '.' + ParaIDChr + ' like ''%' + @CodeValue + '%'''
            FROM dbo.AllQuaryPara
            WHERE SpType = @CodeType
        );
    END;

    SET @InnerSelect =
    (
        SELECT ',' + TableName + '.[' + CoName + '] AS ' + TableName + CoName
        FROM Tbl_AnsCom_DIimToTable
        WHERE TableName_ch =
        (
            SELECT TableType FROM dbo.AllQuaryPara WHERE SpType = @ResultType
        )
        ORDER BY ShowIndex
        FOR XML PATH('')
    );

    SET @InnerSelect = SUBSTRING(@InnerSelect, 2, LEN(@InnerSelect));
    IF (@ResultType <> 'TestPiece')
        SET @InnerSelect += ',' + @ResultType + '.Code AS ID';
    ELSE
        SET @InnerSelect += ',' + @ResultType + '.DouCapsuleCode AS ID';
    --PRINT '@InnerSelect: ' + @InnerSelect;

    -------------------------------------------------------- 构造列名------------------------------------------------------------------

    DECLARE @CoChNames VARCHAR(MAX); --
    IF (@CodeType = 'Oil' AND @ResultType = '')
        SET @CoChNames =
    (
        SELECT ',''' + TableName + CoName + ''' AS [' + Name_ch + ']'
        FROM Tbl_AnsCom_DIimToTable
        WHERE TableName_ch = '黑粒子'
              AND IsDimBan = 0
        ORDER BY ShowIndex
        FOR XML PATH('')
    )   ;
    ELSE
        SET @CoChNames =
    (
        SELECT ',''' + TableName + CoName + ''' AS [' + Name_ch + ']'
        FROM Tbl_AnsCom_DIimToTable
        WHERE TableName_ch =
        (
            SELECT TableType FROM dbo.AllQuaryPara WHERE SpType = @ResultType
        )
        ORDER BY ShowIndex
        FOR XML PATH('')
    )   ;

    DECLARE @Varchar500s VARCHAR(MAX);
    IF (@CodeType = 'Oil' AND @ResultType = '')
        SET @Varchar500s =
    (
        SELECT ',''Varchar 500'''
        FROM Tbl_AnsCom_DIimToTable
        WHERE TableName_ch = '黑粒子'
              AND IsDimBan = 0
        ORDER BY ShowIndex
        FOR XML PATH('')
    )   ;
    ELSE
        SET @Varchar500s =
    (
        SELECT ',''Varchar 500'''
        FROM Tbl_AnsCom_DIimToTable
        WHERE TableName_ch =
        (
            SELECT TableType FROM dbo.AllQuaryPara WHERE SpType = @ResultType
        )
        ORDER BY ShowIndex
        FOR XML PATH('')
    )   ;
    -- 出列头的SQL
    DECLARE @SqlName VARCHAR(MAX);

    SET @SqlName
        = ' SELECT ''n'' AS 序号,''ID'' As ID ' + @CoChNames + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s;
    PRINT '@SqlName: ' + @SqlName;
    ----------------------------------------------------------配置输出结果----------------------------------------------------------------------
    --基础版本的 select段Sql语句

    --不存在黑色颜料条件对应白色颜料数据集，处理方法如下
    IF (@CodeValue <> '')
    BEGIN
        IF (
               (
                   @CodeType = 'PigmentBK'
                   AND (
                           @ResultType = 'PigmentW'
                           OR @ResultType = 'ParticalW'
                       )
               )
               OR (
                      @CodeType = 'PigmentW'
                      AND (
                              @ResultType = 'PigmentBK'
                              OR @ResultType = 'ParticalBK'
                          )
                  )
               OR (
                      @CodeType = 'SinCapsule'
                      AND @ResultType = 'DouCapsule'
                  )
               OR (
                      @CodeType = 'SinCapsule'
                      AND @ResultType = 'TestPiece'
                  )
               OR (
                      @CodeType = 'DouCapsule'
                      AND @ResultType = 'SinCapsule'
                  )
               OR (
                      @CodeType = 'Coating'
                      AND @ResultType = 'SinCapsule'
                  )
               OR (
                      @CodeType = 'Coating'
                      AND @ResultType = 'TestPiece'
                  )
               OR (
                      @CodeType = 'SinCapsule'
                      AND @ResultType = 'Coating'
                  )
           )
        BEGIN
            SELECT 'prompt' 提示
            UNION ALL
            SELECT 'Varchar 500';

            SELECT '请选择正确的关系' prompt;
            RETURN;
        END;
        ELSE
        BEGIN
            --参数值不为空时
            --结果集ID大于条件ID时     
            IF (
               (
                   SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
               ) >
               (
                   SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @CodeType
               )
               )
                SET @sql += ' select ' + ISNULL(@InnerSelect, '') + ' INTO #Result FROM ' + @InnerSql + @WhereSql;
            --结果集ID小于条件ID时
            ELSE IF (
                    (
                        SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @ResultType
                    ) <
                    (
                        SELECT ID FROM dbo.AllQuaryPara WHERE SpType = @CodeType
                    )
                    )
                SET @sql += ' select ' + ISNULL(@InnerSelect,
                                                ''
                                               ) + ' INTO #Result FROM ' + @InnerSql + @WhereSql;

            --ELSE --结果集ID等于条件ID时

            ELSE IF (@ResultType = @CodeType) --参数值为空时
            BEGIN
                SET @sql += ' Select ' + ISNULL(@InnerSelect, '') + ' INTO #Result FROM ' + @InnerSql + @WhereSql;
                PRINT '条件=:' + @sql;
            END;
            --如果结果集是Oil，条件是空时，执行如下语句
            ELSE IF (@CodeType = 'Oil' AND @ResultType = '')
            BEGIN
                PRINT '@CodeType2: ' + @CodeType + ' @ResultType2: ' + @ResultType;
                DECLARE @sqlbk NVARCHAR(MAX) = '';
                DECLARE @sqlw NVARCHAR(MAX) = '';
                PRINT '打印黑色粒子语句';
                --黑粒子
                SET @InnerSql
                    = ' Bs_Oil Oil
        LEFT JOIN dbo.Tbl_Base_OilL9Batch OilL9Batch ON OilL9Batch.ID = Oil.L9Batch
        LEFT JOIN Tbl_Base_OilSeries OilSeries ON OilSeries.ID = Oil.Series
        LEFT JOIN Tbl_Base_BC0001 OilBC0001 ON OilBC0001.ID = Oil.BC0001
        LEFT JOIN dbo.Tbl_Base_OilAdditivesA OilAdditivesA ON OilAdditivesA.ID = Oil.AdditivesA
        LEFT JOIN Tbl_Base_OilAdditivesB OilAdditivesB ON OilAdditivesB.ID = Oil.AdditivesB
        INNER JOIN Bs_ParticalToOil ON Bs_ParticalToOil.OilID = Oil.ID
        INNER JOIN Bs_ParticalBK ParticalBK ON ParticalBK.ID = Bs_ParticalToOil.ParticalID
                                               AND PType = 2
        LEFT JOIN Tbl_Base_ParticalKettle ParticalKettle ON ParticalKettle.ID = ParticalBK.Kettle
        LEFT JOIN Tbl_Base_ParticalBE0001 ParticalBE0001BK ON ParticalBE0001BK.ID = ParticalBK.BE0001
        LEFT JOIN Tbl_Base_BC0001 CleanBC0001BK ON CleanBC0001BK.ID = ParticalBK.CleanBC0001
        LEFT JOIN Tbl_Base_BC0001 ConfigBC0001BK ON ConfigBC0001BK.ID = ParticalBK.ConfigBC0001
        LEFT JOIN Tbl_Base_BA0001 FBA0001BK ON FBA0001BK.ID = ParticalBK.FBA0001
        LEFT JOIN Tbl_Base_BA0001 CleanBA0001BK ON CleanBA0001BK.ID = ParticalBK.CleanBA0001
        LEFT JOIN Tbl_Base_BA0002 CleanBA0002BK ON CleanBA0002BK.ID = ParticalBK.CleanBA0002
        LEFT JOIN Tbl_Base_BG0001 BG0001BK ON BG0001BK.ID = ParticalBK.BG0001
        LEFT JOIN Tbl_Base_ParticalPole ParticalNole ON ParticalNole.ID = ParticalBK.Npole
        LEFT JOIN Tbl_Base_ParticalPole ParticalPole ON ParticalPole.ID = ParticalBK.Ppole
        LEFT JOIN Tbl_Base_ParticalSeries ParticalBKSeries ON ParticalBKSeries.ID = ParticalBK.Series
        LEFT JOIN Tbl_Base_BC0001_Big BC0001_BigBK ON BC0001_BigBK.ID = ParticalBK.BC0001Big  ';

                SET @InnerSelect =
                (
                    SELECT ',' + TableName + '.' + CoName + ' AS ' + TableName + CoName
                    FROM Tbl_AnsCom_DIimToTable
                    WHERE TableName_ch = '黑粒子'
                          AND IsDimBan = 0
                    ORDER BY ShowIndex
                    FOR XML PATH('')
                );

                SET @InnerSelect = SUBSTRING(@InnerSelect,
                                             2,
                                             LEN(@InnerSelect)
                                            );
                SET @InnerSelect += ',ParticalBK.Code AS ID';
                SET @sqlbk += ' Select ' + ISNULL(@InnerSelect, '') + '  FROM ' + @InnerSql + @WhereSql;

                SET @InnerSql
                    = ' Bs_Oil Oil
        LEFT JOIN dbo.Tbl_Base_OilL9Batch OilL9Batch ON OilL9Batch.ID = Oil.L9Batch
        LEFT JOIN Tbl_Base_OilSeries OilSeries ON OilSeries.ID = Oil.Series
        LEFT JOIN Tbl_Base_BC0001 OilBC0001 ON OilBC0001.ID = Oil.BC0001
        LEFT JOIN dbo.Tbl_Base_OilAdditivesA OilAdditivesA ON OilAdditivesA.ID = Oil.AdditivesA
        LEFT JOIN Tbl_Base_OilAdditivesB OilAdditivesB ON OilAdditivesB.ID = Oil.AdditivesB
        INNER JOIN Bs_ParticalToOil ON Bs_ParticalToOil.OilID = Oil.ID
        INNER JOIN Bs_ParticalW ParticalW ON ParticalW.ID = Bs_ParticalToOil.ParticalID
                                               AND PType = 1
        LEFT JOIN Tbl_Base_ParticalKettle ParticalKettle ON ParticalKettle.ID = ParticalW.Kettle
        LEFT JOIN Tbl_Base_ParticalBE0001 ParticalBE0001W ON ParticalBE0001W.ID = ParticalW.BE0001
        LEFT JOIN Tbl_Base_BC0001 CleanBC0001W ON CleanBC0001W.ID = ParticalW.CleanBC0001
        LEFT JOIN Tbl_Base_BC0001 ConfigBC0001W ON ConfigBC0001W.ID = ParticalW.ConfigBC0001
        LEFT JOIN Tbl_Base_BA0001 FBA0001W ON FBA0001W.ID = ParticalW.FBA0001
        LEFT JOIN Tbl_Base_BA0001 CleanBA0001W ON CleanBA0001W.ID = ParticalW.CleanBA0001
        LEFT JOIN Tbl_Base_BA0002 CleanBA0002W ON CleanBA0002W.ID = ParticalW.CleanBA0002
        LEFT JOIN Tbl_Base_BG0001 BG0001W ON BG0001W.ID = ParticalW.BG0001
        LEFT JOIN Tbl_Base_ParticalPole ParticalNole ON ParticalNole.ID = ParticalW.Npole
        LEFT JOIN Tbl_Base_ParticalPole ParticalPole ON ParticalPole.ID = ParticalW.Ppole
        LEFT JOIN Tbl_Base_ParticalSeries ParticalWSeries ON ParticalWSeries.ID = ParticalW.Series
        LEFT JOIN Tbl_Base_BC0001_Big BC0001_BigW ON BC0001_BigW.ID = ParticalW.BC0001Big ';
                PRINT '黑色粒子数据：' + @sqlbk;
                SET @InnerSelect =
                (
                    SELECT ',' + TableName + '.' + CoName + ' AS ' + REPLACE(TableName,
                                                                             'W',
                                                                             'BK'
                                                                            ) + CoName
                    FROM Tbl_AnsCom_DIimToTable
                    WHERE TableName_ch = '白粒子'
                          AND IsDimBan = 0
                    ORDER BY ShowIndex
                    FOR XML PATH('')
                );

                SET @InnerSelect = SUBSTRING(@InnerSelect,
                                             2,
                                             LEN(@InnerSelect)
                                            );
                SET @InnerSelect += ',ParticalW.Code AS ID';

                SET @sqlw += ' Select ' + ISNULL(@InnerSelect, '') + '  FROM ' + @InnerSql + @WhereSql;
                PRINT @sqlw;
                SET @sql += 'SELECT  * INTO #Result FROM (' + @sqlbk + 'UNION ALL' + @sqlw + ') a  ';
                PRINT '当结果集是油相时：' + @sql;

            END;



        --如果存在黑色颜料条件对应白色颜料数据集，由于不合理则需要单独处理。
        END;
    END;
    ELSE
    BEGIN
        SET @sql += ' select ' + ISNULL(@InnerSelect, '') + ' INTO #Result FROM ' + @InnerSql + @WhereSql;

    END;
    ------------------------------------------------除去一些错误的字段显示情况-----------------------------------------------   

    --除去当查询条件为黑色粒子或者黑色颜料时，油相结果里存在白色粒子的情况
    IF (
           @CodeType = 'PigmentBK'
           OR @ResultType = 'PigmentBK'
           OR @CodeType = 'ParticalBK'
           OR @ResultType = 'ParticalBK'
       )
    BEGIN
        SET @sql = REPLACE(@sql,
                           'RIGHT JOIN ParticalW ParticalW1 ON ParticalW1.ID = Oil.ParticalIDW1',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'RIGHT JOIN ParticalW ParticalW2 ON ParticalW2.ID = Oil.ParticalIDW2',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'RIGHT JOIN ParticalW ParticalW3 ON ParticalW3.ID = Oil.ParticalIDW3',
                           ' '
                          );
        SET @sql
            = REPLACE(
                         @sql,
                         'inner JOIN Bs_ParticalW ParticalW on ParticalW.ID=Bs_ParticalToOil.ParticalID and PType=1',
                         ' '
                     );
        SET @sql = REPLACE(@sql,
                           'ParticalW1.Code AS ParticalW1Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'ParticalW2.Code AS ParticalW2Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'ParticalW3.Code AS ParticalW3Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql, ', , ,', ' ');

    END;
    --除去当查询条件为白色粒子或者白色颜料时，油相结果里存在黑色粒子的情况
    IF (
           @CodeType = 'PigmentW'
           OR @ResultType = 'PigmentW'
           OR @CodeType = 'ParticalW'
           OR @ResultType = 'ParticalW'
       )
    BEGIN
        SET @sql = REPLACE(@sql,
                           'RIGHT JOIN ParticalBK ParticalBK1 ON ParticalBK1.ID = Oil.ParticalIDBK1',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'RIGHT JOIN ParticalBK ParticalBK2 ON ParticalBK2.ID = Oil.ParticalIDBK2',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'RIGHT JOIN ParticalBK ParticalBK3 ON ParticalBK3.ID = Oil.ParticalIDBK3',
                           ' '
                          );
        SET @sql
            = REPLACE(
                         @sql,
                         'inner join Bs_ParticalBK ParticalBK on ParticalBK.ID=Bs_ParticalToOil.ParticalID and PType=2',
                         ' '
                     );
        SET @sql = REPLACE(@sql,
                           'ParticalBK1.Code AS ParticalBK1Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'ParticalBK2.Code AS ParticalBK2Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'ParticalBK3.Code AS ParticalBK3Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql, ', , ,', ' ');
    END;
    --除去油相结果集里面存在多个白色或者黑色粒子的字段的情况
    IF (@ResultType = 'Oil' AND @CodeValue <> '')
    BEGIN
        IF (@ResultType = 'Oil' AND @CodeType = 'Oil')
        BEGIN
            PRINT '有Oil时，执行1';
            --SET @sql = REPLACE(@sql, 'ParticalBK1.Code AS ParticalBK1Code',
            --                   'ParticalBK.Code AS ParticalBK1Code');
            SET @sql = REPLACE(@sql,
                               'ParticalBK2.Code AS ParticalBK2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalBK3.Code AS ParticalBK3Code',
                               ' '
                              );
            --SET @sql = REPLACE(@sql, 'ParticalW1.Code AS ParticalW1Code',
            --                   'ParticalW.Code AS ParticalW1Code');
            SET @sql = REPLACE(@sql,
                               'ParticalW2.Code AS ParticalW2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW3.Code AS ParticalW3Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql, ', , ', ' ');
        END;
        ELSE IF (
                    @ResultType = 'Oil'
                    AND (
                            @CodeType <> 'ParticalBK'
                            AND @CodeType <> 'ParticalW'
                            AND @CodeType <> 'PigmentW'
                            AND @CodeType <> 'PigmentBK'
                        )
                )
        BEGIN
            PRINT '有Oil时，执行2';
            --SET @sql = REPLACE(@sql,
            --                   'ParticalBK1.Code AS ParticalBK1Code',
            --                   'ParticalBK.Code AS ParticalBK1Code');
            SET @sql = REPLACE(@sql,
                               'ParticalBK2.Code AS ParticalBK2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalBK3.Code AS ParticalBK3Code',
                               ' '
                              );
            --SET @sql = REPLACE(@sql,
            --                   'ParticalW1.Code AS ParticalW1Code',
            --                   'ParticalW.Code AS ParticalW1Code');
            SET @sql = REPLACE(@sql,
                               'ParticalW2.Code AS ParticalW2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW3.Code AS ParticalW3Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql, ', , ', ' ');
        END;
        ELSE IF (
                    @ResultType = 'Oil'
                    AND (
                            @CodeType = 'ParticalBK'
                            OR @CodeType = 'ParticalW'
                        )
                )
        BEGIN
            PRINT '有Oil时，执行3';
            SET @sql = REPLACE(@sql,
                               'ParticalBK1.Code AS ParticalBK1Code',
                               'ParticalBK.Code AS ParticalBK1Code'
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalBK2.Code AS ParticalBK2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalBK3.Code AS ParticalBK3Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW1.Code AS ParticalW1Code',
                               'ParticalW.Code AS ParticalW1Code'
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW2.Code AS ParticalW2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW3.Code AS ParticalW3Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql, ', , ', ' ');
        END;
        ELSE
        BEGIN
            PRINT '有Oil时，执行4';
            SET @sql = REPLACE(@sql,
                               'ParticalBK1.Code AS ParticalBK1Code',
                               'ParticalBK.Code AS ParticalBK1Code'
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalBK2.Code AS ParticalBK2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalBK3.Code AS ParticalBK3Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW1.Code AS ParticalW1Code',
                               'ParticalW.Code AS ParticalW1Code'
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW2.Code AS ParticalW2Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql,
                               'ParticalW3.Code AS ParticalW3Code',
                               ' '
                              );
            SET @sql = REPLACE(@sql, ', , ', ' ');
        END;

    END;

    IF (@ResultType = 'Oil' AND @CodeValue = '')
    BEGIN
        PRINT '有Oil时，执行清楚ParticalBK1.Code AS ParticalBK1Code';
        --SET @sql = REPLACE(@sql, 'ParticalBK1.Code AS ParticalBK1Code',
        --                   'ParticalBK.Code AS ParticalBK1Code');
        SET @sql = REPLACE(@sql,
                           'ParticalBK2.Code AS ParticalBK2Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'ParticalBK3.Code AS ParticalBK3Code',
                           ' '
                          );
        --SET @sql = REPLACE(@sql, 'ParticalW1.Code AS ParticalW1Code',
        --                   'ParticalW.Code AS ParticalW1Code');
        SET @sql = REPLACE(@sql,
                           'ParticalW2.Code AS ParticalW2Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql,
                           'ParticalW3.Code AS ParticalW3Code',
                           ' '
                          );
        SET @sql = REPLACE(@sql, ', , ', ' ');
    END;
    PRINT '@sql: ' + @sql;
    ------------------------------------------------------------开始执行sql-----------------------------------------------------------------------------
    IF (@OrderFields IS NULL OR @OrderFields = '')
    BEGIN
        IF (@CodeType = 'Oil' AND @ResultType = '')
            SET @OrderFields = 'ParticalBKOptDate';
        ELSE
            SET @OrderFields = @ResultType + 'OptDate';
    END;
    DECLARE @Pagesql VARCHAR(MAX)
        = '  DECLARE @totalRow int = (Select count(1) FROM #Result) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow   
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''  
  ,@AvgColumn = ''  ';
    --PRINT '打印最终sql1:  ' + @sql + @Pagesql; 

    --print ' SELECT ''n'' AS 序号' + @CoChNames + ',''ID'' As ID UNION ALL SELECT ''Varchar 500'',''Varchar 500''' + @Varchar500s
    --  -- 注销临时表
    EXEC (' SELECT ''n'' AS 序号' + @CoChNames + ',''ID'' As ID UNION ALL SELECT ''Varchar 500'',''Varchar 500''' + @Varchar500s);
    EXEC (@sql + @Pagesql);
    PRINT @sql + @Pagesql;
    --SELECT @sql + @Pagesql 

    --  print '打印最终sql:  '+@sql + @Pagesql;
    --  --PRINT @SqlName;
    -- 运行处表头
    --PRINT @Varchar500s;
    --PRINT ' SELECT ''n'' AS 序号' + @CoChNames + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s;
    --SELECT  @sql+@Pagesql
    --                   FOR
    --                     XML PATH('')   
    IF (@CodeValue <> '')
        IF (
               (
                   @CodeType = 'PigmentBK'
                   AND (
                           @ResultType = 'PigmentW'
                           OR @ResultType = 'ParticalW'
                       )
               )
               OR (
                      @CodeType = 'PigmentW'
                      AND (
                              @ResultType = 'PigmentBK'
                              OR @ResultType = 'ParticalBK'
                          )
                  )
               OR (
                      @CodeType = 'SinCapsule'
                      AND @ResultType = 'DouCapsule'
                  )
               OR (
                      @CodeType = 'SinCapsule'
                      AND @ResultType = 'TestPiece'
                  )
               OR (
                      @CodeType = 'DouCapsule'
                      AND @ResultType = 'SinCapsule'
                  )
               OR (
                      @CodeType = 'Coating'
                      AND @ResultType = 'SinCapsule'
                  )
               OR (
                      @CodeType = 'Coating'
                      AND @ResultType = 'TestPiece'
                  )
               OR (
                      @CodeType = 'SinCapsule'
                      AND @ResultType = 'Coating'
                  )
           )
        BEGIN
            DROP TABLE #temptable;
        END;

    -- 插入日志记录
    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter,
        EmpName
    )
    VALUES
    (   @EmpID,
        GETDATE(),
        'Sp_Analysister_AllQuery_List',
        '全数据查询',
        'select',
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=',
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        )
    );
END;


go

