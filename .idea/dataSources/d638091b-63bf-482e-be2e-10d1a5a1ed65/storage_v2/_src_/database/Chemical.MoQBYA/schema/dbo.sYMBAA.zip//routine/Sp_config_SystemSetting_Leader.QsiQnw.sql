CREATE PROC [dbo].[Sp_config_SystemSetting_Leader]  
@ModelName VARCHAR(50) = '仓储管理',  
@SettingName VARCHAR(50) = ''  
AS  
BEGIN  
SELECT SettingID,  
ROW_NUMBER() OVER (ORDER BY ModelName) AS n  
,ModelName  
,SettingName  
,Remark  
,SettingValue  
,CONVERT(VARCHAR(50),LogEditTime,23) AS LogEditTime  
,LogEditEmpName  
,EditType  
,CheckType  
FROM Tbl_config_SystemSetting  
WHERE ( ModelName = @ModelName  or @ModelName ='')
AND SettingName LIKE '%'+@SettingName+'%'  
ORDER BY ModelName  
END
go

