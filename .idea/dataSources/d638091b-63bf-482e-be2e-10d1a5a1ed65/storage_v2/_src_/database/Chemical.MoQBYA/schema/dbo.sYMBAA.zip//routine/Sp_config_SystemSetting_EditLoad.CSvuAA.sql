CREATE PROC [dbo].[Sp_config_SystemSetting_EditLoad]
@SettingID VARCHAR(50)=''
AS
BEGIN
SELECT SettingID
,ModelName
,SettingName
,SettingValue

FROM Tbl_config_SystemSetting
WHERE  SettingID =@SettingID
END
go

