







-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Insert_DouCapsule_LW_OutList] 
@NeedClare BIT = '1'  -- 是否需要清除原有表
AS
BEGIN
	DECLARE @columnNames  VARCHAR(MAX) = ''   -- 输出的表名段语句，根据select段决定	
	
	SET NOCOUNT ON;
	------------------- 建立临时表区域、插入数据 ---------------------------
	
	
	-- 目标结果表 ------
	 --CREATE TABLE #Output
  --   (
  --        Name VARCHAR(100) ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
  --   )
     
  --   INSERT INTO #Output(Name,BeginValue,EndValue)
  --   VALUES
  --   ('GoodRst',700,2000)      -- 好的产值等级
  --   ,('MiddleRst',500,700)    -- 中等产值等级
  --   ,('BadRst',0,500);        -- 坏的产值等级

	----------------------
	-- 维度参数表 --------
 --温度41
    CREATE TABLE #DouTemp41
     (
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     );
     INSERT into #DouTemp41(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouTemp41_Part
     WHERE istrue = 0  -- 按基础维度计算
     

        --温度8
    CREATE TABLE #DouTemp8            
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     );     
	INSERT into #DouTemp8(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouTemp8_Part
     WHERE istrue = 0  -- 按基础维度计算
     
	
	 --温度25
    CREATE TABLE #DouTemp25
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     );   
     INSERT into #DouTemp25(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouTemp25_Part
     WHERE istrue = 0  -- 按基础维度计算
     
      --转速500  
    CREATE TABLE #DouSpeed500            
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     );      
     INSERT into #DouSpeed500(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouSpeed500_Part
     WHERE istrue = 0  -- 按基础维度计算
     
      --转速400
    CREATE TABLE #DouSpeed400            
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     ); 
     INSERT into #DouSpeed400(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouSpeed400_Part
     WHERE istrue = 0  -- 按基础维度计算
     
     --胶囊固含量
    CREATE TABLE #DouJNGHL            
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     ); 
     INSERT into #DouJNGHL(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouJNGHL_Part
     WHERE istrue = 0  -- 按基础维度计算
    
         --胶囊PH
    CREATE TABLE #DouPH            
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     ); 
     INSERT into #DouPH(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouPH_Part
     WHERE istrue = 0  -- 按基础维度计算
    
     --胶囊PH温度
    CREATE TABLE #DouPhTemp            
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     ); 
     INSERT into #DouPhTemp(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimDouPhTemp_Part
     WHERE istrue = 0  -- 按基础维度计算
	
	-- 电导率
	CREATE TABLE #DDLps  
	(            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)      
     );
     INSERT into #DDLps(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimSinDDLps_Part
	 WHERE istrue = 0  -- 按基础维度计算
	
	
	---- 油项PH值
	--CREATE TABLE #YXPH  
	--(            
 --         ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
 --    );
 --    INSERT into #YXPH(ID,BeginValue,EndValue)
 --    SELECT ID,BeginValue,EndValue FROM dbo.vw_DimYXPH_Part
 --    WHERE istrue = 0  -- 按基础维度计算
	
	
	-- 粘度cp
	CREATE TABLE #NDcp   
	(            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     ); 
     INSERT into #NDcp(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimSinNDcp_Part
     WHERE istrue = 0  -- 按基础维度计算
     
     
     --油相粒径05
     CREATE TABLE #YXLJ05
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     );
     INSERT into #YXLJ05(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimYXLJ05_Part
     WHERE istrue = 0  -- 按基础维度计算
        
     
     --油相粒径09
     CREATE TABLE #YXLJ09
     (            
          ID INT ,BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)             
     );    
     INSERT into #YXLJ09(ID,BeginValue,EndValue)
     SELECT ID,BeginValue,EndValue FROM dbo.vw_DimYXLJ09_Part
     WHERE istrue = 0  -- 按基础维度计算
     --WHERE LEN(REPLACE(Name,'倍数2','')) < LEN(Name)  -- 名称中包含倍数2的，本次切分按照倍数2切分
	--------------------- 临时表建立完毕 --------------------
	
	-------------------- 计算并插入表格 ---------------------
	
	IF(@NeedClare = 1)
		TRUNCATE TABLE Tbl_DouCapsule_LW_OutList;
	
	INSERT INTO Tbl_DouCapsule_LW_OutList(DimDouYXID,
DimDouTemp41ID, DimDouTemp8ID, DimDouTemp25ID, DimDouSpeed500ID, DimDouSpeed400ID, DimDouJNGHLID, 
DimDouPHID, DimDouPhTempID, DimSinDDLpsID, DimSinNDcpID, DimYXLJ05ID, DimYXLJ09ID, Datacount, avgLW)
	SELECT SC.OilID,
	t41.ID,t8.ID,t25.ID,s500.ID,s.ID
	,jnghl.ID,jnph.ID,pht.ID,DD.ID,ND.ID,LJ05.id,LJ09.id
	,COUNT(*)
	,avg(sc.lw)
	FROM dbo.Bs_DouCapsule SC
	Left JOIN dbo.Bs_Oil oil ON SC.OilID = oil.ID
	Left JOIN #DouTemp25 t25 ON SC.Temp25 >= t25.BeginValue AND SC.Temp25 < t25.EndValue
	Left JOIN #DouTemp8 t8 ON SC.Temp8 >= t8.BeginValue AND SC.Temp8 < t8.EndValue
	Left JOIN #DouTemp41 t41 ON SC.Temp41 >= t41.BeginValue AND SC.Temp41 < t41.EndValue
	Left JOIN #DouSpeed500 s500 ON SC.Rspeed500 >= s500.BeginValue AND SC.Rspeed500 < s500.EndValue
	Left JOIN #DouSpeed400 s ON SC.Rspeed400 >= s.BeginValue AND SC.Rspeed400 < s.EndValue
	Left JOIN #DouJNGHL jnghl ON SC.SoildContent >= jnghl.BeginValue AND SC.SoildContent < jnghl.EndValue---------------
	Left JOIN #DouPH jnph ON SC.ph >= jnph.BeginValue AND SC.ph < jnph.EndValue---------------
	Left JOIN #DouPhTemp pht ON SC.PhTemp >= pht.BeginValue AND SC.PhTemp < pht.EndValue---------------
	-- 油项基本属性
	Left JOIN #DDLps DD ON oil.Conductivity >= DD.BeginValue AND oil.Conductivity < DD.EndValue
	Left JOIN #NDcp ND ON oil.Viscosity >= ND.BeginValue AND oil.Viscosity < ND.EndValue
	--Left JOIN #YXPH PH ON oil.PH >= PH.BeginValue AND oil.PH < PH.EndValue
	Left JOIN #YXLJ05 LJ05 ON oil.PSize05 >= LJ05.BeginValue AND oil.PSize05 < LJ05.EndValue
	Left JOIN #YXLJ09 LJ09 ON oil.PSize09 >= LJ09.BeginValue AND oil.PSize09 < LJ09.EndValue
	
	GROUP BY SC.OilID,t41.ID,t8.ID,t25.ID,s500.ID,s.ID
	,jnghl.ID,jnph.ID,pht.ID,DD.ID,ND.ID,LJ05.id,LJ09.id

	------------------------------------ 查询出结果表格 -------------------------------
	--SELECT 
	--dd.Name AS 电导率区间 ,t41.Name AS 温度41区间 ,t8.Name AS 温度8区间 ,t25.Name AS 温度25区间
	--,t.Datacount AS 区间总条数
	--,t.GoodRst AS 好产值条数
	--,t.MiddleRst AS 中等产值条数
	--,t.BadRst AS 坏产值条数
	--,CONVERT(decimal(18,2), (CONVERT(decimal(18,2),t.GoodRst) / CONVERT(decimal(18,2),t.Datacount)) ) AS 好产值比例
	--,CONVERT(decimal(18,2), (CONVERT(decimal(18,2),t.MiddleRst) / CONVERT(decimal(18,2),t.Datacount)) ) AS 中等产值比例
	--,CONVERT(decimal(18,2), (CONVERT(decimal(18,2),t.BadRst) / CONVERT(decimal(18,2),t.Datacount)) ) AS 坏产值比例
	--FROM T_OutputAplc t
	--LEFT JOIN dbo.vw_DimSinDDLps_Part dd ON dd.ID = t.DIMSinDDLpsID
	--LEFT JOIN dbo.vw_DimSinTemp41_Part t41 ON t41.ID = t.DIMSinTemp41ID
	--LEFT JOIN dbo.vw_DimSinTemp8_Part t8 ON t8.ID = t.DIMSinTemp8ID
	--LEFT JOIN dbo.vw_DimSinTemp25_Part t25 ON t25.ID = t.DIMSinTemp25ID
	--ORDER BY t.Datacount desc
	
	
     
	
	
END
go

