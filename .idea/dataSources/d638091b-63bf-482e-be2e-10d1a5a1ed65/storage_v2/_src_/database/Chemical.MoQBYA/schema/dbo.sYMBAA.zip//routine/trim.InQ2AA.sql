-- =============================================
--Author: 王文斌
-- Create date: 2016-06-16
-- Description:  去掉前后的空格
-- =============================================
CREATE FUNCTION [dbo].[trim]
(
@StrValue varchar(50) = ''
)
RETURNS VARCHAR(500)
AS
BEGIN	 
	RETURN ltrim(rtrim(@StrValue))

END
go

