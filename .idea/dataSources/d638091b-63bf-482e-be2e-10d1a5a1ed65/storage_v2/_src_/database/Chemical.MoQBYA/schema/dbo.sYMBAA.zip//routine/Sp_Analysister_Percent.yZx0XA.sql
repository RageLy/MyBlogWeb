

-- exec [Sp_Analysister_Stad] 'Dim7:Y:this10%DimMpCode:-1%DimMpLotCode:-1%DimMpSeries:-1%DimSDJAvg:-1%DimSDJSqt:-1%DimNhjPH:-1%DimZcjND:-1%DimMsFsjUse:-1%DimMsLpjCode:-1%DimMsLpjUse:-1%DimMsNhjType:-1%DimMsNhjUse:-1%DimMsZcjUse:-1%DimMsCapsulePH:-1%DimMsWaterType:-1%DimMsWaterPH:-1%DimMsWaterDDlps:-1%DimMsLPH:-1%DimMsOverPH:-1%DimMsOverND:-1%DimMsOverGHL:-1%DimMsOverZL:-1%DimMsNdBe:-1%DimMsGhlBe:-1%DimJsCode:-1%DimJsType:-1%DimJsNdBe:-1%DimJsGhlBe:-1%DimMsTtTemp:-1%DimMsTtSd:-1%DimMsTtGTemp:-1%DimMsTtGSd:-1%DimMsTtITOhd:-1%DimMsTtSpeed:-1%DimMsHxFpTemp1:-1%DimMsHxFpTemp2:-1%DimMsHxFpTemp3:-1%DimMsHxFpTemp4:-1%DimMsHxFpTemp5:-1%DimMsHxFpTemp6:-1%DimMsHxFpTemp7:-1%DimMsCjTemp:-1%DimMsCjSd:-1%DimMsCjSpeed:-1%DimMsCjMshd:-1%DimJsTtTemp:-1%DimJsTtSd:-1%DimJsTtSpeed:-1%DimJsTtJx:-1%DimJsCjTemp:-1%DimJsCjSpeed:-1%DimJsCjJshd:-1%DimJsDs:-1%DimMsDs:-1%DimMpTbLv:-1%DimMpFdLv:-1%DimLineSW:-1%DimScJP:-1%DimZcZK:-1%DimSYJudge:-1%DimOEDJudge:-1%Dim0minLBK:-1%Dim2minLBK:-1%Dim0minLW:-1%Dim2minLW:-1%Dim2mindetaLBK:-1%Dim2mindetaLW:-1%DimDbd:-1%DimWBdata:-1%DimQddl:-1','质检膜片批次%时间%水滴角均值%line%平均值%水滴角均值%数量','图','id','Coating',1

-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 柱图、折线图两个图形的标准分析器sp

-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_Percent]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimWelderID:-1%DimResultType:-1' ,
    @OtherCond VARCHAR(MAX) = '%出错类型%无分组%平均工作率%line%总和%总时长%数量' ,
    @Type VARCHAR(10) = '图' , -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
    @OrderFields VARCHAR(50) = 'id' ,
    @SpName VARCHAR(50) = 'WeldTime' ,
    @EmpID INT = 1 ,
                              -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '10' ,
    @XValue VARCHAR(50) = '' ,
    @DSValue VARCHAR(50) = ''
AS
    BEGIN

        ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

        SET NOCOUNT ON;

        DECLARE @SiftValue VARCHAR(MAX);
        SET @SiftValue = REPLACE(@condition, '|', ',');

        DECLARE @Usertitle VARCHAR(200) = ''; -- 标题            
        DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
        DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
        DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                
        DECLARE @ChatType VARCHAR(50) = ''; -- 图形名称                
        DECLARE @CTOC VARCHAR(50) = ''; -- @OtherCond 传入的比较方式                
        DECLARE @ErrorRecord NVARCHAR(MAX) = '';
        DECLARE @CompareType VARCHAR(50) = ''; -- 比较方式                  

        -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

        DECLARE @OtherCondTbl TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                String NVARCHAR(50)
            );

        INSERT INTO @OtherCondTbl
                    SELECT string
                    FROM   dbo.f_splitSTR(@OtherCond, '%');
        IF (   (   SELECT String
                   FROM   @OtherCondTbl
                   WHERE  ID = 1
               ) <> ''
           )
            BEGIN
                SET @Usertitle = (   SELECT String
                                     FROM   @OtherCondTbl
                                     WHERE  ID = 1
                                 );
            END;
        SET @XName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 2
                     );
        --SET @DSName = (   SELECT Name FROM dbo.vw_DimGroupWd_Part
        --              );
        SET @YName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 4
                     );


        -- OtherCond解析完毕            
        -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

        ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


        -- 时间表 时间临时表必然需要
        CREATE TABLE #time
            (
                id VARCHAR(200) ,
                beginDate DATETIME ,
                endDate DATETIME ,
                beginDate_Lp DATETIME ,
                endDate_Lp DATETIME ,
                beginDate_Ly DATETIME ,
                endDate_Ly DATETIME
            );

        -- 打印出来用于调试
        PRINT '
    CREATE TABLE #time
    (
      id VARCHAR(200) ,
      beginDate DATETIME ,
      endDate DATETIME ,
      beginDate_Lp DATETIME ,
      endDate_Lp DATETIME ,
      beginDate_Ly DATETIME ,
      endDate_Ly DATETIME
    )
    '   ;

        -- 如果有其它需要用 #时间表的必须在这里添加

        DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
        DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
        DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
        DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
        DECLARE @NumSql VARCHAR(1000); -- 用于拼接@Sql中 指标计算方式的Sql语句            
        DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句



        -- 处理维度临时表
        CREATE TABLE #Dims
            (
                DimName VARCHAR(50) ,
                DimValues VARCHAR(MAX) ,
                ChName VARCHAR(50) ,
                Isneed VARCHAR(50) ,
                DimOrdersql VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                isrange VARCHAR(50)
            );

        EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue ,
                                        @XName = @XName ,
                                        @DsName = @DSName;



        -- 拼接创建维度临时表的语句

        IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @YName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'Y' ,
                                   '' ,
                                   AtYSql ,
                                   IsRange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @YName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
            END;
        ELSE
            BEGIN
                UPDATE #Dims
                SET    Isneed = 'Y'
                WHERE  ChName = @YName;
                UPDATE #Dims
                SET    Isneed = 'ND'
                WHERE  ChName = '顺序维度选择';
                UPDATE #Dims
                SET    Isneed = 'ND'
                WHERE  ChName = '分组维度';
            END;
        --SELECT *
        --FROM   #Dims;
        SET @DSName = (   SELECT Name_ch
                          FROM   dbo.Tbl_AnsCom_DIimToTable
                          WHERE  ID = (   SELECT DimValues
                                          FROM   #Dims
                                          WHERE  ChName = '分组维度'
                                      )
                      );
        SET @sql += ISNULL(
                        (   SELECT 'CREATE TABLE #' + DimName
                                   +
                                -- 非范围维度类型3列
                                CASE WHEN isrange = 0 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                                     -- 范围维度类型5列
                                     WHEN isrange = 1 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'
                                END
                            FROM   #Dims
                            WHERE  Isneed <> 'ND'
                            FOR XML PATH('')
                        ) ,
                        ''
                          );
        --PRINT @sql
        DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
        -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析

        -- 用 Dims 临时表拼接需要解析的 维度字符串
        SET @NeedSiftvalue = ISNULL(
                                 (   SELECT '%' + DimName + ':' + DimValues
                                     FROM   #Dims
                                     WHERE  Isneed <> 'ND'
                                     FOR XML PATH('')
                                 ) ,
                                 ''
                                   );



        -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
        SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                      'Dim7:'
                                      + dbo.GetDimValue(@SiftValue, 'Dim7')
                                      + @NeedSiftvalue
                                  ELSE
                                      SUBSTRING(
                                                   @NeedSiftvalue ,
                                                   2 ,
                                                   LEN(@NeedSiftvalue)
                                               )
                             END;

        -- 解析维度
        SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''
                    + @NeedSiftvalue + ''', @EmpID = '
                    + CAST(@EmpID AS VARCHAR(50)) + ';';

        DECLARE @Ycolumn VARCHAR(200) = ISNULL(
                                            (   SELECT DimYsql
                                                FROM   #Dims
                                                WHERE  ChName = @YName
                                            ) ,
                                            ''
                                              ); -- Y轴在本表上面的列名

        ------------------------------------------------------------维度选择-----------------------------------------------------

        CREATE TABLE #TempWD
            (
                Id INT IDENTITY(1, 1) NOT NULL ,
                TableName NVARCHAR(50) ,
                DimName NVARCHAR(50),
				Name_Ch NVARCHAR(50)
            );

        DECLARE @sqltemp NVARCHAR(MAX) = '';

        SET @sqltemp += (   SELECT 'INSERT INTO #TempWD SELECT tableName,CoName,Name   from vw_'
                                   + DimName + '_part  where ID in ('
                                   +   (   SELECT DimValues
                                           FROM   #Dims
                                           WHERE  ChName = '顺序维度选择'
                                       ) + ')'
                            FROM   #Dims
                            WHERE  ChName = '顺序维度选择'
                        );

        EXEC ( @sqltemp );

		--SELECT * FROM #TempWD
		INSERT INTO #TempWD (   TableName ,
		                        DimName,
								Name_Ch
		                    )
		SELECT TableName,CoName,Name_ch FROM dbo.Tbl_AnsCom_DIimToTable WHERE Name_ch=@YName AND SpType LIKE '%'+@SpName+'%'
        PRINT @sqltemp;
        --SELECT * FROM #Dims
        -------------------------------------------------------------------数据源配置---------------------------------------------------
        DECLARE @TimeName VARCHAR(50); -- 用于判断时间的标志
        IF (   @XName = '时间'
               OR @XName = '无横轴'
           )
            BEGIN
                SET @TimeName = (   SELECT MainTable + '.OptDate'
                                    FROM   dbo.Tbl_AnsCom_DIimToTable
                                    WHERE  DimNum = (   SELECT DimName
                                                        FROM   #Dims
                                                        WHERE  ChName = @YName
                                                    )
                                );
                IF (   @TimeName = ''
                       OR @TimeName IS NULL
                   )
                    SET @TimeName = (   SELECT TimeName
                                        FROM   Tbl_AnsCom_AnaSpConfig
                                        WHERE  SpName = @SpName
                                    );
            END;
        ELSE
            SET @TimeName = (   SELECT MainTable + '.OptDate'
                                FROM   dbo.Tbl_AnsCom_DIimToTable
                                WHERE  DimNum = (   SELECT DimName
                                                    FROM   #Dims
                                                    WHERE  ChName = @XName
                                                )
                            );

        --PRINT '时间配置字段: '+@TimeName
        IF (   @TimeName = ''
               OR @TimeName IS NULL
           )
            BEGIN
                SET @TimeName = (   SELECT TimeName
                                    FROM   Tbl_AnsCom_AnaSpConfig
                                    WHERE  SpName = @SpName
                                );
            END;


        IF (   @TimeName = ''
               OR @TimeName IS NULL
           )
            BEGIN
                SET @ErrorRecord += '查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '
                                    + @SpName + '为空,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_Percent' , -- SpName - nvarchar(50)
                           @ErrorRecord ,             -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister @condition=''' + @condition
                           + ''',@OtherCond=''' + @OtherCond + ''',@Type='''
                           + @Type + ''',@SpName''' + @SpName
                           + ''',@EmpID=''' + CAST(@EmpID AS NVARCHAR(2))
                           + '''',
                           GETDATE()                  -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;

        DECLARE @GroupCode NVARCHAR(50) = '';
        SET @GroupCode += (   SELECT TableName + '.' + CoName
                              FROM   dbo.Tbl_AnsCom_DIimToTable
                              WHERE  Name_ch = @DSName
                                     AND SpType LIKE '%' + @SpName + '%'
                          );
        DECLARE @selectSql NVARCHAR(MAX) = '';
        SET @selectSql += (   SELECT TableName + '.' + DimName + ','
                              FROM   #TempWD
                              FOR XML PATH('')
                          );
        SET @selectSql = LEFT(@selectSql, LEN(@selectSql) - 1);
        DECLARE @DataSourceSql NVARCHAR(MAX) = '';
        SET @DataSourceSql += 'select ' + @GroupCode + ',' + @selectSql
                              + ' INTO   #tempTb from '
                              +   (   SELECT JoinTables + CHAR(10)
                                             + BaseTable
                                      FROM   Tbl_AnsCom_AnaSpConfig
                                      WHERE  SpName = @SpName
                                  );

        SET @sql += @DataSourceSql;
        -- 时间维表一定需要 放在可能会取到时间的表之后 
        IF ( CHARINDEX('Dim7', @SiftValue) <> 0 )
            SET @DataSourceSql += ' INNER JOIN #time t on ' + @TimeName
                                  + ' >= t.beginDate and ' + @TimeName
                                  + ' <= t.endDate';

        -- 临时存储拼接的SQL语句
        DECLARE @sql1 VARCHAR(MAX) = '';

        -- 将INNER JOIN 维度临时表段拼接起来
        SET @sql1 = (   SELECT ' INNER JOIN #' + DimName + ' AS ' + DimName
                               + ' on '
                               +
                            -- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
                            CASE WHEN isrange = 1 THEN
                                     DimName + '.BeginValue <= ' + DimYsql
                                     + ' AND ' + DimName + '.EndValue > '
                                     + DimYsql
                                 -- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
                                 ELSE DimName + '.ID = ' + DimYsql
                            END
                        FROM   #Dims
                        WHERE  Isneed <> 'ND'
                               AND Isneed <> 'X'
                               AND Isneed <> 'Y'
                        FOR XML PATH('')
                    );

        -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
        SET @sql1 = REPLACE(REPLACE(@sql1, '&lt;', '<'), '&gt;', '>');

        -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'

        SET @sql += ISNULL(@sql1, '');

        SET @sql += ' WHERE ' + @Ycolumn + ' IS NOT NULL ';
        PRINT @sql;
        -----------	-------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
        DECLARE @Counti INT = 1;
        DECLARE @Middlesql NVARCHAR(MAX) = '';

        DECLARE @CreateTable NVARCHAR(500) = 'Create table #Result(PercentValue decimal(18,4),DimX NVARCHAR(50),GroupValue NVARCHAR(50))';
        DECLARE @WdSelectName_ch NVARCHAR(20) = '';
		DECLARE @WdSelect NVARCHAR(20) = '';
        WHILE ( @Counti <= (   SELECT COUNT(*)
                               FROM   #TempWD
                           )
              )
            BEGIN
                SET @WdSelectName_ch = (   SELECT Name_Ch
                                    FROM   #TempWD
                                    WHERE  Id = @Counti
                                );
								  SET @WdSelect = (   SELECT  DimName
                                    FROM   #TempWD
                                    WHERE  Id = @Counti
                                );
                SET @Middlesql += 'insert into #Result SELECT 
               CONVERT(FLOAT, t.nindex) / t.CountValue * 100
                 PercentValue ,''' +    @WdSelectName_ch + ''' WdName ,GroupValue 
				 FROM  (   SELECT ROW_NUMBER() OVER ( PARTITION BY CountValue
                                      ORDER BY b.WDValue
                                    ) nindex ,WDValue ,c.CountValue
           FROM   (   SELECT DISTINCT ' + @WdSelect
                                  + ' WDValue
                      FROM   #tempTb
                      WHERE  ' + @WdSelect
                                  + ' IS NOT NULL
                  ) b
                  CROSS JOIN (   SELECT COUNT(DISTINCT ' + @WdSelect
                                  + ') CountValue
                                 FROM   #tempTb
                                 WHERE  ' + @WdSelect
                                  + ' IS NOT NULL
                             ) c
       ) t
       RIGHT JOIN (   SELECT DISTINCT ' + @WdSelect
                                  + ' WDValue ,
                             Code GroupValue
                      FROM   #tempTb
                      WHERE  ' + @WdSelect
                                  + ' IS NOT NULL
                  ) x ON x.WDValue = t.WDValue' + CHAR(10);

                SET @Counti += 1;
            END;

        DECLARE @ProduceSql NVARCHAR(MAX) = '';

        DECLARE @wheresql NVARCHAR(200) = '';
        SET @wheresql += 'declare @sql NVARCHAR(200)=(select DISTINCT GroupValue+'','' from #result FOR XML PATH(''''))'
                        + CHAR(10);
        SET @wheresql += 'SET @sql=LEFT(@sql,LEN(@sql)-1)' + CHAR(10);
        SET @ProduceSql += 'exec(''SELECT * into #result_final FROM #result AS P PIVOT 
(
    max(PercentValue) FOR 
    p.GroupValue IN (''+@sql+'')
) AS T select #result_final.* from #result_final left join #tempWd on Name_ch=DimX order by Id'') '+CHAR(10);


        --    SELECT '  CREATE TABLE #time
        --(
        --  id VARCHAR(200) ,
        --  beginDate DATETIME ,
        --  endDate DATETIME ,
        --  beginDate_Lp DATETIME ,
        --  endDate_Lp DATETIME ,
        --  beginDate_Ly DATETIME ,
        --  endDate_Ly DATETIME
        --)'+ @sql+@CreateTable + @Middlesql+@wheresql+@ProduceSql;





        EXEC ( @sql + @CreateTable + @Middlesql + @wheresql + @ProduceSql );
        ---------------------------------------------自建标题---------------------------------------------------

        DECLARE @t VARCHAR(100);

        -- 按是否需要来拼接要出标题的 维度            
        SET @t = '#time';
        IF (   @Usertitle = ''
               OR @Usertitle IS NULL
           )
            BEGIN
                DECLARE @TimeStr NVARCHAR(100) = (   SELECT dbo.GetTimeName(
                                                                               beginDate ,
                                                                               endDate
                                                                           )
                                                            + ','
                                                     FROM   #time
                                                     FOR XML PATH('')
                                                 );
                SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1);
                IF (   (   SELECT COUNT(*)
                           FROM   #time
                       ) > 5
                   )
                    BEGIN
                        SET @TimeStr = (   SELECT TOP 5 dbo.GetTimeName(
                                                                           beginDate ,
                                                                           endDate
                                                                       )
                                                        + ','
                                           FROM   #time
                                           FOR XML PATH('')
                                       );
                        SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1)
                                       + '...';
                    END;
                SET @Usertitle = @TimeStr + ' [' + @XName + ']在[' + @DSName
                                 + ']上的[百分比分析]';
                IF (   (   SELECT COUNT(*)
                           FROM   #Dims
                           WHERE  Isneed = 'F'
                       ) <> 0
                   )
                    BEGIN
                        DECLARE @WDFilter NVARCHAR(500) = (   SELECT '['
                                                                     + ChName
                                                                     + '],'
                                                              FROM   #Dims
                                                              WHERE  Isneed = 'F'
                                                              FOR XML PATH('')
                                                          );
                        SET @WDFilter = ',另筛选'
                                        + LEFT(@WDFilter, LEN(@WDFilter) - 1);
                        SET @Usertitle += @WDFilter;
                    END;
            END;

        EXEC Sp_Com_Get_ChtTitle_2Y @TitleNames = @t ,
                                    @EndStrTitle = @Usertitle ,
                                    @YName = '维度位置百分比' ,
                                    @Unit = '' ,
                                    @XName = '维度名称' ,
                                    @YMax = '' ,
                                    @YMin = '';
        ---------------------------------------

        DROP TABLE #TempWD;
        DROP TABLE #time;
        DROP TABLE #Dims;
        -- 插入日志记录
        INSERT INTO Tbl_Log_AnaUseLog (   EmpID ,
                                          EmpName ,
                                          freshTime ,
                                          spName ,
                                          AnaName ,
                                          siftvalue ,
                                          OherParemeter
                                      )
        VALUES ( @EmpID ,
                 (   SELECT EmpName
                     FROM   Tbl_Com_Employee
                     WHERE  EmpID = @EmpID
                 ) ,
                 GETDATE(),
                 'Sp_Analysister_Percent' ,
                 '' + @SpName + '百分比',
                 @condition ,
                 '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='
                 + @OtherCond
               );


    END;
go

