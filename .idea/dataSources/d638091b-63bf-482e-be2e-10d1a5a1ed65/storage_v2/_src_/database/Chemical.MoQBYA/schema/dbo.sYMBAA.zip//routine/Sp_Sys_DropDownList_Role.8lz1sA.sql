-- =============================================  
-- Author:  曹乐平  
-- Create date: 2014-06-24  
-- Description: 角色下拉  
-- =============================================  
create PROCEDURE [dbo].[Sp_Sys_DropDownList_Role]  
AS  
BEGIN  
 select          
    0 as  ID  
    ,'请选择' as Name         
    union all          
    select          
    RoleID,          
    RoleName          
    from dbo.Tbl_Sys_Role  
END
go

