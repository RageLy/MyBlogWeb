-- =============================================  
-- Description: <获取角色的所有权限>  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_GetRoleAuthList]  
 @RoleID varchar(50) = '',  
 @webconfig VARCHAR(500)=''  
AS  
BEGIN  
 SET NOCOUNT ON;  
 SELECT a.FormID,a.MenuID,a.AuthLevel from Tbl_Sys_Tactics a   
 inner join Tbl_Sys_RoleTactics b on a.TacticsID=b.TacticsID  
 inner join Tbl_Sys_Role c on b.RoleID = c.RoleID   
 where c.RoleID=@RoleID and a.MenuID is not NULL AND a.WebConfig =@webconfig AND b.WebConfig =@webconfig  
END
go

