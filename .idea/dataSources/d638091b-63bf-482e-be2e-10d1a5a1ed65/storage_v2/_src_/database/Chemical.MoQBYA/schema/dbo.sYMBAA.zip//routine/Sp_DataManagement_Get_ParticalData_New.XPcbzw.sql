



-- =============================================
-- Author:		白冰
-- Create date: 2016-06-06
-- Description:	获取数据库中关于某特定ID的粒子数据，便于在Web展现
-- =============================================
CREATE PROCEDURE [dbo].[Sp_DataManagement_Get_ParticalData_New]
	@ID NVARCHAR(50) = ''
AS
BEGIN
	
	SET NOCOUNT ON
	
	IF @ID IS NOT NULL AND LEN(@ID) <> 0
	BEGIN
		SELECT 
		Code
		 ,CONVERT(NVARCHAR(50), OptDate, 23) AS OptDate
         , PType
         , Series
         , Class
         , Kettle
         , GrindPress
         , GrindTimeB
         , GrindTimeE
         , GrindOutPut
         , CLTemp10MIN
         , CLTemp20MIN
         , CLTemp30MIN
         , CLTemp60MIN
         , CLTemp90MIN
         , CLTemp120MIN
         , LQTemp10MIN
         , LQTemp20MIN
         , LQTemp30MIN
         , LQTemp60MIN
         , LQTemp90MIN
         , LQTemp120MIN
         , GHL
         , PigmentCode
         , Remark
		FROM dbo.Bs_ParticalSp
		WHERE ID=@ID
	END
		
END
go

