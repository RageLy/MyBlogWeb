-- =============================================  
-- Description: 网站用户登录存储过程  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_UserLogin]  
 @UserName varchar(50)='123321',  
 @Password varchar(50)='40BD001563085FC35165329EA1FF5C5ECBDBBEEF',  
 @webconfig varchar(500) =''  
AS  
BEGIN  
 SET NOCOUNT ON;  
 declare @countUser int =0;  
  
 select @countUser = COUNT(0) from dbo.Tbl_Sys_User where UserAccount=@UserName and UserPassword=@Password;  
 if(@countUser>0)  
 begin  
  select '0';  
  --查询所对应角色列表  
  select e.RoleID [RoleID],e.RoleName,e.QueryRange,e.CanSeePhone   
  FROM Tbl_Sys_Role AS e  
  left join Tbl_Sys_UserRoleRelation d on e.RoleID=d.RoleID   
  LEFT JOIN Tbl_Sys_User AS a ON d.UserID=a.UserID  
  where UserAccount=@UserName;  
  
  --查询出对应的登录ID,店铺/客户信息  
  select a.UserID,UserAccount,b.EmpID,b.EmpName,e.RoleName,e.RoleID--,c.DeptName,c.ProjectID   
  from dbo.Tbl_Sys_User a  
  left join Tbl_Com_Employee b on a.UserID=b.UserId  
 -- left join Tbl_Com_Dept c on c.DeptID=b.DeptID  
  left join Tbl_Sys_UserRoleRelation d on d.UserID=a.UserID  
  left join Tbl_Sys_Role e on e.RoleID=d.RoleID  
   where UserAccount=@UserName  
    
  select a.UserID,d.MenuID,d.FormID,d.AuthLevel from Tbl_Sys_User e  
  left join Tbl_Com_Employee a on a.UserID=e.UserID  
  left join Tbl_Sys_UserRoleRelation b on b.UserID=a.UserID  
  left join Tbl_Sys_RoleTactics c on c.RoleID=b.RoleID  
  left join Tbl_Sys_Tactics d on d.TacticsID=c.TacticsID    
  where UserAccount=@UserName AND c.WebConfig =@webconfig AND d.WebConfig =@webconfig  
    
 end  
 else  
 begin  
  --查询出相关错误  
  select @countUser = COUNT(0) from dbo.Tbl_Sys_User where UserAccount=@UserName  
  if(@countUser>0)  
   select '密码错误！';  
  else  
   select '用户名不存在！';  
 end  
END
go

