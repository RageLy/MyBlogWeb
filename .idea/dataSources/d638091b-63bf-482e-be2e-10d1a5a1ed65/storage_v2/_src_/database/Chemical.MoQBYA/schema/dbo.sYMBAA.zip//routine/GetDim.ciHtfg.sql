
-- =============================================
-- Author:		<柳燕杰>
-- alter date: <2012-07-10>
-- Description:	<根据维度名称在字符串中获取相应的维度>
-- =============================================
CREATE function [dbo].[GetDim](
@SiftValue   varchar(Max),   --待分拆的字符串
@DimName varchar(500)     --数据分隔符
)returns @Result table(string varchar(max))
as
begin
	if (@DimName='Dim7_Patrol')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_Patrol%'
	end
	else if (@DimName='Dim7_PatrolDate')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_PatrolDate%'
	end
	else if (@DimName='Dim7_GetConnectTeam')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_GetConnectTeam%'
	end
	else if (@DimName='Dim7_GetEventdispose2')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_GetEventdispose2%'
	end
	else if (@DimName='Dim7_GetEventdispose')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_GetEventdispose%'
	end
	else if (@DimName='Dim7_GetConnectTeam2')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_GetConnectTeam2%'
	end
	else if (@DimName='Dim7_CheckDate')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_CheckDate%'
	end
	else if (@DimName='Dim7_JudgeTime')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_JudgeTime%'
	end
  else if (@DimName='Dim7_JudgeTime')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_JudgeTime%'
	end
	else if(@DimName ='Dim7_ContractBegin')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_ContractBegin%'
	end
	else if(@DimName ='Dim7_ContractEnd')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7_ContractEnd%'
	end
	else if(@DimName ='Dim7')
	begin
	 insert into @Result
	 select String from dbo.Split(@SiftValue,'%') where String like 'Dim7%'
	end
	else
	begin
		insert into @Result
		select convert(varchar(500),x.string) 
		from dbo.Split(REPLACE(
		(
			select String
			from dbo.Split(@SiftValue,'%') 
			where String like @DimName+'%' and SUBSTRING(String,LEN(@DimName)+1,1) = ':'
		) 
		,@DimName+':',''),',') x
		where x.string is not null and  x.string !=''
	end
	return
end
go

