-- =============================================  
-- Author:  杨艺  
-- Create date: 2014-10-20  
-- Description: 综合报表_新保综合报表  
-- =============================================  
CREATE PROCEDURE [dbo].[SP_Syn_Report_NewInsure]   
  
@Condition varchar(max)=''                               
,@OrderFields varchar(100) = ''                                
,@Type NVARCHAR(10) = '销售顾问' -- 途径、车系、保险公司、销售顾问、合计  
AS  
BEGIN  
  
-- 默认值   
IF (@Condition = '')  
BEGIN  
 SET @Condition = 'Dim7:MRL:0%Dim4:1000%Dim20:1000'  
END  
  
IF (@OrderFields = '')  
BEGIN  
 SET @OrderFields = ''  
END  
  
  
  
-- 时间表  Dim7                                                                                                                          
CREATE TABLE #time                                                                                                                           
(                                                                                                                                      
 id               VARCHAR(500)                                                                                                                                              
 ,beginDate      DATETIME                                                                                                                                                     
 ,endDate        DATETIME                                                                                                                                 
 ,beginDate_Lp   DATETIME                                                                                                                                                     
 ,endDate_Lp     DATETIME                                                                                                                                 
 ,beginDate_Ly   DATETIME                                                                 
 ,endDate_Ly     DATETIME                                                        
);                                                                               
                                                        
-- 车系  Dim4                                                                                                            
create table #CarSeries                                                                                                           
(                                                                                                          
 VWID INT                                                                                                          
 ,[ID] INT                                                                                                          
 ,Name VARCHAR(500) DEFAULT ''                                                                                                          
);                                                                     
                      
                   
--Dim20 #SaleChannel                                  
create table #SaleChannel                                             
(                        
 VWID INT                                                                                                    
 ,[ID] INT                                                                                                   
 ,Name VARCHAR(500) DEFAULT ''                                                                                                    
);     
  
  
  
--解析维度数据                                                     
exec [dbo].[Sp_Com_Getdimensions] @SIFtValue = @Condition     
  
-- 同比环比时间临时表  
CREATE TABLE #lplyTime  
(  
 ltype VARCHAR(10),  
 BeginDate DATETIME,  
 EndDate DATETIME  
)  
  
-- 保险数据临时表  
CREATE TABLE #TempData  
(  
 id INT IDENTITY,  
 ltype VARCHAR(5),  
 car INT,  
 channel INT,  
 Insure INT,  
 Emp INT,  
 cCount INT,  
 newInsureFee DECIMAL(18,2),  
 IsBusInsure INT,  
 SaleManID INT  
   
)  
  
-- 最终结果数据  
CREATE TABLE #Result  
(  
 cType NVARCHAR(500), -- 名称  
 curCount INT, -- 当期台次  
 lyCount DECIMAL(18,2), -- 环比台次  
 lpCount DECIMAL(18,2), -- 同比台次  
 curNewInsureFee DECIMAL(18,2), -- 当期手续费  
 lyNewInsureFee DECIMAL(18,2), -- 环比手续费  
 lpNewInsureFee DECIMAL(18,2), -- 同比手续费  
 newInsureFeeGp decimal(18,2), -- 手续费组内占比  
 lyGrown decimal(18,2), -- 手续费同增  
 lpGrown decimal(18,2), -- 手续费环增  
 curNewInsurePercent DECIMAL(18,2), -- 新保台次占比  
 lyNewInsurePercent DECIMAL(18,2), -- 新保占比环增  
 lpNewInsurePercent DECIMAL(18,2), -- 新保占比同增  
 curBusInsure varchar(10),  -- 当期商业险渗透率  
 lyBusInsure varchar(10),  -- 环比商业险渗透率  
 lpBusInsure varchar(10),  -- 同比商业险渗透率  
)  
  
-- 排序结果集  
CREATE TABLE #ResultOrder  
(  
 id INT,  
 cType NVARCHAR(500), -- 名称  
 curCount INT, -- 当期台次  
 lyCount DECIMAL(18,2), -- 环比台次  
 lpCount DECIMAL(18,2), -- 同比台次  
 curNewInsureFee DECIMAL(18,2), -- 当期手续费  
 lyNewInsureFee DECIMAL(18,2), -- 环比手续费  
 lpNewInsureFee DECIMAL(18,2), -- 同比手续费  
 newInsureFeeGp decimal(18,2), -- 手续费组内占比  
 lyGrown decimal(18,2), -- 手续费同增  
 lpGrown decimal(18,2), -- 手续费环增  
 curNewInsurePercent DECIMAL(18,2), -- 新保台次占比  
 lyNewInsurePercent DECIMAL(18,2), -- 新保占比环增  
 lpNewInsurePercent DECIMAL(18,2), -- 新保占比同增  
 curBusInsure varchar(10),  -- 当期商业险渗透率  
 lyBusInsure varchar(10),  -- 环比商业险渗透率  
 lpBusInsure varchar(10),  -- 同比商业险渗透率  
)  
  
CREATE TABLE #ResultSales  
(  
 ltype   VARCHAR(10) NULL,  
 saleChannelID INT NULL,  
 scName  NVARCHAR(50),  
 carSeriesID  INT NULL,  
 carName  NVARCHAR(50),  
 EmpID   INT NULL,  
 EmpName  NVARCHAR(50)  
   
)  
  
-- 得到环比同比时间表  
INSERT #lplyTime  ( ltype ,BeginDate ,EndDate )  
SELECT 'cur',BeginDate,endDate FROM #time  
UNION ALL  
SELECT 'ly',beginDate_Lp,endDate_Lp FROM #time  
UNION ALL  
SELECT 'lp',beginDate_Ly,endDate_Ly FROM #time  
  
  
--SELECT * FROM #lplytime  
--SELECT * FROM #CarSeries  
--SELECT * FROM #SaleChannel  
--RETURN  
  
  
          
  
DECLARE @CurSaleCount INT -- 当期销售数量  
,  @LpSaleCount INT -- 环比销售数量  
,  @LySaleCount INT -- 同比销售数量  
  
SELECT @CurSaleCount = SUM(CASE WHEN t.ltype = 'cur' THEN 1 ELSE 0 END),  
    @LpSaleCount = SUM(CASE WHEN t.ltype = 'lp' THEN 1 ELSE 0 END),  
    @LySaleCount = SUM(CASE WHEN t.ltype = 'ly' THEN 1 ELSE 0 END)  
FROM dbo.Tbl_Sales_CarSales AS css  
LEFT JOIN dbo.Tbl_Base_Car bc ON css.FrameNum = bc.FrameNum  
INNER JOIN #lplyTime AS t ON css.CarSalesTime BETWEEN t.beginDate AND t.endDate  
INNER JOIN #CarSeries AS cs ON ISNULL(bc.CarSeriesID,0) = cs.ID  
INNER JOIN #SaleChannel AS sch ON ISNULL(css.SaleChannelID,0) = sch.ID  
  
-- 统计各分组的销售数据  
INSERT #ResultSales  ( ltype ,saleChannelID ,scName ,carSeriesID,carName ,EmpID ,EmpName )  
SELECT t.ltype,css.SaleChannelID ,scName.Name,bc.CarSeriesID,car.Name,css.EmpID,e.EmpName  
FROM dbo.Tbl_Sales_CarSales AS css  
LEFT JOIN dbo.Tbl_Base_Car bc ON css.FrameNum = bc.FrameNum  
INNER JOIN #lplyTime AS t ON css.CarSalesTime BETWEEN t.beginDate AND t.endDate  
INNER JOIN #CarSeries AS cs ON ISNULL(bc.CarSeriesID,0) = cs.ID  
INNER JOIN #SaleChannel AS sch ON ISNULL(css.SaleChannelID,0) = sch.ID  
LEFT JOIN dbo.Tbl_Com_Employee e ON e.EmpID = css.EmpID  
LEFT JOIN dbo.Tbl_Base_CarSeries car ON cs.ID = car.CarSeriesID  
LEFT JOIN dbo.Tbl_Base_SaleChannel scName ON sch.ID = scName.SaleChannelID  
  
-- 得到计算所需要的数据，再根据转入的TYPE进行具体的分组聚合计算  
INSERT #TempData  ( ltype ,car ,channel ,Insure ,Emp ,cCount ,newInsureFee ,IsBusInsure, SaleManID)  
  
SELECT   
 t.ltype AS ltype,  
 cs.ID AS car,  
 sch.ID AS channel,  
 si.InsurerID AS Insure,  
 si.EmpID AS Emp,  
 1 AS cCount,  
 ISNULL(si.BusInsureAmount,0) * ISNULL(si.BusInsureRate,0)   
  + ISNULL(si.TrafficInsureAmount,0) * ISNULL(si.TrafficInsureRate,0) AS newInsureFee,  
    CASE WHEN ISNULL(si.BusInsureAmount,0) > 0 THEN 1 ELSE 0 END AS IsBusInsure,  
    css.EmpID  
   
FROM dbo.Tbl_Sales_Insure AS si   
LEFT JOIN dbo.Tbl_Sales_CarSales css ON si.FrameNum = css.FrameNum  
LEFT JOIN dbo.Tbl_Base_Car bc ON si.FrameNum = bc.FrameNum  
INNER JOIN #lplyTime AS t ON si.[Date] BETWEEN t.beginDate AND t.endDate  
INNER JOIN #CarSeries AS cs ON ISNULL(bc.CarSeriesID,0) = cs.ID  
INNER JOIN #SaleChannel AS sch ON ISNULL(css.SaleChannelID,0) = sch.ID  
  
-- 得到组内所有手续费用总和  
DECLARE @curTotalInsureFee DECIMAL(18,2)  
,  @lyTotalInsureFee DECIMAL(18,2)  
,  @lpTotalInsureFee DECIMAL(18,2)  
  
SELECT @curTotalInsureFee = SUM(ISNULL(newInsureFee,0)) FROM #TempData WHERE ltype = 'cur'  
SELECT @lpTotalInsureFee = SUM(ISNULL(newInsureFee,0)) FROM #TempData WHERE ltype = 'lp'  
SELECT @lyTotalInsureFee = SUM(ISNULL(newInsureFee,0)) FROM #TempData WHERE ltype = 'ly'  
  
  
--SELECT * FROM #TempData  
  
IF (@Type = '途径')  
BEGIN  
   
 INSERT #Result ( cType ,curCount ,lyCount ,lpCount ,curNewInsureFee ,lyNewInsureFee ,lpNewInsureFee ,curBusInsure ,lyBusInsure ,lpBusInsure )  
 SELECT   
  ISNULL(sc.Name,'未知渠道')  
  -- 台次  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00  
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
   
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
    
  -- 手续费用  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
    
  -- 商业险渗透率  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND scName = sc.Name)),0) * 100 AS DECIMAL(18,2))  
   
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND scName = sc.Name)),0) * 100 AS DECIMAL(18,2)) -   
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly' AND scName = sc.Name)),0) * 100 AS DECIMAL(18,2))  
    
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND scName = sc.Name)),0) * 100 AS DECIMAL(18,2)) -   
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp' AND scName = sc.Name)),0) * 100 AS DECIMAL(18,2))  
 FROM #TempData t LEFT JOIN dbo.Tbl_Base_SaleChannel sc ON t.channel = sc.SaleChannelID  
 --WHERE sc.Name IS NOT NULL  
 GROUP BY sc.Name  
   
END  
ELSE IF (@Type = '车系')  
BEGIN  
  
 INSERT #Result ( cType ,curCount ,lyCount ,lpCount ,curNewInsureFee ,lyNewInsureFee ,lpNewInsureFee, newInsureFeeGp,lyGrown,lpGrown ,curBusInsure ,lyBusInsure ,lpBusInsure )  
  
 SELECT   
  ISNULL(cs.Name,'未知车系')  
  -- 台次  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
  -- 手续费用  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)  
   
  -- 手续费同比  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
    
  -- 手续费环比  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
   
  -- 手续费组内占比  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@curTotalInsureFee),0) * 100 AS DECIMAL(18,2))  
  -- 手续费组内占比同增  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@curTotalInsureFee),0) * 100 AS DECIMAL(18,2)) -  
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2))  / NULLIF(ABS(@lpTotalInsureFee),0) * 100 AS DECIMAL(18,2))  
  -- 手续费组内占比环增  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@curTotalInsureFee),0) * 100 AS DECIMAL(18,2)) -  
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@lyTotalInsureFee),0) * 100 AS DECIMAL(18,2))  
    
    
  -- 商业险  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND carName = cs.Name)),0) * 100 AS DECIMAL(18,2))  
   
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND carName = cs.Name)),0) * 100 AS DECIMAL(18,2)) -  
    
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly' AND carName = cs.Name)),0) * 100 AS DECIMAL(18,2))  
    
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND carName = cs.Name)),0) * 100 AS DECIMAL(18,2)) -  
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp' AND carName = cs.Name)),0) * 100 AS DECIMAL(18,2))  
    
 FROM #TempData t LEFT JOIN dbo.Tbl_Base_CarSeries cs ON t.car = cs.CarSeriesID  
 --WHERE cs.Name IS NOT NULL  
 GROUP BY cs.Name  
   
END  
ELSE IF (@Type = '保险公司')  
BEGIN  
   
 DECLARE @curCount INT  
   ,@lyCount INT  
   ,@lpCount INT  
 -- 提前计算出要使用的分母 提高运行速度  
 SELECT @curCount = COUNT(1) FROM #tempData WHERE ltype = 'cur'  
 SELECT @lyCount = COUNT(1) FROM #tempData WHERE ltype = 'ly'  
 SELECT @lpCount = COUNT(1) FROM #tempData WHERE ltype = 'lp'  
   
 INSERT #Result (cType,curCount,lyCount,lpCount, curNewInsureFee,lyNewInsureFee,lpNewInsureFee,curNewInsurePercent,lyNewInsurePercent,lpNewInsurePercent,curBusInsure,lyBusInsure,lpBusInsure)  
 SELECT   
  ISNULL(bi.Name,'未知保险公司')  
  -- 台次  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)   
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
  -- 手续费用  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
   
  -- 新保台次占比  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) * 100.00  / ABS(NULLIF(@curCount,0))  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) * 100.00  / ABS(NULLIF(@curCount,0)) -  
  ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@lyCount,0))  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@curCount,0)) -  
  ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@lpCount,0))   
    
  -- 商业险  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS(@CurSaleCount),0) * 100 AS DECIMAL(18,2))  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS(@CurSaleCount),0) * 100 AS DECIMAL(18,2)) -  
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS(@LySaleCount),0) * 100 AS DECIMAL(18,2))  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS(@CurSaleCount),0) * 100 AS DECIMAL(18,2)) -   
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS(@LpSaleCount),0) * 100 AS DECIMAL(18,2))  
 FROM #TempData t LEFT JOIN dbo.Tbl_Base_Insurer bi on t.Insure = bi.InsurerID  
 --WHERE bi.Name IS NOT NULL   
 GROUP BY bi.Name,t.Insure  
   
END  
ELSE IF (@Type = '销售顾问')  
BEGIN  
   
 INSERT #Result ( cType ,curCount ,lyCount ,lpCount ,curNewInsureFee ,lyNewInsureFee ,lpNewInsureFee ,curBusInsure ,lyBusInsure ,lpBusInsure )  
 SELECT   
  ISNULL(e.EmpName,'未知销售顾问')  
  -- 台次  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2))  
  -- 手续费用  
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
 , CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00   
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2))  
  -- 商业险  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND EmpName = e.EmpName)),0) * 100 AS DECIMAL(18,2))  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND EmpName = e.EmpName)),0) * 100 AS DECIMAL(18,2)) -  
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly' AND EmpName = e.EmpName)),0) * 100 AS DECIMAL(18,2))  
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND EmpName = e.EmpName)),0) * 100 AS DECIMAL(18,2)) -   
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
  / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp' AND EmpName = e.EmpName)),0) * 100 AS DECIMAL(18,2))  
 FROM #TempData t LEFT JOIN dbo.Tbl_Com_Employee e ON t.SaleManID = e.EmpID  
 --WHERE e.EmpName IS NOT NULL  
 GROUP BY e.EmpName  
   
END  
  
  
  
-- 最后输出判断，如果是合计就出那个九宫格，如果不是就@Type要求出具体数据 ----------------------------  
  
IF (@Type = '合计')  
BEGIN  
  
 SELECT  '新保台次' AS '指标名称'  
   -- 台次  
  , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) AS '数值'  
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00   
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2)),0) AS '环比'  
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00   
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2)),0) AS '同比'  
 FROM #TempData  
   
 UNION ALL  
   
 SELECT   
   '手续费用'  
   -- 手续费用  
  , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)  
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00   
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2)),0)  
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00   
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2)),0)  
 FROM #TempData  
   
 UNION ALL   
   
 SELECT   
   '商业险渗透率'  
   -- 商业险  
  , ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
   / NULLIF(ABS(@CurSaleCount),0) * 100 AS DECIMAL(18,2)),0)  
  , ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
   / NULLIF(ABS(@CurSaleCount),0) * 100 AS DECIMAL(18,2)) -   
   CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
   / NULLIF(ABS(@LySaleCount),0) * 100 AS DECIMAL(18,2)),0)  
  , ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
   / NULLIF(ABS(@CurSaleCount),0) * 100 AS DECIMAL(18,2)) -   
   CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsBusInsure ELSE 0 END),0) AS DECIMAL(18,2))   
   / NULLIF(ABS(@LpSaleCount),0) * 100 AS DECIMAL(18,2)),0)  
    
 FROM #TempData  
 
  insert into Tbl_Com_AnaUseLog                      
(EmpID,freshTime,spName,AnaName,siftvalue,OherParemeter)                      
values (0,GETDATE(),'SP_Syn_Report_NewInsure','新保综合报表',@Condition                      
,'@Type='+@Type+',@EmpID='+'0')  
  
END  
ELSE  
BEGIN  
  
 IF (@OrderFields = '')  
 BEGIN  
    
  SET @OrderFields = 'cType'  
    
 END  
  
 DECLARE @sql VARCHAR(MAX)  
  
  
 SET @sql = 'INSERT #ResultOrder  
    SELECT   
    ROW_NUMBER() OVER (ORDER BY ' + @OrderFields + '),*  
    FROM #Result'   
  
 --PRINT @sql  
 EXEC (@sql)  
  
  
 -- 输出结果  
  
 SELECT * FROM #ResultOrder ORDER BY id  
 

   
END  
    
   
  
  
  
  
  
  
  
-- 释放临时表空间 ----------------------------------------------------------------  
  
IF OBJECT_ID('tempdb..#lylptime') IS NOT NULL  
BEGIN  
 DROP TABLE #lylptime  
END  
  
IF OBJECT_ID('tempdb..#ResultSales') IS NOT NULL  
BEGIN  
 DROP TABLE #ResultSales  
END  
  
  
IF OBJECT_ID('tempdb..#time') IS NOT NULL  
BEGIN  
 DROP TABLE #time  
END  
  
IF OBJECT_ID('tempdb..#CarSeries') IS NOT NULL  
BEGIN  
 DROP TABLE #CarSeries  
END  
  
IF OBJECT_ID('tempdb..#SaleChannel') IS NOT NULL  
BEGIN  
 DROP TABLE #SaleChannel  
END  
  
IF OBJECT_ID('tempdb..#TempData') IS NOT NULL  
BEGIN  
 DROP TABLE #TempData  
END  
  
IF OBJECT_ID('tempdb..#Result') IS NOT NULL  
BEGIN  
 DROP TABLE #Result  
END  
  
  
  
  
END
go

