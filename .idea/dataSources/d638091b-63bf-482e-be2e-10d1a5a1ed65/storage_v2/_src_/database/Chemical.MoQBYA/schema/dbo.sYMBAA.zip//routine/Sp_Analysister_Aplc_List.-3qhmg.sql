




-- =============================================
-- Author: hjl
-- Create Date: 2017年2月16日
-- Descript: 分区计算表的列表呈现功能
  
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_Aplc_List]            
  @condition VARCHAR(MAX)='DimSinYX:-1%DimOilSeries:2%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinTemp8:-1%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimSinJNPH:-1%DimSinBG0002:-1%DimOilDensity:-1%DimOilSTension:-1'
 ,@OrderFields VARCHAR(50) = 'Datacount desc'
 ,@EmpID INT = 1
 ,@PageIndex VARCHAR(5)='1'
 ,@PageSize VARCHAR(5)='10'
 ,@SpName VARCHAR(max) = 'SinCapsule' -- 要求分析的主体段
 ,@Target VARCHAR(50) = 'DimSinOutValue_DimOilSeries2'  -- 分析的目标列名
AS
BEGIN
       
---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            
    
    IF(@OrderFields = '')
		SET @OrderFields = 'Datacount desc'
    
    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue=REPLACE(@condition,'|',',');
    
    DECLARE @SelectSql VARCHAR(MAX) = '';   -- 用于 select 段取数据
    DECLARE @GroupBySql VARCHAR(MAX) = '';  -- 用于 Groupby 段取数据
    
    DECLARE @ADDColumnSql VARCHAR(MAX) = '';   -- 用于 给结果临时表修改列
    DECLARE @ColumnSql VARCHAR(MAX) = '';  -- 用于 拼接插入表的数据
    
    DECLARE @ColumnNames VARCHAR(MAX) = '';  -- 用于 输出时的表头
	DECLARE @Varchars VARCHAR(MAX) = '';
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       

   -- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable]
     @SiftValue = @SiftValue
	,@XName = ''
	,@DsName = '';
     
     --SELECT * FROM #Dims;
     
     -- 拼接创建维度临时表的语句
     
    DECLARE @sql VARCHAR(MAX) = '';
     
    SET @sql += ISNULL( ( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') ),'');

	

		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析
     
     -- 用 Dims 临时表拼接需要解析的 维度字符串
     SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
     
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;

     -- 解析维度
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + ISNULL(@NeedSiftvalue,'') + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';
    
	--return ;            
    
---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        
------------------------------------------------------------- 维度及取表 参数设定 --------------------------------------------------------------------------------             
            
	 CREATE TABLE #Result_B            
	 (            
	  Datacount INT
	  ,GoodRst INT
	  ,MiddleRst INT
	  ,BadRst INT
	  ,GoodBL DECIMAL(18,2)
	  ,MiddleBL DECIMAL(18,2)
	  ,BadBL DECIMAL(18,2)
	 )
    
	DECLARE @TimeName varchar(50);   -- 用于判断时间的标志            
    
    SET @SelectSql += ( SELECT ','+ DimName + '.Name'
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
	
	SET @GroupBySql += ( SELECT ','+ DimName + '.Name'
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
    
    SET @ADDColumnSql += ( SELECT ' ALTER TABLE #Result_B ADD '+ DimName + ' VARCHAR(200);'
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
    
    SET @ColumnSql += ( SELECT ','+ DimName
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
    
    SET @ColumnNames += ( SELECT ','''+ DimName + ''' AS ' + ChName
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
    
    SET @Varchars += ( SELECT ',''varchar 500'''
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
    
	-- 有选择时去掉第一个逗号
	IF ( @SelectSql <> '') SET @GroupBySql = SUBSTRING(@GroupBySql,2,LEN(@GroupBySql) + 1 );
	
---------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              
	
	--DECLARE @sql VARCHAR(MAX);
	DECLARE @TarTableName VARCHAR(50) = 'T_Aplc_' +  @SpName + '_' + @Target;
	
    DECLARE @Sql2 VARCHAR(MAX);
    
	-- 基础版本的 select段Sql语句
	
	set @sql +=
		'INSERT into #Result_B(Datacount,GoodRst,MiddleRst,BadRst,GoodBL,MiddleBL,BadBL' + isnull(@ColumnSql,'') + ') '       
		+ ' SELECT distinct SUM(Datacount),SUM(GoodRst),SUM(MiddleRst),SUM(BadRst)
			,convert(decimal(18,2), convert(decimal(18,4),SUM(GoodRst)) / convert(decimal(18,4),SUM(Datacount)) * 100 )
			,convert(decimal(18,2), convert(decimal(18,4),SUM(MiddleRst)) / convert(decimal(18,4),SUM(Datacount)) * 100 )
			,convert(decimal(18,2), convert(decimal(18,4),SUM(BadRst)) / convert(decimal(18,4),SUM(Datacount)) * 100 ) '
		+ isnull(@SelectSql,'') + '
		 FROM ' + @TarTableName + ' Bs ';
	
	-- 温度8维度
	DECLARE @sql1 VARCHAR(MAX) = '';
	-- 将INNER JOIN 维度临时表段拼接起来  ' INNER JOIN #Temp8N AS temp8 on temp8.ID = OutputAplc.DIMSinTemp8ID '  原表中的ID字符为 维度名称+ID
	SET @sql1 = ( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' +  DimName + '.ID = Bs.' + DimName 
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
	
	set @sql += isnull(@sql1,'');
	
	IF ( ISNULL(@SelectSql,'') <> '') set @sql += ' GROUP BY ' + @GroupBySql;
	
	PRINT @ADDColumnSql;
	IF ( ISNULL(@ADDColumnSql,'') <> '')  EXEC(@ADDColumnSql);
	
	print @sql;
	
	EXEC(@sql);
	
	SET @Sql2 = 
	 '	select  ''n'' AS 序号 ' + isnull(@ColumnNames,'')
	 + ',''Datacount'' AS 总生产数,''GoodRst'' AS 好产值数,''MiddleRst'' AS 中等产值数
	 ,''BadRst'' AS 坏产值数,''GoodBL'' AS 好产值占比,''MiddleBL'' AS 中等产值占比,''BadBL'' AS 坏产值占比'
	 + 
	 '
     union all
     select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'' 
     '
     + isnull(@Varchars,'');
     
     EXEC (@Sql2);
     
	DECLARE @totalRow INT = 0;
	SELECT @totalRow = COUNT(*) FROM #Result_B;
     
  EXEC dbo.Sp_Sys_Page @tblName = '#Result_B'
	,@fldName =  @OrderFields
	,@rowcount = @totalRow
	,@PageIndex = @PageIndex
	,@PageSize = @PageSize
	,@SumType = 0
	,@SumColumn = ''
	,@AvgColumn = ''
     
     DROP TABLE #Result_B;

          
END
go

