
CREATE PROC sp_help_TestDimOK

 @DimNum VARCHAR(50)='DimDeltaBK'
		,@TableName VARCHAR(50)='#DeltaBK'
		,@SiftValue VARCHAR(max)= 'DimDeltaBK:-1'
AS
BEGIN
 SET @TableName ='#'+ REPLACE(@TableName,'#','')  

--查看解析值是否正确
EXEC ('
CREATE TABLE '+@TableName+' ( VWID INT , [ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)) ;

EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''+@SiftValue+''', @EmpID = 1; 
  
EXEC dbo.sp_Com_TempTableSplit @tempTable = '''+@TableName+''';

select * from '+@TableName)

--查询Tbl_AnsCom_DIimToTable 数据是否添加正确
SELECT * FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = @DimNum

--查询视图数据是否判断视图是否创建正确
EXEC(' SELECT * FROM dbo.vw_'+@DimNum+'_Part')
EXEC(' SELECT * FROM dbo.vw_'+@DimNum+'_PartALL')



--得到解析字符串
PRINT '
CREATE TABLE '+@TableName+' ( VWID INT , [ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2)) ;

EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''+@SiftValue+''', @EmpID = 1; 
  
EXEC dbo.sp_Com_TempTableSplit @tempTable = '''+@TableName+''';

select * from '+@TableName+'; drop table '+@TableName

END
go

