
-- =============================================
-- Author:		白冰
-- Create date: 2016-06-03
-- Description:	获取粒子数据信息列表
-- Parameter：	@ParticalCode -- 粒子编号
--				@PType：-- 黑色粒子、白色粒子
--				@PigmentCode：-- 颜料编号
--              @OptDate：-- 粒子制作时间
--				@Kettle： -- 粒子反应釜
-- =============================================

-- EXEC Sp_Bs_List_ParticalBak @OptDateB=N'2014-6-15',@OptDateE=N'2014-6-23',@SpName=N'Partical',@Code=N'1406BK005',@PageSize=N'15',@PageIndex=N'1',@OrderFields=N'',@Type=N'查询',@ID=N'',@EmpID=N'1'
CREATE PROCEDURE [dbo].[Sp_Bs_List_ParticalBak]
    @OptDateB VARCHAR(50) = '' ,
    @OptDateE VARCHAR(50) = '' ,
    @SpName VARCHAR(20) = '' ,
    @Code VARCHAR(50) = ''  --胶囊取值
    ,
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '10' ,
    @OrderFields VARCHAR(50) = '' ,
    @Type VARCHAR(50) = ''  -- "查询" "编辑" 类型，是查询的List，还是编辑用的加载    
    ,
    @ID VARCHAR(50) = '' ,
    @EmpID VARCHAR(50) = '1'
AS
    BEGIN
        DECLARE @sql NVARCHAR(MAX)= '';
        SET @Code = LTRIM(RTRIM(@Code));
        IF ( ( SELECT   1
               FROM     dbo.Tbl_AnsCom_AnaSpConfig
               WHERE    SpName = @SpName
             ) = 1 )
            BEGIN
                SET @sql = 'select * into #Result from (';
                SET @sql += ( SELECT    JoinTables
                              FROM      Tbl_AnsCom_AnaSpConfig
                              WHERE     SpName = @SpName
                            ) + ' ';
                SET @sql += ( SELECT    BaseTable
                              FROM      dbo.Tbl_AnsCom_AnaSpConfig
                              WHERE     SpName = @SpName
                            );
                SET @sql += CHAR(10) + ' where ';
                SET @sql += CHAR(10) 
                    + ( SELECT  TimeName
                        FROM    Tbl_AnsCom_AnaSpConfig
                        WHERE   SpName = @SpName
                      ) + '>=''' + @OptDateB + ''' and ';
                SET @sql += CHAR(10) + ( SELECT TimeName
                                         FROM   Tbl_AnsCom_AnaSpConfig
                                         WHERE  SpName = @SpName
                                       ) + '<=''' + @OptDateE + ''' and ';
                SET @sql += CHAR(10) + ( SELECT CodeName
                                         FROM   Tbl_AnsCom_AnaSpConfig
                                         WHERE  SpName = @SpName
                                       ) + '=''' + @Code + ''' ';
                
           
                PRINT @sql;
--SELECT * FROM Tbl_AnsCom_AnaSpConfig
            END;
        ELSE
            SELECT  '数据源配置不存在';

	
   -- 数据分页    
 DECLARE @totalRow int = @@ROWCOUNT ;    
  
    if(@OrderFields='')    
  set @OrderFields ='optdate desc'    

  -- 编辑的加载 
		 INSERT INTO Tbl_Log_AnaUseLog
			(EmpID, freshTime, spName,
				AnaName, siftvalue, OherParemeter)
			VALUES (@EmpID, GETDATE(), 'Sp_Bs_List_Partical',
				'查询粒子数据', 'select',@Code)    
     
 IF(@Type = '查询')
 begin
 
  EXEC dbo.Sp_Sys_Page @tblName = '#Result'                      
  ,@fldName = @OrderFields                              
  ,@rowcount = @totalRow     
  ,@PageIndex = @PageIndex     
  ,@PageSize = @PageSize      
  ,@SumType = 0    
  ,@SumColumn = ''    
  ,@AvgColumn = ''    
     
     end
 ELSE     
    SELECT * FROM #Result    
	
    END;
go

