   
-- =============================================      

-- Description: 保存“我的常用菜单”      
-- =============================================      
CREATE proc[dbo].[Sp_Sys_GetMyMenuList]      
 @PageSize int='10'      
 ,@PageIndex int='1'      
 ,@EmpID int='1'      
AS      
BEGIN      
 select       
 'MyMenuId' MyMenuId      
 ,'MenuTitle' as 菜单名称    
 ,'EmpID' as EmpID    
 union all      
 select       
 'varchar,200'      
 ,'varchar,200'  
  ,'varchar,200'      
      
 select       
 MyMenuId as MyMenuId      
 ,[menuTitle] as MenuTitle   
 ,EmpID     
  into #tp       
 from tbl_sys_myMenu where empId=@EmpID      
 order by MyMenuId        
   declare @pageCount int =1         
       
    EXEC [Sp_Sys_Page] @tblName='#tp',@fldName='MyMenuId',@rowcount=@@rowcount,@PageSize=@PageSize, @PageIndex=@PageIndex        
END      
--select * from tbl_sys_myMenu      
go

