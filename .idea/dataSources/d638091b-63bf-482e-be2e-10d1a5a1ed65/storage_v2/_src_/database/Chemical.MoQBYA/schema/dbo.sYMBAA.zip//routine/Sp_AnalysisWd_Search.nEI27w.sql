
                                         
CREATE PROCEDURE [dbo].[Sp_AnalysisWd_Search]
    @EmpID VARCHAR(500) = '' , -- 此参数由框架自动传入，不在XML中配置
    @SpType NVARCHAR(20) = 'Coating'
AS
    BEGIN
        SELECT  DimNum ,
                Name_ch ,
                CoName ,
                ID
        FROM    dbo.Tbl_AnsCom_DIimToTable
        WHERE   AnalysisType LIKE '%Y2%'
                AND SpType LIKE '%' + @SpType + '%';
                
    END;
go

