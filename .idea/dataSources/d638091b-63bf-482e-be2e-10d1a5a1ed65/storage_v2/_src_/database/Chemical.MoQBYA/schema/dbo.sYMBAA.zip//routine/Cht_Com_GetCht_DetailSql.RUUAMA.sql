
-- =============================================      
-- Author:  <刘轶>      
-- Create date: <2014-7-7>      
-- Description: <出明细的存储过程数量以外的CompareType拼接sql>      
-- =============================================      
 
CREATE function [dbo].[Cht_Com_GetCht_DetailSql](  
@XGroup  varchar(255)=''  
,@DSGroup  varchar(255)=''  
,@XValue  varchar(255)=''  
,@DSValue  varchar(255)=''
,@CompareType  varchar(255)=''
,@SiftValue  varchar(max)=''
,@ResultColName varchar(max)=''
,@DenoName varchar(max)=''
)    
returns varchar(max)               
AS                       
BEGIN	   
	declare @ResultSql varchar(max)  =''	--返回sql
		,@TempSql varchar(max)  =''			--临时sql 输出最终结果
		,@TempSql2 varchar(max)  =''			--临时sql2
	
	set @TempSql = 'select                 
		  ''id'' 编号                 
		  ,''des'' 描述                        
		  ,''result'' 结果                
		  union all               
		  select               
		  ''vachar,500''  id                        
		  ,''vachar,500''  des                       
		  ,''vachar,500'' result '
	--select * from #ResultData
	--select * from #time

	-- 计算基数 分子 从基础结果表提取
	set @ResultSql +=' declare @BReslut decimal(18,2) '   -- 结果基数    
			+' declare @Deno decimal(18,2)  '     -- 全部占比分母 
			+' declare @Result decimal(18,2) '		--计算结果
			+' declare @DateID nvarchar(100) '		--计算结果
			+' declare @DateStr1 nvarchar(500) '		--第一行名称
			+' declare @DateStr2 nvarchar(500) '		--第二行名称
	
	set @ResultSql += ' update a set a.begindate=b.begindate,a.enddate=b.enddate 
		from #ResultData as a inner join #time as b on a.dateID = b.ID '--根据日期ID更新日期
	
	set @ResultSql += ' 
		select @BReslut = ' + @ResultColName+ ' from  #ResultData 
		where ' + @XGroup + ' = ' + ' ''' + @XValue +''' and isnull(' + @DSGroup + ','''') = ' + ' ''' + @DSValue +''' '
	--时间在第一位或者第四位的时候
	if([dbo].GetDimHead(@SiftValue,1)='dim7' OR [dbo].GetDimHead(@SiftValue,4)='dim7')
	begin
		set @ResultSql+= ' set @DateStr1= (select convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)+'',''
			from #time FOR XML PATH('''')) '
	end
	else if([dbo].GetDimHead(@SiftValue,2)='dim7')
	begin
		set @ResultSql+= ' set @DateStr1= (select top 1 convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23) 
			from #time where convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)='''+@XValue+''' ) '
	end
	else if([dbo].GetDimHead(@SiftValue,3)='dim7')
	begin
		set @ResultSql+= ' set @DateStr1= (select top 1 convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)
			from #time where convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)='''+@DSValue+''' ) '
	end
	
	--select @CompareType
	if(@CompareType = '同比')
	begin
		set @ResultSql += ' update a set a.begindate=b.begindate,a.enddate=b.enddate 
		from #ResultData_Ly as a inner join #time as b on a.dateID = b.ID '--根据日期ID更新日期
		-- 计算得到分母
		set @ResultSql += ' 
			select @Deno = ' + @ResultColName+ ' from  #ResultData_Ly
		where ' + @XGroup + ' = ' + ' ''' + @XValue +''' and isnull(' + @DSGroup + ','''') = ' + ' ''' + @DSValue +''' '
		--计算结果
		set @ResultSql += ' 
		set @Result=case when isnull(@Deno,0)=0 or isnull(@BReslut,0)=0 then 0 else (isnull(@BReslut,0)-isnull(@Deno,0))/isnull(@Deno,0)*100 end
		'
		
			
		--时间在第一位或者第四位的时候
		if([dbo].GetDimHead(@SiftValue,1)='dim7' OR [dbo].GetDimHead(@SiftValue,4)='dim7')
		begin
			set @ResultSql+= ' set @DateStr2= (select convert(nvarchar, begindate_ly,23)+''至''+convert(nvarchar, enddate_Ly,23)+'',''
				from #time FOR XML PATH('''')) '
		end
		else if([dbo].GetDimHead(@SiftValue,2)='dim7')
		begin
			set @ResultSql+= ' set @DateStr2= (select top 1 convert(nvarchar, begindate_ly,23)+''至''+convert(nvarchar, enddate_Ly,23) 
				from #time where convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)='''+@XValue+''' ) '
		end
		else if([dbo].GetDimHead(@SiftValue,3)='dim7')
		begin
			set @ResultSql+= ' set @DateStr2= (select top 1 convert(nvarchar, begindate_ly,23)+''至''+convert(nvarchar, enddate_Ly,23)
				from #time where convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)='''+@DSValue+''' ) '
		end
	end
	
	else if(@CompareType = '环比')
	begin
		set @ResultSql += ' update a set a.begindate=b.begindate,a.enddate=b.enddate 
		from #ResultData_Lp as a inner join #time as b on a.dateID = b.ID '--根据日期ID更新日期
		-- 计算得到分母
		set @ResultSql += '
			select @Deno = ' + @ResultColName+ ' from  #ResultData_Lp
			where ' + @XGroup + ' = ' + ' ''' + @XValue +''' and isnull(' + @DSGroup + ','''') = ' + ' ''' + @DSValue +''' '
		--计算结果
		set @ResultSql += ' 
		set @Result=case when isnull(@Deno,0)=0 or isnull(@BReslut,0)=0 then 0 else (isnull(@BReslut,0)-isnull(@Deno,0))/isnull(@Deno,0)*100 end
		'
		--时间在第一位或者第四位的时候
		if([dbo].GetDimHead(@SiftValue,1)='dim7' OR [dbo].GetDimHead(@SiftValue,4)='dim7')
		begin
			set @ResultSql+= ' set @DateStr2= (select convert(nvarchar, begindate_lp,23)+''至''+convert(nvarchar, enddate_Lp,23)+'',''
				from #time FOR XML PATH('''')) '
		end
		else if([dbo].GetDimHead(@SiftValue,2)='dim7')
		begin
			set @ResultSql+= ' set @DateStr2= (select top 1 convert(nvarchar, begindate_lp,23)+''至''+convert(nvarchar, enddate_Lp,23) 
				from #time where convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)='''+@XValue+''' ) '
		end
		else if([dbo].GetDimHead(@SiftValue,3)='dim7')
		begin
			set @ResultSql+= ' set @DateStr2= (select top 1 convert(nvarchar, begindate_lp,23)+''至''+convert(nvarchar, enddate_Lp,23)
				from #time where convert(nvarchar, begindate,23)+''至''+convert(nvarchar, enddate,23)='''+@DSValue+''' ) '
		end
	end
	
	---- 计算组内占比 分母 -- 组内分母可以直接有 计算结果表得到
	

	-- 如果是占比方式  需要加入分母供除法
	else if(@CompareType = '全部占比')
	begin

		-- 计算得到分母
		set @ResultSql += '
			select @Deno = ' + @DenoName+ ' from  #ResultData_All'
		--计算结果
		set @ResultSql += ' 
		set @Result=case when isnull(@Deno,0)=0 then 0 else isnull(@BReslut,0)/isnull(@Deno,0)*100 end
		'
		
		set @ResultSql+= ' set @DateStr2= ''全部总计'' '
	end
	
	else if(@CompareType = '组内占比')
	begin

		
		-- 计算得到分母
		set @ResultSql += '
			select @Deno = '+ @DenoName + ' from  #ResultData'
		--计算结果
		set @ResultSql += ' 
		set @Result=case when isnull(@Deno,0)=0 then 0 else isnull(@BReslut,0)/isnull(@Deno,0)*100 end
		'

		set @ResultSql+= ' set @DateStr2= ''组内总计'' '
	end
	

	
	--计算
	if(@CompareType = '环比' or @CompareType = '同比')
	begin
		--如果横轴是时间 不重复显示时间
		if([dbo].GetDimHead(@SiftValue,2)='dim7')
		begin
			set @XValue=''
		end
		--如果分组是时间 不重复显示时间
		if([dbo].GetDimHead(@SiftValue,3)='dim7')
		begin
			set @DSValue=''
		end

	
	
		set @TempSql+= ' 
			select 1 as id,@DateStr1+'' '+@XValue+' '+@DSValue+''' as des
			,CONVERT(varchar(50),@BReslut) as result '
		set @TempSql+= ' union
				select 2 as id,@DateStr2+'' '+@XValue+' '+@DSValue+''' as des
				,CONVERT(varchar(50),@Deno) as result '	
	end
	else --组内占比和全部占比
	begin
		set @TempSql+= '
			select 1 as id,'''+@XValue+' '+@DSValue+''' as des
			,CONVERT(varchar(50),@BReslut) as result '
		set @TempSql+= ' union
				select 2 as id,@DateStr2 as des
				,CONVERT(varchar(50),@Deno) as result '	
	end	
	
	
	set @TempSql+= ' union
			select 3 as id,'''+@CompareType+''' as des,CONVERT(varchar(50), @Result)+''%'' as result '
		
	set @TempSql+= '
			select 1 as [PageIndex],1 as [pageCount],3 as [rowCount] 
			'
	return @ResultSql+@TempSql
end
go

