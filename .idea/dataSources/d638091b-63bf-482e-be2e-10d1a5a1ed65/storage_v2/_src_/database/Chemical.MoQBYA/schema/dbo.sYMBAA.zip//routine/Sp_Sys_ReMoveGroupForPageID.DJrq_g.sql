
-- =============================================
-- Author:		<柳燕杰>
-- Create date: <2012-05-18>
-- Description:	<根据传入的PageID以及GroupID来删除当前Page下的Group>
-- =============================================
create PROCEDURE [dbo].[Sp_Sys_ReMoveGroupForPageID]
	 @PageGroupID varchar(200)
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    delete Tbl_Sys_PageGroup
    WHERE  PageGroupID = @PageGroupID
    
    select '0'
END
go

