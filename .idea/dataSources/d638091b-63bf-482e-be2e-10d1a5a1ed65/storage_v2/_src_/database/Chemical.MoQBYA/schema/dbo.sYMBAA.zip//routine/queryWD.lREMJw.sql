CREATE PROCEDURE queryWD
@WDinput NVARCHAR(50)=''
AS
    BEGIN
        DECLARE @WD NVARCHAR(50) = '';
        DECLARE @Name_ch NVARCHAR(50) = '';
          SELECT @Name_ch=Name_ch,@WD=CoName
                          FROM   dbo.Tbl_AnsCom_DIimToTable
                          WHERE  DimNum = @WDinput
                  
        DECLARE @Sql NVARCHAR(MAX) = '';
        SET @Sql = 'insert into ResultWD  SELECT '''+@Name_ch+''',CAST(SUM(a.GY) AS FLOAT) / COUNT(*) 坏率 ,
       COUNT(*) 数据量
FROM   (   SELECT CASE WHEN min0LBK <= 19 THEN 0
                       ELSE 1
                  END GY 

           FROM   dbo.Bs_Coating_ZJ
                  INNER JOIN dbo.Bs_Coating ON Bs_Coating.Code = Bs_Coating_ZJ.CoatingCode
                  INNER JOIN dbo.Bs_Coating_MS ON Bs_Coating_MS.Code = Bs_Coating.CoatingMsCode
           WHERE  min0LBK IS NOT NULL
                  AND MpSeries IN ( 8, 9, 10, 11 )
                  AND ' + @WD
                   + ' IS NOT NULL
                  --AND MsNdBe < 210
       ) a  ';
	   PRINT @Sql
        EXEC ( @Sql );

		--PRINT @Sql
    END;
go

