CREATE PROC [dbo].[Sp_Com_DefaultDateTime]
AS
BEGIN

select 'BeginDate' BeginDate          
,'EndDate' EndDate            
union all            
select 'varchar 200'         
,'varchar 200' 
union  all
SELECT CONVERT(VARCHAR(50),GETDATE(),23) AS BeginDate,CONVERT(VARCHAR(50),GETDATE(),23) AS EndDate
END
go

