
-- =============================================
-- Author:		hjl
-- Create date: 2016-04-1
-- Description:	一个油相、一组公益参数循环计算
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Reg_YCGHJS]
@JSBH      VARCHAR(100) = 'hjl41第一次计算'
,@RegNum	VARCHAR(100) = '第一对温度41转速41'
,@YXNum		VARCHAR(100) = 'RN1505FB001'		--回归计算的油相编号
,@CSMC1     VARCHAR(100) = 't41'       --实验计算的参数名称1
,@CSMC2     VARCHAR(100) = 's41'      --实验计算的参数名称2
,@Min1		DECIMAL(12,2) = 10		-- 计算2的小值
,@Max1		DECIMAL(12,2) = 500		--计算2的最大值
,@Interval1	DECIMAL(12,2) = 10		--计算2的间隔值
,@Min2		DECIMAL(12,2) = 1		-- 计算2的小值
,@Max2		DECIMAL(12,2) = 40		--计算2的最大值
,@Interval2	DECIMAL(12,2) = 1		--计算2的间隔值
,@t8        DECIMAL(12,2) = 150	
,@t25        DECIMAL(12,2) = 150	
,@t41        DECIMAL(12,2) = 150	
,@s8         DECIMAL(12,2) = 5	
,@s25        DECIMAL(12,2) = 5	
,@s41        DECIMAL(12,2) = 5	

AS
BEGIN

	--- 验证油相编号存在
	IF NOT EXISTS(SELECT * FROM dbo.Tbl_Data_eCapsule WHERE YXNum = @YXNum)
	BEGIN
		SELECT '油相编号不存在！';
		RETURN;
	END

	-- 验证实验参数正确
	IF (@CSMC1 NOT IN ('t8','t25','t41','s8','s25','s41'))
	BEGIN
		SELECT '实验参数名称不存在！';
		RETURN;
	END

	IF (@CSMC2 NOT IN ('t8','t25','t41','s8','s25','s41'))
	BEGIN
		SELECT '实验参数名称不存在！';
		RETURN;
	END
-------------------------------------- 开始算法 --------------------------------------------------
	-- 设定循环计算参数

	DECLARE @whileNum1 INT ,@index1 INT = 0
	SET @whileNum1 = (@Max1 - @Min1) / @Interval1
	DECLARE @whileNum2 INT ,@index2 INT = 0
	SET @whileNum2 = (@Max2 - @Min2) / @Interval2
	DECLARE @YZBS INT = 1
	
	WHILE @index1 <= @whileNum1 --1循环开始 判断运行次数
	BEGIN
		
		--- 设定参数1初始参数
		IF @CSMC1 = 't8' SET @t8 = @Min1 + @index1 * @Interval1;
		if @CSMC1 ='t25' SET @t25 = @Min1 + @index1 * @Interval1;
		if @CSMC1 ='t41' SET @t41 = @Min1 + @index1 * @Interval1;
		if @CSMC1 ='s25' SET @s25 = @Min1 + @index1 * @Interval1;
		if @CSMC1 ='s41' SET @s41 = @Min1 + @index1 * @Interval1;
		
		SET @index2 = 0
		--INSERT Reg_eCapsule_Detail(JSBH,RegNum)
		--SELECT 'hjl41第一次计算',@CSMC1
		
		
		WHILE @index2 <= @whileNum2 --@t8循环开始 判断运行次数
		BEGIN
		
		--- 设定参数2初始参数
			IF @CSMC2 = 't8' SET @t8 = @Min2 + @index2 * @Interval2;
			if @CSMC2 ='t25' SET @t25 = @Min2 + @index2 * @Interval2;
			if @CSMC2 ='t41' SET @t41 = @Min2 + @index2 * @Interval2;
			if @CSMC2 ='s25' SET @s25 = @Min2 + @index2 * @Interval2;
			if @CSMC2 ='s41' SET @s41 = @Min2 + @index2 * @Interval2;
			
			--INSERT Reg_eCapsule_Detail(JSBH,RegNum)
			--SELECT 'hjl41第一次计算',@CSMC2
			
			--- 对单个油相的各个釜位计算标准值
			INSERT dbo.Reg_eCapsule_Detail
					( JSBH,RegNum, whileNum,YXNum ,Fu ,FStandardValue ,FValue ,FDeviationValue ,OutputValue ,
					  temp41a ,speed41a ,temp8a ,temp25a ,speed25a ,
					  temp41 ,speed41 ,temp8 , temp25 ,speed25 ,point
					  ,temp41sz ,speed41sz ,temp8sz ,temp25sz ,speed25sz 
					  ,t8,t25,t41,s8,s25,s41
					)
			SELECT @JSBH   -- 计算次数标识
				,@RegNum    -- 标识本次计算的是什么
				,@YZBS
				,e.YXNum,e.Fu,e.FStandradValue,e.FValue
				,e.OutputValueml / f.FDegree   -- 实际产值除以釜位影响得到去除釜位因素的产值
				,e.OutputValueml, -- 实际产值  记录
				e.Temp41,e.Speed580,e.Temp8,e.Temp25,e.Speed,41.5,580,8.0,25.0,404.0   -- 各种参数记录
				,e.OutputValueml / f.FDegree 
				+ (e.Temp41 - 41.5 )*@t41 
				- (e.Speed580 - 580)*@s41 
				+ (e.Temp8 - 8.0 )*@t8 
				+ (e.Temp25 - 25.0)*@t25 
				- (e.Speed - 404.0)*@s25   --  预计产值
				,(e.Temp41 - 41.5 )*@t41   --  每个工艺参数造成的偏差
				,(e.Speed580 - 580)*@s41 * -1
				,(e.Temp8 - 8.0 )*@t8 
				,(e.Temp25 - 25.0)*@t25 
				,(e.Speed - 404.0)*@s25 * -1 
				--- 每个工艺参数当前的值
				,@t8
				,@t25
				,@t41
				,@s8
				,@s25
				,@s41
				
			FROM dbo.Tbl_Data_eCapsule AS e
			LEFT JOIN Reg_FuValue f ON CAST(e.Fu AS INT) = f.Fu
			WHERE YXNum = @YXNum
			
			-- 计算本组的平均值
			UPDATE dbo.Reg_eCapsule_Detail
			SET avgPoint = ISNULL((SELECT AVG(point) 
							   FROM dbo.Reg_eCapsule_Detail AS d 
							   WHERE d.YXNum = dbo.Reg_eCapsule_Detail.YXNum),0)
			WHERE JSBH = @JSBH
			AND RegNum = @RegNum
			AND whileNum = @YZBS
			AND dbo.Reg_eCapsule_Detail.YXNum = @YXNum
			
			-- 循环子1+1
			SET @index2 = @index2 + 1;
			-- 一组油相的标识+1
			SET @YZBS = @YZBS + 1;
			
		END --循环2结束
		
		-- 循环子1+1
		SET @index1 = @index1 + 1;
		
	END --循环1结束
	
	--- 计算出每一条的离散度
	UPDATE dbo.Reg_eCapsule_Detail
	SET DiscreteValue = ABS(ISNULL((point - avgPoint)/NULLIF(avgPoint,0),0))
	WHERE JSBH = @JSBH
		and	RegNum = @RegNum  
		 AND YXNum = @YXNum

END

go

