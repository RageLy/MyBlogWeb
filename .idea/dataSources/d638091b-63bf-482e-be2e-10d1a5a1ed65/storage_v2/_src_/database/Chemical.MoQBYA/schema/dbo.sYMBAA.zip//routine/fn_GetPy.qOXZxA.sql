CREATE FUNCTION [dbo].[fn_GetPy] ( @str VARCHAR(500) = '' )
RETURNS VARCHAR(500)
AS
    BEGIN 
        DECLARE @strlen INT ,
            @return VARCHAR(500) ,
            @ii INT 
        DECLARE @c NCHAR(1) ,
            @chn NCHAR(1) 
        SELECT  @strlen = LEN(@str) ,
                @return = '' ,
                @ii = 0 
        SET @ii = 0 
        WHILE @ii < @strlen
            BEGIN 
                SELECT  @ii = @ii + 1 ,
                        @chn = SUBSTRING(@str, @ii, 1) 
                IF @chn >= '吖'
                    SELECT  @c = CHAR(COUNT(*) + 63)
                    FROM    ( SELECT TOP 27
                                        *
                              FROM      ( SELECT    chn = '吖'
                                          UNION ALL
                                          SELECT    '八'
                                          UNION ALL
                                          SELECT    '嚓'
                                          UNION ALL
                                          SELECT    '咑'
                                          UNION ALL
                                          SELECT    '妸'
                                          UNION ALL
                                          SELECT    '发'
                                          UNION ALL
                                          SELECT    '旮'
                                          UNION ALL
                                          SELECT    '铪'
                                          UNION ALL
                                          SELECT    '丌' --because have no 'i' 
                                          UNION ALL
                                          SELECT    '丌'
                                          UNION ALL
                                          SELECT    '咔'
                                          UNION ALL
                                          SELECT    '垃'
                                          UNION ALL
                                          SELECT    '嘸'
                                          UNION ALL
                                          SELECT    '拏'
                                          UNION ALL
                                          SELECT    '噢'
                                          UNION ALL
                                          SELECT    '妑'
                                          UNION ALL
                                          SELECT    '七'
                                          UNION ALL
                                          SELECT    '呥'
                                          UNION ALL
                                          SELECT    '仨'
                                          UNION ALL
                                          SELECT    '他'
                                          UNION ALL
                                          SELECT    '屲' --no 'u' 
                                          UNION ALL
                                          SELECT    '屲' --no 'v' 
                                          UNION ALL
                                          SELECT    '屲'
                                          UNION ALL
                                          SELECT    '夕'
                                          UNION ALL
                                          SELECT    '丫'
                                          UNION ALL
                                          SELECT    '帀'
                                          UNION ALL
                                          SELECT    @chn
                                        ) AS a
                              ORDER BY  chn COLLATE Chinese_PRC_CI_AS
                            ) AS b
                    WHERE   b.chn <= @chn 
                ELSE
                    SET @c = @chn 
                SET @return = @return + @c 
            END 
        RETURN(@return) 
    END
go

