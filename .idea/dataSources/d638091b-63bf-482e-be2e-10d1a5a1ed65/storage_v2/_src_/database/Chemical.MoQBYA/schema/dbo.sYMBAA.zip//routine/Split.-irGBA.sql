
-- =============================================
-- Author:		<吴国锋>
-- alter date: <alter Date,2013年7月9日 10:31:06,>
-- Description:	<分割字符串,>
-- =============================================
create function [dbo].[Split](
@TargetSTR   varchar(MAX),   --待分拆的字符串
@Seperator varchar(10)     --数据分隔符
)returns @Result table(StartIndex int,string varchar(MAX))
as
begin
 declare @splitlen int,@i int=0
 set @splitlen=LEN(@Seperator+'a')-2 
 while CHARINDEX(@Seperator,@TargetSTR)>0
 begin
  insert @Result values(@i,LEFT(@TargetSTR,CHARINDEX(@Seperator,@TargetSTR)-1))
  set @TargetSTR=stuff(@TargetSTR,1,CHARINDEX(@Seperator,@TargetSTR)+@splitlen,'')
  set @i=@i+1
 end
 
 insert @Result values(@i,@TargetSTR)
 return
end
go

