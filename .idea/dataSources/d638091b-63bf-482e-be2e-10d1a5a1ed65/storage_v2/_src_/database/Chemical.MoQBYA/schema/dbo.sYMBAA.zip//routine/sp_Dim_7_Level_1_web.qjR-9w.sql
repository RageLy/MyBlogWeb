CREATE proc [dbo].[sp_Dim_7_Level_1_web]
as
  
  select 'Id' [Id],'Name' [Name]
	union all
	select 'int' [Id],'varchar(50)' [Name]
	union all
  select cast(CharID as varchar(50)) as [Id],
      [CharName] as [Name] from Tbl_Dim7_Level
go

