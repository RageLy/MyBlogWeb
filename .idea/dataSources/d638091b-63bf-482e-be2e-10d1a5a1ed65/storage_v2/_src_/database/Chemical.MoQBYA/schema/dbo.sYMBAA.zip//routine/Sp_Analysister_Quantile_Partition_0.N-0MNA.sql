
--****************************************
--作者:hmw
--创建时间:2017-08-24
--说明:使用分位数方法将两两维度对比
--****************************************




CREATE PROCEDURE [dbo].[Sp_Analysister_Quantile_Partition_0]
    @Condition VARCHAR(MAX) = '' ,
    @DataType INT ,
    @YValue NVARCHAR(50) ,
    @ReferenceValue INT,
	@WDCount INT,
    @SpName NVARCHAR(50),
    @COUNTi INT,
    @FixBCH int
AS
    BEGIN
        --PRINT '目标维度: '+@YValue;
        DECLARE @sql NVARCHAR(MAX)= '';
        CREATE TABLE #Num
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL
                     PRIMARY KEY ,
              NumValue INT
            );
        DECLARE @tempNum INT= @DataType;
        WHILE ( @tempNum > 0 )
            BEGIN
                --PRINT @tempNum;
                INSERT  INTO #Num
                        ( NumValue )
                VALUES  ( @tempNum );
                       
                SET @tempNum -= 1;
            END; 
            
            --获取维度
        CREATE TABLE #ConTable
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL
                     PRIMARY KEY ,
              DimID NVARCHAR(4) ,
              DimNum NVARCHAR(50) ,
              DimYSQL NVARCHAR(50)
            );
        INSERT  INTO #ConTable
                ( DimID
                )
                SELECT  string
                FROM    dbo.f_splitSTR(@Condition, ',');
       
        
        UPDATE  #ConTable
        SET     DimYSQL = TableName + CoName ,
                DimNum = Tbl_AnsCom_DIimToTable.DimNum
        FROM    Tbl_AnsCom_DIimToTable
        WHERE   CAST(#ConTable.DimID AS INT) = Tbl_AnsCom_DIimToTable.ID;
         
        --SELECT  *
        --FROM    #ConTable; 
        DECLARE @SelectStr NVARCHAR(MAX)= @YValue + ' is not NULL ' + CHAR(10)
            + ( SELECT  ' and ' + TableName + '' + CoName + ' Is not NULL '
                        + CHAR(10)
                FROM    #ConTable
                        LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
              FOR
                XML PATH('')
              );
                                               -------------筛选数-----------------
        SET @sql += 'select ' + @YValue
            + ( SELECT  +',' + TableName + '' + CoName
                FROM    #ConTable
                        LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
              FOR
                XML PATH('')
              ) + ',GY into #TempQuantileResult from QuantileResult_'+@SpName+'_'+@YValue+' where '
            + @SelectStr;
                     
        DECLARE @count INT= ( SELECT    MAX(ID)
                              FROM      #ConTable
                            );
        WHILE ( @count > 0 )
            BEGIN
             --PRINT @count
                DECLARE @DimNumTemp NVARCHAR(50)= ( SELECT  DimNum
                                                    FROM    #ConTable
                                                    WHERE   ID = @count
                                                  );
                DECLARE @DimName NVARCHAR(50)= ( SELECT TableName + ''
                                                        + CoName
                                                 FROM   dbo.Tbl_AnsCom_DIimToTable
                                                 WHERE  DimNum = ( SELECT
                                                              DimNum
                                                              FROM
                                                              #ConTable
                                                              WHERE
                                                              ID = @count
                                                              )
                                               );
               
                                               
             ------------------------------------------------创建维度临时表-------------------------------------------------------        
                SET @sql += 'CREATE TABLE #' + @DimNumTemp
                    + '([ID] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY, 
                    DimNum NVARCHAR(50),
                    DimQJ NVARCHAR(50),
                    Name NVARCHAR(500) DEFAULT '''',
                    BeginValue DECIMAL(18,4), 
                    EndValue DECIMAL(18,4),DiffValue decimal(18,4));'
                    + CHAR(10);
                    --PRINT '创建表：'+@sql
						SET @sql+='insert into #' + @DimNumTemp+ ' select '''+@DimNumTemp+''',NULL,Name,Beginvalue,Endvalue,Endvalue-Beginvalue from vw_'+@DimNumTemp+'_part where istrue='+CAST(@FixBCH AS NVARCHAR(2))

              -------------------------------------------------插入维度数据--------------------------------------------------------------------    
              --  SET @sql += 'select X,ID,SumTotal into #' + @DimNumTemp
              --      + 'ResultData from (select ' + @DimName
              --      + ' AS X, ROW_NUMBER() OVER (ORDER BY ' + @DimName
              --      + ' ) AS ID from #TempQuantileResult WHERE ' + @DimName
              --      + ' IS NOT NULL) a Cross join (select count(*) SumTotal from #TempQuantileResult WHERE '
              --      + @DimName + ' IS NOT NULL) b ' + CHAR(10);
              --      --PRINT '创建表1：'+@sql
              --  ---------------------------------------------根据传递的分区数量拼凑分区组合--------------------------------------------------------------------
              --  DECLARE @innerSelectNew NVARCHAR(MAX)= '';
              --  --SELECT * FROM #Num
              --  SET @innerSelectNew = 'SELECT  x0,'
              --      + ( SELECT  'x' + CAST(NumValue AS NVARCHAR(4)) + ','
              --          FROM    #Num
              --        FOR
              --          XML PATH('')
              --        ); 
              --        --PRINT '查询字段：'+@innerSelectNew
              --  SET @innerSelectNew = LEFT(@innerSelectNew,
              --                             LEN(@innerSelectNew) - 1);
              --  SET @sql += @innerSelectNew;  
              --  --PRINT '查询字段结果：'+@sql
              --  SET @sql += ' into #' + @DimNumTemp + 'result1 FROM    
              --  (  SELECT MIN(X) x0
              --       FROM   #' + @DimNumTemp + 'ResultData
              --     ) b
              --    CROSS JOIN ( SELECT MAX(X)+1 x'
              --      + CAST(@DataType AS NVARCHAR(4)) + '
              --       FROM   #' + @DimNumTemp + 'ResultData
              --     ) c' + CHAR(10);
              --  SET @sql += ( SELECT    'CROSS JOIN  (select X AS x'
              --                          + CAST(NumValue AS NVARCHAR(2))
              --                          + ' from #' + @DimNumTemp
              --                          + 'ResultData where ID=ROUND(SumTotal*'
              --                          + CAST(NumValue AS NVARCHAR(4)) + '/'
              --                          + CAST(@DataType AS NVARCHAR(4))
              --                          + ',0)) a'
              --                          + CAST(NumValue AS NVARCHAR(2))
              --                          + CHAR(10)
              --                FROM      #Num
              --                WHERE     NumValue < @DataType
              --              FOR
              --                XML PATH('')
              --              );
              --  DECLARE @t1 NVARCHAR(MAX)= '';
              --  SET @t1 = ''
              --      + ( SELECT  ' select ''' + @DimNumTemp + ''','
              --                  + CAST(NumValue AS NVARCHAR(10))
              --                  + ',''[''+CAST(x'
              --                  + CAST(NumValue-1 AS NVARCHAR(10))
              --                  + ' AS NVARCHAR(10)) +''-''+ CAST(x'
              --                  + CAST(NumValue  AS NVARCHAR(10))
              --                  + ' AS NVARCHAR(10))+'']'',x'
              --                  + CAST(NumValue - 1 AS NVARCHAR(10)) + ',x'
              --                  + CAST(NumValue AS NVARCHAR(10)) + ',x'
              --                  + CAST(NumValue AS NVARCHAR(10)) + '-x'
              --                  + CAST(NumValue - 1 AS NVARCHAR(10))
              --                  + ' from #' + @DimNumTemp
              --                  + 'result1 UNION ALL'
              --          FROM    #Num
              --        FOR
              --          XML PATH('')
              --        );
              --  SET @t1 = LEFT(@t1, LEN(@t1) - 9);
              --  SET @sql += 'insert into #' + @DimNumTemp + @t1 + CHAR(10);

                
              --  SET @sql += ' DROP TABLE #' + @DimNumTemp + 'ResultData  '
              --      + CHAR(10) + 'DROP TABLE #' + @DimNumTemp + 'result1'
              --      + CHAR(10);
                SET @count -= 1;
                --PRINT @count;
                --SET @sql=''
            END;
        --PRINT '插入组合数据'+@sql;
            
        DECLARE @Resultdata VARCHAR(MAX);
        DECLARE @ResultName VARCHAR(MAX)= '';
        SET @ResultName = ( SELECT  ',' + DimNum + ' varchar(100),' + DimNum
                                    + 'QJ varchar(100),' + DimNum
                                    + 'DiffValue decimal(18,4)'
                            FROM    #ConTable
                          FOR
                            XML PATH('')
                          );
        --PRINT '结果数据：' + @ResultName+@YValue;
       
        SET @Resultdata = ( SELECT  'CREATE TABLE #Resultdata
	   (ID int IDENTITY(1, 1) NOT NULL PRIMARY KEY
		' + ISNULL(@ResultName, '') + ',GY INT,' + @YValue + ' varchar(100) )'
                          );
        --PRINT '结果数据1 '+@Resultdata;
        
        DECLARE @Resultzj VARCHAR(MAX);
        SET @Resultzj = ( @Resultdata + ' insert into #Resultdata select '
                          + ( SELECT    DimNum + '.Name,' + DimNum + '.DimQJ,'
                                        + DimNum + '.DiffValue AS ' + DimNum
                                        + 'DiffValue,'
                              FROM      #ConTable
                            FOR
                              XML PATH('')
                            ) + 'GY,' + @YValue + ' from #TempQuantileResult '
                          + CHAR(10)
                          + ( SELECT    ' Left join #' + DimNum + ' AS '
                                        + DimNum + ' on #TempQuantileResult.'
                                        + DimYSQL + '>=' + DimNum
                                        + '.BeginValue and #TempQuantileResult.'
                                        + DimYSQL + '<' + DimNum + '.EndValue'
                                        + CHAR(10)
                              FROM      #ConTable
                            FOR
                              XML PATH('')
                            ) + 'where '
                          + ( SELECT    DimNum + '.Name is not NULL And '
                              FROM      #ConTable
                            FOR
                              XML PATH('')
                            ) );
                          --   + '1=1' + CHAR(10) + ' Group by ' + CHAR(10)
                          --+ ( SELECT    DimNum + '.Name,' + DimNum
                          --              + '.DiffValue,'
                          --    FROM      #ConTable
                          --  FOR
                          --    XML PATH('')
                          --  ) + 'GY,' + @YValue + CHAR(10) );
        SET @Resultzj = LEFT(@Resultzj, LEN(@Resultzj) - 4);
        SET @Resultzj = REPLACE(REPLACE(REPLACE(@Resultzj, '&amp;', '&'),
                                        '&gt;', '>'), '&lt;', '<');
        SET @sql += @Resultzj;
        --PRINT @Resultzj;
      -----------------------------------------------创建存储最终结果的表并将结果写入表内--------------------------------------
        DECLARE @CreateTable VARCHAR(MAX);
  
        SET @CreateTable = ( SELECT ' CREATE TABLE #Result1
	   (GoodValue int,
	    floatValue decimal(18,4),
	    PercentON NVARCHAR(10),
	    ComCount int,
		DataCount int
		' + ISNULL(@ResultName, '') + ')' + CHAR(10)
                           );
                           --PRINT '@CreateTable: '+@CreateTable
        DECLARE @ONRelation NVARCHAR(MAX)= '';
      
        SET @ONRelation += ( SELECT ' and a.' + DimNum + '=b.' + DimNum
                             FROM   #ConTable
                           FOR
                             XML PATH('')
                           );
         --PRINT @ONRelation                  
        DECLARE @GroupBy VARCHAR(500);

        SET @GroupBy = ( SELECT ',' + DimNum + ',' + DimNum + 'QJ,' + DimNum
                                + 'DiffValue'
                         FROM   #ConTable
                       FOR
                         XML PATH('')
                       );
        DECLARE @GroupBy1 VARCHAR(500);
        --SELECT * FROM #DimsTb
        SET @GroupBy1 = ( SELECT    DimNum + ',' + DimNum + 'QJ,' + DimNum
                                    + 'DiffValue,'
                          FROM      #ConTable
                        FOR
                          XML PATH('')
                        );
        SET @GroupBy = ISNULL(@GroupBy, '');
        SET @ONRelation = ISNULL(@ONRelation, '');
        SET @GroupBy1 = ISNULL(@GroupBy1, '');
        IF ( @GroupBy1 <> '' )
            DECLARE @groupBy2 NVARCHAR(500)= 'Group by ' + LEFT(@GroupBy1,
                                                              LEN(@GroupBy1)
                                                              - 1); 
        ELSE
            SET @groupBy2 = '';
         DECLARE @YValueName NVARCHAR(50)=''   
        SET @YValueName = 'CAST(' + @YValue + ' AS float)';
        --PRINT '@GroupBy: '+@GroupBy+'@GroupBy1: '+@GroupBy1+'@GroupBy2: '+@groupBy2
        --PRINT '目标维度'+@YValue
        SET @sql += @CreateTable
            + 'INSERT  INTO #Result1
        SELECT  ISNULL(a.DataCount,0) GoodValue ,
                ROUND(CAST(ISNULL(a.DataCount,0) AS FLOAT)
                      / ( CASE WHEN ISNULL(b.DataCount,0) = 0 THEN 1
                               ELSE ISNULL(b.DataCount,0)
                          END ) * 100, 4) floatValue ,
                CAST(ROUND(CAST(ISNULL(a.DataCount,0) AS FLOAT)
                           / ( CASE WHEN ISNULL(b.DataCount,0) = 0 THEN 1
                                    ELSE ISNULL(b.DataCount,0)
                               END ) * 100, 4) AS NVARCHAR(8)) +''%'' PercentON ,
                               c.DataCount ComCount,
                               
                b.*
        FROM    ( SELECT    
                            SUM(CASE WHEN ' + @YValueName + ' IS NOT NULL THEN 1
                                     ELSE 0
                                END) DataCount 
                            ' + @GroupBy + '
                  FROM      #Resultdata
                  WHERE     GY = 1
                  GROUP BY  ' + @GroupBy1 + '
                            GY
                ) a
                RIGHT JOIN ( SELECT  
                                    SUM(CASE WHEN ' + @YValueName + ' IS NOT NULL
                                             THEN 1
                                             ELSE 0
                                        END) DataCount 
                                    ' + @GroupBy + '
                            FROM    #Resultdata
                            ' + @groupBy2 + '
                          ) b ON 1 = 1
                                 ' + @ONRelation + '
                 CROSS JOIN (select  SUM(CASE WHEN ' + @YValueName + ' IS NOT NULL
                                             THEN 1
                                             ELSE 0
                                        END) DataCount  from #Resultdata) c'
            + CHAR(10);
            --PRINT @sql
        --PRINT @ReferenceValue;
        DECLARE @Detail VARCHAR(MAX) = 'select GoodValue,floatValue,DataCount ,PercentON,ComCount'
            + @GroupBy + ' INTO #RDetail From #Result1' + CHAR(10);
          --------------------------------------------将所有满足结果的数据写入到展示表里--------------------------------------------
        DECLARE @NameCh NVARCHAR(100)= ( SELECT '''' + DimID + ''','''
                                                + Name_ch + ''','  --'黏合剂pH值',配墨中PH1','
                                         FROM   #ConTable
                                                LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
                                       FOR
                                         XML PATH('')
                                       ); 
                                       --PRINT '汉字标题: '+@NameCh
        SET @NameCh = RIGHT(@NameCh, LEN(@NameCh) - 1);
		 DECLARE @NameChSet NVARCHAR(100)= ''''+( SELECT  DimID+','  --'黏合剂pH值',配墨中PH1','
                                         FROM   #ConTable
                                                LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
                                       FOR
                                         XML PATH('')
                                       )+''''
        SET @sql += @Detail;
        DECLARE @ResultSet NVARCHAR(500)= '';
        SET @ResultSet += 'insert into NewShowTable_'+CAST(@WDCount AS NVARCHAR(2))+'W_'+CAST(@DataType AS NVARCHAR(5))+'B_'+@SpName+'_'+@YValue+' SELECT '+CAST(@COUNTi AS NVARCHAR(5))+',''' + @NameCh
              + 'GoodValue,floatValue,PercentON,DataCount,ComCount,'''+CONVERT(varchar(100), GETDATE(), 21)+''','+@NameChSet + @GroupBy
               + ' from #RDetail' + CHAR(10);
               
        SET @sql += @ResultSet;
        --PRINT '详细: ' + @ResultSet;
        DECLARE @DropTable NVARCHAR(500)= 'DROP TABLE #RDetail' + CHAR(10)
            + 'DROP TABLE #TempQuantileResult' + CHAR(10)
            + 'DROP TABLE #Result1' + CHAR(10) + 'DROP TABLE #Resultdata'
            + CHAR(10) + ( SELECT   'DROP Table #' + DimNum + CHAR(10)
                           FROM     #ConTable
                         FOR
                           XML PATH('')
                         );
        --PRINT @sql
        EXEC(@sql+@DropTable);
        --SELECT  @sql + @DropTable
        --FOR     XML PATH('');
    END;
go

