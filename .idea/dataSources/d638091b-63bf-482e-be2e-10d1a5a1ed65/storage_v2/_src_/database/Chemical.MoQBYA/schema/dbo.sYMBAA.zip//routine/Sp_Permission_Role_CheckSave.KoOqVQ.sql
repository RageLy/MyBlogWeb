-- =============================================    
-- Author:  <曹乐平>    
-- Create date: <2014-06-25>    
-- Description: <角色保存检查>    
-- =============================================    
create PROCEDURE [dbo].[Sp_Permission_Role_CheckSave]    
 @RoleID varchar(500)=''    
 ,@RoleName varchar(500)=''   
 as     
 Begin     
set nocount on    
      
     if exists(select RoleName from dbo.Tbl_Sys_Role where RoleName=@RoleName and RoleID!=@RoleID  )    
      begin    
		select '角色名称不能重复！'    
      end    
      else    
      begin  

       select '0'    
      end     
  
   end
go

