-- =============================================
-- Author:		杨艺
-- Create date: 2016-03-29
-- Description:	回归算法计算
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Reg_eInk]

	@RegNum		VARCHAR(100)		--回归计算的批次编号 
,	@YXNum		VARCHAR(100)		--回归计算的油相编号
,	@t8Min		DECIMAL(12,2) 		--温度8的初始值			
,	@t8Max		DECIMAL(12,2) 		--温度8的最大值
,	@t8Interval	DECIMAL(12,2) 		--温度8的间隔值

,	@t41Min			DECIMAL(12,2) 	--温度41的初始值	
,	@t41Max			DECIMAL(12,2) 	--温度41的最大值
,	@t41Interval	DECIMAL(12,2) 	--温度41的间隔值

,	@s41Min			DECIMAL(12,2) 	--速度41的初始值	
,	@s41Max			DECIMAL(12,2) 	--速度41的最大值
,	@s41Interval	DECIMAL(12,2) 	--速度41的间隔值

,	@t25Min			DECIMAL(12,2) 	--温度25的初始值	
,	@t25Max			DECIMAL(12,2) 	--温度25的最大值
,	@t25Interval	DECIMAL(12,2) 	--温度25的间隔值

,	@s25Min			DECIMAL(12,2) 	--速度25的初始值	
,	@s25Max			DECIMAL(12,2) 	--速度25的最大值
,	@s25Interval	DECIMAL(12,2) 	--速度25的间隔值



AS
BEGIN


-- 验证回归编号是否重复和油箱是否存在

IF EXISTS(SELECT * FROM dbo.Reg_eCapsule WHERE RegNum = @RegNum)
BEGIN
	SELECT '回归编号已存在！';
	RETURN;
END

IF NOT EXISTS(SELECT * FROM dbo.Tbl_Data_eCapsule WHERE YXNum = @YXNum)
BEGIN
	SELECT '油相编号不存在！';
	RETURN;
END


DECLARE @whileNum INT ,@t8 DECIMAL(12,2),@t25 DECIMAL(12,2),@t41 DECIMAL(12,2),@s25 DECIMAL(12,2),@s41 DECIMAL(12,2)
SET @whileNum = 1;


DECLARE @begintime DATETIME

SET @t8 = @t8Min;

WHILE (@t8 <= @t8Max) --@t8循环开始 判断运行次数
BEGIN
	
	SET @t25 = @t25Min;
	
	WHILE (@t25 <= @t25Max) 
	BEGIN
		
		SET @s25 = @s25Min;
		
		WHILE (@s25 <= @s25Max)
		BEGIN
			
			SET @t41 = @t41Min;
			
			WHILE (@t41 <= @t41Max)
			BEGIN
				
				SET @s41 = @s41Min;
				
				WHILE (@s41 <= @s41Max)
				BEGIN
				
					--SELECT @whileNum
					--各釜位评分
					INSERT dbo.Reg_eCapsule_Detail
							( RegNum ,YXNum ,Fu ,FStandardValue ,FValue ,FDeviationValue ,OutputValue ,
							  temp41a ,speed41a ,temp8a ,temp25a ,speed25a ,
							  temp41 ,speed41 ,temp8 , temp25 ,speed25 ,point,whileNum,
							  temp41sz ,speed41sz ,temp8sz ,temp25sz ,speed25sz,
							  t8,t25,t41,s25,s41
							)
					SELECT 
						@RegNum,e.YXNum,e.Fu,e.FStandradValue,e.FValue ,
						ISNULL(e.OutputValueml/(NULLIF(e.FValue,0)/NULLIF(e.FStandradValue,0)),0),e.OutputValueml,
						e.Temp41,e.Speed580,e.Temp8,e.Temp25,e.Speed,41.5,580,8.0,25.0,404.0,
						ISNULL(e.OutputValueml/(NULLIF(e.FValue,0)/NULLIF(e.FStandradValue,0)),0) 
						- (e.Temp41 - 41.5 )*@t41 
						- (e.Speed580 - 580)*@s41 
						- (e.Temp8 - 8.0 )*@t8 
						- (e.Temp25 - 25.0)*@t25 
						- (e.Speed - 404.0)*@s25,
						@whileNum,
						(e.Temp41 - 41.5)*@t41 * -1  --  每个工艺参数造成的偏差
						,(e.Speed580 - 580)*@s41 * -1
						,(e.Temp8 - 8.0)*@t8  * -1
						,(e.Temp25 - 25.0)*@t25  * -1
						,(e.Speed - 404.0)*@s25 * -1
						--- 每个工艺参数当前的值
						,@t8
						,@t25
						,@t41
						,@s25
						,@s41
						
					FROM dbo.Tbl_Data_eCapsule AS e
					WHERE YXNum = @YXNum
					
					
					
					--PRINT '回归编号：' + CAST(@RegNum AS VARCHAR(10)) + '；子编号：' + CAST(@whileNum AS VARCHAR(10) ) + ' 完成;'
					

					SET @whileNum += 1
					
					-- 重新调整系数，添加偏离值
					SET @s41 += @s41Interval;
				END	
					  
				-- 重新调整系数，添加偏离值
				SET @t41 = @t41 + @t41Interval;
			END
			
			-- 重新调整系数，添加偏离值
			SET @s25 = @s25 + @s25Interval;
		
		END 
		
		-- 重新调整系数，添加偏离值
		SET @t25 = @t25 + @t25Interval;
		
	END 
	
  -- 重新调整系数，添加偏离值
  SET @t8 = @t8 + @t8Interval;
  
END --循环结束



			--计算各油相平均分数
			--UPDATE dbo.Reg_eCapsule_Detail
			--SET avgPoint = ISNULL((SELECT AVG(point) 
			--					   FROM dbo.Reg_eCapsule_Detail AS d 
			--					   WHERE d.YXNum = dbo.Reg_eCapsule_Detail.YXNum),0)
			--WHERE RegNum = @RegNum 
			--  AND whileNum = @whileNum
			--  AND dbo.Reg_eCapsule_Detail.YXNum = @YXNum


            UPDATE  a
            SET     avgPoint = a.n ,
                    DiscreteValue = ABS(ISNULL(( point - a.n ) / NULLIF(a.n, 0),
                                               0))
            FROM    ( SELECT    AVG(point) OVER ( PARTITION BY whileNum ) AS n,*
                      FROM      dbo.Reg_eCapsule_Detail
                      WHERE     RegNum = @RegNum
                                AND YXNum = @YXNum
                    ) a
			
			
			--得出各个油相的离散度总和
			INSERT  dbo.Reg_eCapsule ( LValue,YXNum ,LSD ,RegNum,whileNum ,c_temp8 ,c_temp25 ,c_temp41 ,c_speed25 ,c_speed41 ,cTime)
			
			SELECT avgPoint,@YXNum,ISNULL(SUM(DiscreteValue),0),@RegNum,whileNum,t8,t25,t41,s25,s41,GETDATE() 
			FROM dbo.Reg_eCapsule_Detail 
			WHERE RegNum = @RegNum AND YXNum = @YXNum
			GROUP BY whileNum,t8,t41,t25,s41,s25,avgPoint

			
			

END
go

