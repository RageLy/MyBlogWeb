-- =============================================
-- Author:		杨艺
-- Create date: 2016-04-05
-- Description:	三次回归计算查找最佳C值
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Reg_eInk_Primary]
	@YXNum		VARCHAR(100)	--油相名称
,	@t8Min		DECIMAL(12,2) 		--温度8的初始值			
,	@t8Max		DECIMAL(12,2) 		--温度8的最大值
,	@t8Interval	DECIMAL(12,2) 		--温度8的间隔值

,	@t41Min			DECIMAL(12,2) 	--温度41的初始值	
,	@t41Max			DECIMAL(12,2) 	--温度41的最大值
,	@t41Interval	DECIMAL(12,2) 	--温度41的间隔值

,	@s41Min			DECIMAL(12,2) 	--速度41的初始值	
,	@s41Max			DECIMAL(12,2) 	--速度41的最大值
,	@s41Interval	DECIMAL(12,2) 	--速度41的间隔值

,	@t25Min			DECIMAL(12,2) 	--温度25的初始值	
,	@t25Max			DECIMAL(12,2) 	--温度25的最大值
,	@t25Interval	DECIMAL(12,2) 	--温度25的间隔值

,	@s25Min			DECIMAL(12,2) 	--速度25的初始值	
,	@s25Max			DECIMAL(12,2) 	--速度25的最大值
,	@s25Interval	DECIMAL(12,2) 	--速度25的间隔值
AS
BEGIN
	
	-- 每组最佳C值
	DECLARE @t41 DECIMAL(12,2),@s41 DECIMAL(12,2),@t8 DECIMAL(12,2),@t25 DECIMAL(12,2),@s25 DECIMAL(12,2)
	-- 三次的回归编号
	DECLARE @regNum1 VARCHAR(100),@regNum2 VARCHAR(100),@regNum3 VARCHAR(100)
	
	-- 时间记录
	DECLARE @beginTime DATETIME
	
	SET @beginTime = GETDATE();
	
	SET @regNum1 = 'Reg1' + RIGHT(CAST(RAND() AS VARCHAR(200)),6);
	SET @regNum2 = 'Reg2' + RIGHT(CAST(RAND() AS VARCHAR(200)),6);
	SET @regNum3 = 'Reg3' + RIGHT(CAST(RAND() AS VARCHAR(200)),6);
	
	
	-- 第一组 温度和速度进行回归计算-------------------------------
	EXEC dbo.Sp_Reg_eInk 
		@RegNum = @regNum1, -- varchar(100)
	    @YXNum = @YXNum, -- varchar(100)
	    @t8Min = 0, -- decimal
	    @t8Max = 0, -- decimal
	    @t8Interval = 1, -- decimal
	    @t41Min = @t41Min, -- decimal
	    @t41Max = @t41Max, -- decimal
	    @t41Interval = @t41Interval, -- decimal
	    @s41Min = @s41Min, -- decimal
	    @s41Max = @s41Max, -- decimal
	    @s41Interval = @s41Interval, -- decimal
	    @t25Min = 0, -- decimal
	    @t25Max = 0, -- decimal
	    @t25Interval = 1, -- decimal
	    @s25Min = 0, -- decimal
	    @s25Max = 0, -- decimal
	    @s25Interval = 1 -- decimal
	
	--保存本次回归计算的时长，单位秒
	INSERT dbo.Reg_Datetime
	        ( RegNum, whileNum, regDatetime )
	SELECT @regNum1,0,DATEDIFF(s,@beginTime,GETDATE());
	
	-- 得到第一组最佳的C值 t41和s508
	SELECT TOP 1 @t41 = c_temp41,@s41 = c_speed41
	FROM dbo.Reg_eCapsule 
	WHERE YXNum = @YXNum AND RegNum = @regNum1 
	ORDER BY LSD ASC
	
	-- 设置时间
	SET @beginTime = GETDATE();
	
	-- 第二组 温度和速度进行回归计算-------------------------------
	EXEC dbo.Sp_Reg_eInk 
		@RegNum = @regNum2, -- varchar(100)
	    @YXNum = @YXNum, -- varchar(100)
	    @t8Min = @t8Min, -- decimal
	    @t8Max = @t8Max, -- decimal
	    @t8Interval = @t8Interval, -- decimal
	    @t41Min = @t41, -- decimal
	    @t41Max = @t41, -- decimal
	    @t41Interval = @t41Interval, -- decimal
	    @s41Min = @s41, -- decimal
	    @s41Max = @s41, -- decimal
	    @s41Interval = @s41Interval, -- decimal
	    @t25Min = 0, -- decimal
	    @t25Max = 0, -- decimal
	    @t25Interval = 1, -- decimal
	    @s25Min = 0, -- decimal
	    @s25Max = 0, -- decimal
	    @s25Interval = 1 -- decimal
	
	--保存本次回归计算的时长，单位秒
	INSERT dbo.Reg_Datetime
	        ( RegNum, whileNum, regDatetime )
	SELECT @regNum1,0,DATEDIFF(s,@beginTime,GETDATE());
	
	-- 得到第二组最佳的C值 t8
	SELECT TOP 1 @t8 = c_temp8
	FROM dbo.Reg_eCapsule 
	WHERE YXNum = @YXNum AND RegNum = @regNum2
	ORDER BY LSD ASC
	
	-- 设置时间
	SET @beginTime = GETDATE();
	
	-- 第三组 温度和速度进行回归计算-------------------------------
	EXEC dbo.Sp_Reg_eInk 
		@RegNum = @regNum3, -- varchar(100)
	    @YXNum = @YXNum, -- varchar(100)
	    @t8Min = @t8, -- decimal
	    @t8Max = @t8, -- decimal
	    @t8Interval = @t8Interval, -- decimal
	    @t41Min = @t41, -- decimal
	    @t41Max = @t41, -- decimal
	    @t41Interval = @t41Interval, -- decimal
	    @s41Min = @s41, -- decimal
	    @s41Max = @s41, -- decimal
	    @s41Interval = @s41Interval, -- decimal
	    @t25Min = @t25Min, -- decimal
	    @t25Max = @t25Max, -- decimal
	    @t25Interval = @t25Interval, -- decimal
	    @s25Min = @s25Min, -- decimal
	    @s25Max = @s25Max, -- decimal
	    @s25Interval = @s25Interval -- decimal
	
	--保存本次回归计算的时长，单位秒
	INSERT dbo.Reg_Datetime
	        ( RegNum, whileNum, regDatetime )
	SELECT @regNum1,0,DATEDIFF(s,@beginTime,GETDATE());
	
	-- 得到第三组最佳的C值 t25和s404
	SELECT TOP 1 @t25 = c_temp25,@s25 = c_speed25
	FROM dbo.Reg_eCapsule 
	WHERE YXNum = @YXNum AND RegNum = @regNum3
	ORDER BY LSD ASC
	

	
	PRINT ' 本次回归计算 c_temp41:' + CAST(@t41 AS VARCHAR(10)) + ' c_speed580:' + CAST(@s41 AS VARCHAR(10))
	PRINT '              c_temp8:' + CAST(@t8 AS VARCHAR(10))
	PRINT '              c_temp25:' + CAST(@t25 AS VARCHAR(10)) + ' c_speed:' + CAST(@s25 AS VARCHAR(10))
	

END
go

