-- =============================================  
-- Description: 获取常用菜单储过程  
-- =============================================   
CREATE proc[dbo].[sp_sys_getMyMenu]    
 @EmpID  int='-1'    
AS    
BEGIN    
 select     
 'MyMenuId'MyMenuId    
 ,'MenuId'[MenuId]    
 ,'MenuTitle'[MenuTitle]    
 ,'MenuIcon'[MenuIcon]    
 ,'Condition' [Condition]    
 ,'HumenString' HumenString    
 ,'OtherCond' OtherCond  
 union all    
 select     
 'varchar,200'    
 ,'varchar,200'    
 ,'varchar,200'    
 ,'varchar,200'    
 ,'varchar,200'    
 ,'varchar,200'  
  ,'varchar,200'    
 union all    
 select     
 CONVERT(varchar(50),MyMenuId)    
 ,[menuId]    
 ,[menuTitle]    
 ,[menuIcon]    
 ,isnull(Condition,'')    
 ,isnull(HumenString,'')    
 ,isnull(OtherCond,'')   
 from tbl_sys_myMenu where empId=@EmpID    
END
go

