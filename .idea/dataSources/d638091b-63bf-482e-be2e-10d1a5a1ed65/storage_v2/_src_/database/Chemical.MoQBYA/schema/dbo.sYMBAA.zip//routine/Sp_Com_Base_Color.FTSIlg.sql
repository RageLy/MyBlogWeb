-- =============================================                    
-- Author:  thm                   
-- Create date: <2014-1-10>                    
-- Description: <售前车色下拉框>                    
-- =============================================               
--exec [Sp_Web_DropDownList_CarSeries]         
CREATE PROCEDURE [dbo].[Sp_Com_Base_Color]               
AS              
BEGIN                
  select                 
  '0' ID,                
  '请选择' Name                
 union all              
 select               
  CAST (ColorId as varchar(500)) ID,              
  cast (Name as varchar(500)) Name              
 from Tbl_Base_Color a               
 where isnull(IsBan,0) <> 1     
END
go

