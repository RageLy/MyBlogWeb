
/*
刘轶 2014-8-5 展厅新增检查 编辑
*/
CREATE proc [dbo].[sp_ExhibitionAddCheck_InEdit]    
@EmpID varchar(50)=''    
,@CPlan varchar(50)=''    
as    
begin    
    
if(@EmpID ='')    
begin    
 select '销售员ID不能为空！'    
 return    
end    
if(@CPlan = '')    
begin    
 select '标准不能为空！'    
 return    
end    
if(ISNUMERIC(@CPlan)  = 0)    
begin    
 select '标准只能为数字！'    
 return    
end    
    
update Tbl_Com_Employee set CPlan = @CPlan where EmpID =@EmpID    
select '0'    
    
    
    
end
go

