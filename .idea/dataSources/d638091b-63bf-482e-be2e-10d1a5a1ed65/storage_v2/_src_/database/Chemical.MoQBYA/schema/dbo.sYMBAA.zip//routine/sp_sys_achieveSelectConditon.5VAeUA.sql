-- =============================================
--陈建波  
--查询保存的搜索条件  
--2015.11.6  
-- =============================================

create procedure [dbo].[sp_sys_achieveSelectConditon]  
   @EmpID  int='-1'  
as  
  
begin
select * from TBL_SaveSelectConditon where EmpId=@EmpID 
 end


go

