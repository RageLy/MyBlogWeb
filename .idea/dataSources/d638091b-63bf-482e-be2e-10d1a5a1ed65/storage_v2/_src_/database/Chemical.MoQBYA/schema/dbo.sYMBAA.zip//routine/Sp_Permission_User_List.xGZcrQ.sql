    
-- =============================================        
-- Author:  <曹乐平>        
-- Create date: <2014-06-23>        
-- Description: <系统账户信息>        
-- =============================================        
CREATE PROCEDURE [dbo].[Sp_Permission_User_List]        
@PageIndex varchar(50)='1'    
,@PageSize varchar(50)='16'    
,@OrderFields varchar(50)='UserID desc'    
,@EmpName VARCHAR(50)=''    
,@UserAccount  VARCHAR(50)=''    
,@DeptName  VARCHAR(50)=''    
,@BusinessName VARCHAR(50)=''   
as         
Begin         
set nocount on        
if @OrderFields =''    
begin    
 set @OrderFields ='UserID desc'    
end    
      
 select         
 cast(b.UserID as varchar(50)) UserID      
 ,cast(a.EmpID as varchar(50)) EmpID    
 ,a.EmpNo    
 ,a.EmpName UserName    
 ,cast(a.DeptID as varchar(50)) DepartMentID      
 ,cast(c.DeptName as varchar(500))  DeptName    
 ,b.UserAccount    
 ,b.UserPassword    
 ,e.RoleName  
 ,h.BusinessName     
     into #Result    
  from Tbl_Com_Employee a           
  left join Tbl_Sys_User b on a.UserID=b.UserID        
  left join Tbl_Com_Dept c on a.DeptID = c.DeptID      
  left join Tbl_Sys_UserRoleRelation d on b.UserID = d.UserID    
  left join Tbl_Sys_Role e on d.RoleID=e.RoleID    
  left join Tbl_Com_EmployeeBusiness as h on a.BusinessId = h.BusinessId   
  where 1=1 --and isnull(a.EmployeeStateID,0)!=2    
  and EmpName !='admin'    
  AND(@EmpName='' OR a.EmpName LIKE '%'+@EmpName+'%' OR a.EmpNo LIKE '%'+@EmpName+'%' )     
  AND (@UserAccount='' OR b.UserAccount LIKE '%'+@UserAccount+'%')    
  AND (@DeptName='' OR c.DeptName LIKE '%'+@DeptName+'%')    
  AND (@BusinessName='' OR h.BusinessName LIKE '%'+@BusinessName+'%')   
    
         
--调用通用分页      
declare @pageCount int =@@ROWCOUNT       
exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize              
    
End
go

