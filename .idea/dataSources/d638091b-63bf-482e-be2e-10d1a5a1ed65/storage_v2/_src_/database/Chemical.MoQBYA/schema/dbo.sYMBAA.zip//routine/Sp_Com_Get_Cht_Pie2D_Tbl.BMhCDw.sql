
/***********************************  
--饼图出列表 传入 出图的结果集名称 需满足 列名为 Name 和 num  
--THM   
************************************/  
CREATE Proc [dbo].[Sp_Com_Get_Cht_Pie2D_Tbl]    
@TableName varchar(50) = '#Result'  --数据临时表名称  
,@OrderFields varchar(50)='num'  --排序字段  
,@NameColumnName varchar(50)= '名称' -- 分组列中文列名    
,@NumColumnName varchar(50)= '数量'  -- 数量列中文列名  
,@RateColumnName varchar(50)= '比例'  -- 比例列中文列名  
as    
BEGIN    
if(@OrderFields = '')    
set @OrderFields = 'Name'    
if(CHARINDEX(@OrderFields,'Rate',0)<>-1)    
set @OrderFields = REPLACE(@OrderFields,'Rate','num')    
    create table #Tmp_Result
 (
 n int
 ,Name varchar(50)
 ,num int
 ,Rate decimal(18,2)
 ) 
declare @Sql varchar(Max)=''    
set @sql='    
select ''n'' as 序号    
,''Name'' as '+@NameColumnName+'    
,''num'' as '+@NumColumnName+'    
,''Rate'' as '+@RateColumnName+'    
union all    
select ''varchar 200'' as 序号    
,''varchar 200'' as '+@NameColumnName+'    
,''varchar 200'' as '+@NumColumnName+'    
,''varchar 200'' as '+@RateColumnName+' 

 
 declare @Sum int = 0;
select @Sum = SUM(num) from '+@TableName+'; 
insert into #Tmp_Result  (n,Name,num,Rate)   
select ROW_NUMBER() over(order by '+@OrderFields+') as n,cast(Name as varchar(50)) as Name    
,num    
,case when @Sum<>0 then num/ CAST(@Sum AS decimal(18,2))*100 else 100 end Rate        
from '+@TableName+'    
order by '+ @OrderFields+';
   
 if  exists (select * from '+@TableName+') 
BEGIN 
select n,Name,num,cast(cast(Rate as decimal(18,2)) as varchar(50))+''%'' as Rate from #Tmp_Result    
union all     
select count(1)+1 as n ,''合计'' as Name    
,Sum(num) as num , ''100%'' as Rate from #Tmp_Result
END
ELSE 
BEGIN
select null as n,null as Name,null as num ,null as Rate from '+@TableName+'
END  
'    
print @sql    
exec(@sql)    
END
go

