
-- =============================================  
-- Description: <保存角色的权限信息>  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_AuthSave]  
 -- Add the parameters for the stored procedure here  
 @roleid varchar(50)='',  
 @authdata varchar(max),  
 @webconfig VARCHAR(500)=''  
AS  
BEGIN  
SET NOCOUNT ON;  
   
 delete from Tbl_Sys_Permission   
 where PermissionID in  
 (  
  select PermissionID from  
  Tbl_Sys_TrPemission a   
  where a.TacticsID in  
   (  
    select d.TacticsID from  
    Tbl_Sys_RoleTactics c   
    left join Tbl_Sys_Tactics d on d.TacticsID=c.TacticsID   
    where c.RoleID=@roleid   
   )  
 )  
   
 delete from Tbl_Sys_Tactics   
 where TacticsID in  
 (  
  select d.TacticsID from  
  Tbl_Sys_RoleTactics c   
  left join Tbl_Sys_Tactics d on d.TacticsID=c.TacticsID   
  where c.RoleID=@roleid  
 )AND ISNULL(WebConfig,'') = @webconfig  
   
  
   
 delete from Tbl_Sys_TrPemission   
 where TacticsID in  
 (  
  select d.TacticsID from  
  Tbl_Sys_RoleTactics c   
  left join Tbl_Sys_Tactics d on d.TacticsID=c.TacticsID   
  where c.RoleID=@roleid  
 )  
   
 delete from Tbl_Sys_RoleTactics  
 where RoleID=@roleid AND ISNULL(WebConfig,'') = @webconfig   
  
--select * from Tbl_Sys_Role  
 declare @Tactics table  
 (  
  s varchar(MAX)  
 )  
   
 declare @TacticTable table  
 (  
 StartIndex INT,  
  s varchar(MAX)  
 )    
 insert into @Tactics select [string] from dbo.split(@authdata,'&')  
 DECLARE @parentFormid VARCHAR(max)='',@Parent_TacticsID VARCHAR(50) = '0' ,@FromCom VARCHAR(50)=''  
   
 declare @Tactic varchar(MAX)  
 declare Tactic_cursor cursor for  
 select s from  @Tactics    
 open Tactic_cursor  
 FETCH NEXT FROM Tactic_cursor   
 INTO @Tactic    
 WHILE @@FETCH_STATUS = 0  
 BEGIN  
    
  delete from @TacticTable  
  insert into @TacticTable select StartIndex,[string] from dbo.split(@Tactic,'|')  
  ----------------------------------  
  --SELECT * FROM @TacticTable  
  ----------------------------------  
  DECLARE @SystemType VARCHAR(50) ='BS'  
    
  SELECT TOP 1 @FromCom =  s FROM @TacticTable WHERE StartIndex =0   
  SELECT @parentFormid = s FROM @TacticTable WHERE StartIndex =1   
  IF(@FromCom = '')  
  BEGIN  
   SET @Parent_TacticsID ='0'  
  END  

  IF(CHARINDEX('CS_',@parentFormid)>0)  
   SET @SystemType ='CS'  
  else IF(CHARINDEX('Android_',@parentFormid)>0)  
   SET @SystemType ='Android'  
   
     print '-----------------*****'+@parentFormid+'+++++'+@SystemType
  -----------------------------------  
  declare @sql varchar(MAX)=''    
  declare @cell varchar(MAX)  
  declare cell_cursor cursor for  
  select s from  @TacticTable    
  open cell_cursor  
  FETCH NEXT FROM cell_cursor   
  INTO @cell    
  WHILE @@FETCH_STATUS = 0  
  BEGIN  
     
   set @sql=@sql+''''+@cell+''','  
     
   FETCH NEXT FROM cell_cursor   
   INTO @cell  
  end  
  CLOSE cell_cursor  
  DEALLOCATE cell_cursor  
    
  set @sql=SUBSTRING(@sql,0,len(@sql))  
  if @sql<>''''''  
  begin     
    
   set @sql='insert into Tbl_Sys_Tactics (FormID,MenuID,AuthLevel,TacticsName,Parent_TacticsID,SystemType,WebConfig) values ('  
   +@sql+','+@Parent_TacticsID+','''+@SystemType+''','''+@webconfig+''')'    
   print @sql   
       
   exec(@sql)  
   declare @id int  
   set @id=@@IDENTITY  
     
   --print @Parent_TacticsID  
   --PRINT '----------'+@FromCom+'------------'  
   --------------------------  
   IF(ISNULL(@FromCom,'') = '')  
      BEGIN  
      --PRINT '*********'+@FromCom+CAST( @id AS VARCHAR(50))  
   SELECT @Parent_TacticsID = CAST( @id AS VARCHAR(50))  
      END  
      ---------------------------  
   insert into Tbl_Sys_RoleTactics(RoleID,TacticsID,WebConfig) values (@roleid,@id,@webconfig)  
     
  end  
    
  FETCH NEXT FROM Tactic_cursor   
  INTO @Tactic  
 end  
 CLOSE Tactic_cursor  
 DEALLOCATE Tactic_cursor  
  
 select '0'  
END
go

