  
  
  
  
  
  

-- =============================================                            
-- Author: hjl                                            
-- Create Date: 2016年7月18日  
-- Edit Date: 2016年7月18日                                                  
-- Descript: 原材料、检测参数等check工具  
  
-- =============================================  
  
CREATE PROCEDURE [dbo].[Sp_Analysister_CheckCount]  
  @condition VARCHAR(MAX)='Dim7:Y:this10%DimSinYX:-1%DimOilSeries:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-1%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDelt
aBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimSinJNPH:-1%DimSinBG0002:-1%DimOilDensity:-1%DimOilSTension:-1'  
 ,@OtherCond VARCHAR(MAX) ='%BK颜料%釜%胶囊产值%line%平均值%温度8%数量'  
 ,@Type VARCHAR(10) = '图' -- '业务列表'  业务列表表示用于展示业务的列表  
 ,@OrderFields VARCHAR(50) = ''  
 ,@EmpID INT = 1  
 ,@PageIndex VARCHAR(5)='1'  
 ,@PageSize VARCHAR(5)='15'  
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'  
AS  
BEGIN  
  
---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------              
  
 SET NOCOUNT ON;  
  
    DECLARE @SiftValue VARCHAR(MAX);  
    SET @SiftValue=REPLACE(@condition,'|',',');  
      
    DECLARE @Usertitle VARCHAR(50) = ''          -- 标题              
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称                  
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称                  
    DECLARE @YName VARCHAR(50) = ''               -- @OtherCond  传入的Y轴名称                  
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                  
    DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                  
  
    DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式                    
  
    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                  
  
 IF(@Type <> '业务列表')  
 BEGIN  
  DECLARE @OtherCondTbl TABLE              
  (              
   ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY              
   ,String NVARCHAR(50)              
   )              
     
  INSERT INTO @OtherCondTbl  
   SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')  
  
   SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )  
   SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )  
   SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )  
   SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)  
   SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)  
   SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)  
     END  
     -- OtherCond解析完毕              
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------              
      
----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                         
      
  
 -- 时间表 时间临时表必然需要  
    CREATE TABLE #time              
    (              
      id VARCHAR(200) ,              
      beginDate DATETIME ,              
      endDate DATETIME ,              
      beginDate_Lp DATETIME ,              
      endDate_Lp DATETIME ,              
      beginDate_Ly DATETIME ,              
      endDate_Ly DATETIME              
    )  
   
 -- 如果有其它需要用 #时间表的必须在这里添加  
   
    DECLARE @InnerSelect VARCHAR(max) = ''; -- 用于拼接@Sql中 Y轴的取表字段              
    DECLARE @XOrder VARCHAR(500);      -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序              
    DECLARE @DsOrder VARCHAR(500);     -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序              
    DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg                
    DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句              
 DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句  
   
  
 -- 处理维度临时表  
    CREATE TABLE #Dims  
   (  
  DimName varchar(50)  
  ,DimValues varchar(max)  
  ,ChName varchar(50)  
  ,Isneed varchar(50)  
  ,DimOrdersql varchar(50)  
  ,DimYsql varchar(50)  
  ,isrange varchar(50)  
   );  
       
     EXEC [Sp_Com_GetdimensionTable]  
     @SiftValue = @SiftValue  
 ,@XName = ''  
 ,@DsName = '';  
       
       
  
     -- 拼接创建维度临时表的语句  
  
       
    SET @sql += ( SELECT 'CREATE TABLE #' +  DimName +   
     -- 非范围维度类型3列  
     CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'  
     -- 范围维度类型5列  
       WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'    
     END  
  FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );  
      
    IF @sql is null  
  set @sql = '';  
      
 DECLARE @NeedSiftvalue VARCHAR(MAX)= '';  
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析  
       
     -- 用 Dims 临时表拼接需要解析的 维度字符串  
     SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));  
       
     IF @NeedSiftvalue is null  
  set @NeedSiftvalue = '';  
       
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %  
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue   
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;  
  
     -- 解析维度  
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';  
       
    
---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                          
                 
------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------               
      
    DECLARE @Dims varchar(50);  
    -- 在XML中修改  
    DECLARE @SpName VARCHAR(50) = CASE  
  WHEN @XName = 'BK颜料' THEN 'PigmentBKcheck'  
  WHEN @XName = 'W颜料' THEN 'PigmentWcheck'  
  WHEN @XName = 'BK粒子' THEN 'PigmentBK'  
  WHEN @XName = 'W粒子' THEN 'PigmentW'  
  WHEN @XName = '油相' THEN 'OilCheck'  
  WHEN @XName = '单层胶囊' THEN 'SinCapsuleCheck'  
  WHEN @XName = '双层胶囊' THEN 'DouCapsuleCheck'  
  WHEN @XName = '墨水' THEN 'MsDynamicCheck'  
  WHEN @XName = '涂布' THEN 'MsTBCheck'  
  ELSE ''  
  END  
    ;  
      
    IF @SpName = ''  
    BEGIN  
  SELECT 'sp配置有问题';  
  RETURN;  
    END  
      
 declare @TimeName varchar(50);   -- 用于判断时间的标志  
          
         
 set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName)  
   
 IF(@TimeName = '' OR @TimeName IS NULL)  
 BEGIN  
  SELECT '找不到时间配置字段'  
  RETURN;  
 END  
   
 DECLARE @Xcolumn VARCHAR(50) = ISNULL( (SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'X'),'dbo.GetTimeName(t.begindate,t.enddate)');  -- 横轴在本表上面的列名,如果没有说明是时间维度  
 DECLARE @Gcolumn VARCHAR(50) = ISNULL( (SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'G'),'dbo.GetTimeName(t.begindate,t.enddate)');  -- 分组在本表上面的列名，如果没有说明是时间维度  
 DECLARE @Ycolumn VARCHAR(50) = ISNULL( (SELECT DimYsql FROM #Dims WHERE ChName = @YName ),'');  -- Y轴在本表上面的列名  
-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------                
   
    
 -- 处理select语句  
   
 SET @InnerSelect =  
 (  
  SELECT ',' + TableName + '.' + CoName + ' AS ' + TableName + CoName  FROM Tbl_AnsCom_DIimToTable  
  WHERE CoType = '原材料' AND CHARINDEX(',' + @SpName + ',',SpType) > 0  
  ORDER BY ShowIndex FOR XML PATH('')  
 );  
   
   
   
 --SET @InnerSelect = SUBSTRING(@InnerSelect,2,LEN(@InnerSelect));  
 -- 加入时间和编号两个列  
 SET @InnerSelect = (SELECT 'CONVERT(varchar(100),' + TimeName + ',20) '+REPLACE(@TimeName,'.','')+',' + CodeName + ' Code' FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName)  
 + @InnerSelect;  
   
 --select @InnerSelect;  
 -- 处理 select 数量的语句   
 DECLARE @CountSelect VARCHAR(MAX) = ''  
 SET @CountSelect =  
 (  
  SELECT ',CAST(COUNT( DISTINCT ' + TableName + CoName + ' ) AS varchar(50)) AS ' + TableName + CoName  FROM Tbl_AnsCom_DIimToTable  
  WHERE CoType = '原材料' AND CHARINDEX(',' + @SpName + ',',SpType) > 0  
  ORDER BY ShowIndex FOR XML PATH('')  
 );  
   
 --SET @CountSelect = SUBSTRING(@CountSelect,2,LEN(@CountSelect));  
    -- 加入时间和编号两个列  
 SET @CountSelect = 'CAST(COUNT(distinct ' + REPLACE(@TimeName,'.','') + ' ) as varchar(50)) as '+REPLACE(@TimeName,'.','')+',CAST(Count(distinct Code) as varchar(50)) as Code'  
 + @CountSelect;  
   
   -- 构造列名  
     
   DECLARE @CoChNames VARCHAR(MAX) ;  
     
   SET  @CoChNames =  
    (  
  SELECT ',''' + TableName + CoName + ''' AS [' + ISNULL(TableName_ch,'') + Name_ch + ']' FROM Tbl_AnsCom_DIimToTable  
  WHERE CoType = '原材料' AND CHARINDEX(',' + @SpName + ',',SpType) > 0  
  ORDER BY ShowIndex FOR XML PATH('')  
 );  
   
 --SET @CoChNames = SUBSTRING(@CoChNames,2,LEN(@CoChNames));  
 -- 加入时间和编号两个列  
 SET @CoChNames = ''''+REPLACE(@TimeName,'.','')+''' as 时间,''Code'' AS [' + @XName + '编号]'  
 + @CoChNames;  
   
   
    DECLARE @Varchar500s VARCHAR(MAX) ;  
     
    SET  @Varchar500s =  
    (  
  SELECT ',''Varchar 500''' FROM Tbl_AnsCom_DIimToTable  
  WHERE CoType = '原材料' AND CHARINDEX(',' + @SpName + ',',SpType) > 0  
  ORDER BY ShowIndex FOR XML PATH('')  
 );  
    --SET @Varchar500s = SUBSTRING(@Varchar500s,2,LEN(@Varchar500s));  
 -- 加入时间和编号两个列  
 SET @Varchar500s = '''Varchar 500'',''Varchar 500'''  
 + @Varchar500s;  
   
   
   set @sql +=   
   '  
    SELECT DISTINCT ';  
    
 DECLARE @FromSql VARCHAR(max) = (SELECT JoinTables  + ' ' +BaseTable FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName);  
   
 IF(@FromSql IS NULL OR @FromSql = '')  
 BEGIN  
  SELECT 'sp配置有问题';  
  RETURN;  
 END  
    
 SET @sql += ISNULL(@InnerSelect,'') + ' INTO #Result FROM '  + @FromSql;  
  
   -----------------------------------------------------  
   -- 按照是否需要的表格拼装对应的表格  
    
   -- 时间维表一定需要 放在可能会取到时间的表之后   
  IF(CHARINDEX('Dim7',@SiftValue) <> 0)             
 SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';              
    
  -- 临时存储拼接的SQL语句  
  DECLARE @sql1 VARCHAR(max) = '';  
    
  -- 将INNER JOIN 维度临时表段拼接起来  
  SET @sql1 = ( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' +   
   -- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’  
  CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql  
   -- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID  
  ELSE DimName + '.ID = ' + DimYsql END  
  FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));  
    
   -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来  
  SET @sql1 = REPLACE(REPLACE(@sql1,'&lt;','<'),'&gt;','>') ;  
    
  -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'  
  SET @sql += isnull( @sql1,'');  
    
    
   -- 默认使用时间排序  
  IF(@OrderFields IS NULL OR @OrderFields = '')  
 SET @OrderFields = REPLACE(@TimeName,'.','');  
  PRINT @TimeName  
    
    
    
   --获取批次条数的语句  
   DECLARE @Pagesql VARCHAR(MAX) =    
  '  SELECT ' + @CountSelect + ' FROM #Result   
     UNION ALL  
  SELECT * FROM #Result'  
   
     --获取批次条数的语句  
 --  DECLARE @Pagesql VARCHAR(MAX) =    
 -- '    
 --    INSERT INTO #Result  
 --SELECT ' + @CountSelect + ' FROM #Result ;  
 -- '  
  
   
   
 -- set @Pagesql +=    
 --'  DECLARE @totalRow int = (Select count(1) FROM #Result) ;  
 -- EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                          
 -- ,@fldName = ''' + @OrderFields + '''                                 
 -- ,@rowcount = @totalRow     
 -- ,@PageIndex = ' + @PageIndex + '      
 -- ,@PageSize = ' + @PageSize + '      
 -- ,@SumType = 0  
 -- ,@SumColumn = ''    
 -- ,@AvgColumn = ''    
 --'    
    
  -- 注销临时表  
 SET @sql += isnull ( ( SELECT ' DROP TABLE #' +  DimName + ';'  
  FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') ) , '');  
   
  print ( @sql + @Pagesql);  
  --PRINT @SqlName;  
  -- 运行处表头  
  --PRINT @Varchar500s;  
  PRINT(' SELECT ' + @CoChNames + ' UNION ALL SELECT ' + @Varchar500s);  
  EXEC(' SELECT ' + @CoChNames + ' UNION ALL SELECT ' + @Varchar500s);  
  EXEC(@sql + @Pagesql);  
    
   
 -- 注销临时表  
 DROP TABLE #time;  
 DROP TABLE #Dims;  
  
END
go

