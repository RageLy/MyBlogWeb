-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Help_GetCreateDimStringNotNumNotID] 
@DimNum NVARCHAR(500) = 'DimParticalZeta', --如果 DimNum =null 则默认 = 'Dim_'+@DimTableName   注意：该字符串不能包含“_” eg: DimTHMCS  或者 DimCS      
@Name_ch NVARCHAR(500) ='粒子Zeta电位值',   --维度中文现在名称      
@DimLevel Nvarchar(500) ='0,2,5', --数值维度 选项集合类型和倍数； 0 选项集合类型  
@DimLevel_str NVARCHAR(500) ='选项集合类型,倍数2,倍数5' ,  --一级筛选显示其对应 @DimLevel  
@AtYSql NVARCHAR(500) = 'Zeta' , -- 表上面的取值
@TableName nvarchar(30)='Bs_Partical' --维度表名来源
AS        
BEGIN        

SET NOCOUNT ON;

IF EXISTS (SELECT 1 FROM Tbl_AnsCom_DIimToTable WHERE DimNum = RTRIM(LTRIM(@DimNum)) )
BEGIN
	SELECT '维度已存在！'
	--RETURN;
END
      
PRINT 'select * from VW_'+@DimNum+'_partAll'      
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'         
PRINT '-- DELETE Tbl_AnsCom_DIimToTable WHERE DimNum ='''+@DimNum+''''        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
     
PRINT 'Drop View VW_'+@DimNum+'_part'        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
PRINT 'Drop View VW_'+@DimNum+'_partAll'        

PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
--========================================================================================        
DECLARE @tableindex int=CHARINDEX('.',@AtYSql,0)
DECLARE @Atsql1 NVARCHAR(50)=substring(@AtYSql,@tableindex+1,LEN(@AtYSql)-@tableindex)
--PRINT @tableSql
DECLARE @Sql_DimToTable NVARCHAR(max)=''
--SET @Sql_DimToTable += CHAR(10) +'/*'

SET @Sql_DimToTable += CHAR(10) +'DELETE FROM dbo.Tbl_AnsCom_DIimToTable where DimNum = ''' + @DimNum + '''';

SET @Sql_DimToTable += CHAR(10) +'INSERT INTO dbo.Tbl_AnsCom_DIimToTable '         
SET @Sql_DimToTable += CHAR(10) +'( DimNum,ViewName,Name_ch,AllValue,DimLevel,isrange,AtYSql)'        
SET @Sql_DimToTable += CHAR(10) +'VALUES  ( '''+ @DimNum +''','''+ @DimNum +''','''+@Name_ch+''',-1,'  
SET @Sql_DimToTable += CHAR(10) +''''+@DimLevel_str+''',0,''' + @AtYSql + ''')'
-- SET @Sql_DimToTable += CHAR(10) +'*/'       
PRINT @Sql_DimToTable  -- sp_Help_GetCreateDimString        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'  
DECLARE @Sql_VWPart VARCHAR(max)=''        
        
    SET @Sql_VWPart += CHAR(10) + 'Create View VW_'+@DimNum+'_part'        
SET @Sql_VWPart += CHAR(10) + 'AS' 

SET @Sql_VWPart+=CHAR(10)+'SELECT  -1 AS Id ,'
SET @Sql_VWPart+=CHAR(10) +'''全部集合''AS Name ,'
SET @Sql_VWPart+=CHAR(10) +'''1'' AS istrue ,'
SET @Sql_VWPart+=CHAR(10) +'''属性集合'' 选项集合类型'
SET @Sql_VWPart+=CHAR(10) +' FROM    Tbl_AnsCom_DIimToTable AS b'
SET @Sql_VWPart+=CHAR(10) +' WHERE   DimNum = '''+@DimNum+''''
SET @Sql_VWPart+=CHAR(10) +' UNION ALL'
SET @Sql_VWPart+=CHAR(10) +' SELECT  x.ID AS Id ,'
SET @Sql_VWPart+=CHAR(10) +' CAST(x.'+@Atsql1+' AS VARCHAR(20)) AS Name ,'
SET @Sql_VWPart+=CHAR(10) +'''0'' AS istrue ,'
SET @Sql_VWPart+=CHAR(10) +'''基础刻度'' 选项集合类型'
SET @Sql_VWPart+=CHAR(10) +' FROM Tbl_AnsCom_DIimToTable b'
SET @Sql_VWPart+=CHAR(10) +' CROSS JOIN ( SELECT DISTINCT '
SET @Sql_VWPart+=CHAR(10) +@Atsql1+' ,ID'
SET @Sql_VWPart+=CHAR(10) +' FROM '+@TableName+'  WHERE '+@Atsql1+ ' IS NOT NULL ) x'               
SET @Sql_VWPart+=CHAR(10) +' WHERE DimNum = '''+@DimNum+''''
PRINT @Sql_VWPart

PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'  
DECLARE @Sql_VWPartall VARCHAR(max)=''   
SET @Sql_VWPartall+=CHAR(10)+'CREATE View VW_'+@DimNum+'_partAll'
SET @Sql_VWPartall+=CHAR(10)+'AS'
SET @Sql_VWPartall+=CHAR(10)+'SELECT  Id AS VWID ,Id ,Name'
SET @Sql_VWPartall+=CHAR(10)+'FROM    VW_'+@DimNum+'_part'
SET @Sql_VWPartall+=CHAR(10)+'WHERE   istrue = 0'
SET @Sql_VWPartall+=CHAR(10)+'UNION ALL'
SET @Sql_VWPartall+=CHAR(10)+'SELECT  -1 ,Id ,Name'
SET @Sql_VWPartall+=CHAR(10)+'FROM    VW_'+@DimNum+'_part'
SET @Sql_VWPartall+=CHAR(10)+'WHERE   istrue = 0'
PRINT @Sql_VWPartall
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'  
END
go

