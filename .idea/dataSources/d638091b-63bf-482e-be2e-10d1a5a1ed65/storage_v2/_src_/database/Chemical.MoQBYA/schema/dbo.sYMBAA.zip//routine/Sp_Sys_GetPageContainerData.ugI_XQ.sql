-- =============================================  
-- Author:  蒋睿智  
-- Create date: 2012-1-18  
-- Description: 通过容器名字获取相关信息进行加载  
-- =============================================  
CREATE proc [dbo].[Sp_Sys_GetPageContainerData]  
 -- Add the parameters for the stored procedure here  
 @ContainerName varchar(500),  
 @UserID int=0  
AS  
BEGIN  
 -- [test_Sp_Sys_GetContainerData] 'faceWeb',32  
 -- interfering with SELECT statements. select * from dbo.Tbl_Sys_Page b left join dbo.Tbl_Sys_PageContainer c on b.PageContainerID=c.PageContainerID  
 -- select * from Tbl_Sys_PageGroup where groupid='Grp_WokingS' and pagegroupid=268  
 SET NOCOUNT ON;  
  
 if((select COUNT(0) from dbo.Tbl_Sys_PageContainer where ContainerName=@ContainerName and UserID=@UserID and [Type]=2)=0)  
 begin  
  insert into dbo.Tbl_Sys_PageContainer (ContainerName,UserID,[Type],Remark) values(@ContainerName,@UserID,2,'首页面板')  
 end  
    -- Insert statements for procedure here  
      
    if((select COUNT(0) from dbo.Tbl_Sys_Page b   
 left join dbo.Tbl_Sys_PageContainer c on b.PageContainerID=c.PageContainerID  
 where c.ContainerName=@ContainerName and c.UserID=@UserID)>0)  
 begin  
   
 SELECT c.PageContainerID,a.PageGroupID, b.PageID,b.PageTitle,ISNULL(convert(int,b.IsBoard),0) as IsBoard,a.GroupID,a.GroupName
 ,a.Condition,a.HumenString,a.fullCondition,a.otherCond,a.SpParams,a.ColumnHide,d.sortgroupids ,a.form,A.UserTitle
 from dbo.Tbl_Sys_PageGroup a   
 right join dbo.Tbl_Sys_Page b on a.PageID=b.PageID  
 left join dbo.Tbl_Sys_PageContainer c on b.PageContainerID=c.PageContainerID  
 left join dbo.Tbl_sys_PageGrouppos d on a.PageID=d.pageid  
 where c.ContainerName=@ContainerName and c.UserID=@UserID  
 order by b.PageID, a.sort asc;  
 end  
 else  
 begin  
  select c.PageContainerID,  
  '' PageGroupID,  
  '' PageID,  
  '' PageTitle,  
  0 IsBoard,
  '' GroupID,  
  '' GroupName,  
  '' Condition,  
  ''HumenString,  
  ''FullCondition,  
  '' otherCond,  
  '' SpParams,  
  '' ColumnHide,  
  '' sortgroupids,
  ''  form,
  ''  UserTitle
  from dbo.Tbl_Sys_PageContainer c   
  where c.ContainerName=@ContainerName and c.UserID=@UserID  
 end  
END
go

