-- =============================================
-- Author:		<Author,,hmw>
-- Create date: <Create Date,,2017-12-22>
-- Description:	<Description,,数据全查询>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AllQuary]
    @SpName NVARCHAR(20) = '' ,
    @BeginTime NVARCHAR(10) = '' ,
    @EndTime NVARCHAR(10) = '' ,
    @Code NVARCHAR(50) ,
    @ExpNo NVARCHAR(50) = '' ,
    @RecipeName NVARCHAR(50) = '' ,
    @OrderFields VARCHAR(50) = '' ,
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15' ,
    @EmpID INT = '1'
AS
    BEGIN
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @SelectSql NVARCHAR(MAX) = '';
        DECLARE @SelectTitleSql NVARCHAR(MAX) = '';
        DECLARE @VarcharsSql NVARCHAR(MAX) = '';
        DECLARE @InnerSql NVARCHAR(MAX) = '';
        DECLARE @WhereSql NVARCHAR(MAX) = '';
        DECLARE @NewSpName NVARCHAR(50) = @SpName;
        DECLARE @ErrorRecord NVARCHAR(MAX) = '';
        --英文字段

      
            SET @SelectSql += (   SELECT   TableName + '.[' + CoName + '] AS '
                                           + TableName + CoName + ','
                                  FROM     dbo.Tbl_AnsCom_DIimToTable
                                  WHERE    MainTable = @NewSpName
                                  ORDER BY ShowIndex
                                  FOR XML PATH('')
                              );

        SET @SelectSql = '' + @NewSpName + '.ID,'
                         + LEFT(@SelectSql, LEN(@SelectSql) - 1);
        --PRINT @SelectSql;
        --中文字段
        
            SET @SelectTitleSql += (   SELECT   '''' + TableName + CoName
                                                + ''' AS ''' + Name_ch + ''','
                                       FROM     dbo.Tbl_AnsCom_DIimToTable
                                       WHERE    MainTable = @NewSpName
                                       ORDER BY ShowIndex
                                       FOR XML PATH('')
                                   );
        SET @SelectTitleSql = 'select ''n'' As ''序号'',''ID'' AS ''ID'','
                              + LEFT(@SelectTitleSql, LEN(@SelectTitleSql)
                                                      - 1);
        --PRINT @SelectTitleSql;
        
            SET @VarcharsSql += 'union all select ''Varchar 500'',''Varchar 500'''
                                +   (   SELECT   ',''Varchar 500'''
                                        FROM     dbo.Tbl_AnsCom_DIimToTable
                                        WHERE    MainTable = @NewSpName
                                        ORDER BY ShowIndex
                                        FOR XML PATH('')
                                    );

        --连接字符串
        DECLARE @tempSpName NVARCHAR(50) = @SpName;
        
        SET @InnerSql += (   SELECT 'SELECT ' + @SelectSql
                                    + ' into #Result FROM ' + JoinTables
                                    + CHAR(10) + BaseTable + CHAR(10)
                             FROM   dbo.Tbl_AnsCom_AnaSpConfig
                             WHERE  SpName = @tempSpName
                         );
        IF (   (   SELECT ISNULL(JoinTables, '') + ISNULL(BaseTable, '')
                   FROM   Tbl_AnsCom_AnaSpConfig
                   WHERE  SpName = @tempSpName
               ) = ''
           )
            BEGIN
                SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables,BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = ''' + @SpName
                                    + '''结果为空 ,可能导致报错,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_AllQuary' , -- SpName - nvarchar(50)
                           @ErrorRecord ,  -- ErrorInto - nvarchar(1000)
                           'Exec Sp_AllQuary @PageIndex = ''' + @PageIndex
                           + ''' ,
                                @PageSize = ''' + @PageSize
                           + ''' ,
                                @OrderFields = ''' + @OrderFields
                           + ''' ,
                                @Code = ''' + @Code
                           
                               
                           + ''' ,@BeginTime=''' + @BeginTime
                           + ''',@EndTime=''' + @EndTime + ''',@SpName'''
                           + @SpName + ''',@EmpID='''
                           + CAST(@EmpID AS NVARCHAR(2)) + '''',
                           GETDATE()       -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;
        --PRINT @SpName+@OtherCode
        --PRINT @InnerSql;
        IF (   @BeginTime <> ''
               OR @EndTime <> ''
               OR @Code <> ''
               OR @ExpNo <> ''
               OR @RecipeName <> ''
           )
            BEGIN
                SET @WhereSql += 'Where ';
                PRINT @WhereSql;
                IF ( @BeginTime <> '' )
                    SET @WhereSql += @NewSpName + '.OptDate>='''
                                     + CONVERT(NVARCHAR(120), @BeginTime, 23)
                                     + ''' and ';
                IF ( @EndTime <> '' )
                    SET @WhereSql += @NewSpName + '.OptDate<='''
                                     + CONVERT(NVARCHAR(120), @EndTime, 23)
                                     + ''' and ';
                IF (   
                        @Code <> ''
                   )
                    SET @WhereSql += (SELECT CodeName FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName=@SpName)+' like ''%' + @Code
                                     + '%'' and ';
                                     IF(@SpName='Experiments')
                                     SET  @WhereSql+=@SpName+'.Expno like ''%'+@ExpNo+'%'' and '+@SpName+'.CodeNo like ''%'+@Code+'%'' and '+@SpName+'.RecipeName like ''%'+@RecipeName+'%'' and '
               
                SET @WhereSql = LEFT(@WhereSql, LEN(@WhereSql) - 3);
                PRINT @WhereSql;
            END;
        IF (   @OrderFields IS NULL
               OR @OrderFields = ''
                 
           )
            SET @OrderFields = REPLACE((SELECT CodeName FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName=@SpName), '.', '');
        ELSE
            SET @OrderFields = REPLACE('ID', '.', '');


        DECLARE @Pagesql VARCHAR(MAX) = '  DECLARE @totalRow int = (Select count(1) FROM #Result) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow   
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''  
  ,@AvgColumn = ''  
 '      ;
        SET @sql += @InnerSql + @WhereSql;
        --SELECT @SelectTitleSql + @VarcharsSql+@sql+@Pagesql;
        EXEC ( @SelectTitleSql + @VarcharsSql );
        PRINT @sql;
        EXEC ( @sql + @Pagesql );

        INSERT INTO Tbl_Log_AnaUseLog (   EmpID ,
                                          freshTime ,
                                          spName ,
                                          AnaName ,
                                          siftvalue ,
                                          OherParemeter ,
                                          EmpName
                                      )
        VALUES ( @EmpID ,
                 GETDATE(),
                 'Sp_AllQuery' ,
                 @SpName + '数据管理',
                 'select' ,
                 @BeginTime + @EndTime + @Code + @RecipeName+@ExpNo,
                 (   SELECT EmpName
                     FROM   Tbl_Com_Employee
                     WHERE  EmpID = @EmpID
                 )
               );
    END;

go

