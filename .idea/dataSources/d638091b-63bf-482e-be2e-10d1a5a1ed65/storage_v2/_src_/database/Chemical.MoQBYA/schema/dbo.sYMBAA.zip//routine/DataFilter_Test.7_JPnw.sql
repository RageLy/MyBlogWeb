
--EXEC [DataFilter_Test] 1222,3,3,'SinCapsule','Oil','SinCapsuleOutPut',0,10,80,20,'163','124|125|126|127|135|136|137|138|139|140|148|149|409|410|411|412|413|414|415|416|417|418|419|420|421|422|423|424|425|426|427|428|429|430|163|165|166|168|170|155|158|159|160|161|162|173|174'



CREATE PROCEDURE [dbo].[DataFilter_Test]
    @DataID INT = 1222 ,                         --原始数据的ID
    @WDCount INT = 3 ,                           --维度数
    @BC INT = 3 ,                                --步长数
    @SpType NVARCHAR(20) = 'SinCapsule' ,        --数据源
    @SubTable NVARCHAR(20) = 'Oil' ,             --数据源的上一级数据源
    @YValue NVARCHAR(100) = 'SinCapsuleOutPut' , --目标维度
    @TargetValue INT = 0 ,
    @GoodValueTarget INT = 10 ,
    @GoodTargetValue INT = 80 ,
    @BadTargetValue INT = 20 ,
    @LeftTarget NVARCHAR(100) = '163' ,          --主分析维度在Tbl_AnsCom_DIimToTable的ID号
    @WDChar NVARCHAR(500) = '124|125|126|127|135|136|137|138|139|140|148|149|409|410|411|412|413|414|415|416|417|418|419|420|421|422|423|424|425|426|427|428|429|430|163|165|166|168|170|155|158|159|160|161|162|173|174'
AS
    BEGIN
        --SELECT CHARINDEX(@LeftTarget,@WDChar,0)
        -----------------------------截取ID字段----------------------------------------
        DECLARE @SpitStr NVARCHAR(500) = '';
        SET @SpitStr = LEFT(@WDChar, CHARINDEX(@LeftTarget, @WDChar, 0) - 2);
        --SELECT @SpitStr
        ------------------------------维度数量的循环--------------------------------
        CREATE TABLE #Num
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                NumValue NVARCHAR(2)
            );
        DECLARE @tempNum INT = @WDCount;
        WHILE ( @tempNum > 0 )
            BEGIN
                --PRINT @tempNum;
                INSERT INTO #Num ( NumValue )
                VALUES ( @tempNum );

                SET @tempNum -= 1;
            END;
        --SELECT *
        --FROM   #Num;
        ------------------------------创建排列组合数---------------------------------------------------
        CREATE TABLE #SortTb
            (
                ID INT IDENTITY(1, 1) NOT NULL ,
                SortValue NVARCHAR(20)
            );
        DECLARE @SortSelectSql NVARCHAR(MAX) = 'select '
                                               + (   SELECT   'a' + NumValue
                                                              + '.NumValue + '','' + '
                                                     FROM     #Num
                                                     WHERE    NumValue < @WDCount
                                                     ORDER BY NumValue ASC
                                                     FOR XML PATH(''));
        SET @SortSelectSql = LEFT(@SortSelectSql, LEN(@SortSelectSql) - 7)
                             + ' SortValue ';
        --SELECT *
        --FROM   #Num;
        DECLARE @SortInnerSql NVARCHAR(MAX) = 'from #Num a1' + CHAR(10)
                                              + (   SELECT   'inner join (select * from #Num) a'
                                                             + CAST(CAST(NumValue AS INT)
                                                                    + 1 AS NVARCHAR(3))
                                                             + ' on a'
                                                             + CAST(CAST(NumValue AS INT)
                                                                    + 1 AS NVARCHAR(3))
                                                             + '.ID<a'
                                                             + NumValue + '.ID'
                                                             + CHAR(10)
                                                    FROM     #Num
                                                    WHERE    NumValue < @WDCount
                                                                        - 1
                                                    ORDER BY NumValue ASC
                                                    FOR XML PATH(''));
        DECLARE @SortSql NVARCHAR(MAX) = @SortSelectSql + @SortInnerSql;
        SET @SortSql = REPLACE(REPLACE(@SortSql, '&gt;', '>'), '&lt;', '<');
        INSERT INTO #SortTb ( SortValue )
        EXEC ( @SortSql );
        --SELECT *
        --FROM   #SortTb;
        PRINT @SortSql;
        ----------------------------------------------最终循环的表------------------------------------------------------

        CREATE TABLE #SortResult
            (
                Id INT IDENTITY(1, 1) NOT NULL ,
                OldId INT ,
                Value NVARCHAR(10)
            );
        DECLARE @CountNew INT = 1;
        DECLARE @Sum INT = (   SELECT COUNT(*)
                               FROM   #SortTb );
        WHILE ( @CountNew <= @Sum )
            BEGIN
                DECLARE @OldValue NVARCHAR(20) = (   SELECT SortValue
                                                     FROM   #SortTb
                                                     WHERE  ID = @CountNew );
                INSERT INTO #SortResult ( OldId ,
                                          Value )
                            SELECT @CountNew ,
                                   string
                            FROM   dbo.f_splitSTR(@OldValue, ',');
                SET @CountNew += 1;
            END;
        --SELECT *
        --FROM   #SortResult;
        ---------------------------------------------拆分维度区间---------------------------------------------------
        DECLARE @QJZdAddsql NVARCHAR(MAX) = '';
        DECLARE @QJZdupdatesql NVARCHAR(MAX) = '';
        --SET @QJZdAddsql += (   SELECT   ' if not exists(select * from syscolumns where id=object_id(''NewShowTableID_'
        --                                + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
        --                                + CAST(@BC AS NVARCHAR(2)) + 'B_'
        --                                + @SpType + '_' + @YValue
        --                                + ''') and name=''W' + NumValue
        --                                + 'downValue'') begin ALTER TABLE NewShowTableID_'
        --                                + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
        --                                + CAST(@BC AS NVARCHAR(2)) + 'B_'
        --                                + @SpType + '_' + @YValue + ' ADD W'
        --                                + NumValue + 'downValue FLOAT; end '
        --                                + CHAR(10)
        --                                + ' if not exists(select * from syscolumns where id=object_id(''NewShowTableID_'
        --                                + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
        --                                + CAST(@BC AS NVARCHAR(2)) + 'B_'
        --                                + @SpType + '_' + @YValue
        --                                + ''') and name=''W' + NumValue
        --                                + 'upValue'') begin ALTER TABLE NewShowTableID_'
        --                                + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
        --                                + CAST(@BC AS NVARCHAR(2)) + 'B_'
        --                                + @SpType + '_' + @YValue + ' ADD W'
        --                                + NumValue + 'upValue FLOAT; end'
        --                                + CHAR(10)
        --                       FROM     #Num
        --                       ORDER BY NumValue ASC
        --                       FOR XML PATH(''));
        SET @QJZdupdatesql += (   SELECT   'UPDATE NewShowTableID_'
                                           + CAST(@WDCount AS NVARCHAR(2))
                                           + 'W_' + CAST(@BC AS NVARCHAR(2))
                                           + 'B_' + @SpType + '_' + @YValue
                                           + ' SET W' + NumValue
                                           + 'downValue = SUBSTRING(维度'
                                           + NumValue
                                           + '分区区间, 2, CHARINDEX(''-'', 维度'
                                           + NumValue + '分区区间,3) - 2) ,  W'
                                           + NumValue
                                           + 'upValue = SUBSTRING(维度'
                                           + NumValue
                                           + '分区区间 , CHARINDEX(''-'', 维度'
                                           + NumValue + '分区区间,3) + 1,LEN(维度'
                                           + NumValue
                                           + '分区区间) - CHARINDEX(''-'', 维度'
                                           + NumValue + '分区区间,3) - 1) where (w'
                                           + NumValue + 'downValue='''' or w'
                                           + NumValue
                                           + 'downValue is NULL) and (w'
                                           + NumValue + 'upValue='''' or w'
                                           + NumValue + 'upValue is NULL)'
                                           + CHAR(10)
                                  FROM     #Num
                                  ORDER BY NumValue ASC
                                  FOR XML PATH(''));
        --SELECT * FROM NewShowTableID_3W_3B_SinCapsule_SinCapsuleOutPut
        PRINT @QJZdAddsql;
        PRINT @QJZdupdatesql;
        EXEC ( @QJZdAddsql );
        EXEC ( @QJZdupdatesql );


        ---------------------获取表的查询字段列表-----------------------------------------------------------
        DECLARE @CoNameStr NVARCHAR(MAX) = '';
        DECLARE @OutVarCoNameStr NVARCHAR(MAX) = '';
        DECLARE @sqlCoNameStr NVARCHAR(MAX) = 'set @CoNameStr=(   SELECT CoName + '',''
                                       FROM   dbo.Tbl_AnsCom_DIimToTable
                                       WHERE  ID in ('
                                              + REPLACE(@SpitStr, '|', ',')
                                              + ') order by charindex('',''+convert(varchar,ID)+'','','''
                                              + REPLACE(@SpitStr, '|', ',')
                                              + ','')
                                       FOR XML PATH(''''))' + CHAR(10)
                                              + '
									   SET @CoNameStr = LEFT(@CoNameStr, LEN(@CoNameStr) - 1)';
        --SELECT @sqlCoNameStr;
        EXEC sp_executesql @sqlCoNameStr ,
                           N'@CoNameStr NVARCHAR(MAX) output' ,
                           @OutVarCoNameStr OUTPUT;
        SET @CoNameStr = @OutVarCoNameStr;
        PRINT '字段列表:' + @CoNameStr;

        ---------------------获取表的字段数量-------------------------------------------------------------------
        DECLARE @OutVarCount INT = 0;
        DECLARE @Count INT = 0;
        DECLARE @sqlCount NVARCHAR(MAX) = ' set @a=( SELECT COUNT(*)
                        FROM   dbo.Tbl_AnsCom_DIimToTable
                       where  ID in (' + REPLACE(@SpitStr, '|', ',') + '))';

        EXEC sp_executesql @sqlCount ,
                           N'@a int output' ,
                           @OutVarCount OUTPUT;
        SET @Count = @OutVarCount;
        PRINT '字段数量：' + CAST(@Count AS NVARCHAR(2));
        ----------------------------------------------输出一个表-------------------------------------------------------
        DECLARE @Table TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL ,
                CoName NVARCHAR(30)
            );
        DECLARE @sqlTable NVARCHAR(MAX) = ' 
            SELECT   CoName  
            FROM   dbo.Tbl_AnsCom_DIimToTable
           WHERE  ID in (' + REPLACE(@SpitStr, '|', ',')
                                          + ') order by charindex('',''+convert(varchar,ID)+'','','''
                                          + REPLACE(@SpitStr, '|', ',')
                                          + ','')';
        INSERT INTO @Table
        EXEC ( @sqlTable );

        -------------------------------------------------选维度------------------------------------------------------------
        DECLARE @WDTable TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL ,
                Name NVARCHAR(5)
            );
        INSERT INTO @WDTable
                    SELECT string
                    FROM   dbo.Split(@SpitStr, '|');

        --SELECT *
        --FROM   @WDTable;
        -------------------------------------------------建立表------------------------------------------------------------
        DECLARE @Result NVARCHAR(MAX) = '';
        SET @Result += ' CREATE TABLE #Temp
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL ,
              CoNameID INT ,
              CoName NVARCHAR(50) ,
              ZdValue FLOAT
            ); ' + (   SELECT 'SELECT ' + @CoNameStr
                              + ' into #tempBaseTable from ' + CHAR(10)
                              + JoinTables + ' WHERE  ' + @SpType + '.ID = '
                              + CAST(@DataID AS NVARCHAR(5)) + '' + CHAR(10)
                       FROM   dbo.Tbl_AnsCom_AnaSpConfig
                       WHERE  SpName = @SpType );
        --SELECT @CoNameStr
        DECLARE @vari INT = 1;
        WHILE ( @vari <= (   SELECT COUNT(*)
                             FROM   @WDTable ))
            BEGIN
                DECLARE @tempvarID NVARCHAR(3) = (   SELECT Name
                                                     FROM   @WDTable
                                                     WHERE  ID = @vari );
                DECLARE @tempvarName NVARCHAR(30) = (   SELECT CoName
                                                        FROM   @WDTable
                                                               LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.ID = [@WDTable].Name
                                                        WHERE  [@WDTable].ID = @vari );
                DECLARE @insertSql NVARCHAR(MAX) = 'insert INTO #Temp(CoNameID,CoName) values ('
                                                   + @tempvarID + ','''
                                                   + @tempvarName + ''') '
                                                   + CHAR(10);
                SET @vari += 1;
                SET @Result += @insertSql;
            END;

        -----------------------------------------------------开始循环更新字段的值----------------------------------------------------
        DECLARE @DataUpdateStr NVARCHAR(MAX) = '';
        DECLARE @Counti INT = 1;
        --SELECT *
        --FROM   @Table;
        WHILE ( @Counti <= @Count )
            BEGIN
                SET @DataUpdateStr += (   SELECT ' UPDATE  #Temp
        SET ZdValue = ( SELECT ' +            CoName
                                                 + ' FROM #tempBaseTable )
        WHERE ID = ''' +                      CAST(@Counti AS NVARCHAR(3))
                                                 + '''' + CHAR(10)
                                          FROM   @Table
                                          WHERE  ID = @Counti );
                SET @Counti += 1;
            END;
        SET @Result += @DataUpdateStr;
        SET @Result += ' select * from #Temp ';
        --PRINT @Result;
        --------------------------------------------------------基础数据源-----------------------------------------------------------------
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @LeftStr NVARCHAR(MAX) = '('
                                         + (   SELECT   ' 维度' + NumValue
                                                        + '编号 = ' + @LeftTarget
                                                        + ' or'
                                               FROM     #Num
                                               ORDER BY NumValue ASC
                                               FOR XML PATH(''));
        SET @LeftStr = LEFT(@LeftStr, LEN(@LeftStr) - 2) + ')';

        DECLARE @InnerStr NVARCHAR(MAX) = '';
        DECLARE @sqlSuper NVARCHAR(MAX) = '';
        SET @sql = ' select TB.ID,'
                   + (   SELECT   'TB.维度' + NumValue + '编号,TB.维度' + NumValue
                                  + ','
                         FROM     #Num
                         ORDER BY NumValue ASC
                         FOR XML PATH(''))
                   + 'TB.GoodValue AS 优等数据,TB.floatValue AS 优等数据占比,TB.DataCount AS 组合总数据,TB.ComCount AS 全总数据'
                   + (   SELECT   ',TB.维度' + NumValue + '分区区间,TB.维度' + NumValue
                                  + '分区区段,TB.维度' + NumValue + '区间差值'
                         FROM     #Num
                         ORDER BY NumValue ASC
                         FOR XML PATH('')) + CHAR(10)
                   + 'from (SELECT * FROM NewShowTableID_'
                   + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                   + CAST(@BC AS NVARCHAR(2)) + 'B_' + @SpType + '_'
                   + @YValue + ' WHERE ' + @LeftStr + ') TB' + CHAR(10);
        SET @InnerStr += (   SELECT   @sql
                                      + (   SELECT   'inner join #Temp W' + Value
                                                     + ' on 维度' + Value + '编号=W'
                                                     + Value + '.CoNameID and W'
                                                     + Value + '.ZdValue>W'
                                                     + Value + 'downValue and W'
                                                     + Value + '.ZdValue<=W'
                                                     + Value + 'upValue and W'
                                                     + Value + '.CoNameID<>'
                                                     + @LeftTarget + ''
                                                     + CHAR(10)
                                            FROM     #SortResult
                                            WHERE    OldId = NumValue
                                            ORDER BY OldId ASC
                                            FOR XML PATH(''))
                                      + ' where floatValue>='
                                      + CAST(@TargetValue AS NVARCHAR(3))
                                      + ' and GoodValue>='
                                      + CAST(@GoodValueTarget AS NVARCHAR(3))
                                      + '  union all '
                             FROM     #Num
                             ORDER BY NumValue ASC
                             FOR XML PATH(''));
        SET @InnerStr = REPLACE(
                            REPLACE(
                                REPLACE(@InnerStr, '&amp;', '&'), '&lt;', '<') ,
                            '&gt;' ,
                            '>');
        SET @InnerStr = LEFT(@InnerStr, LEN(@InnerStr) - 10);
        PRINT @InnerStr;
        SET @Result += @InnerStr;
        SET @Result += 'select * into #NewResult from (' + @InnerStr + ') a'
                       + CHAR(10);

        DECLARE @UnionSql NVARCHAR(MAX) = (   SELECT   '(select (case when a'
                                                       + NumTB.NumValue
                                                       + '.维度分区区段 is not null then a'
                                                       + NumTB.NumValue
                                                       + '.维度分区区段 else b'
                                                       + NumTB.NumValue
                                                       + '.维度分区区段 end) 维度分区区段,(case when a'
                                                       + NumTB.NumValue
                                                       + '.维度分区区间 is not null then a'
                                                       + NumTB.NumValue
                                                       + '.维度分区区间 else b'
                                                       + NumTB.NumValue
                                                       + '.维度分区区间 end) 维度分区区间,a'
                                                       + NumTB.NumValue
                                                       + '.优等维度分区区段数量,a'
                                                       + NumTB.NumValue
                                                       + '.优等平均值,b'
                                                       + NumTB.NumValue
                                                       + '.差等维度分区区段数量,b'
                                                       + NumTB.NumValue
                                                       + '.差等平均值 from (select '
                                                       + (   SELECT   ' 维度'
                                                                      + NumValue
                                                                      + '分区区段 AS 维度分区区段,维度'
                                                                      + NumValue
                                                                      + '分区区间 AS 维度分区区间,COUNT(维度'
                                                                      + NumValue
                                                                      + '分区区段) AS 优等维度分区区段数量,'
                                                                      + CHAR(10)
                                                             FROM     #Num
                                                             WHERE    NumValue = NumTB.NumValue
                                                             ORDER BY NumValue ASC
                                                             FOR XML PATH(''))
                                                       + 'avg(优等数据占比) 优等平均值 from #NewResult'
                                                       + CHAR(10)
                                                       + '  where 维度'
                                                       + NumValue + '编号 = '
                                                       + @LeftTarget
                                                       + ' and 优等数据占比>='
                                                       + CAST(@GoodTargetValue AS NVARCHAR(3))
                                                       + '  GROUP BY 维度'
                                                       + NumValue + '分区区段,维度'
                                                       + NumValue + '分区区间) a'
                                                       + NumValue
                                                       + ' full JOIN (SELECT  '
                                                       + (   SELECT   ' 维度'
                                                                      + NumValue
                                                                      + '分区区段 AS 维度分区区段,维度'
                                                                      + NumValue
                                                                      + '分区区间 AS 维度分区区间,COUNT(维度'
                                                                      + NumValue
                                                                      + '分区区段) AS 差等维度分区区段数量,'
                                                                      + CHAR(10)
                                                             FROM     #Num
                                                             WHERE    NumValue = NumTB.NumValue
                                                             ORDER BY NumValue ASC
                                                             FOR XML PATH(''))
                                                       + 'AVG(优等数据占比) 差等平均值 FROM #NewResult'
                                                       + CHAR(10)
                                                       + '  where 维度'
                                                       + NumValue + '编号 = '
                                                       + @LeftTarget
                                                       + ' and 优等数据占比<='
                                                       + CAST(@BadTargetValue AS NVARCHAR(3))
                                                       + ' GROUP BY 维度'
                                                       + NumValue + '分区区段,维度'
                                                       + NumValue + '分区区间) b'
                                                       + NumValue + ' ON a'
                                                       + NumValue
                                                       + '.维度分区区段 = b'
                                                       + NumValue
                                                       + '.维度分区区段 and a'
                                                       + NumValue
                                                       + '.维度分区区间 = b'
                                                       + NumValue + '.维度分区区间 )'
                                                       + CHAR(10)
                                                       + 'UNION all '
                                                       + CHAR(10)
                                              FROM     #Num NumTB
                                              ORDER BY NumValue ASC
                                              FOR XML PATH(''));
        SET @UnionSql = LEFT(@UnionSql, LEN(@UnionSql) - 11);
        SET @UnionSql = REPLACE(REPLACE(@UnionSql, '&gt;', '>'), '&lt;', '<');
        SET @Result += 'select * into #Result from (' + @UnionSql + ') t'
                       + CHAR(10);
        PRINT @UnionSql;
        DECLARE @sqlNew NVARCHAR(MAX) = CHAR(10)+'SELECT 维度分区区段,维度分区区间,isnull(sum(优等维度分区区段数量),0) 优等达标区间数量总计 ,isnull(avg(优等平均值),0) 优等达标区间平均胜率,isnull(sum(差等维度分区区段数量),0) 优等胜率过低区间数量总计,isnull(avg(差等平均值),0) 优等胜率过低区间平均胜率
 from #Result group by 维度分区区段,维度分区区间';
        SET @Result += @sqlNew;
        DROP TABLE #Num;
        EXEC ( @Result );
        --SELECT @Result;
    END;
go

