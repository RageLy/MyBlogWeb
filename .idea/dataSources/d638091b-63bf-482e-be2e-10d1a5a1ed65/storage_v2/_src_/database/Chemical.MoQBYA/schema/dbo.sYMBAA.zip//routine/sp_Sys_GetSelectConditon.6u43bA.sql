-- =============================================  
--查询保存的搜索条件   
-- =============================================  
create procedure [dbo].[sp_Sys_GetSelectConditon]    
   @EmpID  int='-1'    
as    
begin  
	select * from TBL_Sys_SaveSelectConditon where EmpId=@EmpID   
end
go

