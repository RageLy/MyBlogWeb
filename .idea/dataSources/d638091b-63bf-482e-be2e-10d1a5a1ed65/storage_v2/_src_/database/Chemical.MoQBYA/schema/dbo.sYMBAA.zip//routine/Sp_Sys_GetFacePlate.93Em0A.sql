
-- =============================================  
-- Author:  <龚炎>  
-- Create date: <2012-05-15>  
-- Description: <得到当前用户的面板类别>  
-- =============================================  
Create PROCEDURE [dbo].[Sp_Sys_GetFacePlate]  
 @UserId varchar(50)  
AS  
BEGIN  
  
 SET NOCOUNT ON;  
 --[Sp_Web_GetFacePlate] 49  
     select  
             'PageID'PageID,  
             'PageTitle'PageTitle  
             union all  
             select  
             'int'PageID,  
             'varchar,50'PageTitle  
             union all  
            select   
            cast(a.PageID as varchar(500))PageID,   
            cast(a.PageTitle as varchar(500))PageTitle from Tbl_Sys_Page a  
              left join Tbl_Sys_PageContainer b  
                 on  
               a.PageContainerID=b.PageContainerID  
               where b.UserID=@UserId and b.ContainerName='FaceWeb';  
  
END
go

