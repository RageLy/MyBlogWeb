-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-07-23>
-- Description:	<获取政治面貌>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Com_PoliticalStatus_List]
	@PageIndex varchar(50)='1',
    @PageSize varchar(50)='5',
    @OrderFields varchar(50)='PoliticalStatusID desc'
AS
BEGIN
	SET NOCOUNT ON;
	
		
if(@OrderFields='')
		set @OrderFields ='PoliticalStatusID desc'

	select 
	cast(PoliticalStatusID as varchar(500))  PoliticalStatusID   
	,PoliticalStatusName
	into #Result
	from Tbl_Com_PoliticalStatus
	
	if(@@ROWCOUNT=0)
	begin
		insert into #Result select '0',''
	end
	declare @pageCount int =@@ROWCOUNT 
	exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize 
END
go

