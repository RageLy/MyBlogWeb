-- =============================================
-- Author:		THM
-- Create date: 2014-09-12
-- Description:	分析器判断维度是否必须加入筛选
-- =============================================
CREATE FUNCTION [dbo].[GetDim_IsNeedInner]
(
 @XName varchar(500)='车系' 
,@DsName varchar(500)='工单类型'
,@ThisDimNum varchar(500)='Dim4'
,@SiftValue varchar(max)='Dim7:Y:this%Dim19:99999%Dim4:1000%Dim18:1000%Dim511:-99999%Dim512:-99999%Dim513:-99999%Dim514:-99999'
)
RETURNS int
AS
BEGIN
declare  @DimAllStr varchar(500)=''
		,@DimName_ch varchar(500)=''
		
select @DimAllStr = DimNum+':'+AllValue
	  ,@DimName_ch = Name_ch	 
from Tbl_AnsCom_DIimToTable where DimNum = @ThisDimNum	

if(@DimName_ch=@XName) return 1;
if(@DimName_ch = @DsName) return 2;

declare @SiftTbl TABLE          
(        
ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY        
,String Nvarchar(max)
)

insert into @SiftTbl select String from dbo.f_splitSTR(@SiftValue,'%')   

if not exists(select 1 from @SiftTbl where String = @DimAllStr) return 3;

return 0;

END
go

