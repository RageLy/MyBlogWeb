      
      
-- =============================================      
-- Author:  曹乐平      
-- Create date: 2011-11-21      
-- Description: 保存“我的常用菜单”中的条件      
-- =============================================      
CREATE proc[dbo].[Sp_Sys_SaveMyMenuCondition]      
 @MyMenuId varchar(200)      
 ,@Condition varchar(max)=''
 ,@HumenString varchar(max)=''
 ,@OtherCond varchar(max)=''
AS      
BEGIN      
 update tbl_sys_myMenu set Condition = @Condition,HumenString=@HumenString ,OtherCond=@OtherCond     
 where myMenuId = @MyMenuId      
END
go

