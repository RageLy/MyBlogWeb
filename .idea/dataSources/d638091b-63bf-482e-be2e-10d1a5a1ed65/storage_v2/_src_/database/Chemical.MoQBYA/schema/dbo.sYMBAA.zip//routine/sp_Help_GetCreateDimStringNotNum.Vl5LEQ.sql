-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_Help_GetCreateDimStringNotNum] 
@CoName NVARCHAR(500) = 'ParticalZeta', --如果 DimNum =null 则默认 = 'Dim_'+@DimTableName   注意：该字符串不能包含“_” eg: DimTHMCS  或者 DimCS 
@TableName NVARCHAR(50)='',   
@TableName_ch NVARCHAR(50)='',
@Name_ch NVARCHAR(500) ='粒子Zeta电位值',   --维度中文现在名称      
@DimLevel_str Nvarchar(500) ='基础数据', --数值维度 选项集合类型和倍数； 0 选项集合类型  
@SpName NVARCHAR(50)='',
@Valuesql NVARCHAR(100)='',
@AtYSql NVARCHAR(500) = 'Partical.Zeta',  -- 表上面的取值
@MainTable NVARCHAR(500) = '',  -- 用于什么地方的指标
@tag NVARCHAR(50)=''
AS        
BEGIN        

SET NOCOUNT ON;
DECLARE @DimNum NVARCHAR(100)='Dim'+@TableName+@CoName

IF EXISTS (SELECT 1 FROM Tbl_AnsCom_DIimToTable WHERE DimNum = RTRIM(LTRIM(@DimNum)) )
BEGIN
	SELECT '维度已存在！'
	--RETURN;
END
      
PRINT 'select * from VW_'+@DimNum+'_partAll'      
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'         
PRINT '-- DELETE Tbl_AnsCom_DIimToTable WHERE DimNum ='''+@DimNum+''''        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
     
PRINT 'Drop View VW_'+@DimNum+'_part'        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
PRINT 'Drop View VW_'+@DimNum+'_partAll'        

PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
--========================================================================================        
DECLARE @tableindex int=CHARINDEX('.',@Valuesql,0)
DECLARE @Valuesql1 NVARCHAR(50)=substring(@Valuesql,@tableindex+1,LEN(@Valuesql)-@tableindex)
--PRINT @tableSql
DECLARE @temptablename NVARCHAR(50)=substring(@Valuesql,0,@tableindex)
DECLARE @Sql_DimToTable NVARCHAR(max)=''
--SET @Sql_DimToTable += CHAR(10) +'/*'

SET @Sql_DimToTable += CHAR(10) +'IF NOT EXISTS (SELECT 1 FROM dbo.Tbl_AnsCom_DIimToTable where DimNum = ''' + @DimNum + ''') 
BEGIN ';

-- 添加配置行
SET @Sql_DimToTable += CHAR(10) +'INSERT INTO dbo.Tbl_AnsCom_DIimToTable '         
SET @Sql_DimToTable += CHAR(10) +'( DimNum,ViewName,Name_ch,CoName,TableName,TableName_ch,AllValue,DimLevel,BaseCount,CutInt,NumDecimal,SpType,isrange,AtYSql,IsDimBan,MainTable)'        
SET @Sql_DimToTable += CHAR(10) +'VALUES  ( '''+ @DimNum +''','''+ @DimNum +''','''+@Name_ch+''','''+@CoName+''','''+@TableName+''','''+@TableName_ch+''',-1,'  
SET @Sql_DimToTable += CHAR(10) +''''+@DimLevel_str+''',NULL,NULL,NULL,'''+@SpName+''',0,''' + @AtYSql + ''',0,'''+@MainTable+''')'


SET @Sql_DimToTable += ' 
END 
ELSE 
BEGIN '

SET @Sql_DimToTable += CHAR(10) +'UPDATE dbo.Tbl_AnsCom_DIimToTable SET ViewName = ''' + @DimNum + ''',Name_ch = ''' + @Name_ch + ''',CoName='''+@CoName+''',TableName='''+@TableName+''',TableName_ch='''+@TableName_ch+''',AllValue = -1,DimLevel = ''' 
+ @DimLevel_str + ''',BaseCount = NULL,CutInt = NULL,NumDecimal = NULL,SpType='''+@SpName+''',isrange =0,AtYSql = ''' + @AtYSql + ''',IsDimBan=0,MainTable='''+@MainTable+'''';

SET @Sql_DimToTable += CHAR(10) +'WHERE DimNum = ''' + @DimNum + '''';
SET @Sql_DimToTable += ' 
END
'
-- SET @Sql_DimToTable += CHAR(10) +'*/'       
PRINT @Sql_DimToTable  -- sp_Help_GetCreateDimString        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'  
DECLARE @Sql_VWPart VARCHAR(max)=''        
        
    SET @Sql_VWPart += CHAR(10) + 'Create View VW_'+@DimNum+'_part'        
SET @Sql_VWPart += CHAR(10) + 'AS' 

SET @Sql_VWPart+=CHAR(10)+'SELECT  -1 AS Id ,'
SET @Sql_VWPart+=CHAR(10) +'''全部集合''AS Name ,'
SET @Sql_VWPart+=CHAR(10) +'''1'' AS istrue ,'
SET @Sql_VWPart+=CHAR(10) +'''属性集合'' 选项集合类型'
SET @Sql_VWPart+=CHAR(10) +' FROM    Tbl_AnsCom_DIimToTable AS b'
SET @Sql_VWPart+=CHAR(10) +' WHERE   DimNum = '''+@DimNum+''''
SET @Sql_VWPart+=CHAR(10) +' UNION ALL'
SET @Sql_VWPart+=CHAR(10) +' SELECT  x.ID AS Id ,'
SET @Sql_VWPart+=CHAR(10) +' CAST(x.'+@Valuesql1+' AS VARCHAR(20)) AS Name ,'
SET @Sql_VWPart+=CHAR(10) +'''0'' AS istrue ,'
SET @Sql_VWPart+=CHAR(10) +'''基础刻度'' 选项集合类型'
SET @Sql_VWPart+=CHAR(10) +' FROM Tbl_AnsCom_DIimToTable b'
SET @Sql_VWPart+=CHAR(10) +' CROSS JOIN ( SELECT DISTINCT '
SET @Sql_VWPart+=CHAR(10) +@Valuesql1+' ,ID'
SET @Sql_VWPart+=CHAR(10) +' FROM '+@temptablename+'  WHERE '+@Valuesql1+ ' IS NOT NULL ) x'               
SET @Sql_VWPart+=CHAR(10) +' WHERE DimNum = '''+@DimNum+''''
PRINT @Sql_VWPart

PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'  
DECLARE @Sql_VWPartall VARCHAR(max)=''   
SET @Sql_VWPartall+=CHAR(10)+'CREATE View VW_'+@DimNum+'_partAll'
SET @Sql_VWPartall+=CHAR(10)+'AS'
SET @Sql_VWPartall+=CHAR(10)+'SELECT  Id AS VWID ,Id ,Name'
SET @Sql_VWPartall+=CHAR(10)+'FROM    VW_'+@DimNum+'_part'
SET @Sql_VWPartall+=CHAR(10)+'WHERE   istrue = 0'
SET @Sql_VWPartall+=CHAR(10)+'UNION ALL'
SET @Sql_VWPartall+=CHAR(10)+'SELECT -1,notall.Id,(SELECT Name FROM VW_'+@DimNum+'_part WHERE istrue = 1 )  FROM'
SET @Sql_VWPartall+=CHAR(10)+'(SELECT  Id AS VWID ,Id ,Name'
SET @Sql_VWPartall+=CHAR(10)+'FROM    VW_'+@DimNum+'_part'
SET @Sql_VWPartall+=CHAR(10)+'WHERE   istrue = 0) notall'
PRINT @Sql_VWPartall
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'  

 PRINT 'UPDATE dbo.Tbl_AnsCom_SelfDims SET selectdim=selectdim+'','+@DimNum+''',Allselectdim=Allselectdim+'','+@DimNum+''' where tag like ''%'+@tag+'%'''
END

go

