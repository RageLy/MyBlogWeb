  
  
  
  
-- =============================================          
--分析器维度调整  
-- =============================================       
       
CREATE PROCEDURE [dbo].[Sp_Distance_InEdit]
    @ID NVARCHAR(50) ,
    @GoodDownValue NVARCHAR(10) = '',
    @GoodUpValue NVARCHAR(10) = '' ,
    @BadDownValue NVARCHAR(10) = '' ,
    @BadUpValue NVARCHAR(10) = '' ,
    @EmpID VARCHAR(50) = '1'
AS
    BEGIN    
 --------------------- 变量声明  -------------------------    
        DECLARE @Column NVARCHAR(20)= '';  
        DECLARE @DistanceTypeStr NVARCHAR(500)= '';  
		DECLARE @DistanceTypeStrEsp NVARCHAR(500)= '';  
        DECLARE @GoodDownValueConvert NVARCHAR(20)= '';  
        DECLARE @BadDownValueConvert NVARCHAR(20)= '';  
        DECLARE @GoodUpValueConvert NVARCHAR(20)= '';  
        DECLARE @BadUpValueConvert NVARCHAR(20)= '';  
        DECLARE @SetCoName NVARCHAR(20)= '';  
        DECLARE @SetSpType NVARCHAR(20)= ''; 
		DECLARE @SetTableName NVARCHAR(20)= ''; 
  --      PRINT @BadDownValue;  
		--PRINT @GoodDownValue
		IF(@GoodDownValue='' OR @GoodDownValue IS NULL)
		BEGIN
		SELECT '请输入参数'
		return
		end
		IF(@GoodUpValue='' OR @GoodUpValue IS NULL)
		BEGIN
		SELECT '请输入参数'
		return
		end
		IF(@BadDownValue='' OR @BadDownValue IS NULL)
		BEGIN
		SELECT '请输入参数'
		return
		end
		IF(@BadUpValue='' OR @BadUpValue IS NULL)
		BEGIN
		SELECT '请输入参数'
		return
		end
        SET @Column = ( SELECT  CoName
                        FROM    dbo.Tbl_AnsCom_DIimToTable
                        WHERE   DimNum = @ID
                      );  
        SET @GoodDownValueConvert = CONVERT(NVARCHAR(20), ISNULL(CAST(@GoodDownValue AS DECIMAL),
                                                              0));  
        SET @BadDownValueConvert = CONVERT(NVARCHAR(20), ISNULL(CAST(@BadDownValue AS DECIMAL),
                                                              0));  
        SET @GoodUpValueConvert = CONVERT(NVARCHAR(20), ISNULL(CAST(@GoodUpValue AS DECIMAL), 0));  
        SET @BadUpValueConvert = CONVERT(NVARCHAR(20), ISNULL(CAST(@BadUpValue AS DECIMAL), 0));  
        PRINT @GoodDownValueConvert;  
        SET @SetCoName = ( SELECT   Name_ch
                           FROM     dbo.Tbl_AnsCom_DIimToTable
                           WHERE    DimNum = @ID
                         );  
        SET @SetSpType = ( SELECT   ( CASE WHEN MainTable = 'ParticalBK'
                                           THEN 'PigmentBK'
                                           WHEN MainTable = 'ParticalW'
                                           THEN 'PigmentW'
										   --WHEN MainTable = 'CapsuleDynamic'
             --                              THEN 'Coating'
										   --WHEN MainTable = 'CoatingMs'
             --                              THEN 'Coating'
										   --WHEN MainTable = 'Coating'
             --                              THEN 'Coating'
										   --WHEN MainTable = 'CoatingZJ'
             --                              THEN 'Coating'
                                           ELSE MainTable
                                      END )
                           FROM     dbo.Tbl_AnsCom_DIimToTable
                           WHERE    DimNum = @ID
                         );  
						               
		 SET @SetTableName = ( SELECT   ( CASE WHEN MainTable = 'ParticalBK'
                                           THEN 'PigmentBK'
                                           WHEN MainTable = 'ParticalW'
                                           THEN 'PigmentW'
										   WHEN MainTable = 'CapsuleDynamic'
                                           THEN 'Coating'
										   WHEN MainTable = 'CoatingMs'
                                           THEN 'Coating'
										   WHEN MainTable = 'Coating'
                                           THEN 'Coating'
										   WHEN MainTable = 'CoatingZJ'
                                           THEN 'Coating'
                                           ELSE MainTable
                                      END )
                           FROM     dbo.Tbl_AnsCom_DIimToTable
                           WHERE    DimNum = @ID
                         );  
						               
        SET @DistanceTypeStr = ' ( CASE WHEN '+@SetSpType+'.' + @Column + ' between '
            + @BadDownValueConvert + ' and ' + @BadUpValueConvert
            + ' THEN 0 WHEN ' +@SetSpType+'.'+ @Column + ' between ' + @GoodDownValueConvert
            + ' and ' + @GoodUpValueConvert + ' THEN 1 ELSE NULL END ) GY ';  
            --   SET @DistanceTypeStr = ' ( CASE WHEN ' + @Column + ' >='
            --+ @BadDownValueConvert +' and ' + @Column + ' <' + @BadUpValueConvert
            --+ ' THEN 0 WHEN ' + @Column + '>=' + @GoodDownValueConvert
            --+ ' and ' + @Column + ' <' + @GoodUpValueConvert + ' THEN 1 ELSE NULL END ) GY ';  
		SET @DistanceTypeStrEsp = ' ( CASE WHEN '+ @Column + ' between '
            + @BadDownValueConvert + ' and ' + @BadUpValueConvert
            + ' THEN 0 WHEN ' +@Column + ' between ' + @GoodDownValueConvert
            + ' and ' + @GoodUpValueConvert + ' THEN 1 ELSE NULL END ) GY ';  
            --   SET @DistanceTypeStr = ' ( CASE WHEN ' + @Column + ' >='
            --+ @BadDownValueConvert +' and ' + @Column + ' <' + @BadUpValueConvert
            --+ ' THEN 0 WHEN ' + @Column + '>=' + @GoodDownValueConvert
            --+ ' and ' + @Column + ' <' + @GoodUpValueConvert + ' THEN 1 ELSE NULL END ) GY ';  
        PRINT '执行编辑';  
        UPDATE  Tbl_BaseSetDistance
        SET     CoName = @SetCoName ,
                GoodUpValue = CAST(@GoodUpValue AS DECIMAL) ,
                GoodDownValue =CAST(@GoodDownValue AS DECIMAL)  ,
                BadUpValue = CAST(@BadUpValue AS DECIMAL) ,
                BadDownValue = CAST(@BadDownValue AS DECIMAL) ,
                DistanceTypeStr = @DistanceTypeStr ,
				DistanceTypeStrEsp=@DistanceTypeStrEsp,
                SpType = @SetTableName
        WHERE   DimNum = @ID;  
        SELECT  0;     
    END;
go

