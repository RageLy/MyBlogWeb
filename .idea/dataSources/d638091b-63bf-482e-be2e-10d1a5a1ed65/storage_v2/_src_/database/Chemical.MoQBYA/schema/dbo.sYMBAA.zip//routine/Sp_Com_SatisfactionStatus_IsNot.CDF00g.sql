                      
/*                      
刘轶  2015-8-25 满意度调查 默认未调查                      
*/                      
CREATE proc [dbo].[Sp_Com_SatisfactionStatus_IsNot]   
@type varchar(100) = ''                     
as                        
BEGIN 
if(@type = '')
begin                                   
	select  '未调查' AS SatisfactionStatus_S                  
	,CONVERT(VARCHAR(10),GETDATE(),23) AS ShouldSatisfactionBeginDate               
	,CONVERT(VARCHAR(10),GETDATE(),23) AS ShouldSatisfactionEndDate   
end 

                  
END
go

