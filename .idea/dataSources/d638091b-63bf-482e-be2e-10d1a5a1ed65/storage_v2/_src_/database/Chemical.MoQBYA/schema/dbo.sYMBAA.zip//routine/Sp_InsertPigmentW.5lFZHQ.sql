
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年5月26日                                                
-- Descript: 从Excel插入白色颜料
-- =============================================                 
--   exec [Sp_InsertBs_PigmentW]
CREATE PROCEDURE [dbo].[Sp_InsertPigmentW]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN
        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_PigmentW
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_PigmentW
                            GROUP BY 颜料编号
                        );

        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_PigmentW
                           );

        --插入颜料大釜
        PRINT '开始插入Tbl_Base_PigmentWKettle数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_PigmentWKettle ( Name )
                    SELECT DISTINCT [颜料大釜]
                    FROM   TempTb_PigmentW
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_PigmentWKettle
                                          WHERE  [颜料大釜] = Name
                                      );


        PRINT '表Tbl_Base_PigmentWKettle数据插入完毕，继续下一步';
        --插入颜料内部编号
        PRINT '开始插入Tbl_Base_PigmentWInnerCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_PigmentWinnerCode ( InnerCode )
                    SELECT DISTINCT 颜料内部编号
                    FROM   TempTb_PigmentW
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_PigmentWinnerCode
                                          WHERE  颜料内部编号 = InnerCode
                                      )
                           AND 颜料内部编号 IS NOT NULL;

        PRINT '表Tbl_Base_PigmentWInnerCode数据插入完毕，继续下一步';
        --插入BC0002参数
        PRINT '开始插入Tbl_Base_PigmentWBC0002数据，继续下一步';
        DELETE FROM dbo.TempTb_PigmentW_BC0002
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_PigmentW_BC0002
                            GROUP BY BC0002批次
                        );
        INSERT INTO dbo.Tbl_Base_BC0002 (   BC0002Code ,
                                            Provider ,
                                            Purity ,
                                            Water,RKDate
                                        )
                    SELECT DISTINCT BC0002批次 ,
                           BC0002厂家 ,
                           BC0002纯度 ,
                           BC0002水分,BC0002入库日期
                    FROM   dbo.TempTb_PigmentW_BC0002
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BC0002
                                          WHERE  BC0002批次 = BC0002Code
                                      )
                           AND BC0002批次 IS NOT NULL;

        PRINT '表Tbl_Base_PigmentWBC0002数据插入完毕，继续下一步';
        /*插入Bs_PigmentW的数据*/
        DELETE FROM dbo.TempTb_PigmentW_BC0013
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_PigmentW_BC0013
                            GROUP BY BC0013批次
                        );
        INSERT INTO dbo.Tbl_Base_BC0013 (   BC0013 ,
                                            RefIndex ,
                                            Purity,RKDate
                                        )
                    SELECT DISTINCT BC0013批次 ,
                           BC0013折光率 ,
                           BC0013纯度,BC0013入库日期
                    FROM   dbo.TempTb_PigmentW_BC0013
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BC0013
                                          WHERE  BC0013批次 = BC0013
                                      )
                           AND BC0013批次 IS NOT NULL;
        UPDATE dbo.Tbl_Base_BC0002
        SET    Provider = BC0002厂家 ,
               Purity = BC0002纯度 ,
               Water = BC0002水分,
			   RkDate=BC0002入库日期
        FROM   dbo.TempTb_PigmentW_BC0002
        WHERE  BC0002Code = BC0002批次;
        UPDATE dbo.Tbl_Base_BC0013
        SET    RefIndex = BC0013折光率 ,
               Purity = BC0013纯度,
			   RkDate=BC0013入库日期
        FROM   dbo.TempTb_PigmentW_BC0013
        WHERE  BC0013 = BC0013批次;

        UPDATE dbo.Bs_PigmentW
        SET    OptDate = [反应日期] ,
               PSize05Bef = [颜料粒径05] ,
               PSize09Bef = [颜料粒径09] ,
               TGA = [颜料TGA] ,
			   RKDate=颜料入库日期,
               BC0013 = BC0013.ID ,
               BC0002 = BC0002.ID ,
               InnerCode = Tbl_Base_PigmentWinnerCode.ID ,
               PH = [PH值] ,
               ReactOutput = [反应后产量] ,
               GrindOutput = [研磨后产量] ,
               CentrifugalTGA = [离心后TGA] ,
               Kettle = Tbl_Base_PigmentWKettle.ID ,
               CTRSpeedActually = [恒温转速] ,
               FRSpeedActually = [加料转速] ,
               Temp9Less30 = [小于30分9点温度] ,
               Humidity9Less60 = [小于60分9点湿度] ,
               Temp11Less30 = [小于30分11点温度] ,
               Humidity11Less60 = [小于60分11点湿度] ,
               Temp13Less30 = [小于30分13点温度] ,
               Humidity13Less60 = [小于60分13点湿度] ,
               Temp15Less30 = [小于30分15点温度] ,
               Humidity15Less60 = [小于60分15点湿度] ,
               Temp17Less30 = [小于30分17点温度] ,
               Humidity17Less60 = [小于60分17点湿度] ,
               RemarK = [备注] ,
               update_time = GETDATE()
        FROM   [dbo].TempTb_PigmentW
               LEFT JOIN Tbl_Base_BC0013 BC0013 ON BC0013.BC0013 = TempTb_PigmentW.BC0013批次
               LEFT JOIN Tbl_Base_BC0002 BC0002 ON BC0002.BC0002Code = TempTb_PigmentW.BC0002批次
               LEFT JOIN Tbl_Base_PigmentWKettle ON Tbl_Base_PigmentWKettle.Name = TempTb_PigmentW.颜料大釜
               LEFT JOIN Tbl_Base_PigmentWinnerCode ON Tbl_Base_PigmentWinnerCode.InnerCode = TempTb_PigmentW.[颜料内部编号]
        WHERE  Code = [颜料编号];


        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_PigmentW
                                            INNER JOIN dbo.TempTb_PigmentW ON TempTb_PigmentW.颜料编号 = Bs_PigmentW.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;
        PRINT '开始插入Bs_PigmentW数据，继续下一步';
        INSERT INTO dbo.Bs_PigmentW (   OptDate ,
                                        Code ,
                                        PSize05Bef ,
                                        PSize09Bef ,
                                        TGA ,
                                        BC0013 ,
                                        BC0002 ,
                                        InnerCode ,
                                        PH ,
										RKDate,
                                        ReactOutput ,
                                        GrindOutput ,
                                        CentrifugalTGA ,
                                        Kettle ,
                                        CTRSpeedActually ,
                                        FRSpeedActually ,
                                        Temp9Less30 ,
                                        Humidity9Less60 ,
                                        Temp11Less30 ,
                                        Humidity11Less60 ,
                                        Temp13Less30 ,
                                        Humidity13Less60 ,
                                        Temp15Less30 ,
                                        Humidity15Less60 ,
                                        Temp17Less30 ,
                                        Humidity17Less60 ,
                                        RemarK ,
                                        update_time
                                    )
                    SELECT [反应日期] ,
                           [颜料编号] ,
                           [颜料粒径05] ,
                           [颜料粒径09] ,
                           [颜料TGA] ,
                           BC0013.ID ,
                           BC0002.ID ,
                           Tbl_Base_PigmentWinnerCode.ID ,
                           [PH值] ,
						   颜料入库日期,
                           [反应后产量] ,
                           [研磨后产量] ,
                           [离心后TGA] ,
                           Tbl_Base_PigmentWKettle.ID ,
                           [恒温转速] ,
                           [加料转速] ,
                           [小于30分9点温度] ,
                           [小于60分9点湿度] ,
                           [小于30分11点温度] ,
                           [小于60分11点湿度] ,
                           [小于30分13点温度] ,
                           [小于60分13点湿度] ,
                           [小于30分15点温度] ,
                           [小于60分15点湿度] ,
                           [小于30分17点温度] ,
                           [小于60分17点湿度] ,
                           [备注] ,
                           GETDATE()
                    FROM   [dbo].TempTb_PigmentW
                           LEFT JOIN Tbl_Base_BC0013 BC0013 ON BC0013.BC0013 = TempTb_PigmentW.BC0013批次
                           LEFT JOIN Tbl_Base_BC0002 BC0002 ON BC0002.BC0002Code = TempTb_PigmentW.BC0002批次
                           LEFT JOIN Tbl_Base_PigmentWKettle ON Tbl_Base_PigmentWKettle.Name = TempTb_PigmentW.颜料大釜
                           LEFT JOIN Tbl_Base_PigmentWinnerCode ON Tbl_Base_PigmentWinnerCode.InnerCode = TempTb_PigmentW.[颜料内部编号]
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_PigmentW
                                          WHERE  Code = [颜料编号]
                                      )
                           AND [颜料编号] IS NOT NULL;

        PRINT '表Bs_PigmentW数据插入完毕';
        PRINT '所有过程完成';
    END;
go

