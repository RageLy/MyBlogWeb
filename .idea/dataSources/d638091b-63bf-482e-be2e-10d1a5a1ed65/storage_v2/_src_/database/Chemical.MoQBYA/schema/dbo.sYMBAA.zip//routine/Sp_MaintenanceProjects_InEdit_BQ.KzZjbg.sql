



CREATE PROCEDURE [dbo].[Sp_MaintenanceProjects_InEdit_BQ]
@Id varchar(50)='0'    
,@MPDId varchar(50)=''
,@Name varchar(50)='123'
,@Amount varchar(50)=''
,@Quantity varchar(50)=''
,@Remark varchar(50)=''
,@SGId varchar(50)=''
AS

BEGIN
set nocount on 
--项目不能为空
if(LEN(@Name)=0)                          
begin                          
 select '加装名称不能为空！'                          
 return                          
end  
--判断单价为数字
if(@Amount ='') set @Amount=0                 
if(ISNUMERIC(isnull(@Amount,0))=0 or CHARINDEX('e',@Amount)>0 or CHARINDEX('d',@Amount)>0 OR CHARINDEX('.', @Amount) = 1)          
begin                
 select '单价只能为数字！'          
 return                
end 

--判断主键ID,有为编辑
 if( @Id <> '')
  begin
   if exists (select 1 from Tbl_Base_MaintenanceProjectsDetailed where Id = @Id)
    begin
     update Tbl_Base_MaintenanceProjectsDetailed set ProjectName = @Name,
      Amount = @Amount,Quantity = @Quantity ,Remark = @Remark 
      ,ServiceGroupID = @SGId
      where Id = @Id
     select '0'
     return;  
    end
  end
END


--select * from Tbl_Base_MaintenanceProjects;
--select * from Tbl_Base_MaintenanceProjectsDetailed 
go

