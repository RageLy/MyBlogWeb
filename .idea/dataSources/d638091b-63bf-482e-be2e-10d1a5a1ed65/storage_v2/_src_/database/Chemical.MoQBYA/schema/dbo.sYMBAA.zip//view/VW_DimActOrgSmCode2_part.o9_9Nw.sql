Create View VW_DimActOrgSmCode2_part
AS
SELECT  -1 AS Id ,
'全部集合'AS Name ,
'1' AS istrue ,
'属性集合' 选项集合类型
 FROM    Tbl_AnsCom_DIimToTable AS b
 WHERE   DimNum = 'DimActOrgSmCode2'
 UNION ALL
 SELECT  x.ID AS Id ,
 CAST(x.Name AS VARCHAR(20)) AS Name ,
'0' AS istrue ,
'基础刻度' 选项集合类型
 FROM Tbl_AnsCom_DIimToTable b
 CROSS JOIN ( SELECT DISTINCT 
Name ,ID
 FROM Tbl_Base_Compound  WHERE Name IS NOT NULL ) x
 WHERE DimNum = 'DimActOrgSmCode2'

------------------------------------------
go

