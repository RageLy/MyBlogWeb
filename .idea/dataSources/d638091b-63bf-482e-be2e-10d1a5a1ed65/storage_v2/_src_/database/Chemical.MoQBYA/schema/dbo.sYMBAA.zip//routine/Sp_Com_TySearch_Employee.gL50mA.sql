                                           
CREATE PROCEDURE [dbo].[Sp_Com_TySearch_Employee]                                                     
@DepartID varchar(50) = 0                    
,@BusinessName varchar(50)=''       -- 续保专员                                            
--,@PositionName varchar(50)=''  --  ,电销专员, 续保专员                                    
,@EmpID VARCHAR(500)=''                                   
AS                                                          
BEGIN                                            
  select                                                           
  CAST (EmpID as varchar(500)) ID,                                                          
  cast (EmpName as varchar(500)) Name,           
  cast (ZJM as varchar(500)) ZJM,  
  dept.DeptName                                                 
  into #emp                                                        
  from Tbl_Com_Employee a                                                 
--  left join  tbl_com_employeePosition b on b.PositionId=a.PositionId                                      
  left join Tbl_Com_EmployeeBusiness e on a.BusinessId = e.BusinessId   
  LEFT JOIN dbo.Tbl_Com_Dept dept ON dept.DeptID = a.DeptID                                             
  --离职则不选出来                                                     
  where isnull(EmployeeStateID,0) <> 2  and  EmpID != 1                                                 
  and (@DepartID = 0 or a.DeptID = @DepartID)                                                
  --and (@PositionName = '' or @PositionName like '%'+ b.PositionName+'%')                                     
  AND (@BusinessName='' OR @BusinessName like '%'+ e.BusinessName+'%')          
  AND EmpName LIKE '%'+@EmpID+'%'                                            
  order by ZJM                                                 
                                                                                
          
             
             
    select Id AS EmpID,Name AS EmpName  ,ZJM ,DeptName       
    from (                                           
 select ID          
 ,Name           
 ,ZJM    
 ,DeptName        
 from #emp          
   )  as x             
   order by EmpName                                                        
                                                
END
go

