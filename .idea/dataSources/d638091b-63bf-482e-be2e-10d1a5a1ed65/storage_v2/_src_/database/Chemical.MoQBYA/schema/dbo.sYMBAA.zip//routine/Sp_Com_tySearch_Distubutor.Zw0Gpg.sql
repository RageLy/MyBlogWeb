    
CREATE PROCEDURE [dbo].Sp_Com_tySearch_Distubutor      
@DistrbutorName VARCHAR(50)=''    
as                                             
BEGIN       
   select  CAST(DistrbutorID AS INT) Id                                               
 ,CAST(DistrbutorName AS VARCHAR(500)) Name    
 ,CAST(ZJM AS VARCHAR(500)) ZJM    
 into #result                   
   from tbl_asbase_distrbutor         
   where 1=1  AND DistrbutorName LIKE '%'+@DistrbutorName+'%'    

   select Id AS DistrbutorID ,Name AS DistrbutorName ,ZJM   
    from (                                                 
   select Id    
   ,Name     
   ,ZJM    
   from     
   #result    
   )  as x       
   order by ZJM             
           
END
go

