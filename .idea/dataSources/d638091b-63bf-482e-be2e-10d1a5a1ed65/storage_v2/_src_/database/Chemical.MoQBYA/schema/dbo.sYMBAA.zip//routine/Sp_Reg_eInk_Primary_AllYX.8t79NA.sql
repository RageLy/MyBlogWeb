-- =============================================
-- Author:		杨艺
-- Create date: 2016-04-05
-- Description:	计算每个油相的离散度
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Reg_eInk_Primary_AllYX]

	 @YXNum			VARCHAR(100) = ''	
		-- 如果为空就是计算所有油相,如果想计算指定的油相，请用；（分号）做为分隔符 例：YX001;YX002
,	 @t8Min			DECIMAL(12,2) -- decimal
,    @t8Max			DECIMAL(12,2) -- decimal
,    @t8Interval	DECIMAL(12,2)  -- decimal
,    @t41Min		DECIMAL(12,2)  -- decimal
,    @t41Max		DECIMAL(12,2)  -- decimal
,    @t41Interval	DECIMAL(12,2)  -- decimal
,    @s41Min		DECIMAL(12,2)  -- decimal
,    @s41Max		DECIMAL(12,2)  -- decimal
,    @s41Interval	DECIMAL(12,2)  -- decimal
,    @t25Min		DECIMAL(12,2)  -- decimal
,    @t25Max		DECIMAL(12,2)  -- decimal
,    @t25Interval	DECIMAL(12,2)  -- decimal
,    @s25Min		DECIMAL(12,2)  -- decimal
,    @s25Max		DECIMAL(12,2)  -- decimal
,    @s25Interval	DECIMAL(12,2)  -- decimal
AS
BEGIN
	

	IF (@YXNum = '')
	BEGIN
		
		-- 游标循环变量 
		DECLARE YXALLCursor CURSOR FOR 
		SELECT YXNum FROM dbo.Tbl_Base_YX ORDER BY ID;
		
		OPEN YXALLCursor;
		FETCH NEXT FROM YXALLCursor
		INTO @YXNum;
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			EXEC dbo.Sp_Reg_eInk_Primary @YXNum = @YXNum, -- varchar(100)
		    @t8Min = @t8Min, -- decimal
		    @t8Max = @t8Max, -- decimal
		    @t8Interval = @t8Interval, -- decimal
		    @t41Min = @t41Min, -- decimal
		    @t41Max = @t41Max, -- decimal
		    @t41Interval = @t41Interval, -- decimal
		    @s41Min = @s41Min, -- decimal
		    @s41Max = @s41Max, -- decimal
		    @s41Interval = @s41Interval, -- decimal
		    @t25Min = @t25Min, -- decimal
		    @t25Max = @t25Max, -- decimal
		    @t25Interval = @t25Interval, -- decimal
		    @s25Min = @s25Min, -- decimal
		    @s25Max = @s25Max, -- decimal
		    @s25Interval = @s25Interval -- decimal
			
			FETCH NEXT FROM YXALLCursor
			INTO @YXNum;
		END
		
		CLOSE YXALLCursor;
		DEALLOCATE YXALLCursor;
		
		
	END
	ELSE	
	BEGIN
		
		
		-- 游标循环变量 
		DECLARE YXALLCursor CURSOR FOR 
		SELECT yx.YXNum 
		FROM dbo.Tbl_Base_YX AS yx INNER JOIN dbo.f_splitSTR(@YXNum,';') AS y ON yx.YXNum = y.string
		ORDER BY yx.ID;
		
		OPEN YXALLCursor;
		FETCH NEXT FROM YXALLCursor
		INTO @YXNum;
		
		WHILE @@FETCH_STATUS = 0
		BEGIN
			
			EXEC dbo.Sp_Reg_eInk_Primary @YXNum = @YXNum, -- varchar(100)
		    @t8Min = @t8Min, -- decimal
		    @t8Max = @t8Max, -- decimal
		    @t8Interval = @t8Interval, -- decimal
		    @t41Min = @t41Min, -- decimal
		    @t41Max = @t41Max, -- decimal
		    @t41Interval = @t41Interval, -- decimal
		    @s41Min = @s41Min, -- decimal
		    @s41Max = @s41Max, -- decimal
		    @s41Interval = @s41Interval, -- decimal
		    @t25Min = @t25Min, -- decimal
		    @t25Max = @t25Max, -- decimal
		    @t25Interval = @t25Interval, -- decimal
		    @s25Min = @s25Min, -- decimal
		    @s25Max = @s25Max, -- decimal
		    @s25Interval = @s25Interval -- decimal
			
			FETCH NEXT FROM YXALLCursor
			INTO @YXNum;
		END
		
		CLOSE YXALLCursor;
		DEALLOCATE YXALLCursor;
		
	END

END
go

