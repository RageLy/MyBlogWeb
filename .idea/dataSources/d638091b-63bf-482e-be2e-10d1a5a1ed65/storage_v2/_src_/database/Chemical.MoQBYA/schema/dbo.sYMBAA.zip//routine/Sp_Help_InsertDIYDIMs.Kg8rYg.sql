

CREATE PROCEDURE [dbo].[Sp_Help_InsertDIYDIMs]
	@DimNum varchar(50) = 'DimDIYDDLps'
AS
BEGIN

	DELETE FROM T_DIYDIMs WHERE DimNum = @DimNum

	INSERT INTO T_DIYDIMs
	VALUES
	(@DimNum,1,'[70，90)',70,90,'油相电导率','Oil.Conductivity'),
	(@DimNum,2,'[90，100)',90,100,'油相电导率','Oil.Conductivity'),
	(@DimNum,3,'[100，130)',100,130,'油相电导率','Oil.Conductivity')

	SELECT * FROM T_DIYDIMs WHERE DimNum = @DimNum

END
go

