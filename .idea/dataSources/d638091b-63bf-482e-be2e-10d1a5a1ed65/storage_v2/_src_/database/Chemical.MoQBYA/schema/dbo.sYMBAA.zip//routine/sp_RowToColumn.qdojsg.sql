
create proc sp_RowToColumn
@TableName varchar(50)='' --数据存放的临时表
,@ColumnName varchar(50) =''--需要变行为列的列名
,@Data varchar(50) =''--数据列名
,@GroupName varchar(50)='' --分组列名 同时根据其排序
,@tableName1 varchar(50)=''
as
BEGIN
create table #tmp_Columns          
(          
name nvarchar(500)          
)          
insert into #tmp_Columns          
exec (' select distinct '+@ColumnName+' from '+@TableName)

declare @Sql varchar(max)
set @sql        
=(        
select 'max(case when '+@ColumnName+'='''+convert(varchar(500),name)+''' then ['+@Data+'] end) as ['+convert(varchar(50),name)+'],'+CHAR(10) from #tmp_Columns for xml path('')) 

set @sql=left(@sql, len(@sql)-2)

set @sql='insert into '+@tableName1+' (Num1,Num2,Num3) select '--+@GroupName+','
+ @sql
+CHAR(10)+' from '+@TableName
--+CHAR(10)+' group by '+@GroupName       
--+CHAR(10)+' order by '+@GroupName  

print @sql
exec (@sql)
END
go

