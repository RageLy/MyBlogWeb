

-- =============================================
-- Author:		吴国锋
-- Create date: 2012-5-18
-- Description:	删除一个Page以及里面的group
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Sys_DeletePageAndGroups]
	-- Add the parameters for the stored procedure here
	@PageID int
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    -- Insert statements for procedure here
    Delete From dbo.Tbl_Sys_PageGroup where PageID = @PageID;
    
	delete from dbo.Tbl_Sys_Page where PageID=@PageID
	select '0'
END
go

