 -- =============================================            
-- Author:  陈建波          
-- Create date: 2015-08-03            
-- Description: 查询 Tbl_Sys_TableCfg 表指定FrozenColumn值          
-- =============================================  
CREATE proc [dbo].[Sp_Sys_SelectFrozenColumn]  
@FormID varchar(500)           
,@EmpID int=0           
,@GroupID varchar(500)    
as  
Begin  
select FrozenColumn from Tbl_Sys_TableCfg where FormID = @FormID and EmpID = @EmpID and GroupID = @GroupID  
End
 go

