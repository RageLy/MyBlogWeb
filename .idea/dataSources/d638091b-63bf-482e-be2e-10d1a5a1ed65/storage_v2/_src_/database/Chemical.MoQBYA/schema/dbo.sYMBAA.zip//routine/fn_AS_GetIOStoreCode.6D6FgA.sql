-- =============================================
-- Author:  杨艺  
-- Create date: 2015-09-28  
-- Description: 生成一个唯一的出入库单据编号  
-- =============================================
CREATE FUNCTION [dbo].[fn_AS_GetIOStoreCode]
(
	@Type VARCHAR(10)
)
RETURNS VARCHAR(100)
AS
BEGIN


 DECLARE @IOStoreCode VARCHAR(100)  
 SET @IOStoreCode = @Type;
 -- 前缀  
 SET @IOStoreCode += REPLACE(CONVERT(VARCHAR(19), REPLACE(CONVERT(VARCHAR(19), GETDATE(), 120),':', ''), 120), '-','')  
 SET @IOStoreCode = REPLACE(@IOStoreCode, ' ', '')  

 WHILE 1 = 1
    BEGIN  
    
        IF EXISTS ( SELECT 1 FROM dbo.Tbl_AftIO_PartInOutStore AS p WHERE p.IOStoreCode = @IOStoreCode)
            BEGIN  
                SET @IOStoreCode = @Type; -- 前缀  
                SET @IOStoreCode += REPLACE(CONVERT(VARCHAR(19), REPLACE(CONVERT(VARCHAR(19), GETDATE(), 120),
                                                              ':', ''), 120),'-', '')  
                SET @IOStoreCode = REPLACE(@IOStoreCode, ' ', '')  
  
            END  
        ELSE
            BEGIN  
                BREAK;  
            END  
    
    END   
	-- Return the result of the function
	RETURN @IOStoreCode

END
go

