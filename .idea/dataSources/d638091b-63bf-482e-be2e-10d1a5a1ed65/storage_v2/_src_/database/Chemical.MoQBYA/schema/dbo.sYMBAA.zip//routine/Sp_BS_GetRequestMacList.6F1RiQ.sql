        
-- =============================================                                                
-- <Mac过滤 列表>             
-- THM 2014-6-24                            
-- =============================================                                  
CREATE PROCEDURE [dbo].Sp_BS_GetRequestMacList                                
  @PageIndex varchar(50)='1'                
, @PageSize varchar(50)='10'                
, @OrderFields varchar(50)='RpID desc'           
, @KeyValue varchar(50)='-1'                                       
AS                                  
BEGIN              
SET NOCOUNT ON;                                  
if(@OrderFields = '')          
begin          
 set @OrderFields =' RpID desc '          
end  
 
SELECT * 
INTO #Tmp
FROM
(           
SELECT RpID,Name,Mac
,CASE WHEN IsAllowedAccess = 1 THEN '是' else '否' END as IsAllowedAccess,'' IsNew
FROM Tbl_Com_RequestPermission
UNION ALL
SELECT DISTINCT 0 AS RpID,'' AS NAME ,mac, '否' AS IsAllowedAccess  ,'是' IsNew
FROM Tbl_Com_RequestLog 
WHERE Mac NOT IN ( SELECT DISTINCT Mac from Tbl_Com_RequestPermission)
) AS a
              
             
              
declare @pageCount int =@@ROWCOUNT              
--处理查询结果为空时插入空行(列表为行内编辑时需要)                 
if(@pageCount = 0)                      
begin          
 insert into #Tmp values(null,null,null,null,'否','')          
end                     
                    
              
--调用通用分页          
           
exec Sp_Sys_Page '#Tmp',@OrderFields,@pageCount,@PageIndex,@PageSize                                            
               
END
go

