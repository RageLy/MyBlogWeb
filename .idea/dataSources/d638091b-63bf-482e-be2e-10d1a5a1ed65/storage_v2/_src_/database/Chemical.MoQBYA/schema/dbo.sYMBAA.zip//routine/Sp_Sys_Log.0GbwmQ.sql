-- =============================================
-- Description:写日志存储过程
-- =============================================

CREATE proc [dbo].[Sp_Sys_Log] --写日志存储过程
--@id  varchar(50)='' ,
@user varchar(50)='',
@action varchar(50)='',
@tableName varchar(50)='',
@idValue varchar(50)='',
@sql varchar(500)='',
@columns varchar(500)='',
@values varchar(5000)='',
@ip varchar(50)=''
--@time datetime=getdate()
as 
begin
	insert into [Tbl_sys_Log] (
			[user] ,
			[action],
			[tableName],
			[idValue],
			[sql] ,
			[columns] ,
			[values] ,
			[time] ,
			[ip]
		)
		values
		(
			@user,
			@action,
			@tableName,
			@idValue,
			@sql ,
			@columns ,
			@values,
			GETDATE(),
			@ip
		)
end
go

