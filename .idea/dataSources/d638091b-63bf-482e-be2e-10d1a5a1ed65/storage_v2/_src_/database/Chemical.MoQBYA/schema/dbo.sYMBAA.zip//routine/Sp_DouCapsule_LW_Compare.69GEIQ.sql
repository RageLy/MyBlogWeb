




CREATE PROCEDURE [dbo].[Sp_DouCapsule_LW_Compare]

 AS
BEGIN

DECLARE @ID int;
DECLARE @ID2 int;
set @ID=(select max(id) from Bs_DouCapsule)
set @ID2=(select isnull(max(ID2),0) from Tbl_DouCapsule_LW_Compare)

--插入ID1,ID2
if (@ID2<@ID)

BEGIN
insert into Tbl_DouCapsule_LW_Compare(ID1, ID2, DimDouTemp41, DimDouSpeed500, DimDouSpeed400, DimDouTemp8, DimDouTemp25, DimDouLJ, DimDouLJspan, DimDouJNGHL, DimDouDeltaBK, DimDouDeltaW, DimDouPH, DimDouPhTemp,DimSinDDLps, DimSinNDcp, DimYXLJ05, DimYXLJ09)
select id1,id2,
case when temp41*LW>0 then 1 ---'正相关'
when temp41*LW<0 then -1 ---'负相关'
when temp41=0 then 2 ---'无效'
when temp41<>0 and LW=0 then 0 ---'不相关'
end as DimDouTemp41,

case when rspeed500*LW>0 then 1 ---'正相关'
when rspeed500*LW<0 then -1 ---'负相关'
when rspeed500=0 then 2 ---'无效'
when rspeed500<>0 and LW=0 then 0 ---'不相关'
end as DimDouSpeed500,

case when rspeed400*LW>0 then 1 ---'正相关'
when rspeed400*LW<0 then -1 ---'负相关'
when rspeed400=0 then 2 ---'无效'
when rspeed400<>0 and LW=0 then 0 ---'不相关'
end as DimDouSpeed400,

case when temp8*LW>0 then 1 ---'正相关'
when temp8*LW<0 then -1 ---'负相关'
when temp8=0 then 2 ---'无效'
when temp8<>0 and LW=0 then 0 ---'不相关'
end as DimDouTemp8,

case when temp25*LW>0 then 1 ---'正相关'
when temp25*LW<0 then -1 ---'负相关'
when temp25=0 then 2 ---'无效'
when temp25<>0 and LW=0 then 0 ---'不相关'
end as DimDouTemp25,

case when psize*LW>0 then 1 ---'正相关'
when psize*LW<0 then -1 ---'负相关'
when psize=0 then 2 ---'无效'
when psize<>0 and LW=0 then 0 ---'不相关'
end as DimDouLJ,

case when psizespan*LW>0 then 1 ---'正相关'
when psizespan*LW<0 then -1 ---'负相关'
when psizespan=0 then 2 ---'无效'
when psizespan<>0 and LW=0 then 0 ---'不相关'
end as DimDouLJspan,

case when soildcontent*LW>0 then 1 ---'正相关'
when soildcontent*LW<0 then -1 ---'负相关'
when soildcontent=0 then 2 ---'无效'
when soildcontent<>0 and LW=0 then 0 ---'不相关'
end as DimDouJNGHL,

case when deltabk*LW>0 then 1 ---'正相关'
when deltabk*LW<0 then -1 ---'负相关'
when deltabk=0 then 2 ---'无效'
when deltabk<>0 and LW=0 then 0 ---'不相关'
end as DimDouDeltaBK,

case when deltaw*LW>0 then 1 ---'正相关'
when deltaw*LW<0 then -1 ---'负相关'
when deltaw=0 then 2 ---'无效'
when deltaw<>0 and LW=0 then 0 ---'不相关'
end as DimDouDeltaW,

case when ph*LW>0 then 1 ---'正相关'
when ph*LW<0 then -1 ---'负相关'
when ph=0 then 2 ---'无效'
when ph<>0 and LW=0 then 0 ---'不相关'
end as DimDouPH,

case when phtemp*LW>0 then 1 ---'正相关'
when phtemp*LW<0 then -1 ---'负相关'
when phtemp=0 then 2 ---'无效'
when phtemp<>0 and LW=0 then 0 ---'不相关'
end as DimDouPhTemp,

case when Conductivity*LW>0 then 1 ---'正相关'
when Conductivity*LW<0 then -1 ---'负相关'
when Conductivity=0 then 2 ---'无效'
when Conductivity<>0 and LW=0 then 0 ---'不相关'
end as DimSinDDLps,

case when Viscosity*LW>0 then 1 ---'正相关'
when Viscosity*LW<0 then -1 ---'负相关'
when Viscosity=0 then 2 ---'无效'
when Viscosity<>0 and LW=0 then 0 ---'不相关'
end as DimSinNDcp,

case when PSize05*LW>0 then 1 ---'正相关'
when PSize05*LW<0 then -1 ---'负相关'
when PSize05=0 then 2 ---'无效'
when PSize05<>0 and LW=0 then 0 ---'不相关'
end as DimYXLJ05,

case when PSize09*LW>0 then 1 ---'正相关'
when PSize09*LW<0 then -1 ---'负相关'
when PSize09=0 then 2 ---'无效'
when PSize09<>0 and LW=0 then 0 ---'不相关'
end as DimYXLJ09
from (

select a.id id1,b.id id2
,a.temp41-b.temp41 temp41
,a.rspeed500-b.rspeed500 rspeed500
,a.rspeed400-b.rspeed400 rspeed400
,a.temp8-b.temp8 temp8
,a.temp25-b.temp25 temp25
,a.psize-b.psize psize
,a.psizespan-b.psizespan psizespan
,a.SoildContent-b.SoildContent SoildContent
,a.DeltaBK-b.DeltaBK DeltaBK
,a.DeltaW-b.DeltaW DeltaW
,a.PH-b.PH PH
,a.PhTemp-b.PhTemp PhTemp
,a.LW-b.LW LW
,bo.Conductivity-boo.Conductivity Conductivity,
bo.Viscosity-boo.Viscosity Viscosity,
bo.PSize05-boo.PSize05 PSize05,
bo.PSize09-boo.PSize09 PSize09
 from dbo.Bs_DouCapsule a
join dbo.Bs_DouCapsule b
on a.id<b.id and b.id>@ID2 and a.oilid=b.oilid---------------------------------------底表新增数据时，只插入需要更新的数据-------------------
join dbo.Bs_Oil bo
on a.oilid=bo.id
join dbo.Bs_Oil boo
on b.oilid=boo.id
) aa

END

END
go

