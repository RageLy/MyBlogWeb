                        
/*                              
行转列通用 sp    yind                              
                              
调用示例                              
                              
                              
if OBJECT_ID('tempdb.dbo.#tt') is not null                              
drop table #tt                              
                              
create table #tt                              
(                              
name1 varchar(50)                              
,lev varchar(50)                               
,core int                              
)                              
                              
insert into #tt(name1,lev,core)                              
values('ss','1fd',93)                              
,('ss','fds',193)                              
,('ss','ghgg',3)                              
,('kk','ghgg',13)                              
,('ff','ghgg',173)                              
,('ff','fds',133)                              
,('ff','1fd',23)                              
                              
                              
EXEC  dbo.RowToColumn_ForList @table='#tt',@title='lev',@data='core',@groupBy='name1',@orderBy='name1'                              
                              
                              
                              
*/                              
                              
                              
                              
CREATE proc [dbo].[RowToColumn_Forlist]                              
(                                    
 @table varchar(500)='#table',-------  需要转换的table名字，table是3列                                    
 @title varchar(500)='col',   -------  需要把数据转换为列的列名                                 
 @data varchar(500)='col2',   -------  需要取值的列名                        
 @groupBy varchar(500)='col3',  ----  需要分组的列                                
 @orderBy varchar(500)='col3',   ----  排序                       
 @type int=0 ---@type=0 无合计，1，列合计，2，行合计 ，3.行列合计                             
)                                      
as                              
begin                                      
                                       
                              
                              
                              
declare @sql varchar(max)=''                              
declare @sql1 varchar(max)=''                
                          
                          
                          
                          
                          
                              
                              
                              
------- 需要转的列信息                              
create table #tbcol                              
(                              
name nvarchar(500)                              
)                              
insert into #tbcol                              
exec( 'select distinct '+ @title +' from ' +@table)                              
                              
                      
                      
declare @colname nvarchar(max),                      
@colname1 nvarchar(max)                      
                      
set @colname=                      
(                      
 select ''''+name+'1'' '+ quotename(name)+',' from #tbcol for xml path('')                      
)                      
                      
if(@type=1 or @type=3)                      
set @colname=@colname+'''列合计1'' 列合计'                      
else                      
set @colname=LEFT(@colname,LEN(@colname)-1)                      
                      
                      
set @colname='select ''n'' 序号, '+''''+@groupBy+'1'' '+@groupBy+','+@colname                      
                      
set @colname1=                      
(                      
 select '''varhcar,500'' '+ quotename(name)+',' from #tbcol for xml path('')                      
)                      
if(@type=1 or @type=3)                      
set @colname1=@colname1+' ''varchar,500'''                      
else                      
set @colname1=LEFT(@colname1,LEN(@colname1)-1)                      
                      
                      
set @colname1='select ''varchar,500'' 序号,''varchar,500'' 序号,'+@colname1                      
                      
                     
                      
set   @colname=@colname++char(10)+'union all'+CHAR(10)+ @colname1                      
                      
exec (@colname)                      
                              
           
-----------行转列                              
set @sql                              
=(                              
select   'isnull(max(case  when '+ @title+'='''+convert(varchar(500),name)+''' then '+convert(varchar(500),@data) +'   end),0) ['+convert(varchar(50),name)+'1],'+CHAR(10) from #tbcol for xml path('') )                              
                              
set @sql=left(@sql, len(@sql)-2)                              
--print @sql                  
            
--------列合计                              
set @sql1                              
=(                              
select   '+isnull(max(case  when '+ @title+'='''+convert(varchar(500),name)+''' then '+convert(varchar(500),@data)             
+'   end),0) '+CHAR(10) from #tbcol for xml path('') )                              
                              
set @sql1=',('+stuff(@sql1, 1,1,'')+') as 列合计1'              
                      
--print   @sql1               
--return                 
                      
declare @tablename varchar(500)                      
set @tablename='##page'                      
                       
if OBJECT_ID('tempdb.dbo.##page') is not null                      
drop table ##page                      
            
            
--convert(varchar(50), row_number() over (order by '+@groupBy+' )) n,                     
--+' into '+@tablename+              
            
--convert(varchar(50),            
          
if @orderBy='n'          
set @orderBy=@groupBy+'1'          
          
                              
set @sql='select convert(varchar(50),row_number() over (order by '  
+ @orderBy  +'))n,            
 * into ##page from (select '+@groupBy +' as '+@groupBy+'1,'+                       
@sql+CHAR(10)+@sql1+' from '+@table+  ' group by '+@groupBy               
+')C'                           
--+CHAR(10)+'order by '+@orderBy                              
            
            
print @sql                               
exec( @sql)                              
--return            
                  
--set  @orderby=' order by '+@orderBy                    
                      
--------没有列行合计                      
if @type=0                      
begin                      
set @sql='alter table '+@tablename+' drop column 列合计1'            
exec(@sql)            
                      
exec('select * from '+ @tablename )                  
                      
end                            
----------列合计                      
if @type=1                          
begin                      
 --set @colname=                      
 --(                      
 -- select  'isnull('+quotename(name)+',0)'+'+' from #tbcol for xml path('')                      
 --)                      
 --set @colname=LEFT(@colname,LEN(@colname)-1)                        
 --set @sql='select *,'+@colname+' as 列合计 from '+@tablename                
  set @sql='select * from '+@tablename                   
 print  @sql                       
 exec(@sql)                      
end                      
                      
------行合计                      
if @type=2                      
begin                      
set @colname=                      
 (                      
  select  'sum('+quotename(name)+'),' from #tbcol for xml path('')                      
 )                      
            
            
set @colname=LEFT(@colname,LEN(@colname)-1)            
            
set @sql='alter table '+@tablename+' drop column 列合计1'            
exec(@sql)            
            
set @sql='select * from '+@tablename +CHAR(10)+'union all'                      
+CHAR(10)+'select ''合计'',null,'+@colname+ ' from '+@tablename                   
      
print  @sql       
                   
exec(@sql)             
                      
end                      
                      
---------列行合计                      
if @type=3                      
begin                      
                      
set @colname=                      
 (                      
  select  'sum('+quotename(name)+'),' from #tbcol for xml path('')          
 )              
            
             
set @colname=LEFT(@colname,LEN(@colname)-1)            
--print    @colname1                  
set @sql='select * from '+@tablename +CHAR(10)+'union all'                      
+CHAR(10)+'select ''合计'',null,'+@colname+ ',sum(列合计1) from '+@tablename                   
      
print  @sql                    
      
exec(@sql)              
      
                     
                  
end                      
                           
                             
end             
            
            
            
--select convert(decimal(19,2),11) 
go

