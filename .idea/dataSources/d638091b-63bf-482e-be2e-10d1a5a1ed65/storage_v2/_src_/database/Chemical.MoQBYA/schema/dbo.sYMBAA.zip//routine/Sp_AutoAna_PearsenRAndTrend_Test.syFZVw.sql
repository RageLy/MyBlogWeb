

-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 自动相关性系数与趋势计算sp
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_PearsenRAndTrend_Test]
	-- Add the parameters for the stored procedure here
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(max) = 'DimOilSeries,DimSinOutValue,DimSinTemp8,DimSinTemp25,DimSinTemp41,DimSinSpeed,DimSinSpeed580,DimDDLps,DimOilViscosity,DimYXLJ05,DimYXLJ09,DimOilDensity,DimOilSTension'
	,@XDim VARCHAR(50) = 'DimOilSTension'
	,@YDim VARCHAR(50) = 'DimSinOutValue'
	,@DimScale VARCHAR(50) = '倍数'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- 所有的维度表
    CREATE TABLE #Dims
    (
		Dim varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
    -- 分解维度插入零时表
    INSERT INTO #Dims
    SELECT string
    ,CASE WHEN  string = @XDim THEN 'X'  -- 变量dim
	      WHEN  string = @YDim THEN 'Y'  -- 目标dim
		  ELSE 'F' END   -- 条件Dim
    ,ta.IsRange
    ,ta.ViewName
    ,ta.AtYSql
    ,NUll
    FROM dbo.Split(@Dims,',') s
    INNER JOIN dbo.Tbl_AnsCom_DIimToTable ta ON s.string = ta.DimNum
    
    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #Dims WHERE Dim = @YDim;
    
    
    -- 数据源sql段
    DECLARE @TName VARCHAR(500);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
   
    -- 计算所有维度存在数据的条数
    
	--   DECLARE @CountData VARCHAR(max) = '';
	--   SET @CountData = ( SELECT ',Count(' + DimYsql + ')'
	--	FROM #Dims WHERE DType = 'F' FOR XML PATH(''));
	--	-- 去掉第一个,
	--SET @CountData = SUBSTRING(@CountData,2,LEN(@CountData));
	
	--EXEC ('select ' + @CountData + ' From ' + @TName);
	--RETURN;
	
	
    
   -- SELECT * FROM #Dims;
    
    -- 计算所有条件 Dim 的数据量
    DECLARE @CreateT VARCHAR(max) = '';
    
    SET @CreateT += ( SELECT 'CREATE TABLE #' +  Dim + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE DType = 'F' FOR XML PATH('') );
    
	
	-- 拼接所有的基础刻度
	--DECLARE @InsertT VARCHAR(max) = '';
	--SET @InsertT +=
	--   ( SELECT 'insert into #' + Dim + 
	--	CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
	--	     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
	--	     END
	--	 + ViewName + '_Part where istrue = 0;'
	--	FROM #Dims WHERE DType = 'F' FOR XML PATH('') );
		
	DECLARE @InsertT VARCHAR(max) = '';
	if(@DimScale='')
	begin
	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where istrue = 0;'
		FROM #Dims WHERE DType = 'F' FOR XML PATH('') )
	end;
	
	if(@DimScale='倍数')
	begin
	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE 
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'+ ViewName + '_Part where istrue = 2; '
		     WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'+ ViewName + '_Part where istrue = 0; '
		     END
		FROM #Dims WHERE DType = 'F' FOR XML PATH('') )
	end;

print @InsertT;

    -- 拼接计算列

    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' LEFT JOIN #' +  Dim + ' AS ' + Dim + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN Dim + '.BeginValue <= ' + DimYsql + ' AND ' + Dim + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE Dim + '.ID = ' + DimYsql END
		FROM #Dims WHERE DType = 'F' FOR XML PATH(''));
	
    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	
	-- 拼接SiftValue段
    DECLARE @SiftValue VARCHAR(max);
    SET @SiftValue = ( SELECT '''%' +  Dim + ':'' + CAST( isnull(' + Dim + '.ID,0) AS Varchar(10)) + '
		FROM #Dims WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个 % 和最后一个 +
	SET @SiftValue = '''' + SUBSTRING(@SiftValue,3,LEN(@SiftValue) - 3);
	
	-- 拼接 group by 段
    DECLARE @GroupBy VARCHAR(max);
    SET @GroupBy = ( SELECT ',' + Dim + '.ID'
		FROM #Dims WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个,
	SET @GroupBy = SUBSTRING(@GroupBy,2,LEN(@GroupBy));
	
	-- 执行语句
	
	--SET @SqlCount += 'SELECT COUNT(*),' + @SiftValue + ' FROM ' + @SqlJoin;
	
	--select @CreateT + @InsertT + 'SELECT COUNT(*),' + @SiftValue + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy
	--EXEC (@CreateT + @InsertT + 'SELECT * FROM ' + @TName + @SqlJoin);
	
	--SELECT @SiftValue;
	
	
	
	-- 设置目标表格
	DECLARE @ResultTable VARCHAR(max);
	SET @ResultTable = 'T_AutoAnaCountSift_' + ISNULL(@XDim,'') + '_' +  ISNULL(@YDim,'');
	
	-- 拼接 维度条件列名段
    DECLARE @CName VARCHAR(max);
    SET @CName = ( SELECT ',' + Dim + ' INT'
		FROM #Dims WHERE DType = 'F' FOR XML PATH(''));
	
	
	IF exists( SELECT 1 FROM sys.objects where name = @ResultTable )
		EXEC ( 'DROP TABLE ' + @ResultTable );
	
	--SELECT @CName;
	

	EXEC ( 'CREATE TABLE ' + @ResultTable + '
	(	spName varchar(50),
		DataCount int,
		MaxY Decimal(18,6),
		MinY Decimal(18,6),
		AVGY Decimal(18,6),
		Siftvalue varchar(Max)'
		+ @CName +
		'
	)'
	 )
	
	DECLARE @ResultDataSql VARCHAR(500);
	SET @ResultDataSql = '''' + @SpName + ''',COUNT( + ' + @Ysql + '),MAX(' + @Ysql + '),MIN(' + @Ysql + '),AVG(' + @Ysql + '),'
	
	EXEC (@CreateT + @InsertT + 'INSERT INTO ' + @ResultTable + ' SELECT ' + @ResultDataSql + @SiftValue + ',' + @GroupBy + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy);
	
	
	--SELECT  (@CreateT + @InsertT + 'INSERT INTO ' + @ResultTable + ' SELECT ' + @ResultDataSql + @SiftValue + ',' + @GroupBy + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy);
	
	PRINT 'Create Table: ' + @ResultTable
	-- 拼接 drop table 段 用于debug
    --  DECLARE @Droptable VARCHAR(max);
    --  SET @Droptable = ( SELECT 'Drop table #' + Dim + ' ;'
	--	FROM #Dims WHERE DType = 'F' FOR XML PATH(''));
	
	--SELECT @Droptable;
	
END
go

