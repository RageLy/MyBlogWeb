-- =============================================    
-- Description: 根据LoginID获取登录信息    
-- =============================================    
CREATE proc[dbo].[Sp_Sys_GetUserInfo]    
 @LoginID varchar(500)  ,  
 @webconfig varchar(500)  
AS    
BEGIN      
 select e.RoleID [RoleID],e.RoleName,e.QueryRange,e.CanSeePhone   
  FROM Tbl_Sys_Role AS e  
  left join Tbl_Sys_UserRoleRelation d on e.RoleID=d.RoleID   
  LEFT JOIN Tbl_Sys_User AS a ON d.UserID=a.UserID  
  where a.UserID=@LoginID;  

  select a.UserID,UserAccount,b.EmpID,b.EmpName from dbo.Tbl_Sys_User a    
  left join Tbl_Com_Employee b on a.UserID=b.UserId    
  where a.UserID=@LoginID    
      
  select a.UserID,d.MenuID,d.FormID,d.AuthLevel from Tbl_Sys_User e    
  left join Tbl_Com_Employee a on a.UserID=e.UserID    
  left join Tbl_Sys_UserRoleRelation b on b.UserID=a.UserID    
  left join Tbl_Sys_RoleTactics c on c.RoleID=b.RoleID    
  left join Tbl_Sys_Tactics d on d.TacticsID=c.TacticsID      
  where a.UserID=@LoginID  AND c.WebConfig =@webconfig AND d.WebConfig =@webconfig  
END
go

