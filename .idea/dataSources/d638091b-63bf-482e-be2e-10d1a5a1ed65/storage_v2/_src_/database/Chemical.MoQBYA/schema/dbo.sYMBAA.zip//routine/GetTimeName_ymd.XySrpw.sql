


-- =============================================
-- Author:		<clp> 
-- alter date: <2013-07-23> 
-- Description:	<根据起始时间得出 时间名称> 
-- =============================================
CREATE FUNCTION [dbo].[GetTimeName_ymd](
@BeginDate   datetime,    -- 
@EndDate     datetime    -- 结束时间
)returns varchar(50)
as
begin
   declare @result varchar(50);
   set @result = null;
   -- 天
 
 	
 	if( DATEdiff(DD,@BeginDate,@EndDate) < 1 )
      set @result= CAST(YEAR(@BeginDate) AS VARCHAR(5)) + '年' + CAST(MONTH(@BeginDate) AS VARCHAR(5)) + '月' + CAST(DAY(@BeginDate) AS VARCHAR(5)) + '日'
   
   -- 月
   else if( DATEdiff(MM,@EndDate,dateadd(SS,1,@EndDate)) = 1 and DATEdiff(MM,dateadd(SS,-1,@BeginDate),@BeginDate) = 1 and DATEdiff(MM,@BeginDate,dateadd(SS,1,@EndDate)) = 1 )
      set @result= convert(varchar(4),YEAR(@BeginDate),1) + '年' +  convert(varchar(4),Month(@BeginDate),1) + '月';
   
   -- 季度
   else if( DATEdiff(MM,@BeginDate,dateadd(SS,1,@EndDate)) = 3 )
      set @result= convert(varchar(4),YEAR(@BeginDate),1) + '年' + 
      case 
		when Month(@BeginDate) = 1 then '1季度'
		when Month(@BeginDate) = 4 then '2季度'
		when Month(@BeginDate) = 7 then '3季度'
		when Month(@BeginDate) = 10 then '4季度' 
	  end

   -- 年  
   else if( DATEdiff(YY,@BeginDate,dateadd(SS,1,@EndDate)) = 1 and DATEdiff(MM,@EndDate,dateadd(SS,1,@EndDate)) = 1 and DATEdiff(MM,dateadd(SS,-1,@BeginDate),@BeginDate) = 1 )
      set @result= convert(varchar(4),YEAR(@BeginDate),1) + '年'
   
   
   if (@result is null)
      set @result= convert(varchar(10),@BeginDate,23) + '至' + convert(varchar(10),@EndDate,23);
   
   
   return @result

end


go

