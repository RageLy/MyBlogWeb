        
-- =============================================                                                                               
-- Description: <员工列表>                                                                
-- =============================================                                        
CREATE procedure [dbo].Sp_Sys_EmpList                                       
@PageIndex    varchar(50) = '1'                                        
,@PageSize      varchar(50) = '120'                                        
,@OrderFields   varchar(50) = 'EmpID'                                                                   
,@EmpNo VARCHAR(50)=''          --员工编号                          
,@EmpName VARCHAR(50)=''  --员工姓名                                                                                         
as                                        
begin                                                               
    set nocount on;                                        
if(@OrderFields='')        
begin        
 set @OrderFields = 'EmpID'        
end                    
                                                            
  select                                        
CAST( EmpID AS VARCHAR(500)) AS EmpID
,EmpName
,EmpNo
,Sex
,CONVERT(VARCHAR(10),Birth,23) AS Birth
,Address
,Telephone
, CardID
,UserID
,Rmark
,DateLeave
,DateFrom
,Status

  into #Result                                    
 from Tbl_Com_Employee a                                                                   
 --模糊查询条件                      
 where                                         
 --员工编号                       
 (@EmpNo=NULL OR @EmpNo='' OR a.EmpNo LIKE '%'+@EmpNo+'%')                                    
 --员工姓名                          
 AND (@EmpName=NULL OR @EmpName='' OR a.EmpName LIKE '%'+@EmpName+'%')                                                          
 and  a.EmpID != 1                                
                                                                           
declare @pageCount int =@@ROWCOUNT         
 exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize                                          
end
go

