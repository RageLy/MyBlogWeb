
CREATE proc [dbo].[Sp_Echart_scatter_test]
as    
BEGIN
 
  SELECT ROW_NUMBER() OVER(ORDER BY [OutPut]) AS n,'[' + CAST( Temp8 AS VARCHAR(50)) + ',' + CAST( [OutPut] AS VARCHAR(50)) + ',1]' AS 列1
 ,b.Name
 INTO #REsult
 FROM dbo.Bs_SinCapsule a INNER join dbo.vw_DimSinCR_Part b on a.cr >= b.Beginvalue AND a.cr < b.Endvalue AND b.istrue = 0
 

--SELECT ',Name = ''' + Name + ''''  FROM 
--(
-- SELECT DISTINCT Name FROM #REsult
--) x FOR XML PATH('')

SELECT ROW_NUMBER() OVER(ORDER BY n) AS nn,* into #REsult1 FROM #REsult
WHERE Name = '12.40-13.20'

SELECT ROW_NUMBER() OVER(ORDER BY n) AS nn,* into #REsult2 FROM #REsult
WHERE Name = '13.20-14.00'

SELECT a1.列1 AS '12.40-13.20',a2.列1 as '13.20-14.00' FROM #REsult1 a1
FULL JOIN
#REsult2 a2 ON a1.nn = a2.nn

 select '散点图测试' as title
    ,'接待时长' as XName
    ,'销售台数' as YName
    ,'Y2 Name' as YName_Second
    ,'分钟' as XUnit
    ,'台' as YUnit
    ,'Y2 Unit' as YUnit_Second
    ,'1100' AS YMAX
    ,'100' AS YMIN
    ,'9' AS XMAX
    ,'7' AS XMIN
  
END
go

