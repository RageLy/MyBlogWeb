
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年5月26日                                                
-- Descript: 从Excel插入BK颜料
-- =============================================                 
-- exec [Sp_InsertBK]
CREATE PROCEDURE [dbo].[Sp_InsertPigmentBK]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN
        DECLARE @ReturnValue INT = 0;
        DELETE FROM dbo.TempTb_PigmentBK
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_PigmentBK
                            GROUP BY 颜料编号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_PigmentBK
                           );
        PRINT '开始插入Tbl_Base_PigmentBKRawCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_PigmentBKRawCode ( RawCode )
                    SELECT DISTINCT [颜料内部编号]
                    FROM   TempTb_PigmentBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   [Tbl_Base_PigmentBKRawCode]
                                          WHERE  [颜料内部编号] = RawCode
                                      )
                           AND [颜料内部编号] IS NOT NULL;
        PRINT '表Tbl_Base_PigmentBKRawCode数据插入完毕，继续下一步';

        /*颜料外部编号插入 */
        PRINT '开始插入Tbl_Base_PigmentBKOuterCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_PigmentBKOuterCode ( OuterCode )
                    SELECT DISTINCT [颜料外部编号]
                    FROM   TempTb_PigmentBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_PigmentBKOuterCode
                                          WHERE  [颜料外部编号] = OuterCode
                                      )
                           AND [颜料外部编号] IS NOT NULL;
        PRINT '表Tbl_Base_PigmentBKOuterCode数据插入完毕，继续下一步';
        /*颜料外部编号插入 */
        PRINT '开始插入Tbl_Base_PigmentBKBC0015数据，继续下一步';
        DELETE FROM dbo.TempTb_PigmentBK_BC0015
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_PigmentBK_BC0015
                            GROUP BY [BC0015批号]
                        );
        INSERT INTO dbo.Tbl_Base_PigmentBKBC0015 (   BC0015 ,
                                                     GHL ,
                                                     PH,RKDate
                                                 )
                    SELECT DISTINCT [BC0015批号] ,
                           [BC0015固含量] ,
                           [BC0015pH值],BC0015入库日期
                    FROM   TempTb_PigmentBK_BC0015
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_PigmentBKBC0015
                                          WHERE  [BC0015批号] = BC0015
                                      )
                           AND BC0015批号 IS NOT NULL;
        PRINT '表Tbl_Base_PigmentBKBC0015数据插入完毕，继续下一步';

        UPDATE dbo.Tbl_Base_PigmentBKBC0015
        SET    GHL = BC0015固含量 ,
               PH = BC0015pH值,RKDate=BC0015入库日期
        FROM   dbo.TempTb_PigmentBK_BC0015
        WHERE  BC0015 = BC0015批号;
        UPDATE dbo.Bs_PigmentBK
        SET    OptDate = [颜料制备时间] ,
               RawCode = Tbl_Base_PigmentBKRawCode.ID ,
               OuterCode = Tbl_Base_PigmentBKOuterCode.ID ,
               PSize05Bef = [颜料粒径05] ,
               PSize09Bef = [颜料粒径09] ,
               TGA = [颜料TGA] ,
			   RKDate=颜料入库日期,
               BC0015 = Tbl_Base_PigmentBKBC0015.ID ,
               GrindOutPut = [研磨产量] ,
               GHL = [固含量] ,
               CentrifugalTGA = [离心后TGA] ,
               GrindPress = [研磨压力] ,
               GrindTimeB = CONVERT(VARCHAR(100), [颜料制备时间], 23) + ' '
                            + CONVERT(VARCHAR(100), 研磨开始时间, 114) ,
               GrindTimeE = CONVERT(VARCHAR(100), [颜料制备时间], 23) + ' '
                            + CONVERT(VARCHAR(100), 研磨结束时间, 114) ,
               CLTemp15MIN = [出料温度15MIN] ,
               CLTemp30MIN = [出料温度30MIN] ,
               CLTemp45MIN = [出料温度45MIN] ,
               CLTemp60MIN = [出料温度60MIN] ,
               CLTemp90MIN = [出料温度90MIN] ,
               CLTemp120MIN = [出料温度120MIN] ,
               LQTemp10MIN = [冷却水温度10MIN] ,
               LQTemp20MIN = [冷却水温度20MIN] ,
               LQTemp30MIN = [冷却水温度30MIN] ,
               LQTemp60MIN = [冷却水温度60MIN] ,
               LQTemp90MIN = [冷却水温度90MIN] ,
               LQTemp120MIN = [冷却水温度120MIN] ,
               Temp9Less30 = [小于30分9点温度] ,
               Humidity9Less60 = [小于60分9点湿度] ,
               Temp11Less30 = [小于30分11点温度] ,
               Humidity11Less60 = [小于60分11点湿度] ,
               Temp13Less30 = [小于30分13点温度] ,
               Humidity13Less60 = [小于60分13点湿度] ,
               Temp15Less30 = [小于30分15点温度] ,
               Humidity15Less60 = [小于60分15点湿度] ,
               Temp17Less30 = [小于30分17点温度] ,
               Humidity17Less60 = [小于60分17点湿度] ,
               Remark = [备注] ,
               updatetime = GETDATE()
        FROM   [dbo].TempTb_PigmentBK
               LEFT JOIN Tbl_Base_PigmentBKRawCode ON Tbl_Base_PigmentBKRawCode.RawCode = TempTb_PigmentBK.颜料内部编号
               LEFT JOIN Tbl_Base_PigmentBKOuterCode ON Tbl_Base_PigmentBKOuterCode.OuterCode = TempTb_PigmentBK.颜料外部编号
               LEFT JOIN Tbl_Base_PigmentBKBC0015 ON Tbl_Base_PigmentBKBC0015.BC0015 = TempTb_PigmentBK.[BC0015批号]
        WHERE  Code = [颜料编号];
        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_PigmentBK
                                            INNER JOIN dbo.TempTb_PigmentBK ON TempTb_PigmentBK.颜料编号 = Bs_PigmentBK.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;
        PRINT '开始插入Bs_PigmentBK数据，继续下一步';
        INSERT INTO dbo.Bs_PigmentBK (   OptDate ,
                                         Code ,
                                         RawCode ,
                                         OuterCode ,
                                         PSize05Bef ,
                                         PSize09Bef ,
                                         TGA ,
										 RKDate,
                                         BC0015 ,
                                         GrindOutPut ,
                                         GHL ,
                                         CentrifugalTGA ,
                                         GrindPress ,
                                         GrindTimeB ,
                                         GrindTimeE ,
                                         CLTemp15MIN ,
                                         CLTemp30MIN ,
                                         CLTemp45MIN ,
                                         CLTemp60MIN ,
                                         CLTemp90MIN ,
                                         CLTemp120MIN ,
                                         LQTemp10MIN ,
                                         LQTemp20MIN ,
                                         LQTemp30MIN ,
                                         LQTemp60MIN ,
                                         LQTemp90MIN ,
                                         LQTemp120MIN ,
                                         Temp9Less30 ,
                                         Humidity9Less60 ,
                                         Temp11Less30 ,
                                         Humidity11Less60 ,
                                         Temp13Less30 ,
                                         Humidity13Less60 ,
                                         Temp15Less30 ,
                                         Humidity15Less60 ,
                                         Temp17Less30 ,
                                         Humidity17Less60 ,
                                         Remark ,
                                         updatetime
                                     )
                    SELECT [颜料制备时间] ,
                           [颜料编号] ,
                           Tbl_Base_PigmentBKRawCode.ID ,
                           Tbl_Base_PigmentBKOuterCode.ID ,
                           [颜料粒径05] ,
                           [颜料粒径09] ,
                           [颜料TGA] ,
						   颜料入库日期,
                           Tbl_Base_PigmentBKBC0015.ID ,
                           [研磨产量] ,
                           [固含量] ,
                           [离心后TGA] ,
                           [研磨压力] ,
                           CONVERT(VARCHAR(100), [颜料制备时间], 23) + ' '
                           + CONVERT(VARCHAR(100), 研磨开始时间, 114) ,
                           CONVERT(VARCHAR(100), [颜料制备时间], 23) + ' '
                           + CONVERT(VARCHAR(100), 研磨结束时间, 114) ,
                           [出料温度15MIN] ,
                           [出料温度30MIN] ,
                           [出料温度45MIN] ,
                           [出料温度60MIN] ,
                           [出料温度90MIN] ,
                           [出料温度120MIN] ,
                           [冷却水温度10MIN] ,
                           [冷却水温度20MIN] ,
                           [冷却水温度30MIN] ,
                           [冷却水温度60MIN] ,
                           [冷却水温度90MIN] ,
                           [冷却水温度120MIN] ,
                           [小于30分9点温度] ,
                           [小于60分9点湿度] ,
                           [小于30分11点温度] ,
                           [小于60分11点湿度] ,
                           [小于30分13点温度] ,
                           [小于60分13点湿度] ,
                           [小于30分15点温度] ,
                           [小于60分15点湿度] ,
                           [小于30分17点温度] ,
                           [小于60分17点湿度] ,
                           [备注] ,
                           GETDATE()
                    FROM   [dbo].TempTb_PigmentBK
                           LEFT JOIN Tbl_Base_PigmentBKRawCode ON Tbl_Base_PigmentBKRawCode.RawCode = TempTb_PigmentBK.颜料内部编号
                           LEFT JOIN Tbl_Base_PigmentBKOuterCode ON Tbl_Base_PigmentBKOuterCode.OuterCode = TempTb_PigmentBK.颜料外部编号
                           LEFT JOIN Tbl_Base_PigmentBKBC0015 ON Tbl_Base_PigmentBKBC0015.BC0015 = TempTb_PigmentBK.[BC0015批号]
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_PigmentBK
                                          WHERE  Code = [颜料编号]
                                      )
                           AND [颜料编号] IS NOT NULL;

        PRINT '表Bs_PigmentBK数据插入完毕，继续下一步';
        PRINT '所有过程完成';


    END;
go

