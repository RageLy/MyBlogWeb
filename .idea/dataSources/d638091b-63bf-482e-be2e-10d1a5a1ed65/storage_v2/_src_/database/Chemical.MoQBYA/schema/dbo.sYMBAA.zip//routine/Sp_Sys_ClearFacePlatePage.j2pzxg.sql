-- =============================================  
-- Author:  蒋睿智   
-- Create date: 2012-4-23  
-- Description: 清空当前面板操作  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_ClearFacePlatePage]  
 -- Add the parameters for the stored procedure here  
 @PageID varchar(50)  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  
    -- Insert statements for procedure here  
 delete from dbo.Tbl_Sys_PageGroup where PageID=@PageID;  
 select '0'  
END
go

