-- =============================================
-- Author:		<hmw>
-- Create date: <2017-8-3>
-- Description:	<ID类型距离度量明细>
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_Distance_Detail]
    @DimNum NVARCHAR(50),
    @EmpID INT = 1,
    @PageSize VARCHAR(5) = '10',
    @PageIndex VARCHAR(5) = '1',
    @OrderFields VARCHAR(50) = '',
    @OtherCond VARCHAR(50) = ''
AS
BEGIN
    SELECT (CASE
                WHEN a.CoName IS NULL THEN
                    b.CoName
                ELSE
                    a.CoName
            END
           ) CoName,
           (CASE
                WHEN a.X IS NULL THEN
                    b.X
                ELSE
                    a.X
            END
           ) X,
           (CASE
                WHEN a.CountX IS NULL THEN
                    0
                ELSE
                    a.CountX
            END
           ) GCountX,
           (CASE
                WHEN a.CountY IS NULL THEN
                (
                    SELECT DISTINCT
                        CountY
                    FROM TempResultID
                    WHERE Y = '优等'
                          AND CountY IS NOT NULL
                          AND DimNum = @DimNum
                )
                ELSE
                    a.CountY
            END
           ) GCountY,
           CAST((CASE
                     WHEN a.PercentData IS NULL THEN
                         0
                     ELSE
                         a.PercentData
                 END
                ) * 100 AS NVARCHAR(8)) + '%' GPercentData,
           (CASE
                WHEN b.CountX IS NULL THEN
                    0
                ELSE
                    b.CountX
            END
           ) BCountX,
           (CASE
                WHEN b.CountY IS NULL THEN
                (
                    SELECT DISTINCT
                        CountY
                    FROM TempResultID
                    WHERE Y = '差等'
                          AND CountY IS NOT NULL
                          AND DimNum = @DimNum
                )
                ELSE
                    b.CountY
            END
           ) BCountY,
           CAST((CASE
                     WHEN b.PercentData IS NULL THEN
                         0
                     ELSE
                         b.PercentData
                 END
                ) * 100 AS NVARCHAR(8)) + '%' BPercentData,
           CAST(ABS(   (CASE
                            WHEN a.PercentData IS NULL THEN
                                0
                            ELSE
                                a.PercentData
                        END
                       ) - (CASE
                                WHEN b.PercentData IS NULL THEN
                                    0
                                ELSE
                                    b.PercentData
                            END
                           )
                   ) * 100 AS NVARCHAR(8)) + '%' DiffPercentData,
           ABS(   (CASE
                       WHEN a.PercentData IS NULL THEN
                           0
                       ELSE
                           a.PercentData
                   END
                  ) - (CASE
                           WHEN b.PercentData IS NULL THEN
                               0
                           ELSE
                               b.PercentData
                       END
                      )
              ) orderX,
           CAST((CASE
                     WHEN a.MeasureDistance IS NULL THEN
                         0
                     ELSE
                         a.MeasureDistance
                 END
                ) * 100 AS NVARCHAR(8)) + '%' MeasureDistance
    INTO #result
    FROM
        (
            SELECT CoName,
                   X,
                   CountX,
                   CountY,
                   PercentData,
                   DimNum,
                   MeasureDistance
            FROM dbo.TempResultID
            WHERE Y = '优等'
        ) a
        FULL JOIN
        (
            SELECT CoName,
                   X,
                   CountX,
                   CountY,
                   PercentData,
                   DimNum
            FROM dbo.TempResultID
            WHERE Y = '差等'
        ) b
            ON a.DimNum = b.DimNum
               AND b.X = a.X
    WHERE a.DimNum = @DimNum;

    SELECT 'n' 序号,
           'CoName' 字段名,
           'X' 维度取值,
           'GCountX' 优等中数量,
           'GCountY' 优等总数量,
           'GPercentData' 优等中占比,
           'BCountX' 差等中数量,
           'BCountY' 差等总数量,
           'BPercentData' 差等中占比,
           'DiffPercentData' 占比差,
           'MeasureDistance' 占比差总和
    UNION ALL
    SELECT 'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500';
    SET @OrderFields = 'orderX desc';
    DECLARE @totalRow INT = (
                                SELECT COUNT(1) FROM #result
                            );
    EXEC dbo.Sp_Sys_Page @tblName = '#result',
                         @fldName = @OrderFields,
                         @rowcount = @totalRow,
                         @PageIndex = @PageIndex,
                         @PageSize = @PageSize,
                         @SumType = 0,
                         @SumColumn = '',
                         @AvgColumn = '';

    DROP TABLE #result;

    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        EmpName,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter
    )
    VALUES
    (   @EmpID,
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
        GETDATE(),
        'Sp_Analysister_Distance_Detail',
        '' + @DimNum + '列表展示',
        NULL,
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=' + @OtherCond
    );
END;


go

