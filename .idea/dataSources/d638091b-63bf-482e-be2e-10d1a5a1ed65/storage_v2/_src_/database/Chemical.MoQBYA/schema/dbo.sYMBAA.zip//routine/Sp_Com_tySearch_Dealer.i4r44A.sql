  
CREATE PROCEDURE [dbo].[Sp_Com_tySearch_Dealer]    
@Dealer VARCHAR(50)=''  
as                                           
BEGIN     
   select  CAST(DealerId AS INT) Id                                             
 ,CAST(Name AS VARCHAR(500)) Name  
 ,CAST(ZJM AS VARCHAR(500)) ZJM  
 into #result                 
   from Tbl_Web_Dealer       
   where 1=1  AND name LIKE '%'+@Dealer+'%'  
   
     
   select Id AS Dealer ,Name AS DealerName ,ZJM 
    from (                                               
   select Id  
   ,Name   
   ,ZJM  
   from   
   #result  
   )  as x     
   order by ZJM           
         
END
go

