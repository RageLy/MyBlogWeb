-- =============================================
-- Author:		<吴国锋>
-- Update date: <2012-05-15>
-- Description:	<保存面板隐藏列>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Sys_faceGroupColumnChanged]
	@PageID Varchar(50),
	@GroupID Varchar(500),
	@ColumnHide varchar(max)=''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	--if(@PageID=null or @PageID = '')
	--begin
	--	select '请先在首页添加一个面板';
	--	return 
	--end
	--if(@GroupName is null or @GroupName='')
	--  begin
	--    select '请输入在面板显示的标题'
	--    return 
	--  end
	update Tbl_Sys_PageGroup set ColumnHide=@ColumnHide
	where PageGroupID=@PageID and GroupID=@GroupID
	select 0;

END
--select * from Tbl_Sys_PageGroup order by PageID desc
go

