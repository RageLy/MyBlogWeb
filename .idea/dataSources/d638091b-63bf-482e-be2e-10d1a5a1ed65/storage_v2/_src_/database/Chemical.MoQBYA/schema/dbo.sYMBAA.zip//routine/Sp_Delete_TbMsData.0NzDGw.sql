-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE Sp_Delete_TbMsData
    @ID NVARCHAR(20) = '',
    @EmpID NVARCHAR(20) = ''
AS
BEGIN
    IF (@ID <> '')
    BEGIN
        --删除墨水数据
        IF (
           (
               SELECT COUNT(*)
               FROM dbo.Bs_Coating
               WHERE LEFT(Code, 6)IN (
                                         SELECT LEFT(MpCode, 6)FROM Bs_Coating_ZJ WHERE ID = @ID
                                     )
           ) = 1
           )
        BEGIN
            DELETE FROM dbo.Bs_Coating_MS
            WHERE ID IN (
                            SELECT MsCode
                            FROM Bs_Coating,
                                 dbo.Bs_Coating_ZJ
                            WHERE dbo.Bs_Coating.ID = dbo.Bs_Coating_ZJ.CoatingID
                                  AND Bs_Coating_ZJ.ID = @ID
                        );
        END;
        --删除涂布工艺
        --IF ((SELECT COUNT(CoatingID) FROM Bs_Coating_ZJ WHERE ID = @ID) = 0)
        DELETE FROM dbo.Bs_Coating
        WHERE ID IN (
                        SELECT CoatingID FROM Bs_Coating_ZJ WHERE ID = @ID
                    );
        --删除涂布质检
        DELETE FROM dbo.Bs_Coating_ZJ
        WHERE [ID] = @ID;


        INSERT INTO Tbl_Log_AnaUseLog
        (
            EmpID,
            freshTime,
            spName,
            AnaName,
            siftvalue,
            OherParemeter
        )
        VALUES
        (@EmpID, GETDATE(), 'Sp_Delete_TbMsData', '删除涂布质检、工艺、墨水数据', 'DELETE', 'ID =' + @ID);

        SELECT '0';
    END;
    ELSE
    BEGIN
        SELECT '请选择一条记录进行删除';
        RETURN;
    END;
END;
go

