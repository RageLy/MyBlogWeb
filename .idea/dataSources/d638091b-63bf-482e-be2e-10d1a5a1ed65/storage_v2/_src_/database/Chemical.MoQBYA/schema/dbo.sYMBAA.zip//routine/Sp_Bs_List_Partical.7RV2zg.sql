










-- =============================================
-- Author:		白冰
-- Create date: 2016-06-03
-- Description:	获取粒子数据信息列表
-- Parameter：	@ParticalCode -- 粒子编号
--				@PType：-- 黑色粒子、白色粒子
--				@PigmentCode：-- 颜料编号
--              @OptDate：-- 粒子制作时间
--				@Kettle： -- 粒子反应釜
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Bs_List_Partical]
 @OptDateB VARCHAR(50) = ''      
 ,@OptDateE VARCHAR(50) = ''   
 ,@Code VARCHAR(50) = ''  --胶囊取值
 ,@PageIndex varchar(5) = '1'
 ,@PageSize varchar(5) = '10'
 ,@OrderFields varchar(50) = ''
 ,@Type varchar(50) = ''  -- "查询" "编辑" 类型，是查询的List，还是编辑用的加载    
 ,@ID varchar(50) = ''   
 ,@EmpID varchar(50) = '1' 
AS
BEGIN
SET @Code = LTRIM(RTRIM(@Code))

	SELECT  Partical.ID, Partical.Code,
		CONVERT(varchar(50), Partical.OptDate, 23) AS OptDate ,ParticalSeries.Series,
		ParticalKettle.Name AS Kettle, Partical.TOutput, Partical.FOutput, (CASE WHEN PigmentW.Code IS NOT NULL THEN PigmentW.Code
		ELSE PigmentBK.Code END )PigmentCode,
		FBA0001.BA0001, ParticalBE0001.BE0001, CleanBC0001.BC0001 BC0012,ConfigBC0001.BC0001,
		ParticalPole.Ppole, ParticalNole.Npole,
		Partical.Viscosity, Partical.Zeta, Partical.Organic,
		Partical.PSize05,Partical.PSize09,
		Partical.Remark
		INTO #Result 
		FROM    ( SELECT   
		 ( CASE WHEN pbk.ID IS NOT NULL THEN pbk.ID
                           ELSE pw.ID
                      END ) ID , ( CASE WHEN pbk.Code IS NOT NULL THEN pbk.Code
                           ELSE pw.Code
                      END ) Code ,
                    ( CASE WHEN pbk.OptDate IS NOT NULL THEN pbk.OptDate
                           ELSE pw.OptDate
                      END ) OptDate ,
                    ( CASE WHEN pbk.Series IS NOT NULL THEN pbk.Series
                           ELSE pw.Series
                      END ) Series ,
                    ( CASE WHEN pbk.Kettle IS NOT NULL THEN pbk.Kettle
                           ELSE pw.Kettle
                      END ) Kettle ,
                    ( CASE WHEN pbk.FBA0001 IS NOT NULL THEN pbk.FBA0001
                           ELSE pw.FBA0001
                      END ) FBA0001 ,
                    ( CASE WHEN pbk.CleanBA0001 IS NOT NULL
                           THEN pbk.CleanBA0001
                           ELSE pw.CleanBA0001
                      END ) CleanBA0001 ,
                    ( CASE WHEN pbk.CleanBA0002 IS NOT NULL
                           THEN pbk.CleanBA0002
                           ELSE pw.CleanBA0002
                      END ) CleanBA0002 ,
                    ( CASE WHEN pbk.BE0001 IS NOT NULL THEN pbk.BE0001
                           ELSE pw.BE0001
                      END ) BE0001 ,
                    ( CASE WHEN pbk.BG0001 IS NOT NULL THEN pbk.BG0001
                           ELSE pw.BG0001
                      END ) BG0001 ,
                    ( CASE WHEN pbk.CleanBC0001 IS NOT NULL
                           THEN pbk.CleanBC0001
                           ELSE pw.CleanBC0001
                      END ) CleanBC0001 ,
                    ( CASE WHEN pbk.ConfigBC0001 IS NOT NULL
                           THEN pbk.ConfigBC0001
                           ELSE pw.ConfigBC0001
                      END ) ConfigBC0001 ,
                    ( CASE WHEN pbk.TOutput IS NOT NULL THEN pbk.TOutput
                           ELSE pw.TOutput
                      END ) TOutput ,
                    ( CASE WHEN pbk.FOutput IS NOT NULL THEN pbk.FOutput
                           ELSE pw.FOutput
                      END ) FOutput ,
                    ( CASE WHEN pbk.PigmentID IS NOT NULL THEN pbk.PigmentID
                           ELSE pw.PigmentID
                      END ) PigmentID ,
                    ( CASE WHEN pbk.Viscosity IS NOT NULL THEN pbk.Viscosity
                           ELSE pw.Viscosity
                      END ) Viscosity ,
                    ( CASE WHEN pbk.Zeta IS NOT NULL THEN pbk.Zeta
                           ELSE pw.Zeta
                      END ) Zeta ,
                    ( CASE WHEN pbk.Organic IS NOT NULL THEN pbk.Organic
                           ELSE pw.Organic
                      END ) Organic ,
                    ( CASE WHEN pbk.PSize05 IS NOT NULL THEN pbk.PSize05
                           ELSE pw.PSize05
                      END ) PSize05 ,
                    ( CASE WHEN pbk.PSize09 IS NOT NULL THEN pbk.PSize09
                           ELSE pw.PSize09
                      END ) PSize09 ,
                    ( CASE WHEN pbk.Ppole IS NOT NULL THEN pbk.Ppole
                           ELSE pw.Ppole
                      END ) Ppole ,
                    ( CASE WHEN pbk.Npole IS NOT NULL THEN pbk.Npole
                           ELSE pw.Npole
                      END ) Npole ,
                    ( CASE WHEN pbk.ReactivityWet IS NOT NULL
                           THEN pbk.ReactivityWet
                           ELSE pw.ReactivityWet
                      END ) ReactivityWet ,
                    ( CASE WHEN pbk.ReactivityTemp IS NOT NULL
                           THEN pbk.ReactivityTemp
                           ELSE pw.ReactivityTemp
                      END ) ReactivityTemp ,
                    ( CASE WHEN pbk.Remark IS NOT NULL THEN pbk.Remark
                           ELSE pw.Remark
                      END ) Remark ,
                    ( CASE WHEN pbk.info IS NOT NULL THEN pbk.info
                           ELSE pw.info
                      END ) info ,
                    ( CASE WHEN pbk.update_time IS NOT NULL
                           THEN pbk.update_time
                           ELSE pw.update_time
                      END ) update_time
          FROM      dbo.Bs_ParticalBK pbk
                    FULL JOIN dbo.Bs_ParticalW pw ON pw.Code = pbk.Code
        ) Partical
        LEFT JOIN Tbl_Base_ParticalKettle ParticalKettle ON ParticalKettle.ID = Partical.Kettle
        LEFT JOIN dbo.Bs_PigmentW PigmentW ON PigmentW.ID = Partical.PigmentID
        LEFT JOIN dbo.Bs_PigmentBK PigmentBK ON PigmentBK.ID = Partical.PigmentID
        LEFT JOIN Tbl_Base_ParticalBE0001 ParticalBE0001 ON ParticalBE0001.ID = Partical.BE0001
        LEFT JOIN Tbl_Base_BC0001 CleanBC0001 ON CleanBC0001.ID = Partical.CleanBC0001
        LEFT JOIN Tbl_Base_BC0001 ConfigBC0001 ON ConfigBC0001.ID = Partical.ConfigBC0001
        LEFT JOIN Tbl_Base_BA0001 FBA0001 ON FBA0001.ID = Partical.FBA0001
        LEFT JOIN Tbl_Base_BA0001 CleanBA0001 ON CleanBA0001.ID = Partical.CleanBA0001
        LEFT JOIN Tbl_Base_BA0002 CleanBA0002 ON CleanBA0002.ID = Partical.CleanBA0002
        LEFT JOIN Tbl_Base_BG0001 BG0001 ON BG0001.ID = Partical.BG0001
        LEFT JOIN Tbl_Base_ParticalPole ParticalNole ON ParticalNole.ID = Partical.Npole
        LEFT JOIN Tbl_Base_ParticalPole ParticalPole ON ParticalPole.ID = Partical.Ppole
        LEFT JOIN Tbl_Base_ParticalSeries ParticalSeries ON ParticalSeries.ID = Partical.Series
       where ( @Code = '' or Partical.Code like ('%' + @Code + '%') )
       AND ( @OptDateB = '' or Partical.[OptDate] >= @OptDateB )       
       AND ( @OptDateE = '' or Partical.[OptDate] < DATEAdd(DD,1,@OptDateE ) )    
       AND ( @Type = '查询' OR Partical.ID = @ID )
   -- 数据分页    
 DECLARE @totalRow int = @@ROWCOUNT ;    
  
    if(@OrderFields='')    
  set @OrderFields ='optdate desc'    

  -- 编辑的加载 
		 INSERT INTO Tbl_Log_AnaUseLog
			(EmpID, freshTime, spName,
				AnaName, siftvalue, OherParemeter)
			VALUES (@EmpID, GETDATE(), 'Sp_Bs_List_Partical',
				'查询粒子数据', 'select',@Code)    
     
 IF(@Type = '查询')
 begin
 
  EXEC dbo.Sp_Sys_Page @tblName = '#Result'                      
  ,@fldName = @OrderFields                              
  ,@rowcount = @totalRow     
  ,@PageIndex = @PageIndex     
  ,@PageSize = @PageSize      
  ,@SumType = 0    
  ,@SumColumn = ''    
  ,@AvgColumn = ''    
     
     end
 ELSE     
    SELECT * FROM #Result    
	
END
go

