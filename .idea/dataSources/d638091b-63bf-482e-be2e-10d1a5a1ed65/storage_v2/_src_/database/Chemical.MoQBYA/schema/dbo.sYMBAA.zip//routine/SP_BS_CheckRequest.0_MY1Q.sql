CREATE PROC [dbo].[SP_BS_CheckRequest]
@mac VARCHAR(100) = '123'
AS
BEGIN


IF @mac='' 
OR EXISTS (SELECT 1 FROM Tbl_config_SystemSetting WHERE SettingName='Mac过滤' AND SettingValue = '否') 
OR EXISTS(SELECT 1 FROM dbo.Tbl_Com_RequestPermission WHERE ( mac = @mac AND IsAllowedAccess =1))
BEGIN
SELECT '1'
END
ELSE
BEGIN
SELECT '0'
END
END
go

