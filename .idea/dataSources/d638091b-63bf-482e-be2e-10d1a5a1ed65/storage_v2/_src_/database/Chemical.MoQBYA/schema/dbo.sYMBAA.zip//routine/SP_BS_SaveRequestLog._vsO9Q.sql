CREATE PROC [dbo].[SP_BS_SaveRequestLog]
@mac VARCHAR(100)='',
@username varchar(100)='',
@pwd VARCHAR(100)=''
AS
BEGIN
INSERT INTO dbo.Tbl_Com_RequestLog
        ( Mac, Content, LogTime )
VALUES  ( @mac, 
          @username+';'+@pwd,
          Getdate()
          )
END
go

