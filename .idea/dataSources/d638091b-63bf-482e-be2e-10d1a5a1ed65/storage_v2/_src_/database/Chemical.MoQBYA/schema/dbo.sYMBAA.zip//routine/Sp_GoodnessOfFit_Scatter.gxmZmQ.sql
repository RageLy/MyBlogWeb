CREATE PROCEDURE [dbo].[Sp_GoodnessOfFit_Scatter]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimSinYX:-1%DimOilSeries:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimSinJNPH:-1%DimSinBG0002:-1%DimOilDensity:-1%DimOilSTension:-1' ,
    @OtherCond VARCHAR(MAX) = '%温度8%釜%胶囊产值%line%平均值%温度8%数量' ,
    @OrderFields VARCHAR(50) = '' ,
    @SpName VARCHAR(50) = 'SinCapsule' ,
    @EmpID INT = 1 ,
    -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15' ,
    @XValue VARCHAR(50) = '' ,
    @DSValue VARCHAR(50) = ''
AS
    BEGIN
        ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

        SET NOCOUNT ON;

        DECLARE @SiftValue VARCHAR(MAX);
        SET @SiftValue = REPLACE(@condition, '|', ',');
        DECLARE @Usertitle VARCHAR(50) = ''; -- 标题            
        DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
        DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
        DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                              

        -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

        DECLARE @OtherCondTbl TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                String NVARCHAR(50)
            );

        INSERT INTO @OtherCondTbl
                    SELECT string
                    FROM   dbo.f_splitSTR(@OtherCond, '%');

        SET @XName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 2
                     );
        SET @DSName = (   SELECT String
                          FROM   @OtherCondTbl
                          WHERE  ID = 3
                      );
        SET @YName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 4
                     );

        IF (   (   SELECT IsRange
                   FROM   dbo.Tbl_AnsCom_DIimToTable
                   WHERE  SpType LIKE '%' + @SpName + '%'
                          AND Name_ch = @XName
               ) = 0
           )
            BEGIN
                SELECT 'prompt' 提示
                UNION ALL
                SELECT 'VARCHAR 500';
                SELECT 'X轴是非数值类型的维度无法查看拟合优度列表' prompt;
                RETURN;
            END;
        IF ( @XName = '无横轴' )
            BEGIN
                SELECT 'prompt' 提示
                UNION ALL
                SELECT 'VARCHAR 500';
                SELECT 'X轴未选择维度无法查看拟合优度列表' prompt;
                RETURN;
            END;
        ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


        -- 时间表 时间临时表必然需要
        CREATE TABLE #time
            (
                id VARCHAR(200) ,
                beginDate DATETIME ,
                endDate DATETIME ,
                beginDate_Lp DATETIME ,
                endDate_Lp DATETIME ,
                beginDate_Ly DATETIME ,
                endDate_Ly DATETIME
            );

        -- 如果有其它需要用 #时间表的必须在这里添加

        DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
        DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
        DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
        DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
        DECLARE @NumSql VARCHAR(500); -- 用于拼接@Sql中 指标计算方式的Sql语句            
        DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句
        DECLARE @ErrorRecord NVARCHAR(MAX) = '';
        SET @XOrder = ',1 as X排序';
        SET @DsOrder = ',1 as G排序';

        -- 处理维度临时表
        CREATE TABLE #Dims
            (
                DimName VARCHAR(50) ,
                DimValues VARCHAR(MAX) ,
                ChName VARCHAR(50) ,
                Isneed VARCHAR(50) ,
                DimOrdersql VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                isrange VARCHAR(50) ,
            );

        EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue ,
                                        @XName = @XName ,
                                        @DsName = @DSName;
        --SELECT  *
        --FROM    #Dims;
        IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @YName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'ND' ,
                                   '' ,
                                   AtYSql ,
                                   IsRange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @YName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
            END;
        PRINT 'XName' + @XName + @YName;
        IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @XName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'X' ,
                                   '' ,
                                   AtYSql ,
                                   IsRange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @XName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
            END;
        --SELECT  *
        --FROM    #Dims;

        --from 源表
        DECLARE @FromSql VARCHAR(MAX) = (   SELECT JoinTables + CHAR(10)
                                                   + BaseTable + ' '
                                            FROM   Tbl_AnsCom_AnaSpConfig
                                            WHERE  SpName = @SpName
                                        );
        IF (   @FromSql IS NULL
               OR @FromSql = ''
           )
            BEGIN
                SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables,BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = ''' + @SpName
                                    + '''结果为空 ,可能导致报错,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_GoodnessOfFit_Scatter' , -- SpName - nvarchar(50)
                           @ErrorRecord ,               -- ErrorInto - nvarchar(1000)
                           'Exec Sp_GoodnessOfFit_Scatter @PageIndex = '''
                           + @PageIndex
                           + ''' ,
                                @PageSize = ''' + @PageSize
                           + ''' ,
                                @OrderFields = ''' + @OrderFields
                           + ''' ,
                                @XValue = ''' + @XValue
                           + ''',
                                @DSValue = ''' + @DSValue
                           + ''' ,@condition=''' + @condition
                           + ''',@OtherCond=''' + @OtherCond + ''',@SpName'''
                           + @SpName + ''',@EmpID='''
                           + CAST(@EmpID AS NVARCHAR(2)) + '''',
                           GETDATE()                    -- ExecSql - nvarchar(1000)
                       );

                RETURN;
            END;
        PRINT @FromSql;
        -- 拼接创建维度临时表的语句
        SET @sql += (   SELECT 'CREATE TABLE #' + DimName
                               + -- 非范围维度类型3列
                            CASE WHEN isrange = 0 THEN
                                     '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                                 -- 范围维度类型5列
                                 WHEN isrange = 1 THEN
                                     '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'
                            END
                        FROM   #Dims
                        WHERE  Isneed <> 'ND'
                        FOR XML PATH('')
                    );
        DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
        SET @NeedSiftvalue = (   SELECT '%' + DimName + ':' + DimValues
                                 FROM   #Dims
                                 WHERE  Isneed <> 'ND'
                                 FOR XML PATH('')
                             );

        -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %-----------------------------------
        SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                      'Dim7:'
                                      + dbo.GetDimValue(@SiftValue, 'Dim7')
                                      + @NeedSiftvalue
                                  ELSE
                                      SUBSTRING(
                                                   @NeedSiftvalue ,
                                                   2 ,
                                                   LEN(@NeedSiftvalue)
                                               )
                             END;
        -- 解析维度
        SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''
                    + @NeedSiftvalue + ''', @EmpID = '
                    + CAST(@EmpID AS VARCHAR(50)) + ';';

        DECLARE @JudgeGroup NVARCHAR(10) = '';
        SET @JudgeGroup = (   SELECT DimValues
                              FROM   #Dims
                              WHERE  ChName = @DSName
                          );
        IF ( @JudgeGroup = '-1' )
            SET @DSName = '无分组';

        PRINT '分组:' + @DSName;

        -------------------------- 维度解析段------------------------------------------------------------



        -------------------------- 创建 where INNERJOIN 筛选出数据维度主题---------------------------------
        DECLARE @whereWD VARCHAR(MAX) = ''; ---提取控制维度名

        DECLARE @TimeName VARCHAR(50);
        SET @TimeName = (   SELECT TimeName
                            FROM   Tbl_AnsCom_AnaSpConfig
                            WHERE  SpName = @SpName
                        );
						IF(@TimeName = '' OR @TimeName IS NULL)
	BEGIN
		set @ErrorRecord+='查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '''+@SpName+'''为空,请检查;';
		  INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_GoodnessOfFit_Scatter' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_GoodnessOfFit_Scatter @PageIndex = '''+@PageIndex+''' ,
                                @PageSize = '''+@PageSize+''' ,
                                @OrderFields = '''+@OrderFields+''' ,
                                @XValue = '''+@XValue+''',
                                @DSValue = '''+@DSValue+''' ,@condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
	END

        IF ( CHARINDEX('Dim7', @SiftValue) <> 0 )
            SET @whereWD += ' INNER JOIN #time t on ' + @TimeName
                            + ' >= t.beginDate and ' + @TimeName
                            + ' <= t.endDate';

        --创建记录分组的维度列表
        --SELECT @DSName;
        CREATE TABLE #ViewNameTb
            (
                DimNum NVARCHAR(50) ,
                ViewName NVARCHAR(50) ,
                ChName NVARCHAR(50) ,
                Isrange INT ,
                DimYsql NVARCHAR(50)
            );
        IF ( @DSName <> '无分组' )
            BEGIN
                INSERT INTO #ViewNameTb
                            SELECT Tbl_AnsCom_DIimToTable.DimNum ,
                                   Tbl_AnsCom_DIimToTable.ViewName ,
                                   Tbl_AnsCom_DIimToTable.Name_ch ,
                                   IsRange ,
                                   Tbl_AnsCom_DIimToTable.AtYSql
                            FROM   Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @DSName
                                   AND SpType LIKE '%' + @SpName + '%';



                --SELECT *
                --FROM #ViewNameTb;


                SET @whereWD += ISNULL(
                                    (   SELECT ' inner JOIN vw_' + ViewName
                                               + '_Part AS ' + ViewName
                                               + ' on '
                                               + CASE WHEN Isrange = 1 THEN
                                                          ViewName
                                                          + '.BeginValue <= '
                                                          + #ViewNameTb.DimYsql
                                                          + ' AND '
                                                          + ViewName
                                                          + '.EndValue > '
                                                          + #ViewNameTb.DimYsql
                                                      ELSE
                                                          ViewName + '.ID = '
                                                          + DimYsql
                                                 END + ' where ' + ViewName
                                               + '.ID in ('
                                               +   (   SELECT DimValues
                                                       FROM   #Dims
                                                       WHERE  Isneed = 'G'
                                                   ) + ')'
                                        FROM   #ViewNameTb
                                        FOR XML PATH('')
                                    ) ,
                                    ''
                                      );


                SET @whereWD = REPLACE(
                                          REPLACE(@whereWD, '&lt;', '<') ,
                                          '&gt;' ,
                                          '>'
                                      );
            END;
        PRINT '@whereWD: ' + @whereWD;
        --SELECT * FROM #Dims
        --Y 列
        PRINT @YName + @XName;
        DECLARE @Ycolumn VARCHAR(50) = ISNULL((   SELECT DimYsql
                                                  FROM   #Dims
                                                  WHERE  ChName = @YName
                                              ) ,
                                              ''
                                             ); -- Y轴在本表上面的列名
        DECLARE @Xcolumn VARCHAR(50) = ISNULL((   SELECT DimYsql
                                                  FROM   #Dims
                                                  WHERE  ChName = @XName
                                              ) ,
                                              ''
                                             ); -- Y轴在本表上面的列名


        PRINT 'Y列：' + @Ycolumn + 'X列：' + @Xcolumn;
        ------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
        --SELECT *
        --FROM #Dims;
        ------------------------------------------------查询列----------------------------------------------

        DECLARE @QuaryColumn NVARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @QuaryColumn += ( ISNULL(
                                          (   SELECT 'A.' + ViewName
                                                     + 'Name,'
                                              FROM   #ViewNameTb
                                              WHERE  NOT EXISTS (   SELECT 1
                                                                    FROM   #Dims
                                                                    WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                           AND DimYsql = ''
                                                                                         + @Xcolumn
                                                                                         + ''
                                                                )
                                              FOR XML PATH('')
                                          ) ,
                                          ''
                                            )
                                    ) + '';

                SET @QuaryColumn = ','
                                   + SUBSTRING(
                                                  @QuaryColumn ,
                                                  1 ,
                                                  LEN(@QuaryColumn) - 1
                                              );
            END;

        PRINT '查询列: ' + @QuaryColumn + '';
        --------------------------------------------分组语句----------------------------------------------------  
        DECLARE @sqlGroup NVARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @sqlGroup += 'GROUP BY '
                                 + ISNULL(
                                       (   SELECT ViewName + '.Name,'
                                           FROM   #ViewNameTb
                                           WHERE  NOT EXISTS (   SELECT 1
                                                                 FROM   #Dims
                                                                 WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                        AND DimYsql = ''
                                                                                      + @Xcolumn
                                                                                      + ''
                                                             )
                                           FOR XML PATH('')
                                       ) ,
                                       ''
                                         );

                SET @sqlGroup = SUBSTRING(@sqlGroup, 1, LEN(@sqlGroup) - 1);
            END;
        PRINT '分组' + @sqlGroup + '';
        --------------------------------------------分组语句2----------------------------------------------------  
        DECLARE @sqlGroup2 NVARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @sqlGroup2 += 'GROUP BY A.num,A.AVGX,A.AVGY,'
                                  + ( ISNULL(
                                          (   SELECT 'A.' + ViewName
                                                     + 'Name,'
                                              FROM   #ViewNameTb
                                              WHERE  NOT EXISTS (   SELECT 1
                                                                    FROM   #Dims
                                                                    WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                           AND DimYsql = ''
                                                                                         + @Xcolumn
                                                                                         + ''
                                                                )
                                              FOR XML PATH('')
                                          ) ,
                                          ''
                                            )
                                    ) + '';
                SET @sqlGroup2 = SUBSTRING(@sqlGroup2, 1, LEN(@sqlGroup2) - 1);
            END;
        ELSE
            SET @sqlGroup2 = 'GROUP BY A.num,A.AVGX,A.AVGY';
        PRINT '分组2' + @sqlGroup2 + '';
        ---------------------------------------------字段列------------------------------------------------------      
        DECLARE @sqlColumn NVARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @sqlColumn += ( ISNULL(
                                        (   SELECT ViewName + '.Name as '
                                                   + ViewName + 'Name,'
                                            FROM   #ViewNameTb
                                            WHERE  NOT EXISTS (   SELECT 1
                                                                  FROM   #Dims
                                                                  WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                         AND DimYsql = ''
                                                                                       + @Xcolumn
                                                                                       + ''
                                                              )
                                            FOR XML PATH('')
                                        ) ,
                                        ''
                                          )
                                  ) + '';
                SET @sqlColumn = ','
                                 + SUBSTRING(
                                                @sqlColumn ,
                                                1 ,
                                                LEN(@sqlColumn) - 1
                                            );
            END;

        PRINT '列' + @sqlColumn + '';



        ------------------------------------------------ON 条件关联----------------------------------------------
        DECLARE @ONRelation NVARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @ONRelation += ( ISNULL(
                                         (   SELECT 'A.' + ViewName
                                                    + 'Name=B.' + ViewName
                                                    + 'Name and '
                                             FROM   #ViewNameTb
                                             WHERE  NOT EXISTS (   SELECT 1
                                                                   FROM   #Dims
                                                                   WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                          AND DimYsql = ''
                                                                                        + @Xcolumn
                                                                                        + ''
                                                               )
                                             FOR XML PATH('')
                                         ) ,
                                         ''
                                           )
                                   ) + '';

                SET @ONRelation = 'ON '
                                  + LEFT(@ONRelation, LEN(@ONRelation) - 3);
            END;
        PRINT 'ON条件关联: ' + @ONRelation + '';
        ------------------------------------------------变动列----------------------------------------------------------------------
        DECLARE @ColumnOther VARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @ColumnOther += ( ISNULL(
                                          (   SELECT '''' + ViewName
                                                     + 'Name'' '
                                                     + #ViewNameTb.ChName
                                                     + ','
                                              FROM   #ViewNameTb
                                              WHERE  NOT EXISTS (   SELECT 1
                                                                    FROM   #Dims
                                                                    WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                           AND DimYsql = ''
                                                                                         + @Xcolumn
                                                                                         + ''
                                                                )
                                              FOR XML PATH('')
                                          ) ,
                                          ''
                                            )
                                    ) + '';
                SET @ColumnOther = LEFT(@ColumnOther, LEN(@ColumnOther) - 1)
                                   + ',';
            END;
        PRINT '@ColumnOther:' + @ColumnOther;
        -----------------------------------------变动列的字符类型-----------------------------------------------------------------
        DECLARE @VarcharsOther VARCHAR(MAX) = '';
        IF ( @DSName <> '无分组' )
            BEGIN
                SET @VarcharsOther += ( ISNULL(
                                            (   SELECT '''Varchar 500'','
                                                FROM   #ViewNameTb
                                                WHERE  NOT EXISTS (   SELECT 1
                                                                      FROM   #Dims
                                                                      WHERE  #Dims.DimName = #ViewNameTb.DimNum
                                                                             AND DimYsql = ''
                                                                                           + @Xcolumn
                                                                                           + ''
                                                                  )
                                                FOR XML PATH('')
                                            ) ,
                                            ''
                                              )
                                      ) + '';
                SET @VarcharsOther = LEFT(@VarcharsOther, LEN(@VarcharsOther)
                                                          - 1) + ',';
            END;
        PRINT '@VarcharsOther:' + @VarcharsOther;
        IF ( @DSName <> '无分组' )
            DECLARE @InnerCross NVARCHAR(20) = 'INNER';
        ELSE
            SET @InnerCross = 'CROSS';
        ------------------------------------执行sql语句---------------------------------------------
        DECLARE @sqlnew NVARCHAR(MAX) = '';
        SET @sqlnew += 'SELECT COUNT(*) num, MIN(B.X) XMINValue ,
        MAX(B.X) XMAXValue,
        MIN(B.Y) YMINValue ,
        MAX(B.Y) YMAXValue,
        POWER(SUM(( B.X - A.AVGX ) * ( B.Y - A.AVGY )), 2)
        / ( CASE WHEN ( SUM(POWER(( B.X - A.AVGX ), 2))
                        * SUM(POWER(( B.Y - A.AVGY ), 2)) ) = 0 THEN 1
                 ELSE SUM(POWER(( B.X - A.AVGX ), 2))
                      * SUM(POWER(( B.Y - A.AVGY ), 2))
            END ) R2 ,
            ( SUM(B.X * B.Y)*num - SUM(B.X)*SUM(B.Y) )
        / ( CASE WHEN ( SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) ) = 0
                 THEN 1
                 ELSE  SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) 
            END ) K ,
        AVGY - ( ( SUM(B.X * B.Y)*num - SUM(B.X)*SUM(B.Y) )
        / ( CASE WHEN ( SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) ) = 0
                 THEN 1
                 ELSE  SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) 
            END ) ) * AVGX Const ,

 SUM(( B.X - AVGX ) * ( B.Y - AVGY ))
        / ( CASE WHEN ( POWER(SUM(POWER(( B.X - AVGX ), 2)), 0.5)
                        * POWER(SUM(POWER(( B.Y - AVGY ), 2)), 0.5) ) = 0
                 THEN 1
                 ELSE POWER(SUM(POWER(( B.X - AVGX ), 2)), 0.5)
                      * POWER(SUM(POWER(( B.Y - AVGY ), 2)), 0.5)
            END ) Relation 
        ' + @QuaryColumn
                       + ' into #Result
        
FROM    ( SELECT    AVG(' + @Ycolumn + ') AVGY ,
                    AVG(' + @Xcolumn + ' ) AVGX 
                    ' + @sqlColumn
                       + ', 
                    COUNT(*) num from
          ' + CHAR(10) + @FromSql + CHAR(10) + @whereWD + CHAR(10)
                       + @sqlGroup + '
        ) A
        ' + @InnerCross + ' JOIN ( SELECT ' + @Ycolumn
                       + ' Y ,
                            ' + @Xcolumn
                       + ' X 
                            ' + @sqlColumn + '
                    from ' + CHAR(10) + @FromSql + CHAR(10) + @whereWD
                       + '
                   ) B ' + @ONRelation + '
' +     @sqlGroup2 + '';
        SET @sqlnew += ' select *,(case when Relation>0 and Relation<1 then ''正相关'' 
when Relation<0 and Relation>-1 then ''负相关''
when Relation=1 then ''完全正相关'' 
when Relation=-1 then ''完全负相关''
when Relation=0 then ''不相关'' end) RelaRemark into #ResultNew from #Result where num>1';
SET @sqlnew +=' if((select count(*) from #result)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_GoodnessOfFit_Scatter'',''表#Result数据为空,可能造成报错请检查'',''Exec Sp_GoodnessOfFit_Scatter @PageIndex = '''''+@PageIndex+''''',@PageSize = '''''+@PageSize+''''',@OrderFields = '''''+@OrderFields+''''',@XValue = '''''+@XValue+''''',@DSValue = '''''+@DSValue+''''',@condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@SpName'''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(2))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''')  end'

        DECLARE @Varchars VARCHAR(MAX) = 'select ''n'' 序号,''num'' 数量,''XMINValue'' X轴最小值,''XMAXValue'' X轴最大值,''YMINValue'' Y轴最小值,''YMAXValue'' Y轴最大值,''R2'' 拟合优度,''K'' 斜率,''Const'' 截距,'
                                         + @ColumnOther + '''Relation'' 相关系数'
                                         + ' UNION ALL 
    SELECT ''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'','
                                         + @VarcharsOther + '''Varchar 500''';

        PRINT '字段列' + @Varchars;

        IF (   @OrderFields = ''
               OR @OrderFields IS NULL
           )
            SET @OrderFields = 'Relation desc';

        DECLARE @Pagesql VARCHAR(MAX) = '  DECLARE @totalRow int = (Select count(1) FROM #ResultNew) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#ResultNew''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''''
  ,@AvgColumn = ''''
 '      ;
        DECLARE @DebugTime NVARCHAR(500) = 'CREATE TABLE #time
    (
        id VARCHAR(200),
        beginDate DATETIME,
        endDate DATETIME,
        beginDate_Lp DATETIME,
        endDate_Lp DATETIME,
        beginDate_Ly DATETIME,
        endDate_Ly DATETIME
    );' ;
        --SELECT @sql + @sqlnew + @Pagesql;
        EXEC ( @Varchars );
        EXEC ( @sql + @sqlnew + @Pagesql );
        --SELECT @DebugTime+@sql + @sqlnew + @Pagesql;

        -- 注销临时表
        DROP TABLE #time;
        DROP TABLE #Dims;
        DROP TABLE #ViewNameTb;
        --日志记录
        INSERT INTO Tbl_Log_AnaUseLog (   EmpID ,
                                          EmpName ,
                                          freshTime ,
                                          spName ,
                                          AnaName ,
                                          siftvalue ,
                                          OherParemeter
                                      )
        VALUES ( @EmpID ,
                 (   SELECT EmpName
                     FROM   Tbl_Com_Employee
                     WHERE  EmpID = @EmpID
                 ) ,
                 GETDATE(),
                 'Sp_GoodnessOfFit_Scatter' ,
                 '' + @SpName + '散点图拟合分析',
                 @condition ,
                 '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='
                 + @OtherCond
               );
    END;




-- DELETE Tbl_AnsCom_DIimToTable WHERE DimNum ='DimBC0015GHL'

------------------------------------------
go

