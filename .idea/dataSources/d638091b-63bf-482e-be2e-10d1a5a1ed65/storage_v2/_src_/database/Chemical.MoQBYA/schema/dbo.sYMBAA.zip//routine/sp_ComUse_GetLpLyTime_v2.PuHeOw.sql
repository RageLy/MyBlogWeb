-- ====================================                    
                  
-- 默认描述: 获取一个时间段的环比或者同比时间段，两个日期段  
-- 此版本获取的同比环比时间   倒退同样天数的同比环比时间
-- 区别于  [sp_ComUse_GetLpLyTime_v1]     是获取的 为日历同比 环比

-- ====================================                    
                
CREATE proc [dbo].[sp_ComUse_GetLpLyTime_v2]                 
   @beginDate Datetime = '2014-03-01' -- 开始时间                
   ,@endDate Datetime = '2014-03-31'  -- 结束时间        
         
   ,@BeginDateL Datetime = null output -- 开始时间                
   ,@EndDateL Datetime= null output -- 结束时间       
                  
   ,@BeginDateLy Datetime  = null output -- 同比开始时间                
   ,@EndDateLy datetime= null output -- 同比结束时间                
   ,@BeginDateLy2 Datetime  = null output -- 同比开始时间                
   ,@EndDateLy2 datetime= null output -- 同比结束时间                
   ,@BeginDateLp datetime = null output -- 环比开始时间                
   ,@EndDateLp datetime = null output -- 环比结束时间               
   ,@BeginDateLp2 datetime = null output -- 环比开始时间                
   ,@EndDateLp2 datetime = null output -- 环比结束时间  
   ,@type int =1 -----------@type=2 是month类型               
as                
                  
 declare @Diff int = datediff(day,@begindate,@enddate);  -- 日期相距天数 用于计算日期的类型                   
         
 set @Diff=@Diff+1          
           
 if(@type=1)
 begin          
 set @BeginDateLp = DATEADD(DAY,-@Diff,@begindate);                 
 set @EndDateLp = DATEADD(DAY,-@Diff,@enddate);                 
 set @BeginDateLp2 = DATEADD(DAY,-2*@Diff,@begindate);                 
 set @EndDateLp2 = DATEADD(DAY,-2*@Diff,@enddate);      
 end
 
 if(@type=2)
 begin
 set @BeginDateLp = DATEADD(MONTH,-1,@begindate);                 
 set @EndDateLp = DATEADD(SECOND,-1,@begindate);                 
 set @BeginDateLp2 = DATEADD(MONTH,-2,@begindate);                 
 set @EndDateLp2 = DATEADD(SECOND,-1,@BeginDateLp);   
 
 end
 
 
 
             
 set @BeginDateLy = DATEADD(DAY,-364,@begindate);                  
 set @EndDateLy = DATEADD(MINUTE,-1,@begindate);                
 set @BeginDateLy2 = DATEADD(DAY,-728,@begindate);                  
 set @EndDateLy2 = DATEADD(MINUTE,-1, DATEADD(DAY,-364,@begindate));            
           
 set @BeginDateL = DATEADD(YEAR,-1,@begindate);                
 set @EndDateL = DATEADD(YEAR,-1,@enddate);
go

