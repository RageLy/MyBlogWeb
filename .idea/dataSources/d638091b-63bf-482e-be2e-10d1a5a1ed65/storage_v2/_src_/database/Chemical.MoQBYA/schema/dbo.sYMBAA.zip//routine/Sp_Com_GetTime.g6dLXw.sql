-- =============================================  
-- Description: <根据维度名称在字符串中获取相应的维度>  
-- =============================================  
CREATE proc [dbo].[Sp_Com_GetTime]  
@SiftValue   varchar(Max),   --时间字符串  
@tableName varchar(200),  
@needid bit=0  
as  
-- [Sp_Com_GetTime] 'M:2013-4-30'  
begin  
   --获取时间纬度总表,所有时间  
   Create  table #alltime   
   (  
      id varchar(50),  
      Name varchar(50),  
      beginDate varchar(100),  
      enddate varchar(100)  
   )  
   insert into #alltime  
   exec dbo.sp_Dim_7_Level_3_web  
     
   Create table #ids   
   (  
      id varchar(50)  
   )  
     
   --获取传进来的时间编号  
   insert into #ids  
   select String from dbo.split(@SiftValue,',')  
     
   --通过传进来的编号join出结果时间  
   declare @sql varchar(max)  
   if(@needid=0)  
   Begin  
    set @sql='insert into '+@tableName+'   
    select a.beginDate,a.enddate from #alltime a  
    inner join #ids b  
    on a.id=b.id'  
   End  
   Else  
   Begin  
       set @sql='insert into '+@tableName+'   
    select a.id,a.beginDate,a.enddate from #alltime a  
    inner join #ids b  
    on a.id=b.id'  
     
   End  
   exec(@sql)  
     
   --select a.beginDate,a.enddate from #alltime a  
   --inner join #ids b  
   --on a.id=b.id  
end
go

