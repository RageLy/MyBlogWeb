




-- =============================================      

-- Description: 全结构查询
-- Auth:hjl
-- Parameter: 1 @CodeType -- 编号类型    
--            2 @CodeValue -- 编号取值
--            3 @ParaType -- 参数类型
--            4 @ParaValueL -- 参数取值下限
--            5 @paraValueH -- 参数取值上限  
--            6 @ResultType -- 结果类型
-- Content:  拼装SQL查询

-- =============================================   
CREATE proc[dbo].[Sp_Dim_InEdit]
@ID varchar(50) = '346'
,@Action varchar(50) = 'UPDATE'
,@Used	varchar(50) ='单层胶囊'
,@Name_ch	varchar(50) ='test002'
,@CutInt	decimal(18, 4) ='1'
,@NumDecimal	decimal(18, 4) ='1' 
,@BaseCount	INT ='1'
,@EmpID varchar(50) = '1'	
AS
BEGIN
	SET NOCOUNT ON;

IF @Action = 'UPDATE'  --更新数据
BEGIN
			--UPDATE  Tbl_AnsCom_DIimToTable
			--SET
			--Used =@Used
			--,Name_ch =@Name_ch
			--,CutInt =CASE WHEN @CutInt = '' THEN NULL ELSE rtrim(ltrim(@CutInt)) end
			--,NumDecimal = CASE WHEN @NumDecimal = '' THEN NULL ELSE rtrim(ltrim(@NumDecimal)) end
			--,BaseCount = CASE WHEN @BaseCount = '' THEN NULL ELSE rtrim(ltrim(@BaseCount)) end
			--WHERE ID = @ID
			
			UPDATE  Tbl_AnsCom_DIimToTable
			SET
			--Used =@Used
			--,Name_ch =@Name_ch
			CutInt =@CutInt
			,NumDecimal = @NumDecimal
			,BaseCount = @BaseCount
			WHERE ID = @ID
			
		select '修改成功' return end;
end
go

