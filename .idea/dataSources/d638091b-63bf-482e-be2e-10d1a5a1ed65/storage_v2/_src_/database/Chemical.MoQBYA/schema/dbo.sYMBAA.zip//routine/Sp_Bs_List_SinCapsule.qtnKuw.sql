
















-- =============================================   
   
CREATE proc[dbo].[Sp_Bs_List_SinCapsule]
 @OptDateB VARCHAR(50) = ''      
 ,@OptDateE VARCHAR(50) = ''   
 ,@Code VARCHAR(50) = ''  --胶囊取值
 --,@ResultType VARCHAR(50) = '单层胶囊数据'  --结果类型
 ,@PageIndex varchar(5) = '1'
 ,@PageSize varchar(5) = '10'
 ,@OrderFields varchar(50) = ''
 ,@Type varchar(50) = ''  -- "查询" "编辑" 类型，是查询的List，还是编辑用的加载    
 ,@ID varchar(50) = ''    
 ,@EmpID varchar(50) = '1'
AS    
BEGIN    
SET @Code = LTRIM(RTRIM(@Code))
 --------------------- 变量声明  -------------------------    
     
 --DECLARE @Pagesql VARCHAR(2000) = '' -- 用于分页的sql    
    
    
 select jn.ID, CONVERT(varchar(100),jn.OptDate, 23) as OptDate, jn.Code as Code, Lotcode, oil.Code as OilID , SpeType, fu.name as Kettle, Volume, GAA, af1.AF0001, af3.AF0003, bg2.BG0002 as BG0002Code,  Temp41, Time45, Rspeed580, Temp8, Time120, Temp25, Time360, Rspeed400, OutPut, Psize, PsizeSpan,SoildContent, CR, LBK, LW, DeltaBK, DeltaW, jn.PH, PHTemp, jn.Remark 
   INTO #Result
   FROM dbo.Bs_SinCapsule AS jn
   left join Tbl_Base_AF0001 af1
   on jn.AF0001=af1.id
   left join Tbl_Base_AF0003 af3
   on jn.AF0003=af3.id
   left join Tbl_Base_BG0002 bg2
   on jn.BG0002Code=bg2.id
   left join dbo.Tbl_Base_Fu fu
   on jn.Kettle=fu.ID
   LEFT JOIN dbo.Bs_Oil as oil ON jn.OilID = Oil.ID
   where ( @Code = '' or jn.Code like ('%' + @Code + '%') )
   AND ( @OptDateB = '' or jn.[OptDate] >= @OptDateB )       
   AND ( @OptDateE = '' or jn.[OptDate] < DATEAdd(DD,1,@OptDateE ) )   
   AND ( @Type = '查询' OR jn.ID = @ID )
    
     -- 数据分页    
 DECLARE @totalRow int = @@ROWCOUNT ;    
 
    if(@OrderFields='')    
  set @OrderFields ='optdate desc'    
        
   INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_Bs_List_SinCapsule',
        '查询单层胶囊', 'select',@Code)    
        
     
 IF(@Type = '查询')
  EXEC dbo.Sp_Sys_Page @tblName = '#Result'                      
  ,@fldName = @OrderFields                              
  ,@rowcount = @totalRow     
  ,@PageIndex = @PageIndex     
  ,@PageSize = @PageSize      
  ,@SumType = 0    
  ,@SumColumn = ''    
  ,@AvgColumn = ''
  
      
     
 -- 编辑的加载    
 ELSE     
 SELECT * FROM #Result    
 
END     
--select * from tbl_sys_myMenu
go

