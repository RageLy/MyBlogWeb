


-- =============================================                          

-- Update Date: 2016年11月3日
-- 双Y轴图形通用sp
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_Y2_BAK]
  --@condition VARCHAR(MAX)='Dim7:Y:this10%DimDouOutputValue:-100%DimDouFu:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDouTemp41:-1%DimDouSpeed400:-1%DimDouSpeed500:-1%DimYXN:-1%DimDouLJ:-1%DimDouJNGHL:-1%DimDouCR:-1%DimDouLBK:-1%DimDouLW:-1%DimDouDeltaBK:-1%DimDouDeltaW:-1%DimDouPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimDouAF0001:-1%DimDouAF0003:-1%DimDouLJspan-1%DimDouPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1'            
 @condition VARCHAR(MAX)='Dim7:Y:this10%DimDouOutputValue:-100%DimDouFu:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDouTemp41:-1%DimDouSpeed400:-1%DimDouSpeed500:-1%DimSinYX:-1%DimDouLJ:-1%DimDouJNGHL:-1%DimDouCR:-1%DimDouLBK:-1%DimDouLW:-1%DimDouDeltaBK:-1%DimDouDeltaW:-1%DimDouPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimDouAF0001:-1%DimDouAF0003:-1%DimDouLJspan:-1%DimDouPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1'
 ,@OtherCond VARCHAR(MAX) ='温度与产值%釜%时间%胶囊产值%line%平均值%胶囊产值%数量'--'%时间%温度8%产值%line%数量'
 ,@Type VARCHAR(10) = '图' -- '图' or '列表' or '明细'
 ,@SpName VARCHAR(50) = 'DouCapsule'
 ,@OrderFields VARCHAR(50) = 'id'
 ,@EmpID INT = 1

 -- 以下参数只在出明细时使用
 ,@PageIndex VARCHAR(5)='1'
 ,@PageSize VARCHAR(5)='10'
 ,@XValue VARCHAR(50) = ''
 ,@DSValue VARCHAR(50) = ''

AS
BEGIN
            
            
---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            
    
    
    DECLARE @SiftValue VARCHAR(MAX)            
    SET @SiftValue=REPLACE(@condition,'|',',')            
                
    DECLARE @Usertitle VARCHAR(50) = ''          -- 标题            
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''               -- @OtherCond  传入的Y轴名称                
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
    DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                
    DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式
    ------添加双Y
    DECLARE @YName2 VARCHAR(50) = ''                        -- @OtherCond  传入的Y2轴名称
    DECLARE @CTOC2 VARCHAR(50) = ''                         -- @OtherCond 传入的比较方式
    DECLARE @ChartType2 VARCHAR(50) = ''                  -- 展示图形
    DECLARE @CompareType2 VARCHAR(50) = ''        -- 比较方式                      
                
    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                
            
    DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String Nvarchar(50)            
	)            
    
    SET NOCOUNT ON;
           
	INSERT INTO @OtherCondTbl            
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')      

     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)
     SET @YName2 = ( SELECT String FROM @OtherCondTbl WHERE ID = 7)------次Y轴维度
     SET @CTOC2 = ( SELECT String FROM @OtherCondTbl WHERE ID = 8)------次Y轴比较类型      
  
     -- OtherCond解析完毕            
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            
          
----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       
           
----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       
            
	
	-- 时间表 时间临时表必然需要
    CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME            
    )
	
	-- 如果有其它需要用 #时间表的必须在这里添加
	
    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500);      -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500);     -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句            
	DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	DECLARE @CountTypeY2 VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg    
	
    set @XOrder = ',1 as X排序';            
    
    -- 默认使用 sum 遇到需要 count 或 avg 的Y轴再进行修改      
    IF(@CTOC='平均值') set @CountType = 'AVG';
    ELSE IF(@CTOC='数量') set @CountType = 'Count';
    ELSE IF(@CTOC='最大值') set @CountType = 'MAX';     
    ELSE IF(@CTOC='最小值') SET @CountType = 'MIN';   
    ELSE IF(@CTOC='标准差') SET @CountType = 'STDEV';   
    
    IF(@CTOC2='平均值') set @CountTypeY2 = 'AVG';
    ELSE IF(@CTOC2='数量') set @CountTypeY2 = 'Count';
    ELSE IF(@CTOC2='最大值') set @CountTypeY2 = 'MAX';     
    ELSE IF(@CTOC2='最小值') SET @CountTypeY2 = 'MIN';           
    ELSE IF(@CTOC2='标准差') SET @CountTypeY2 = 'STDEV';               
    
------------------------------------------------------系列名称开始
    DECLARE @Ynum1 VARCHAR(500) = ''; -- 定义Y1系列           
    DECLARE @Ynum2 VARCHAR(500);      -- 定义Y2系列  
    set @Ynum1='Y轴1:'+@YName+'('+@CTOC+')'
    set @Ynum2='Y轴2:'+@YName2+'('+@CTOC2+')'
    
    create TABLE  #Yname 
    (            
      YName1 VARCHAR(200) ,
      YName2 VARCHAR(200) 
    )
    insert into #Yname(YName1,YName2)
    values (@Ynum1,@Ynum2)

------------------------------------------------------系列名称结束

    -- 读取转化 Y轴步骤 主要设置 @InnerSelect 内部 select 提取字段部分 还有 外部 select 的算法 @CountType            
	SET @NumSql = ',' + @CountType +'(' + @YName + ') AS num1'+',' + @CountTypeY2 +'(' + @YName2 + ')' ;
          

	-- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable_Y2]
     @SiftValue = @SiftValue
	,@XName = @XName
     
     PRINT '';
     PRINT '-- 维度字符串分解进入维度表完毕 --'; 
     
     -- 拼接创建维度临时表的语句
     
     --SELECT * FROM #Dims;
     
    SET @sql += ( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );
    
		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析
     
     -- 用 Dims 临时表拼接需要解析的 维度字符串
     SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
     
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;

     -- 解析维度
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';
     
     PRINT '';
     PRINT '-- 维度解析段代码拼接完毕 --';    
---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        
  
     -- 结果集表
	 CREATE TABLE #Result_B
	 (
	  DimX varchar(50)
	  ,OrderX int
	  ,num1 decimal(18,2)
	  ,num2 decimal(18,2)
	 );


    DECLARE @Dims varchar(50);
    
	declare @TimeName varchar(50);   -- 用于判断时间的标志
	
	IF CHARINDEX('时间',@Xname) <> 0
		--SET @XOrder = 't.id AS X排序'
		SET @XOrder = '1 AS X排序'
	ELSE 
		SELECT  @XOrder = ( CASE WHEN DimOrdersql = '' THEN DimName + '.VWID'
								-- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS X排序'
							 WHEN DimOrdersql <> '' THEN DimOrdersql
								-- 有特殊排序字符则使用特殊的
							 ELSE '1' END
						  + ' AS X排序' )  -- 都没有则用默认
		FROM #Dims 
		WHERE Isneed = 'X';

	SET @InnerSelect += ',' + @XOrder ;          
            
	set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName)
	IF(@TimeName = '' OR @TimeName IS NULL)
	BEGIN
		SELECT '找不到时间配置字段'
		RETURN;
	END
 
	-- Group by段的
   set @Dims = @XName + ',X排序 '  -- 横轴排序字段             
    
	DECLARE @PieColumn VARCHAR(100)
	SET @PieColumn = '';

-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              
  
  -- 基础版本的 select段Sql语句

  set @sql +=
  '
  INSERT INTO #Result_B(DimX,OrderX,num1,num2)
   SELECT ' + @Dims + @NumSql + ' AS num2
   FROM
   (
   SELECT  1 AS [1], ';
   
   IF(CHARINDEX('Dim7',@SiftValue) <> 0)
		SET @sql += 'dbo.GetTimeName(t.begindate,t.enddate) AS 时间'
   -- 时间维一定有 选出

   -- 按照 是否需要维度 拼装选择的维度字段

	-- 横轴上面的取值要拿出来
	SET @sql += isnull((SELECT ',' + DimName + '.Name AS ' + @XName FROM #Dims WHERE Isneed = 'X'),'')
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名

	-- Y 轴上面的取值要拿出来
	DECLARE @YSQL VARCHAR(100);
	DECLARE @YSQL1 VARCHAR(100);
	DECLARE @YSQL2 VARCHAR(100);
	
	-- 从维度表中取出Y轴上面的维度
	SELECT @YSQL1 = ',' + DimYsql + ' AS ' + @YName FROM #Dims WHERE ChName = @YName;
	SELECT @YSQL2 = ',' + DimYsql + ' AS ' + @YName2 FROM #Dims WHERE ChName = @YName2;
	if (@YSQL1<>@YSQL2)
	 begin
	  select @YSQL=@YSQL1+@YSQL2;
	  end
	  else 
	  begin
	  select @YSQL=@YSQL1
	  end
	-- 实例： ',data.Temp8 AS 温度8';
	
	-- 如果Y轴上面的选取数据是非维度化的内容，则需要在此处注册
	IF ( @YSQL IS NULL) 
		SET @YSQL = CASE 
				WHEN @YName = '举例' THEN ',data.exp' + @YName    -- 这一句是注册样例
				ELSE ',1 AS [Y轴] ' END;
	
	SET @sql += @YSQL;

	DECLARE @FromSql VARCHAR(max) = (SELECT JoinTables FROM Tbl_AnsCom_AnaSpConfig  WHERE SpName = @SpName);
     
    IF(@FromSql IS NULL OR @FromSql = '')
    BEGIN
		SELECT 'sp配置有问题';
		RETURN;
    END
     
    SET @sql += ISNULL(@InnerSelect,'') + ' FROM ' +@FromSql; 

  -- 时间维表一定需要 放在可能会取到时间的表之后            
   IF(CHARINDEX('Dim7',@SiftValue) <> 0)           
	SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';            
  
  -- 临时存储拼接的SQL语句
  DECLARE @sql1 VARCHAR(max) = '';
  
  -- 将INNER JOIN 维度临时表段拼接起来
  SET @sql1 = ( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE DimName + '.ID = ' + DimYsql END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
		
   -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
  SET @sql1 = REPLACE(REPLACE(@sql1,'&lt;','<'),'&gt;','>') ;
  
  -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'
  SET @sql += @sql1 ;
  
  set @sql += '
  ) x
  GROUP BY ' + @Dims;

  -- 排序段
  SET @sql += ' Order By X排序;'
  
  -- 注销临时表
	SET @sql += ( SELECT 'DROP TABLE #' +  DimName + ';'
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );
  
  PRINT '';
  PRINT '-- 全部提取数据语句拼接完毕 运行语句 ：';  
  PRINT @sql;
  EXEC(@sql);
  PRINT '';
  PRINT '-- 执行语句完毕 -- '; 
  
------------------------------------------------------------ 各比较类型数据计算 ----------------------------------------------------------------------                  
   CREATE TABLE #Result_Final            
    (            
      OrderX INT ,            
      DimX VARCHAR(max) ,                     
      num1 DECIMAL(18, 2),
      num2 DECIMAL(18, 2)        
    )             
                 
     CREATE TABLE #Result_All            
    (            
      DimX VARCHAR(max) ,            
      OrderX INT ,                      
      num1 DECIMAL(18, 2),
      num2 DECIMAL(18, 2) 
    )
   
	INSERT  INTO #Result_Final ( OrderX,DimX,num1,num2 )
	SELECT OrderX,DimX,num1,num2 FROM  #Result_B;

	DECLARE @YMax1 DECIMAL(18,2),@YMin1 DECIMAL(18,2)
	DECLARE @YMax2 DECIMAL(18,2),@YMin2 DECIMAL(18,2)

	SELECT @YMax1 = MAX(num1),@YMin1 = MIN(num1) FROM #Result_B
	SELECT @YMax2 = MAX(num2),@YMin2 = MIN(num2) FROM #Result_B
  
	IF(@YMax1=@YMin1) 
		SELECT   @YMin1 = @YMin1 -2 ,@YMax1 =@YMax1+3
	IF(@YMax2=@YMin2) 
		SELECT   @YMin2 = @YMin2 -2 ,@YMax2 =@YMax2+3

------------------------------------------------------------------------------------- 图形输出格式计算 -------------------------------------------------------------------                
                
    DECLARE @Rsql VARCHAR(MAX);            
    DECLARE @FinalColumn NVARCHAR(1000);
    
  
    CREATE TABLE #Result_C            
  ( OrderX INT,DimX VARCHAR(50),num1 VARCHAR(50),num2 VARCHAR(50))            
    CREATE TABLE #Result_D            
  ( OrderX INT,DimX VARCHAR(50),num1 VARCHAR(50),num2 VARCHAR(50))            
    CREATE TABLE #Result_F            
  ( OrderX INT,DimX VARCHAR(50),num1 VARCHAR(50),num2 VARCHAR(50))   

    -- 表 拼接标题用变量
    DECLARE @title TABLE (cName NVARCHAR(100))
    DECLARE @titleSql VARCHAR(max)
                
  -- 行转列输出数据               

	SET @Rsql = ' SELECT DimX,num1 as Y轴1,num2 as Y轴2 FROM #Result_Final ORDER BY abs(OrderX)';
	--SET @Rsql = ' SELECT DimX,num1 as ['+@Ynum1+']'+',num2 as [' +@Ynum2+']'+ ' FROM #Result_Final ORDER BY abs(OrderX)';
	PRINT '';
	PRINT '-- 执行以下输出结果代码 -- ';
	print @Rsql;
	
   EXEC(@Rsql);
	
  --  图形标题拼接            
                
    IF ( @Type = '图')            
    BEGIN                             
		DECLARE @t VARCHAR(100)            

		-- 按是否需要来拼接要出标题的 维度            
		SET @t = '#time'
		
                EXEC Sp_Com_Get_ChtTitle_2Y @TitleNames = @t,
                    @EndStrTitle = @Usertitle, @YName = @Ynum1,@YName_Second=@Ynum2,@Unit='',@xName=@XName,
                    @YMax = @YMax1, @YMin = @YMin1  ,@YMax_Second=@YMax2,@YMin_Second=@YMin2,@splitNumber='5'
   END
   
   --select * from #Yname
   print 'axisLabel:'+@Ynum1;
	-- 注销临时表
	DROP TABLE #Result_B
    DROP TABLE #Result_Final
    DROP TABLE #Result_All
    DROP TABLE #Result_C
    DROP TABLE #Result_D
    DROP TABLE #Result_F
	DROP TABLE #time;
	DROP TABLE #Dims;
	DROP TABLE #Yname; 
           
     INSERT INTO Tbl_Log_AnaUseLog    
            ( EmpID ,    
              freshTime ,    
              spName ,    
              AnaName ,    
              siftvalue ,    
              OherParemeter    
            )    
     VALUES ( @EmpID ,    
              GETDATE() ,    
              'Sp_Analysister_OY_DouCapsule' ,    
              '双层胶囊多维分析' ,    
              @condition ,    
              '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='    
              + @OtherCond    
            )             
          
   END
go

