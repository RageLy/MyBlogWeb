          
-- =============================================                      
-- Mac过滤权限设置    
-- THM 2016-01-14              
-- =============================================                      
CREATE procedure [dbo].[sp_BS_SetRequestMac]                      
@RpID varchar(500)=''                                
,@Name varchar(500)=''                  
,@Mac varchar(MAX)=''      
,@IsAllowedAccess varchar(10) =''               
as                       
Begin                       
set nocount on                      
if(@Name='')                      
begin                      
 select '名称不能为空！'                     
 return                     
end          
        
--判断编辑        
 if(@RpID<>'')                      
 begin                       
                   
  if exists(select 1 from Tbl_Com_RequestPermission where Name=@Name and RpID<>@RpID)                      
  begin                      
   select '名称不能重复！'               
   return                     
  end                      
  else                      
  begin                      
   update Tbl_Com_RequestPermission         
   set Name=@Name       
    ,Mac=@Mac              
    ,IsAllowedAccess = @IsAllowedAccess
   where  RpID=@RpID                     
   select '0'                      
  end                     
                   
end        
--新增                      
else                      
begin        
 --判断重复                  
 if exists(select 1 from Tbl_Com_RequestPermission where Name=@Name)                      
 begin                      
  select '名称不能重复！'                      
 end                      
 else                      
 begin                      
  insert into Tbl_Com_RequestPermission         
  (Name,Mac,IsAllowedAccess)         
  values         
  (@Name,@Mac,@IsAllowedAccess )                      
  select '0'                      
 end                  
end                      
end
go

