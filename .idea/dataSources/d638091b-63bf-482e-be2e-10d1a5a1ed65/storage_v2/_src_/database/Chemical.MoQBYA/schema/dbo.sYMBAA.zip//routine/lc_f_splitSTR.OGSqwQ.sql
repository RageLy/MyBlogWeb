
-- =============================================
-- Author:		<刘轶>
-- create date: <2014年7月7日>
-- Description:	<Description,分割字符串,>
-- =============================================
create function [dbo].[lc_f_splitSTR](
@TargetSTR   varchar(MAX),   --待分拆的字符串
@Seperator varchar(10)     --数据分隔符
)returns @Result table(string varchar(MAX))
as
begin
 declare @splitlen int
 set @splitlen=LEN(@Seperator+'a')-2 
 while CHARINDEX(@Seperator,@TargetSTR)>0
 begin
  insert @Result values(LEFT(@TargetSTR,CHARINDEX(@Seperator,@TargetSTR)-1))
  set @TargetSTR=stuff(@TargetSTR,1,CHARINDEX(@Seperator,@TargetSTR)+@splitlen,'')
 end
 
 insert @Result values(@TargetSTR)
 return
end
go

