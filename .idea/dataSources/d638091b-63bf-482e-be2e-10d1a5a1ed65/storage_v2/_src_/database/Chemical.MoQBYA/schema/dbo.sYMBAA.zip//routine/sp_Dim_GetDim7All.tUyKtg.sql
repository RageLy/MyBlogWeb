
  
  
  
-- =============================================  
-- Author:  曹乐平  
-- Create date: 2013-11-15  
-- Description: 用余文杰的时间查询器修改，直接范围完整的时间表  
-- =============================================  
CREATE function [dbo].[sp_Dim_GetDim7All](  
  
)returns @Result table([FName] [varchar](200) NOT NULL  
 ,[FValue] [varchar](500) NOT NULL  
  ,[FDate] [varchar](200) NOT NULL  
  ,[FDateType] [varchar](200) NOT NULL  
  ,[BeginDate] datetime not Null  
  ,[EndDate] datetime not null  
  )  
as  
begin  
 declare @DayCount int = 750
 ,@WeekCount int = 110
    ,@MonthCount int=48
    ,@QuarterCount int = 16
    ,@YearCount int = 6  
    ,@WeekEnd int = 7  
 --[sp_Dim_7_Level_3_web] '年^日历年'  
 declare @sqlcol     varchar(8000)  
 declare @sqltype    varchar(8000)  
    declare @sql        varchar(8000)  
 declare @CharID     int  
 declare @CharName   varchar(50)  
 declare @sqlfname        varchar(8000)  
 declare @sqlfvalue        varchar(8000)  
 declare @sqlfilterVal        varchar(8000)  
 declare @sqltemp varchar(8000)  
   
   
    
 --当前自然月  
 declare @Today datetime  
 set @Today=GETDATE()  
 declare @YearTextThis varchar(200)  
 set @YearTextThis=cast(YEAR(@Today) as varchar(4))  
 declare @MonthTextThis varchar(200)  
 set @MonthTextThis=cast(Month(@Today) as varchar(2))  
 insert @Result   
 values('M:this',@YearTextThis+'-'+@MonthTextThis+'-01至今','月','当前自然月',  
 @YearTextThis+'-'+@MonthTextThis+'-01'  
 ,cast(DATEPART(YEAR,@Today) as varchar(4))+'-'+cast(DATEPART(MONTH,@Today) as varchar(2))+'-'+cast(DATEPART(Day,@Today) as varchar(2))+' 23:59:59')  
    
   
 declare @n int   
 set @n=0  
   
   
 --当前天  
 while @n<@DayCount  
 Begin  
   declare @dayvalue1 varchar(200)  
   declare @dtime datetime   
   set @dtime=DATEADD(Day,-@n,Getdate())  
   if @n=0   
     set @dayvalue1='今天'--('+CAST(CONVERT(varchar(10), @dtime, 120) AS varchar(500))+')'  
       
   if @n=1   
     set @dayvalue1='昨天'--('+CAST(CONVERT(varchar(10), @dtime, 120) AS varchar(500))+')'  
  
   if @n=2   
     set @dayvalue1='前天'--('+CAST(CONVERT(varchar(10), @dtime, 120) AS varchar(500))+')'  
       
   if @n>2  
     set @dayvalue1=cast(@n as varchar(200))+'天前'--('+CAST(CONVERT(varchar(10), @dtime, 120) AS varchar(500))+')'  
       
           
       
   insert @Result   
   values('D'+cast(@n as  varchar(200)),@dayvalue1,'天','当前天',  
   cast(DATEPART(YEAR,@dtime) as varchar(10))+'-'+cast(DATEPART(MONTH,@dtime) as varchar(10))+'-'+cast(DATEPART(Day,@dtime) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@dtime) as varchar(10))+'-'+cast(DATEPART(MONTH,@dtime) as varchar(10))+'-'+cast(DATEPART(Day,@dtime) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
 End  
   
    --日历天  
    set @n=0  
 while @n<@DayCount  
 Begin  
   declare @DayText varchar(200)  
   declare @Dayvalue2 varchar(200)  
   declare @Day datetime  
   set @Day = DATEADD(DAY,-@n,GETDATE())  
   set @dayvalue2 ='D:'+ cast(YEAR(@Day) as varchar(4))+'-'+cast(MONTH(@Day) as varchar(2))+'-'+cast(DAY(@Day) as varchar(2))  
   set @DayText = cast(YEAR(@Day) as varchar(4))+'.'+cast(MONTH(@Day) as varchar(2))+'.'+cast(DAY(@Day) as varchar(2))  
   insert @Result   
   values(@dayvalue2,@DayText,'天','日历天',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
 End  
   
 set @n=0  
    --当前周  
 while @n<@WeekCount  
 Begin  
   declare @Weekvalue1 varchar(200)  
   declare @WeekText varchar(200)  
   set @Day = DATEADD(DAY,-@n*7,GETDATE())   
   set @Weekvalue1='7天至'+cast(YEAR(@Day) as varchar(4))+'.'+cast(MONTH(@Day) as varchar(2))+'.'+cast(DAY(@Day) as varchar(2))  
   insert @Result   
   values('W'+cast(@n as varchar(200)),@Weekvalue1,'周','当前周',  
   cast(DATEPART(YEAR,DATEAdd(Day,-6,@day)) as varchar(10))+'-'+cast(DATEPART(MONTH,DATEAdd(Day,-6,@day)) as varchar(10))+'-'+cast(DATEPART(Day,DATEAdd(Day,-6,@day)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 23:59:59')  
     
     
   set @n=@n+1  
 End  
   
 set @n=0  
    --日历周  
 while @n<@WeekCount  
 Begin  
   declare @Weekvalue2 varchar(200)  
   declare @WeekText2 varchar(200)  
   declare @WeekToDay int  
   declare @WeekN int  
   declare @ThisWeekEnd datetime  
   set @WeekToDay= DATEPART(WEEKDAY,GETDATE())  
     
   set @WeekN=@WeekEnd-@WeekToDay  
   if @WeekN<0  
     set @WeekN=@WeekN+7  
      
   set @ThisWeekEnd=DATEADD(DAY,@WeekN,GETDATE())  
   set @Day = DATEADD(DAY,-@n*7,@ThisWeekEnd)   
   set @Weekvalue1='一周截止'+cast(YEAR(@Day) as varchar(4))+'.'+cast(MONTH(@Day) as varchar(2))+'.'+cast(DAY(@Day) as varchar(2))  
   insert @Result   
   values('W'+':'+cast(YEAR(@Day) as varchar(4))+'-'+cast(MONTH(@Day) as varchar(2))+'-'+cast(DAY(@Day) as varchar(2)),@Weekvalue1,'周','日历周',  
   cast(DATEPART(YEAR,DATEAdd(Day,-6,@day)) as varchar(10))+'-'+cast(DATEPART(MONTH,DATEAdd(Day,-6,@day)) as varchar(10))+'-'+cast(DATEPART(Day,DATEAdd(Day,-6,@day)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
 End  
   
 set @n=0  
    --当前月  
 while @n<@MonthCount  
 Begin  
   declare @Monthvalue1 varchar(200)  
   set @Day = DATEADD(DAY,-@n*28,GETDATE())   
   set @Monthvalue1='28天至'+cast(YEAR(@Day) as varchar(4))+'.'+cast(MONTH(@Day) as varchar(2))+'.'+cast(DAY(@Day) as varchar(2))  
   insert @Result   
   values('M'+cast(@n as varchar(200)),@Monthvalue1,'月','当前月',  
   cast(DATEPART(YEAR,DATEAdd(Day,-27,@day)) as varchar(10))+'-'+cast(DATEPART(MONTH,DATEAdd(Day,-27,@day)) as varchar(10))+'-'+cast(DATEPART(Day,DATEAdd(Day,-27,@day)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
 End  
   
 set @n=0  
 declare @Month datetime  
 set @Month=getdate()  
    --日历月  
 while @n<@MonthCount  
 Begin  
   declare @Monthvalue2 varchar(200)  
   declare @MonthText2 varchar(200)  
   declare @temp datetime  
   declare @begin datetime  
     
   set @temp= DateAdd(Month,1,@Month)  
   set @temp =cast(cast(YEAR(@temp) as varchar(10))+'-'+cast(Month(@temp) as varchar(10))+'-01' as datetime)  
   set @temp = DATEADD(day,-1,@temp)  
   set @Month=@temp  
   set @begin=cast(cast(YEAR(@temp) as varchar(10))+'-'+cast(Month(@temp) as varchar(10))+'-01' as datetime)  
     
   set @Monthvalue2='MRL:'+cast(@n as varchar(200))  
   set @MonthText2=cast(YEAR(@Month) as varchar(4))+'年'+cast(MONTH(@Month) as varchar(2))+'月'  
   insert @Result   
   values(@Monthvalue2,@MonthText2,'月','日历月',  
   cast(DATEPART(YEAR,DATEAdd(Day,-DATEDIFF(day,@begin,@Month),@Month)) as varchar(10))+'-'+cast(DATEPART(MONTH,DATEAdd(Day,-DATEDIFF(day,@begin,@Month),@Month)) as varchar(10))+'-'+cast(DATEPART(Day,DATEAdd(Day,-DATEDIFF(day,@begin,@Month),@Month)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@Month) as varchar(10))+'-'+cast(DATEPART(MONTH,@Month) as varchar(10))+'-'+cast(DATEPART(Day,@Month) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
   set @Month = DATEADD(MONTH,-@n,GETDATE())   
 End  
  
   
    set @n=0  
    --当前季  
 while @n<@QuarterCount  
 Begin  
   declare @QuarterText varchar(200)  
   set @Day = DATEADD(DAY,-@n*13*7,GETDATE())   
   set @QuarterText='13周至'+cast(YEAR(@Day) as varchar(4))+'.'+cast(MONTH(@Day) as varchar(2))+'.'+cast(DAY(@Day) as varchar(2))  
   insert @Result   
   values('Q'+cast(@n as varchar(200)),@QuarterText,'季','当前季',  
   cast(DATEPART(YEAR,DATEAdd(DAY,(-13*7)+1,@Day)) as varchar(10))+'-'+cast(DATEPART(MONTH,DATEAdd(DAY,(-13*7)+1,@Day)) as varchar(10))+'-'+cast(DATEPART(Day,DATEAdd(DAY,(-13*7)+1,@Day)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
 End  
   
    --日历季  
   declare @currentMonth int  
   declare @Quarter datetime  
     
   --得出是那一季  
   set @currentMonth= DatePart(Month,Getdate())  
   set @Quarter=cast(case   
       when @currentMonth>=1 and @currentMonth<=3  
   then CAST(DATEPART(year,getdate()) as varchar(10))+'-03-31'  
      when @currentMonth>=4 and @currentMonth<=6  
   then CAST(DATEPART(year,getdate()) as varchar(10))+'-06-30'  
      when @currentMonth>=7 and @currentMonth<=9  
   then CAST(DATEPART(year,getdate()) as varchar(10))+'-09-30'  
      when @currentMonth>=10 and @currentMonth<=12  
   then CAST(DATEPART(year,getdate()) as varchar(10))+'-12-31'  
   end  as datetime)  
     
    set @n=0  
 while @n<@QuarterCount  
 Begin  
   declare @QuarterText2 varchar(200)  
   declare @season varchar(200)  
   set @season = case DATEPART(MONTH,@Quarter)   
   when 3   
       then cast(DATEPART(YEAR,@Quarter) as varchar(200) ) +'年一季度截止'   
   when 6  
       then cast(DATEPART(YEAR,@Quarter) as varchar(200) ) +'年二季度截止'   
   when 9  
       then cast(DATEPART(YEAR,@Quarter) as varchar(200) ) +'年三季度截止'   
   when 12  
       then cast(DATEPART(YEAR,@Quarter) as varchar(200) ) +'年四季度截止'   
   end   
     
   declare @qbegin datetime  
   declare @qend datetime  
   if DATEPART(MONTH,@Quarter)= 3  
   Begin  
      set @qbegin=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-01-01' as datetime)  
      set @qend=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-03-31' as datetime)  
   End  
     
   if DATEPART(MONTH,@Quarter)= 6  
   Begin  
      set @qbegin=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-04-01' as datetime)  
      set @qend=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-06-30' as datetime)  
   End  
     
   if DATEPART(MONTH,@Quarter)= 9  
   Begin  
      set @qbegin=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-07-01' as datetime)  
      set @qend=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-09-30' as datetime)     
   End  
     
   if DATEPART(MONTH,@Quarter)= 12  
   Begin  
      set @qbegin=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-10-01' as datetime)  
      set @qend=CAST( CAST(DATEPART(Year,@Quarter) as varchar(10))+'-12-31' as datetime)     
   End  
     
   --case   
   --when 3   
   --    then set @qbegin= CAST()  
   --when 6  
   --    then   
   --when 9  
   --    then   
   --when 12  
   --    then   
   --end   
     
   set @QuarterText2=@season+cast(DATEPART(year,@Quarter) as varchar(10))+'.'+cast(DATEPART(MONTH,@Quarter) as varchar(10))+'.'+cast(DATEPART(Day,@Quarter) as varchar(10))  
   insert @Result   
   values('Q:'+cast(Datepart(year,@Quarter) as varchar(10))+'-'+cast(Datepart(Month,@Quarter) as varchar(10))+'-'+cast(Datepart(Day,@Quarter) as varchar(10)),@QuarterText2,'季','日历季',  
   cast(DATEPART(YEAR,@qbegin) as varchar(10))+'-'+cast(DATEPART(MONTH,@qbegin) as varchar(10))+'-'+cast(DATEPART(Day,@qbegin) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@qend) as varchar(10))+'-'+cast(DATEPART(MONTH,@qend) as varchar(10))+'-'+cast(DATEPART(Day,@qend) as varchar(10))+' 23:59:59')  
   set @Quarter = DATEADD(Month,-2,@Quarter)  
   set @Quarter=DateAdd(day,-1,cast(cast(DATEPART(year,@Quarter) as varchar(10))+'-'+cast(DATEPART(MONTH,@Quarter) as varchar(10))+'-01' as datetime))  
   set @n=@n+1  
 End  
   
   
 set @n=0  
    --当前年  
 while @n<@YearCount  
 Begin  
   declare @YearText varchar(200)  
   set @Day = DATEADD(DAY,-@n*52*7,GETDATE())   
   set @YearText='52周至'+cast(YEAR(@Day) as varchar(4))+'.'+cast(MONTH(@Day) as varchar(2))+'.'+cast(DAY(@Day) as varchar(2))  
   insert @Result   
   values('Y'+cast(@n as varchar(200)),@YearText,'年','当前年',  
   cast(DATEPART(YEAR,DATEADD(Day,-52*7+1,@Day)) as varchar(10))+'-'+cast(DATEPART(MONTH,DATEADD(Day,-52*7+1,@Day)) as varchar(10))+'-'+cast(DATEPART(Day,DATEADD(Day,-52*7+1,@Day)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,@day) as varchar(10))+'-'+cast(DATEPART(MONTH,@day) as varchar(10))+'-'+cast(DATEPART(Day,@day) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
 End  
   
   
    set @n=0  
    --当前年  
    declare @year datetime  
    set @year = GETDATE()  
 while @n<@YearCount  
 Begin  
   declare @YearText2 varchar(200)  
   set @YearText2=cast(YEAR(@year) as varchar(4))  
   insert @Result   
   values('Y:'+@YearText2,@YearText2+'年','年','日历年',  
   cast(DATEPART(YEAR,CAST(@YearText2+'-01-01' as datetime)) as varchar(10))+'-'+cast(DATEPART(MONTH,CAST(@YearText2+'-01-01' as datetime)) as varchar(10))+'-'+cast(DATEPART(Day,CAST(@YearText2+'-01-01' as datetime)) as varchar(10))+' 00:00:00',  
   cast(DATEPART(YEAR,CAST(@YearText2+'-12-31' as datetime)) as varchar(10))+'-'+cast(DATEPART(MONTH,CAST(@YearText2+'-12-31' as datetime)) as varchar(10))+'-'+cast(DATEPART(Day,CAST(@YearText2+'-12-31' as datetime)) as varchar(10))+' 23:59:59')  
   set @n=@n+1  
   set @year=DATEADD(Year,-1,@year)  
 End  
   
 --当前自然年  
 set @Today=GETDATE()  
 set @YearTextThis=cast(YEAR(@Today) as varchar(4))  
 insert @Result   
 values('Y:this',@YearTextThis+'-01-01至今','年','自然年至今',  
 @YearTextThis+'-01-01'  
 ,cast(DATEPART(YEAR,@Today) as varchar(4))+'-'+cast(DATEPART(MONTH,@Today) as varchar(2))+'-'+cast(DATEPART(Day,@Today) as varchar(2))+' 23:59:59')  
     
 --5 年至今  
 set @Today=DATEADD(YEAR,-5, GETDATE())  
 set @YearTextThis=cast(YEAR(@Today) as varchar(4))  
 insert @Result   
 values('Y:this5',@YearTextThis+'-01-01至今','年','自然年至今',  
 @YearTextThis+'-01-01'  
 ,cast(DATEPART(YEAR,GETDATE()) as varchar(4))+'-'+cast(DATEPART(MONTH,GETDATE()) as varchar(2))+'-'+cast(DATEPART(Day,GETDATE()) as varchar(2))+' 23:59:59')  
  --10 年至今  
 set @Today=DATEADD(YEAR,-10, GETDATE())  
 set @YearTextThis=cast(YEAR(@Today) as varchar(4))  
 insert @Result   
 values('Y:this10',@YearTextThis+'-01-01至今','年','自然年至今',  
 @YearTextThis+'-01-01'  
 ,cast(DATEPART(YEAR,GETDATE()) as varchar(4))+'-'+cast(DATEPART(MONTH,GETDATE()) as varchar(2))+'-'+cast(DATEPART(Day,GETDATE()) as varchar(2))+' 23:59:59')  
       
 return  
end
go

