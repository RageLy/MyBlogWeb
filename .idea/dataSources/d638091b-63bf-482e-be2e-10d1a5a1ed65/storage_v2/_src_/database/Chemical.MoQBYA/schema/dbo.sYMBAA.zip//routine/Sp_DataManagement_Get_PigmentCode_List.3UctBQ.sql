-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [Sp_DataManagement_Get_PigmentCode_List]
	-- Add the parameters for the stored procedure here
AS
BEGIN
	SELECT DISTINCT code AS value, code AS text FROM dbo.Bs_Pigment
END
go

