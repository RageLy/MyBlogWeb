CREATE PROCEDURE [dbo].[GetCutData]
    @DateType INT ,
    @DimNum NVARCHAR(200) ,
    @SpName NVARCHAR(20)
AS
    BEGIN
        DECLARE @sql NVARCHAR(MAX)= '';
        DECLARE @Select NVARCHAR(300)= '';
        DECLARE @ChoiceWD TABLE
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL
                     PRIMARY KEY ,
              String NVARCHAR(100)
            );
        INSERT  INTO @ChoiceWD
                SELECT  string
                FROM    dbo.f_splitSTR(@DimNum, ',');    
        SELECT  *
        FROM    @ChoiceWD;  
        CREATE TABLE #Num
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL
                     PRIMARY KEY ,
              NumValue INT
            );
        DECLARE @tempNum INT= @DateType;
        WHILE ( @tempNum > 0 )
            BEGIN
                PRINT @tempNum;
                INSERT  INTO dbo.#Num
                        ( NumValue )
                VALUES  ( @tempNum  -- NumValue - int
                          );
                        --INSERT  INTO dbo.Num
                        --        (  NumValue )
                        --VALUES  ( @DateType - 1  -- NUM - int
                        --          );
                SET @tempNum -= 1;
            END;
                SELECT * FROM #Num    
        DECLARE @count INT= ( SELECT    MAX(ID)
                              FROM      @ChoiceWD
                            );
        WHILE ( @count > 0 )
            BEGIN
                PRINT @count;
                DECLARE @DimNumTemp NVARCHAR(50)= ( SELECT  String
                                                    FROM    @ChoiceWD
                                                    WHERE   ID = @count
                                                  );
                DECLARE @DimName NVARCHAR(50)= ( SELECT TableName + '.'
                                                        + CoName
                                                 FROM   dbo.Tbl_AnsCom_DIimToTable
                                                 WHERE  DimNum = ( SELECT
                                                              String
                                                              FROM
                                                              @ChoiceWD
                                                              WHERE
                                                              ID = @count
                                                              )
                                               );
                SET @sql += 'CREATE TABLE #' + @DimNumTemp
                    + '([ID] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY, Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'
                    + CHAR(10);
                SET @sql += ( SELECT    'select X,ID,SumTotal into #'
                                        + @DimNumTemp
                                        + 'ResultData from (select '
                                        + @DimName
                                        + ' AS X, ROW_NUMBER() OVER (ORDER BY '
                                        + @DimName + ' ) AS ID from '
                                        + JoinTables + CHAR(10) + BaseTable
                                        + CHAR(10)
                                        + ') a Cross join (select count(*) SumTotal from '
                                        + JoinTables + CHAR(10) + BaseTable
                                        + ') b ' + CHAR(10)
                              FROM      dbo.Tbl_AnsCom_AnaSpConfig
                              WHERE     SpName = @SpName
                            );
                
                DECLARE @innerSelect NVARCHAR(100)= '';
                SET @innerSelect = 'SELECT  x0,'
                    + ( SELECT  'x' + CAST(NumValue AS NVARCHAR(4)) + ','
                        FROM    #Num
                      FOR
                        XML PATH('')
                      ); 
                SET @innerSelect = LEFT(@innerSelect, LEN(@innerSelect) - 1);
                SET @sql += @innerSelect;  
                SET @sql += ' into #' + @DimNumTemp + 'result1 FROM    
                (  SELECT MIN(X) x0
                     FROM   #' + @DimNumTemp + 'ResultData
                   ) b
                  CROSS JOIN ( SELECT MAX(X) x'
                    + CAST(@DateType AS NVARCHAR(4)) + '
                     FROM   #' + @DimNumTemp + 'ResultData
                   ) c' + CHAR(10);
                SET @sql += ( SELECT    'CROSS JOIN  (select X AS x'
                                        + CAST(NumValue AS NVARCHAR(2))
                                        + ' from #' + @DimNumTemp
                                        + 'ResultData where ID=ROUND(SumTotal*'
                                        + CAST(NumValue AS NVARCHAR(4)) + '/'
                                        + CAST(@DateType AS NVARCHAR(4))
                                        + ',0)) a'
                                        + CAST(NumValue AS NVARCHAR(2))
                                        + CHAR(10)
                              FROM      #Num
                              WHERE     NumValue < @DateType
                            FOR
                              XML PATH('')
                            );
                DECLARE @t1 NVARCHAR(500)= '';
                SET @t1 = ''
                    + ( SELECT  ' select ''' + @DimNumTemp
                                + ''',x'+CAST(NumValue-1 AS NVARCHAR(2))+',x'+CAST(NumValue AS NVARCHAR(2))+' from #'
                                + @DimNumTemp + 'result1 UNION ALL'
                        FROM    #Num
                      FOR
                        XML PATH('')
                      );
                      SET @t1=LEFT(@t1,LEN(@t1)-9)
                SET @sql += 'insert into #' + @DimNumTemp + @t1
                SET @sql += 'select * from #' + @DimNumTemp + CHAR(10);
                
                --SET @sql += 'DROP TABLE #' + @DimNumTemp + 'ResultData  '
                --    + CHAR(10) + 'DROP TABLE #' + @DimNumTemp + 'result1'
                --    + CHAR(10);
                
              
                --SET @sql=''
                SET @count -= 1;
                PRINT @count;
            END;
        PRINT @sql;           
        EXEC(@sql);
        --PRINT @sql;
        
    END;
go

