-- ====================================                    
       
-- 作者：杨艺
-- 时间：2014年8月5日                  
-- 默认描述: 获取一个时间段的环比或者同比时间段，两个日期段  
-- 此版本获取的同比环比时间   倒退同样天数的同比环比时间
-- 区别于  [sp_ComUse_GetLpLyTime_v1]     是获取的 为日历同比 环比

-- 新描述：在 [sp_ComUse_GetLpLyTime_v2] 的基础上修改而来，把预测销售所需要的所有时间点全都计算出来
-- 例：预测 2014年8月的销售，需要得到时间点为以下
-- 注：系统默认一年为52周，不是365天也不是自然年；传入的时间只要是在这个月份的时间就可以

--	上个月		2014-07-01 TO 2014-07-31; 
--	上上个月	2014-06-01 TO 2014-06-30; 
--	去年同月	2013-08-01 TO 2013-08-31; 
--	去年上个月	2013-07-01 TO 2013-07-31;
--	去年上上个月2013-06-01 TO 2013-06-30;
--	去年		2013-08-02 TO 2014-07-31;
--	前年		2012-08-03 TO 2013-08-01;


-- 作者：杨艺
-- 时间：2014年8月7日
-- 描述：修改无法识别天、周、季度、年，但是年返回的没有同比概念，同比时间返回还是环比的时间


-- ====================================                    
                
CREATE PROC [dbo].[Sp_ComUse_GetLpLyTime_V3]               
    @BeginDate	Datetime = '2014-03-01'		-- 开始时间                
   ,@EndDate	Datetime = '2014-03-31'		-- 结束时间        
         
   ,@BeginDateL Datetime = NULL OUTPUT		-- 开始时间                
   ,@EndDateL	DATETIME = NULL OUTPUT		-- 结束时间       
                  
   ,@BeginDateLyLp1 DATETIME = NULL OUTPUT	-- 去年上个月环比开始时间
   ,@EndDateLyLp1	DATETIME = NULL OUTPUT	-- 去年上个月环比结束时间
   ,@BeginDateLyLp2 DATETIME = NULL OUTPUT	-- 去年上上个月环比开始时间
   ,@EndDateLyLp2	DATETIME = NULL OUTPUT	-- 去年上上个月环比结束时间
   
   ,@BeginDateLy	DATETIME = null output -- 同比开始时间                
   ,@EndDateLy		DATETIME = null output -- 同比结束时间                
   ,@BeginDateLy2	DATETIME = null output -- 同比开始时间                
   ,@EndDateLy2		DATETIME = null output -- 同比结束时间                
   ,@BeginDateLp	DATETIME = null output -- 环比开始时间                
   ,@EndDateLp		DATETIME = null output -- 环比结束时间               
   ,@BeginDateLp2	DATETIME = null output -- 环比开始时间                
   ,@EndDateLp2		DATETIME = null output -- 环比结束时间  
               
AS              
                  
   

 DECLARE @Diff INT = DATEDIFF(DAY,@begindate,@enddate);  -- 日期相距天数 用于计算日期的类型     
    
 if(@Diff > -1 And @Diff < 2) -- 日期为一天时  
 Begin   
	
	 SET @BeginDateLp = DATEADD(DAY, -1, @BeginDate);                 
	 SET @EndDateLp = DATEADD(SECOND, -1, DATEADD(DAY,1,@BeginDateLp));                 
	 SET @BeginDateLp2 = DATEADD(DAY, -2, @BeginDate);                 
	 SET @EndDateLp2 = DATEADD(SECOND, -1, DATEADD(DAY,1,@BeginDateLp2));    
	
	 SET @BeginDateL = DATEADD(YEAR, -1, @BeginDate);                
	 SET @EndDateL = DATEADD(SECOND,-1,DATEADD(DAY,1,@BeginDateL));
	 SET @BeginDateLyLp1 = DATEADD(DAY,-1,@BeginDateL);
	 SET @EndDateLyLp1	= DATEADD(DAY,-1,@EndDateL);
	 SET @BeginDateLyLp2 = DATEADD(DAY,-1,@BeginDateLyLp1);
	 SET @EndDateLyLp2 = DATEADD(DAY,-1,@EndDateLyLp1);
	             
	 SET @BeginDateLy = DATEADD(DAY, -364, @BeginDate);                  
	 SET @EndDateLy = DATEADD(MINUTE, -1, @BeginDate);                
	 SET @BeginDateLy2 = DATEADD(DAY, -728, @BeginDate);                  
	 SET @EndDateLy2 = DATEADD(MINUTE, -1, DATEADD(DAY,-364,@BeginDate));            
	           
 
 End  
   
 ELSE IF(@Diff > 5 And @Diff < 9) -- 日期为一周时  
 BEGIN    
	
	 SET @BeginDateLp = DATEADD(WEEK, -1, @BeginDate);                 
	 SET @EndDateLp = DATEADD(SECOND, -1, DATEADD(WEEK,1,@BeginDateLp));                 
	 SET @BeginDateLp2 = DATEADD(WEEK, -2, @BeginDate);                 
	 SET @EndDateLp2 = DATEADD(SECOND, -1, DATEADD(WEEK,1,@BeginDateLp2));    
	
	 SET @BeginDateL = DATEADD(YEAR, -1, @BeginDate);                
	 SET @EndDateL = DATEADD(SECOND,-1,DATEADD(WEEK,1,@BeginDateL));
	 SET @BeginDateLyLp1 = DATEADD(WEEK,-1,@BeginDateL);
	 SET @EndDateLyLp1	= DATEADD(WEEK,-1,@EndDateL);
	 SET @BeginDateLyLp2 = DATEADD(WEEK,-1,@BeginDateLyLp1);
	 SET @EndDateLyLp2 = DATEADD(WEEK,-1,@EndDateLyLp1);
	             
	 SET @BeginDateLy = DATEADD(DAY, -364, @BeginDate);                  
	 SET @EndDateLy = DATEADD(MINUTE, -1, @BeginDate);                
	 SET @BeginDateLy2 = DATEADD(DAY, -728, @BeginDate);                  
	 SET @EndDateLy2 = DATEADD(MINUTE, -1, DATEADD(DAY,-364,@BeginDate));  
 
 END 
   
 Else if(@Diff > 26 And @Diff < 33) -- 日期为一个月时  
 BEGIN  
	 SET @BeginDate = DATEADD(MONTH,DATEDIFF(MONTH,0,@BeginDate),0)
	 SET @EndDate = DATEADD(SECOND,-1,DATEADD(MONTH,1,@BeginDate));
	 SET @BeginDateLp = DATEADD(MONTH, -1, @BeginDate);                 
	 SET @EndDateLp = DATEADD(SECOND, -1, @BeginDate);                 
	 SET @BeginDateLp2 = DATEADD(MONTH, -2, @BeginDate);                 
	 SET @EndDateLp2 = DATEADD(SECOND, -1, @BeginDateLp);   

	 SET @BeginDateL = DATEADD(YEAR, -1, @BeginDate);                
	 SET @EndDateL = DATEADD(SECOND,-1,DATEADD(MONTH,1,@BeginDateL)); 
	 SET @BeginDateLyLp1 = DATEADD(MONTH,-13,@BeginDate);
	 SET @EndDateLyLp1	= DATEADD(SECOND,-1,DATEADD(MONTH,1,@BeginDateLyLp1));
	 SET @BeginDateLyLp2 = DATEADD(MONTH,-14,@BeginDate);
	 SET @EndDateLyLp2 = DATEADD(SECOND,-1,DATEADD(MONTH,1,@BeginDateLyLp2));
	             
	 SET @BeginDateLy = DATEADD(DAY, -364, @BeginDate);                  
	 SET @EndDateLy = DATEADD(MINUTE, -1, @BeginDate);                
	 SET @BeginDateLy2 = DATEADD(DAY, -728, @BeginDate);                  
	 SET @EndDateLy2 = DATEADD(MINUTE, -1, DATEADD(DAY, -364, @BeginDate));            
	           
	 
 END
   
 ELSE IF(@Diff > 82 And @Diff < 95) -- 日期为一个季度时  
 BEGIN  
	
	 SET @BeginDateLp = DATEADD(qq , -1, @BeginDate);                 
	 SET @EndDateLp = DATEADD(SECOND, -1, DATEADD(qq,1,@BeginDateLp));                 
	 SET @BeginDateLp2 = DATEADD(qq, -2, @BeginDate);                 
	 SET @EndDateLp2 = DATEADD(SECOND, -1, DATEADD(qq,1,@BeginDateLp2));    
	
	 SET @BeginDateL = DATEADD(YEAR, -1, @BeginDate);                
	 SET @EndDateL = DATEADD(SECOND,-1,DATEADD(qq,1,@BeginDateL));
	 SET @BeginDateLyLp1 = DATEADD(qq,-1,@BeginDateL);
	 SET @EndDateLyLp1	= DATEADD(qq,-1,@EndDateL);
	 SET @BeginDateLyLp2 = DATEADD(qq,-1,@BeginDateLyLp1);
	 SET @EndDateLyLp2 = DATEADD(qq,-1,@EndDateLyLp1);
	             
	 SET @BeginDateLy = DATEADD(DAY, -364, @BeginDate);                  
	 SET @EndDateLy = DATEADD(MINUTE, -1, @BeginDate);                
	 SET @BeginDateLy2 = DATEADD(DAY, -728, @BeginDate);                  
	 SET @EndDateLy2 = DATEADD(MINUTE, -1, DATEADD(DAY,-364,@BeginDate));  
   
 End   
    
 ELSE IF(@Diff > 363 And @Diff < 367) -- 日期为一个年时  
 BEGIN 
 
	 SET @BeginDateLp = DATEADD(YEAR,-1,@BeginDate);                 
	 SET @EndDateLp = DATEADD(SECOND, -1, DATEADD(YEAR,1,@BeginDateLp));                 
	 SET @BeginDateLp2 = DATEADD(YEAR, -2, @BeginDate);                 
	 SET @EndDateLp2 = DATEADD(SECOND, -1, DATEADD(YEAR,1,@BeginDateLp2));    
	
	 SET @BeginDateL = @BeginDateLp;                
	 SET @EndDateL = @EndDateLp;
	 SET @BeginDateLyLp1 = @BeginDateLp;
	 SET @EndDateLyLp1	= @EndDateLp;
	 SET @BeginDateLyLp2 = @BeginDateLp2;
	 SET @EndDateLyLp2 = @EndDateLp2;
	             
	 SET @BeginDateLy = @BeginDateLp;                  
	 SET @EndDateLy = @EndDateLp;                
	 SET @BeginDateLy2 =@BeginDateLp2;                  
	 SET @EndDateLy2 = @EndDateLp2; 
 
 
 END   
    
 ELSE   -- 其余情况全部返回原值  
 BEGIN  
	 SET @BeginDateLp = @BeginDate;                 
	 SET @EndDateLp = @EndDate;                 
	 SET @BeginDateLp2 = @BeginDate;                 
	 SET @EndDateLp2 = @EndDate;    
	
	 SET @BeginDateL = @BeginDate;                
	 SET @EndDateL = @EndDate;
	 SET @BeginDateLyLp1 = @BeginDate;
	 SET @EndDateLyLp1	= @EndDate;
	 SET @BeginDateLyLp2 = @BeginDate;
	 SET @EndDateLyLp2 = @EndDate;
	             
	 SET @BeginDateLy = @BeginDate;                  
	 SET @EndDateLy = @EndDate;                
	 SET @BeginDateLy2 = @BeginDate;                  
	 SET @EndDateLy2 = @EndDate;    
 END







   --SELECT @BeginDate	             
   --SELECT @EndDate	     
         
   --SELECT @BeginDateL               
   --SELECT @EndDateL	      
   --SELECT @BeginDateLyLp1 
   --SELECT @EndDateLyLp1	
   --SELECT @BeginDateLyLp2 
   --SELECT @EndDateLyLp2	
  
   --SELECT @BeginDateLp	         
   --SELECT @EndDateLp		              
   --SELECT @BeginDateLp2                
   --SELECT @EndDateLp2	
   
   --SELECT @BeginDateLy	                
   --SELECT @EndDateLy		           
   --SELECT @BeginDateLy2	         
   --SELECT @EndDateLy2
go

