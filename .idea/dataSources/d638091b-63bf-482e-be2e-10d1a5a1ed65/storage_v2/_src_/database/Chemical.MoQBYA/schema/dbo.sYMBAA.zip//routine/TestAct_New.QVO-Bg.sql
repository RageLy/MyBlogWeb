CREATE  PROCEDURE TestAct_New
    @InputStr NVARCHAR(100)
AS
    BEGIN 
        DECLARE @LetterLen INT= 0;
        SET @InputStr = REPLACE(REPLACE(@InputStr, '2', '1'), '3', '1');
        SET @LetterLen = ( SELECT   LEN(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@InputStr,
                                                              '3', ''), '2',
                                                              ''), '1', ''),
                                                              ')', ''), '(',
                                                        ''), '=', ''))
                         );
        PRINT @LetterLen;
        DECLARE @DiffConstruct NVARCHAR(100)= '';
        DECLARE @Count INT= 1;
        DECLARE @MaxCount INT= 0;
        CREATE TABLE #Res
            (
              ID INT IDENTITY(1, 1)
                     NOT  NULL ,
              ElementNum INT ,
              DiffConstruct NVARCHAR(100)
            ); 
        
                
        INSERT  INTO #Res
                SELECT  ElementNum ,
                        DiffConstruct
                FROM    Bs_Compound_Learn
                WHERE   ElementNum <= @LetterLen
                ORDER BY ElementNum DESC;
        CREATE  CLUSTERED  INDEX index1 ON #Res (DiffConstruct) ON [PRIMARY];
        --CREATE TABLE #result
        --    (
        --      ID INT IDENTITY(1, 1)
        --             NOT NULL ,
        --      CompID INT ,
        --      Name NVARCHAR(100) ,
        --      diffConstruct NVARCHAR(100) ,
        --      TwoDiffConstruct NVARCHAR(100) ,
        --      IsOk INT,
        --      Lennum int
        --    );
  
        --SET @MaxCount = ( SELECT    COUNT(*)
        --                  FROM      #Res
        --                );
--ID	ElementNum	DiffConstruct	TwoDiffConstruct
--5				8	FC1=CC=CC=C1C	                           
--2				14	OC1CCCN(C(OC(C)(C)C)=O)C1	                           
              CREATE TABLE [#result1]
(
[ID] INT IDENTITY(1, 1)
                 NOT NULL,
[ElementNum] INT,
[DiffConstruct] NVARCHAR(100),
[TwoDiffConstruct] NVARCHAR(100)
)         INSERT INTO #result1
        ( ElementNum ,
          DiffConstruct ,
          TwoDiffConstruct
        )
        SELECT  
                ElementNum ,
                DiffConstruct ,
                NULL

        FROM    #Res
        WHERE   CHARINDEX(DiffConstruct, @InputStr) > 0;
        
                        --LEFT JOIN #Res on
        -- SELECT  *
        --FROM    #result1;               
        --UPDATE  #result1
        --SET     TwoDiffConstruct = #Res.DiffConstruct
        --FROM    #Res
        --WHERE   CHARINDEX(REPLACE(@InputStr, #result1.DiffConstruct, ''),
        --                  @InputStr) > 0; 
        DECLARE @FirstResult NVARCHAR(100)=''
        DECLARE @TwoResult NVARCHAR(100)=''
        SET @MaxCount=(SELECT COUNT(*) FROM #result1)
        WHILE(@Count <= @MaxCount)
        BEGIN
        SET @FirstResult=(SELECT  DiffConstruct FROM #result1 WHERE ID=@Count)
			--SET @TwoResult=(SELECT DiffConstruct+';' FROM #Res WHERE CHARINDEX(DiffConstruct,REPLACE(REPLACE(@InputStr,@FirstResult, ''),'()', ''))>0 FOR XML PATH(''))
			SET @TwoResult=(SELECT DiffConstruct FROM #Res WHERE DiffConstruct=REPLACE(REPLACE(@InputStr,@FirstResult, ''),'()', ''))
			UPDATE #result1 SET TwoDiffConstruct=@TwoResult WHERE ID=@Count AND @TwoResult IS NOT NULL
			SET @Count=@Count+1
        END
        SELECT * FROM #result1 WHERE TwoDiffConstruct IS NOT NULL
        --SELECT  * FROM #result1 left JOIN #Res ON #Res.DiffConstruct = #result1.DiffConstruct WHERE CHARINDEX(REPLACE(@InputStr,#result1.DiffConstruct, ''),@InputStr)>0
                 
        --SELECT * FROM #res WHERE CHARINDEX(REPLACE(@InputStr,DiffConstruct, ''),@InputStr)>0
        --                  @InputStr)
        
                        --SELECT ID ,
                        --       ElementNum ,
                        --       DiffConstruct ,
                        --       TwoDiffConstruct FROM #result1 WHERE CHARINDEX(REPLACE(@InputStr,DiffConstruct,''), @InputStr)>0
        --WHILE ( @Count <= @MaxCount )
        --    BEGIN
        --    --寻找机器学习表里的原材料字符串
        --        SET @DiffConstruct = ( SELECT   DiffConstruct
        --                               FROM     #Res
        --                               WHERE    ID = @Count
        --                             );
        --        SET @Count = @Count + 1;
        --        PRINT '第一次匹配: 序号:'+CAST(@Count AS  NVARCHAR(10))+'  '+@DiffConstruct + ',' + @InputStr;
        --        IF ( ( SELECT   CHARINDEX(@DiffConstruct, @InputStr)
        --             ) > 0 )
        --            BEGIN
        --                INSERT  INTO #result
        --                        ( CompID ,
        --                          Name ,
        --                          diffConstruct ,
        --                          IsOk,
        --                          Lennum
        --                        )
        --                        SELECT  CompID ,
        --                                Name ,
        --                                REPLACE(REPLACE(@InputStr,
        --                                                @DiffConstruct, ''),
        --                                        '()', '') ,
        --                                CASE WHEN ( SELECT  CHARINDEX(@DiffConstruct,
        --                                                      @InputStr)
        --                                          ) > 0 THEN 1
        --                                     ELSE 0
        --                                END IsOK,
        --                                ElementNum
        --                        FROM    dbo.Bs_Compound_Learn
        --                        WHERE   DiffConstruct = @DiffConstruct;

                        
        --                --PRINT @InputStr;
        --                BREAK;
        --            END;
        --    END;
        --SELECT  *
        --FROM    #result;
        DROP TABLE #Res;  
      -------------------------------------------------------------------------------------二次查询-----------------------------------------------------------------------------------    
--CREATE UNIQUE CLUSTERED  INDEX index1 ON #result (ID) ON [PRIMARY];  
--        SET @Count = 1;
        
--        --PRINT @LetterLen; 
--        CREATE TABLE #Res1
--            (
--              ID INT IDENTITY(1, 1)
--                     NOT  NULL ,
--              ElementNum INT ,
--              DiffConstruct NVARCHAR(100)
--            );

   
--        INSERT  INTO #Res1
--                SELECT  ElementNum ,
--                        DiffConstruct
--                FROM    Bs_Compound_Learn
--                WHERE   ElementNum <= (SELECT MAX(Lennum) FROM #result)
--                ORDER BY ElementNum DESC;
        --CREATE UNIQUE CLUSTERED  INDEX index1 ON #Res1 (ID) ON [PRIMARY];    
 --SELECT  *FROM #Res1
        --SET @MaxCount = ( SELECT    COUNT(*)
        --                  FROM      #Res1
        --                );
        --WHILE ( @Count <= @MaxCount )
        --    BEGIN
        --        SET @InputStr = ( SELECT    diffConstruct
        --                          FROM      #result
        --                          WHERE     ID = @Count
        --                        );
        --        SET @LetterLen = ( SELECT   LEN(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@InputStr,
        --                                                      '3', ''), '2',
        --                                                      ''), '1', ''),
        --                                                      ')', ''), '(',
        --                                                      ''), '=', ''))
        --                         );  
        --    --寻找机器学习表里的原材料字符串
        --        SET @DiffConstruct = ( SELECT   DiffConstruct
        --                               FROM     #Res1
        --                               WHERE    ID = @Count
        --                             );
        --        SET @Count = @Count + 1;
        --        PRINT '第二次匹配: 序号:  '+CAST(@Count AS  NVARCHAR(10))+'    '+@DiffConstruct + ',' + @InputStr;
        --        IF ( ( SELECT   CHARINDEX(@DiffConstruct, @InputStr)
        --             ) > 0 )
        --            BEGIN
        --                PRINT @InputStr;
                        
                    
               
        --                --INSERT  INTO #result
        --                --        ( CompID ,
        --                --          Name ,
        --                --          diffConstruct ,
        --                --          IsOk
        --                --        )
        --                --        SELECT  CompID ,
        --                --                Name ,
        --                --                DiffConstruct ,
        --                --                CASE WHEN ( SELECT  CHARINDEX(@DiffConstruct,
        --                --                                      @InputStr)
        --                --                          ) > 0 THEN 1
        --                --                     ELSE 0
        --                --                END IsOK
        --                --        FROM    dbo.Bs_Compound_Learn
        --                --        WHERE   DiffConstruct = @DiffConstruct;
        --                --BREAK;
        --                UPDATE  #result
        --                SET     TwoDiffConstruct = @DiffConstruct
        --                FROM    #result
        --                WHERE   ID = @Count;
        --            END;
            --END;
        --SELECT * FROM #result
        --SELECT  #result.*
        --FROM    #result
        --        LEFT JOIN dbo.Tbl_Base_Compound ON Tbl_Base_Compound.ID = #result.CompID
        --WHERE   IsOk = 1;
        --DROP TABLE #result;
        --DROP TABLE #Res1;
    END;


go

