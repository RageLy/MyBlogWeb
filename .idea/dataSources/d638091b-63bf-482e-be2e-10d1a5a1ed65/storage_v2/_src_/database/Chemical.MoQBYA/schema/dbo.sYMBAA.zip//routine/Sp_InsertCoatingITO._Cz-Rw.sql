
-- =============================================                            
-- Author: hmw                                            
-- Create Date: 2017年5月26日                                                  
-- Descript: 从Excel插入白色颜料  
-- =============================================                   
--   exec [Sp_InsertCoatingITO]  
CREATE PROCEDURE [dbo].[Sp_InsertCoatingITO]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_CoatingITO
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_CoatingITO
                            GROUP BY ITO卷号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_CoatingITO
                           );
        UPDATE dbo.Bs_Coating_ITO
        SET    optDate = 检测日期 ,
		RKDate=ITO入库时间,
               Code = ITO卷号 ,
               LWater = 左水滴角 ,
               LEDJW = 左二碘甲烷接触角 ,
               LBMN = 左表面能 ,
               MWater = 中水滴角 ,
               MEDJW = 中二碘甲烷接触角 ,
               MBMN = 中表面能 ,
               RWater = 右水滴角 ,
               REDJW = 右二碘甲烷接触角 ,
               RBMN = 右表面能 ,
               SDJAvg = 水滴角均值 ,
               SDJsqt = 水滴角标准偏差
        FROM   dbo.TempTb_CoatingITO
        WHERE  Code = ITO卷号;

        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_Coating_ITO
                                            INNER JOIN dbo.TempTb_CoatingITO ON TempTb_CoatingITO.ITO卷号 = Bs_Coating_ITO.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;

        INSERT INTO dbo.Bs_Coating_ITO (   optDate ,
		RKDate,
                                           Code ,
                                           LWater ,
                                           LEDJW ,
                                           LBMN ,
                                           MWater ,
                                           MEDJW ,
                                           MBMN ,
                                           RWater ,
                                           REDJW ,
                                           RBMN ,
                                           SDJAvg ,
                                           SDJsqt
                                       )
                    SELECT 检测日期 ,
					ITO入库时间,
                           ITO卷号 ,
                           左水滴角 ,
                           左二碘甲烷接触角 ,
                           左表面能 ,
                           中水滴角 ,
                           中二碘甲烷接触角 ,
                           中表面能 ,
                           右水滴角 ,
                           右二碘甲烷接触角 ,
                           右表面能 ,
                           水滴角均值 ,
                           水滴角标准偏差
                    FROM   dbo.TempTb_CoatingITO
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_Coating_ITO
                                          WHERE  Code = ITO卷号
                                      )
                           AND ITO卷号 IS NOT NULL;
    END;
go

