create view myview as select re=rand()
go

