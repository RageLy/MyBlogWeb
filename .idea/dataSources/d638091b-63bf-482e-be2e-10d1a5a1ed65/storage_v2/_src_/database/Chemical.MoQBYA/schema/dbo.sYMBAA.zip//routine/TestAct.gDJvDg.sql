CREATE  PROCEDURE TestAct
    @InputStr NVARCHAR(100)
AS
    BEGIN 
        DECLARE @LetterLen INT= 0;
        SET @InputStr=REPLACE(REPLACE(@InputStr,'2', '1'),'3', '1')
        SET @LetterLen = ( SELECT   LEN(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(@InputStr,
                                                              '3', ''), '2',
                                                              ''), '1', ''),
                                                              ')', ''), '(',
                                                        ''), '=', ''))
                         );
        PRINT @LetterLen;
        DECLARE @DiffConstruct NVARCHAR(100)= '';
        DECLARE @Count INT= 1;
        DECLARE @MaxCount INT= 0;
        SELECT  *
        INTO    #Res
        FROM    Bs_Compound_Learn
        WHERE   ElementNum <= @LetterLen
        ORDER BY ElementNum DESC;
        
        CREATE TABLE #result
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL ,
              CompID INT ,
              Name NVARCHAR(100) ,
              diffConstruct NVARCHAR(100) ,
              IsOk INT
            );
 
        SET @MaxCount = ( SELECT    COUNT(*)
                          FROM      Bs_Compound_Learn
                        );
        WHILE ( @Count <= @MaxCount )
            BEGIN
                SET @DiffConstruct = ( SELECT   DiffConstruct
                                       FROM     #Res
                                       WHERE    ID = @Count
                                     );
                SET @Count = @Count + 1;
                PRINT @DiffConstruct + ',' + @InputStr;

                INSERT  INTO #result
                        ( CompID ,
                          Name ,
                          diffConstruct ,
                          IsOk
                        )
                        SELECT  CompID ,
                                Name ,
                                DiffConstruct ,
                                CASE WHEN ( SELECT  CHARINDEX(SUBSTRING(@DiffConstruct,
                                                              0,
                                                              LEN(@DiffConstruct)
                                                              - 5), @InputStr)
                                          ) > 0 THEN 1
                                     ELSE 0
                                END IsOK
                        FROM    dbo.Bs_Compound_Learn
                        WHERE   DiffConstruct = @DiffConstruct;
                
            END;
        SELECT  #result.*
        FROM    #result
                INNER JOIN dbo.Tbl_Base_Compound ON Tbl_Base_Compound.ID = #result.CompID
        WHERE   IsOk = 1;
        DROP TABLE #result;
    END;


go

