
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年5月27日                                                
-- Descript: 从Excel插入单层胶囊数据
-- =============================================                 
-- exec [Sp_InsertModule]
CREATE PROCEDURE [dbo].[Sp_InsertModule]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        DELETE FROM dbo.TempTb_Module
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Module
                            GROUP BY 样品编号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_Module
                           );
        BEGIN

            UPDATE Bs_Module
            SET    OptDate = 测试时间 ,
                   MakeTime = 制屏时间 ,
                   ModuleType = 模组型号 ,
                   CoatingMsCode = 墨水批次 ,
                   CoatingCode = 膜片批次 ,
                   Code = 样品编号 ,
                   LBK0min = L黑0min ,
                   ABK0min = A黑0min ,
                   BBK0min = B黑0min ,
                   LBK2min = L黑2min ,
                   ABK2min = A黑2min ,
                   BBK2min = B黑2min ,
                   LW0min = L白0min ,
                   AW0min = A白0min ,
                   BW0min = B白0min ,
                   LW2min = L白2min ,
                   AW2min = A白2min ,
                   BW2min = B白2min ,
                   BKFSL0min = 黑反射率0min ,
                   BKFSL2min = 黑反射率2min ,
                   WFSL0min = 白反射率0min ,
                   WFSL2min = 白反射率2min ,
                   CR0min = TempTb_Module.[CR0min] ,
                   CR2min = TempTb_Module.[CR2min] ,
                   DeltaBK2min = [黑DeltaL2min] ,
                   DeltaW2min = [白DeltaL2min] ,
                   DeltaBKMaxToMin = [黑deltaMax减Min] ,
                   DeltaWMaxToMin = [白deltaMax减Min] ,
                   VCOMDY = VCOM电压 ,
                   Temp = 测试温度 ,
                   Wave = 驱动波形 ,
                   LBKMoreW = [黑大于白L值] ,
                   LWMoreBK = [白大于黑L值] ,
                   RBKMoreW = [黑大于白R值] ,
                   RWMoreBK = [白大于黑R值] ,
                   CR5To1 = [CR5比1] ,
                   CR7To1 = [CR7比1] ,
                   BYKSRank = 边缘扩散等级 ,
                   UpDateTime = GETDATE()
            FROM   dbo.TempTb_Module
            WHERE  Code = 样品编号;

            SET @ReturnupdateValue = (   SELECT COUNT(*)
                                         FROM   dbo.Bs_Module
                                                INNER JOIN dbo.TempTb_Module ON TempTb_Module.样品编号 = Bs_Module.Code
                                     );
            SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;

            INSERT INTO dbo.Bs_Module (   OptDate ,
                                          MakeTime ,
                                          ModuleType ,
                                          CoatingMsCode ,
                                          CoatingCode ,
                                          Code ,
                                          LBK0min ,
                                          ABK0min ,
                                          BBK0min ,
                                          LBK2min ,
                                          ABK2min ,
                                          BBK2min ,
                                          LW0min ,
                                          AW0min ,
                                          BW0min ,
                                          LW2min ,
                                          AW2min ,
                                          BW2min ,
                                          BKFSL0min ,
                                          BKFSL2min ,
                                          WFSL0min ,
                                          WFSL2min ,
                                          CR0min ,
                                          CR2min ,
                                          DeltaBK2min ,
                                          DeltaW2min ,
                                          DeltaBKMaxToMin ,
                                          DeltaWMaxToMin ,
                                          VCOMDY ,
                                          Temp ,
                                          Wave ,
                                          LBKMoreW ,
                                          LWMoreBK ,
                                          RBKMoreW ,
                                          RWMoreBK ,
                                          CR5To1 ,
                                          CR7To1 ,
                                          BYKSRank ,
                                          UpDateTime
                                      )
                        SELECT 测试时间 ,
                               制屏时间 ,
                               模组型号 ,
                               墨水批次 ,
                               膜片批次 ,
                               样品编号 ,
                               L黑0min ,
                               A黑0min ,
                               B黑0min ,
                               L黑2min ,
                               A黑2min ,
                               B黑2min ,
                               L白0min ,
                               A白0min ,
                               B白0min ,
                               L白2min ,
                               A白2min ,
                               B白2min ,
                               黑反射率0min ,
                               黑反射率2min ,
                               白反射率0min ,
                               白反射率2min ,
                               [CR0min] ,
                               [CR2min] ,
                               [黑DeltaL2min] ,
                               [白DeltaL2min] ,
                               [黑deltaMax减Min] ,
                               [白deltaMax减Min] ,
                               VCOM电压 ,
                               测试温度 ,
                               驱动波形 ,
                               [黑大于白L值] ,
                               [白大于黑L值] ,
                               [黑大于白R值] ,
                               [白大于黑R值] ,
                               [CR5比1] ,
                               [CR7比1] ,
                               边缘扩散等级 ,
                               GETDATE()
                        FROM   dbo.TempTb_Module
						WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_Module
                                          WHERE  Code = 样品编号
                                      )
                           AND 样品编号 IS NOT NULL;
        END;
    END;
go

