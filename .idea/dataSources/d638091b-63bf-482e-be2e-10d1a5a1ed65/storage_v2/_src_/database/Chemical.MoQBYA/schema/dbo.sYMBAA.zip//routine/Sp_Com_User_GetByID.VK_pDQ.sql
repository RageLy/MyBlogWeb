-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-25>
-- Description:	<个人密码修改>
-- =============================================
CREATE procedure [dbo].[Sp_Com_User_GetByID]
	@UserID varchar(500)='' 
 as 
 Begin 
set nocount on
			select
			cast(Tbl_Sys_User.UserName as varchar(50))UserName,
			cast(Tbl_Sys_User.UserAccount as varchar(50))UserAccount			
			from dbo.Tbl_Sys_User where UserID=@UserID		

   end
go

