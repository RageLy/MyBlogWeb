-- =============================================      
-- Description: <删除用户>    
-- =============================================    
CREATE PROCEDURE [dbo].[Sp_Sys_DeleteUser]    
@UserID varchar(50)=''    
 as     
 begin    
set nocount on;    
    
if @UserID !=''    
begin    
update Tbl_Com_Employee set UserID=null where UserID=@UserID    
delete Tbl_Sys_User where UserID=@UserID    
select '0'    
end    
else    
begin    
 select '请选择一条记录进行删除'    
end    
 end
go

