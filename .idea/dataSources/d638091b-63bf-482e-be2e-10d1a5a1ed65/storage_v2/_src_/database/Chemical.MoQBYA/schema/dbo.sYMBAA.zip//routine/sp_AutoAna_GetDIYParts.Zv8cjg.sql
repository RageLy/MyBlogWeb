-- =============================================
-- Author:		hjl
-- Create date: <Create Date,,>
-- Description:	计算寻找 变量维度与目标维度的之间的关系
-- =============================================
CREATE PROCEDURE sp_AutoAna_GetDIYParts
	-- Add the parameters for the stored procedure here
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(Max) = 'DimSinOutValue:,DimOilSeries:,DimSinTemp41:,DimSinTemp8:,DimSinTemp25:,DimSinSpeed:,DimSinSpeed580:倍数2,DimOilViscosity:,DimDIYDDLps:'
	,@XDIM VARCHAR(50) = 'DimSinSpeed'
	,@YDIM VARCHAR(50) = 'DimSinOutValue'
	,@NameTag VARCHAR(50) = 'hjl'
AS
BEGIN
	
	SET NOCOUNT ON;
	
	DECLARE @ResultTable VARCHAR(max);
	SET @ResultTable = 'T_AutoAnaCountSift_' + ISNULL(@XDim,'') + '_' +  ISNULL(@YDim,'') + '_' +ISNULL(@NameTag,'');
	
	
	--DimSinOutValue,DimOilSeries,,DimSinTemp8,DimSinTemp41,DimSinTemp25,DimSinSpeed,DimSinSpeed580,DimOilViscosity,DimDDLps
	--DimDIYOilVis,DimDIYDDLps
	
	EXEC Sp_AutoAna_PearsenRAndTrend
	@SpName = @SpName
	,@Dims = @Dims
	,@XDim = @XDIM
	,@YDim = @YDIM
	,@NameTag = @NameTag
	,@IsCountR = 0 -- 是否计算 相关系数R
	
	EXEC ( 'ALTER TABLE ' + @ResultTable + ' ADD PearSenR DECIMAL(18,6);' );
	
	CREATE TABLE #Sv
	(
		Sifvalue VARCHAR(MAX)
	)

	EXEC ( ' INSERT INTO #Sv SELECT TOP 1 SiftValue FROM ' + @ResultTable + '
	WHERE DimOilSeries = 3
	ORDER BY DataCount DESC ' );
	
	
	DECLARE @Sv VARCHAR(MAX);
	SELECT @Sv = Sifvalue FROM #Sv;
	
	EXEC [Sp_AutoAna_DataPearsen]
	@SiftValue = @SV
	,@SpName = @SpName
	,@XDim = @XDIM
	,@YDim = @YDIM
	,@NameTag = @NameTag
	
	EXEC (
	'SELECT PearSenR,* FROM T_AutoAnaCountSift_DimSinSpeed_DimSinOutValue_hjl
	WHERE DimOilSeries = 3 AND SiftValue = ''' + @SV + '''
	ORDER BY DataCount DESC'
	)
	

END
go

