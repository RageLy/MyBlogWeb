    
    
    
    
CREATE PROCEDURE [dbo].[Sp_MaintenanceProjectsDetailed_List_BQ]    
@PageIndex varchar(50)='1'                                                                               
,@PageSize varchar(50)='5'                                                                               
,@OrderFields varchar(50)=''        
,@MPDId varchar(50)='20'        
    
AS    
BEGIN    
SET NOCOUNT ON;                    
--设置默认排序                                    
if(LEN(@OrderFields)=0)                                
begin                                          
set @OrderFields=' cast(DetailID as int)'                                
end          
    
--查询维修套餐明细    
    
SELECT    
ID as DetailID,     
ProjectName,    
Amount,    
Quantity,    
TotalAmount,    
mpd.Remark,    
Cast(mpd.ServiceGroupID as Int) as ServiceGroupID,    
sg.ServiceGroupName  
,@MPDId as  MPDId  
into #MaintenanceProjectsDetailed     --select * from Tbl_Base_MaintenanceProjects
FROM Tbl_Base_MaintenanceProjectsDetailed mpd     
left join tbl_Base_ServiceGroup sg on mpd.ServiceGroupID = sg.ServiceGroupID    
WHERE MPDId = @MPDId    
    
 declare @pageCount int =@@ROWCOUNT      
       
 if (@pageCount = 0)      
 begin insert into #MaintenanceProjectsDetailed values(0,null,null,null,null,null,null,null,@MPDId)       
 end      
       
          
 --调用通用分页            
            
exec Sp_Sys_Page '#MaintenanceProjectsDetailed',@OrderFields,@pageCount,@PageIndex,@PageSize         
END
go

