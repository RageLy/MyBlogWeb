













-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 自动相关性系数与趋势计算sp
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_PearsenRAndTrend_LC]
	@SpName VARCHAR(50) = 'DouCapsule'
	,@condition VARCHAR(max)='DimDouKzWd:-1840|-2280%DimOilSeries:3%DimDouOutputValue:-100%DimDouTemp8:-1%DimDouTemp25:-1%DimDouTemp41:-1%DimDouSpeed400:-1%DimDouSpeed500:-1%DimDouLJ:-1%DimDouJNGHL:-1%DimDouCR:-1%DimDouLW:-1%DimDouLBK:-1%DimDouDeltaBK:-1%DimDouDeltaW:-1%DimDouPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimDouLJspan:-1%DimDouPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimOilDensity:-1%DimOilSTension:-1'
    ,@OtherCond  VARCHAR(max)='%温度8%无选项%L白%列表%拟合分析%undefined%undefined'
    ,@EmpID INT = 1
    --,@NameTag VARCHAR(50) = 'lc'
    ,@PageIndex VARCHAR(5)='1'
    ,@PageSize VARCHAR(5)='30'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	DECLARE @SiftValueold VARCHAR(MAX);
    SET @SiftValueold=REPLACE(@condition,'|',',');

    --select left(@SiftValueold,CHARINDEX('%',@SiftValueold)-1)

    DECLARE @Usertitle VARCHAR(50) = ''          -- 标题            
    DECLARE @XName VARCHAR(MAX) = ''              -- 横轴维度名称                
    DECLARE @DSName VARCHAR(MAX) = ''             -- 分组维度名称                
    DECLARE @YName VARCHAR(MAX) = ''               -- @OtherCond  传入的Y轴名称                
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
    DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                
    DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式        
    
    DECLARE @XDim VARCHAR(MAX)
	DECLARE @YDim VARCHAR(MAX)
	DECLARE @IsCountR BIT  -- 是否计算 相关系数R
	DECLARE @IsCountTrend INT =1
	DECLARE @TrendR DECIMAL(18,6) = 0.7
	DECLARE @GetLineR DECIMAL(18,2) = 0.5  -- 计算斜率的R条件
    
	DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(MAX)            
	 )            
  
    INSERT INTO @OtherCondTbl
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')
     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)
     
	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,Dimname varchar(MAX)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
    --维度拆分表
    CREATE TABLE #DimsLS
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(MAX)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable_LS]
     @SiftValue = @SiftValueold
	,@XName = @XName
	,@DsName = @DsName;
    
    -- 创建 控制维度筛选项维度
	 DECLARE @KZWD VARCHAR(MAX) = ''; 
	 DECLARE @KZWDName VARCHAR(MAX) = '';
	 set @KZWDName=(select dimname from #DimsLS where DimYsql='')
	 set @KZWD=(select dimvalues from #DimsLS where DimYsql='' and dimname=@KZWDName)
	 
    --更新#DimsPearSen
	  DECLARE @KZWDDimsTb VARCHAR(MAX) = '';
	 set @KZWDDimsTb =(select  '
	 insert into #DimsPearSen (Dim,Dimname,DType,isrange,ViewName,DimYsql,DimValue,DataCount)
	 select  dimname,tad.Name_ch,''K'',tad.isrange,tad.ViewName,tad.AtYSql
	 ,case when istrue=0 then '''' when istrue=2 then ''倍数2'' when istrue=3 then ''倍数5'' when istrue=4 then ''倍数10'' end as qu  
	 ,''''
	 from VW_'+@KZWDName+'_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in ('+@KZWD+')
	  ')
	  exec( @KZWDDimsTb)
	  
	  insert into  #DimsPearSen(Dim,Dimname,DType,isrange,ViewName,DimYsql,DimValue,DataCount)
	  select DimName,tad.Name_ch,'Y',dm.isrange,tad.ViewName,dm.DimYsql,'','' from #DimsLS dm
	  inner join Tbl_AnsCom_DIimToTable tad
	  on dm.DimName=tad.DimNum
	  where ChName=@YName

      insert into  #DimsPearSen(Dim,Dimname,DType,isrange,ViewName,DimYsql,DimValue,DataCount)
      select DimName,tad.Name_ch,Isneed,dm.isrange,tad.ViewName,dm.DimYsql,'','' from #DimsLS dm
	  inner join Tbl_AnsCom_DIimToTable tad
	  on dm.DimName=tad.DimNum
	  where dm.DimYsql<>'' and Isneed<>'ND' 


	  --控制维度排序
	  CREATE TABLE #DimsKzshift
	  (
		DimName varchar(50)
		,DimValues varchar(max)
	  );

	  DECLARE @KZWDshift VARCHAR(MAX) = '';
	 set @KZWDshift =(select  '
	 insert into #DimsKzshift (DimValues)
	 select  kz.ID
	 from VW_'+@KZWDName+'_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in ('+@KZWD+')
	  ')
	  exec( @KZWDshift)
    
    DECLARE @KZshift VARCHAR(MAX) = '';
    set @KZshift=(select cast(DimValues as varchar(50))+',' from #DimsKzshift order by DimValues FOR XML PATH(''))
    set @KZshift=(select @KZWDName+':'+@KZshift)
    set @KZshift=(select LEFT(@KZshift,LEN(@KZshift)-1))
    DECLARE @KZshiftor VARCHAR(MAX) = '';
    set @KZshiftor=(select substring(@SiftValueold,CHARINDEX('%',@SiftValueold),LEN(@SiftValueold)-CHARINDEX('%',@SiftValueold)+1))
    set @KZshift=@KZshift+@KZshiftor
    --DimDouKzWd:-2280,237%DimOilSeries:3%DimDouOutputValue:-100%DimDouTemp8:-1%DimDouTemp25:-1%DimDouTemp41:-1%DimDouSpeed400:-1%DimDouSpeed500:-1%DimDouLJ:-1%DimDouJNGHL:-1%DimDouCR:-1%DimDouLW:-1%DimDouLBK:-1%DimDouDeltaBK:-1%DimDouDeltaW:-1%DimDouPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimDouLJspan:-1%DimDouPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimOilDensity:-1%DimOilSTension:-1

	  SET @XDim=(SELECT DIM FROM #DimsPearSen WHERE DType='X')
	  SET @YDim=(SELECT DIM FROM #DimsPearSen WHERE DType='Y')

    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #DimsPearSen WHERE Dimname = @YName;
    DECLARE @Xsql VARCHAR(500);
    SELECT @Xsql = DimYsql FROM #DimsPearSen WHERE Dimname = @XName;
    IF(@Xsql IS NULL)  -- 如果X值没有选则取0
		SET @Xsql = '0';

    -- 数据源sql段
    DECLARE @TName VARCHAR(MAX);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
    
    -- where条件
    DECLARE @Where VARCHAR(MAX);
    set @Where = (select ' where ' + @Ysql + ' is not null and ' + @Xsql + ' is not null ');
    
    -- 计算所有条件 Dim 的数据量
    DECLARE @CreateT VARCHAR(max) = '';
    SET @CreateT += ( SELECT 'CREATE TABLE #' +  Dim + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'		
					END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') );


    --控制维度临时表
    DECLARE @CreateT1 VARCHAR(max) = '';
    SET @CreateT1 += ( SELECT 'CREATE TABLE #' +  Dim+'K'+ 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'		
					END
		FROM #DimsPearSen WHERE DType = 'K' FOR XML PATH('') );
    

    -- 根据维度值取维度刻度
	DECLARE @InsertT VARCHAR(max) = '';
	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where ' + 
				CASE WHEN ISNULL(DimValue,'') = '' THEN 'istrue = 0;'
						  ELSE '[选项集合类型] = ''' + DimValue + ''';' END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') )

    -- 根据维度值取维度刻度-控制维度
    DECLARE @InsertT1 VARCHAR(max) = '';
	SET @InsertT1 +=
	   ( SELECT 'insert into #' + Dim + 'K' +  
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where ' + 
				CASE WHEN ISNULL(DimValue,'') = '' THEN 'istrue = 0;'
						  ELSE '[选项集合类型] = ''' + DimValue + ''';' END
		FROM #DimsPearSen WHERE DType ='K' FOR XML PATH('') )
    
 --   -- 拼接计算列
    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' inner JOIN #' +  Dim + ' AS ' + Dim + ' on ' + 
		CASE WHEN isrange = 1 THEN Dim + '.BeginValue <= ' + DimYsql + ' AND ' + Dim + '.EndValue > ' + DimYsql
		ELSE Dim + '.ID = ' + DimYsql END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
    
    --join段 控制维度
    DECLARE @SqlJoin1 VARCHAR(max);
    SET @SqlJoin1 = ( SELECT ' LEFT JOIN #' +  Dim + 'K' + ' AS ' + Dim + 'K on ' + 
		CASE WHEN isrange = 1 THEN Dim + 'K.BeginValue <= ' + DimYsql + ' AND ' + Dim + 'K.EndValue > ' + DimYsql
		ELSE Dim + 'K.ID = ' + DimYsql END
		FROM #DimsPearSen WHERE DType ='K' FOR XML PATH(''));

    if(select count(*) from #DimsPearSen WHERE DType = 'F')=0
    begin
	set @CreateT=@CreateT1
	set @InsertT=@InsertT1
	SET @SqlJoin=@SqlJoin1
	SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	end;
	if(select count(*) from #DimsPearSen WHERE DType = 'F')>0
	begin
	set @CreateT=@CreateT+@CreateT1
	SET @InsertT=@InsertT+@InsertT1
	SET @SqlJoin=@SqlJoin+@SqlJoin1
	SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	end;

    PRINT @CreateT
    PRINT @InsertT
    print @SqlJoin
    PRINT '@InsertT'

	-- 拼接SiftValue段
    DECLARE @SiftValue VARCHAR(max);
    SET @SiftValue = ( SELECT '''%' +  Dim + ':'' + CAST( isnull(' + Dim + 'K.ID,0) AS Varchar(10)) + '
	FROM #DimsPearSen WHERE DType = 'K' FOR XML PATH(''));

	-- 去掉第一个 % 和最后一个 +
	SET @SiftValue = '''' + SUBSTRING(@SiftValue,3,LEN(@SiftValue) - 3);
	
	-- 拼接 group by 段
    DECLARE @GroupBy VARCHAR(max);
    SET @GroupBy = ( SELECT ',' + Dim + 'K.ID'
		FROM #DimsPearSen WHERE DType = 'K' FOR XML PATH(''));

	-- 去掉第一个,
	SET @GroupBy = SUBSTRING(@GroupBy,2,LEN(@GroupBy));
	
	print @GroupBy
	print '@GroupBy'
	
	-- 设置目标表格
	DECLARE @NameTag VARCHAR(max) = '';
	DECLARE @ResultTable VARCHAR(max);
	if(select count(*) from #DimsPearSen where DType='K')>0
	begin
	SET @NameTag=(SELECT '_'+Dim+DimValue from #DimsPearSen where DType='K' FOR XML PATH(''))
	set @NameTag=(select replace(substring(@NameTag,2,LEN(@NameTag)-1),'倍数','BS'))
	end
	else
	SET @NameTag=(SELECT 'ALL');
	SET @ResultTable = 'T_AutoAnaCountSift_' + ISNULL(@XDim,'') + '_' +  ISNULL(@YDim,'') + '_' +ISNULL(@NameTag,'');

	-- 拼接 维度条件列名段
    DECLARE @CName VARCHAR(max);
    SET @CName = ( SELECT ',' + Dim + ' INT'
		FROM #DimsPearSen WHERE DType = 'K' FOR XML PATH(''));

	--删除老的记录
    --delete from  dbo.T_AutoAnaCountSift where Xname=@XName and Yname=@YName and shiftvalue=@KZshift and Update_Time<GETDATE()-1;
    delete from  dbo.T_AutoAnaCountSift where Xname=@XName and Yname=@YName and shiftvalue=@KZshift;
	--是否重新计算
	if(select COUNT(*) from dbo.T_AutoAnaCountSift where Xname=@XName and Yname=@YName and shiftvalue=@KZshift)=0
    begin
    	IF exists( SELECT 1 FROM sys.objects where name = @ResultTable )
		EXEC ( 'DROP TABLE ' + @ResultTable );
	DECLARE @CreateTable VARCHAR(max);
    set @CreateTable=( 'CREATE TABLE ' + @ResultTable + '
	                    (	spName varchar(50),
		                DataCount int,
		                MaxY Decimal(18,6),
		                MinY Decimal(18,6),
		                AVGY Decimal(18,6),
		                SQtY Decimal(18,6),
		                MaxX Decimal(18,6),
		                MinX Decimal(18,6),
		                Xcount int,
		                Siftvalue varchar(Max),
		                PearSenR DECIMAL(18,6),
		                Slope DECIMAL(18,6),
		                LineCons DECIMAL(18,6),
		                ChangePoint int ,
		                Trend Varchar(Max)
		                ' + @CName + ')'
	                )

	insert into dbo.T_AutoAnaCountSift(Xname,Yname,shiftvalue,table_name,Update_Time)
    values(@XName,@YName,@KZshift,@ResultTable,GETDATE());

	--RETURN; 
	DECLARE @ResultDataSql VARCHAR(MAX);
	SET @ResultDataSql = '''' + @SpName + ''',count(*),MAX(' + @Ysql + '),MIN(' + @Ysql + '),AVG(' + @Ysql + '),stdev(' + @Ysql + '),Max(' + @Xsql + '),Min(' + @Xsql + '),Count(Distinct ' + @Xsql + '),'

	EXEC (@CreateT + @InsertT + @CreateTable + 'INSERT INTO ' + @ResultTable + ' SELECT ' + @ResultDataSql + @SiftValue + ',NULL,NULL,NULL,NULL,NULL,' + @GroupBy + ' FROM ' + @TName + @SqlJoin + @Where + ' Group by ' + @GroupBy );

    print '------------'
    print @ResultDataSql
    print @SiftValue
    print @GroupBy
    print @TName
    print @SqlJoin
    print @GroupBy
    print '------------'
    --计算相关性
		DECLARE @UpdateR VARCHAR(MAX);

		SET @UpdateR = '
		DECLARE @N INT = 1;
		DECLARE @SV VARCHAR(MAX);
		DECLARE Cur CURSOR FOR
		SELECT Siftvalue FROM ' + @ResultTable + ' WHERE DataCount > 1 AND MaxX <> MinX ' + '' + '
		OPEN Cur
		FETCH NEXT FROM Cur INTO @SV
		WHILE @@FETCH_STATUS =0
		BEGIN
			
			EXEC [Sp_AutoAna_DataPearsen]
			@SiftValue = @SV
			,@SpName = ''' + @SpName + '''
			,@XDim = ''' + @XDim + '''
			,@YDim = ''' + @YDim + '''
			,@NameTag = ''' + @NameTag + '''
			,@GetLineR  = ' + CAST(@GetLineR AS VARCHAR(20)) + '
			
			IF( ' + CAST(@IsCountTrend AS VARCHAR(10)) + ' = 1 )
			BEGIN
				IF EXISTS( select 1 FROM ' + @ResultTable + ' WHERE SiftValue = @SV AND Abs(PearSenR) < + ' + CAST(@TrendR AS VARCHAR(20)) + ' )
					EXEC [Sp_AutoAna_DataTrend]
					@SiftValue = @SV
					,@SpName = ''' + @SpName + '''
					,@XDim = ''' + @XDim + '''
					,@YDim = ''' + @YDim + '''
					,@NameTag = ''' + @NameTag + '''
			
			END
			
			Print ( ''执行完:'' + Cast(@N AS Varchar(10)) )
			
			SET @N = @N + 1
			
			FETCH NEXT FROM Cur INTO @SV
		END	
		CLOSE Cur
		DEALLOCATE Cur
		'
    EXEC(@UpdateR)
    end 
    select '计算完成'   return ;

	END
go

