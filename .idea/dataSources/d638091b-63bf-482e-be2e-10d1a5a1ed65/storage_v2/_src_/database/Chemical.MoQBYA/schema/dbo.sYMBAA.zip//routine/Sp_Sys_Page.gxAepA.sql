/*                    
分页sp yind                    
调用示例                    
                    
if object_id('tempdb.dbo.#tb') is not null                    
drop table #tb                    
                    
select  *                     
into #tb                    
from tbl_base_car                    
                    
declare @rowcount int                    
set @rowcount=@@rowcount                    
                    
                    
        
exec [Sp_Sys_Page] @tblName='#tb',@fldName='framenum',@rowcount=@rowcount,  @SumType=1 ,    
                         @PageSize=20, @PageIndex=1  ,@SumColumn='carseriesid'      
                             
                 
                    
                    
*/                      
                       
                            
CREATE PROCEDURE [dbo].[Sp_Sys_Page]                               
(                                 
 @tblName   varchar(255)       -- 表名                                     
 ,@fldName varchar(255)=''      -- 排序                               
 ,@rowcount int=1000         ------------行数                          
 ,@PageIndex  int = 1                        
 ,@PageSize   float = 10          -- 页尺寸                         
 ,@SumType int = 0 -- 0 表示不要合计行、1 表示只要小计行一行、2 表示要小计、合计两条合计行3 表示只要合计行一行  
 ,@SumColumn varchar(8000)='price,CarModelID'-----需要汇总的列,用逗号分开         
 ,@AvgColumn varchar(8000)='CarModelID'-----需要求平均值的列,用逗号分开                            
)                          
AS                                      
BEGIN                                      
 --如果表名称为空，退出                                     
 if @tblName ='-1' or @tblName ='' or @tblName is  null                                       
 begin                                      
  select 'lost parameter:table name'                                      
  return                                      
 end                                      
 --如果主键名称为空，退出                                     
 if @fldName ='-1' or @fldName ='' or @fldName is  null                                       
 begin                                      
  select 'lost parameter:key column name'                                      
  return                                      
 end                                      
 --如果页大小为空，退出                                     
 if @PageSize ='-1' or @PageSize ='' or @PageSize is  null                                       
 begin                                      
  select 'lost parameter:page size'                                      
  return                                      
 end                                     
                                      
 --declare @sqlTemp varchar(max)=''--临时sql字符串                                     
declare @sql nvarchar(4000)                              
                              
declare @pagecount int                              
set @pagecount= CEILING(@rowcount/@PageSize)                              
                              
                              
if @rowcount=0                              
select @pageindex=1,@pagecount=1                              
                              
  if(@pagecount<@PageIndex)  
set @PageIndex= @pagecount                    
                      
                      
set @SumColumn=','+@SumColumn+','      
set @AvgColumn=','+@AvgColumn+','                     
                      
declare @tableName nvarchar(500)                  
                      
set @tableName='##page_table'  +replace(NEWID(),'-','')                
                  
--select @tableName                  
                  
                      
if OBJECT_ID('tempdb.dbo.'+@tableName) is not null                      
exec('drop table '+ @tableName)                      
                      
                              
set @sql=                              
'                        
                      
                          
select *                      
into '+@tableName+                  
--##page_table      
' from (                              
select ROW_NUMBER() over(order by '+ @fldName +') as n ,* from '                      
+  @tblName+  ' )                       
tb  where tb.n>='+ltrim((@PageIndex-1)*@PageSize+1)                      
+' and  tb.n<='+ltrim(@PageIndex*@PageSize)                         
                           
                      
                      
--print (@sql)                      
                  
                              
exec(@sql)                              
                      
                      
exec('alter table '+ @tableName+' alter column n varchar(50)')                      
                  
                  
                      
declare @condition varchar(max)                      
set @condition=                      
(                      
 select name2+',' from           
  (                      
   select a.name    
  -- ,isnull('sum('+c.name+')','null') name2     
   ,(case when c.name IS not null then 'sum('+c.name+')'    
   when d.name IS not null then 'avg('+d.name+')'    
   else 'null' end) name2    
   from (                      
   select  name from tempdb.dbo.syscolumns  where id=OBJECT_ID('tempdb.dbo.'+@tblName)                      
   ) a                      
  left join (                      
  select  name from tempdb.dbo.syscolumns  where id=OBJECT_ID('tempdb.dbo.'+@tblName)                      
   and charindex(','+name+',',  @SumColumn)>0 ) c on a.name=c.name       
   left join (                      
  select  name from tempdb.dbo.syscolumns  where id=OBJECT_ID('tempdb.dbo.'+@tblName)                      
   and charindex(','+name+',',  @AvgColumn)>0 ) d on a.name=d.name       
       
                      
  )z                   
  for xml path('')                      
 )       
print @condition     
                    
                      
if(@SumType=0)                      
begin                      
set @sql='select * from  '+@tableName+CHAR(10)                      
end                      
if(@SumType=1)                      
begin                      
set @sql='select * from  '+@tableName+CHAR(10)+                      
'union all'+CHAR(10)                      
+'select ''小计'','+left(@condition,len(@condition)-1)+ ' from ' +@tableName                     
end                      
                      
if(@SumType=2)                      
begin                      
set @sql='select * from  '+@tableName+CHAR(10)                      
+'union all'+CHAR(10)                      
+'select ''小计'','+left(@condition,len(@condition)-1)+ ' from '+@tableName+CHAR(10)                      
+'union all'+CHAR(10)                      
+'select ''合计'','+left(@condition,len(@condition)-1)+ ' from '+@tblName                      
end                      
                      
if(@SumType=3)                      
begin                      
set @sql='select * from  '+@tableName+CHAR(10)                      
+'union all'+CHAR(10)                      
+'select ''合计'','+left(@condition,len(@condition)-1)+ ' from '+@tblName                      
end                      
                      
        
 print (@sql)        
                      
exec(@sql)                      
                      
--return                      
                              
--------------------------分页信息-------------------------------                            
                         
  
                              
select @PageIndex as PageIndex ,@pagecount as [pageCount],@rowcount as [rowCount]                              
                              
                  
                  
---------------删除临时表-------------------------------                              
if OBJECT_ID('tempdb.dbo.'+@tableName) is not null                      
exec('drop table '+ @tableName)                              
                              
                              
end
go

