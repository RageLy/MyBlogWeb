          
/*          
刘轶  2015-9-10 售前 潜客资源转移的申请列表  默认申请中      
*/          
CREATE proc [dbo].[Sp_Com_ApplyStatus_IsNot]            
as            
BEGIN            
select 'ApplyStatus' ApplyStatus                  
,'A' A                    
union all                    
select 'varchar 200'                 
,'varchar 200'                     
union all                       
select  '申请中' AS ApplyStatus      
,'' AS A           
END
go

