
--EXEC [DataFilter] 1222,3,3,'SinCapsule','Oil','SinCapsuleOutPut','163','165,166,168,170'
CREATE PROCEDURE [dbo].[DataFilter]
    @DataID INT = 1222 ,  --原始数据的ID
    @WDCount INT = 3 ,    --维度数
    @BC INT = 3 ,         --步长数
    @SpType NVARCHAR(20) = 'SinCapsule' , --数据源
    @SubTable NVARCHAR(20) = 'Oil' ,      --数据源的上一级数据源
    @YValue NVARCHAR(100) = 'SinCapsuleOutPut' , --目标维度
    @LeftTarget NVARCHAR(100) = '163' ,          --主分析维度在Tbl_AnsCom_DIimToTable的ID号
    @RightTarget NVARCHAR(100) = '165,166,168,170' --该维度之后的控制参数在Tbl_AnsCom_DIimToTable里面的ID号
AS
    BEGIN
        ------------------------------维度数量的循环--------------------------------
        CREATE TABLE #Num
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                NumValue NVARCHAR(2)
            );
        DECLARE @tempNum INT = @WDCount;
        WHILE ( @tempNum > 0 )
            BEGIN
                --PRINT @tempNum;
                INSERT INTO #Num ( NumValue )
                VALUES ( @tempNum );

                SET @tempNum -= 1;
            END;
        --SELECT *
        --FROM   #Num;
        ------------------------------创建排列组合数---------------------------------------------------
        CREATE TABLE #SortTb
            (
                ID INT IDENTITY(1, 1) NOT NULL ,
                SortValue NVARCHAR(20)
            );
        DECLARE @SortSelectSql NVARCHAR(MAX) = 'select '
                                               + (   SELECT   'a' + NumValue
                                                              + '.NumValue + '','' + '
                                                     FROM     #Num
                                                     WHERE    NumValue < @WDCount
                                                     ORDER BY NumValue ASC
                                                     FOR XML PATH(''));
        SET @SortSelectSql = LEFT(@SortSelectSql, LEN(@SortSelectSql) - 7)
                             + ' SortValue ';
        --SELECT *
        --FROM   #Num;
        DECLARE @SortInnerSql NVARCHAR(MAX) = 'from #Num a1' + CHAR(10)
                                              + (   SELECT   'inner join (select * from #Num) a'
                                                             + CAST(CAST(NumValue AS INT)
                                                                    + 1 AS NVARCHAR(3))
                                                             + ' on a'
                                                             + CAST(CAST(NumValue AS INT)
                                                                    + 1 AS NVARCHAR(3))
                                                             + '.ID<a'
                                                             + NumValue + '.ID'
                                                             + CHAR(10)
                                                    FROM     #Num
                                                    WHERE    NumValue < @WDCount
                                                                        - 1
                                                    ORDER BY NumValue ASC
                                                    FOR XML PATH(''));
        DECLARE @SortSql NVARCHAR(MAX) = @SortSelectSql + @SortInnerSql;
        SET @SortSql = REPLACE(REPLACE(@SortSql, '&gt;', '>'), '&lt;', '<');
        INSERT INTO #SortTb ( SortValue )
        EXEC ( @SortSql );
        --SELECT *
        --FROM   #SortTb;
        PRINT @SortSql;
        ----------------------------------------------最终循环的表------------------------------------------------------

        CREATE TABLE #SortResult
            (
                Id INT IDENTITY(1, 1) NOT NULL ,
                OldId INT ,
                Value NVARCHAR(10)
            );
        DECLARE @CountNew INT = 1;
        DECLARE @Sum INT = (   SELECT COUNT(*)
                               FROM   #SortTb );
        WHILE ( @CountNew <= @Sum )
            BEGIN
                DECLARE @OldValue NVARCHAR(20) = (   SELECT SortValue
                                                     FROM   #SortTb
                                                     WHERE  ID = @CountNew );
                INSERT INTO #SortResult ( OldId ,
                                          Value )
                            SELECT @CountNew ,
                                   string
                            FROM   dbo.f_splitSTR(@OldValue, ',');
                SET @CountNew += 1;
            END;
        --SELECT *
        --FROM   #SortResult;
        ---------------------------------------------拆分维度区间---------------------------------------------------
        DECLARE @QJZdAddsql NVARCHAR(MAX) = '';
        DECLARE @QJZdupdatesql NVARCHAR(MAX) = '';
        SET @QJZdAddsql += (   SELECT   ' if not exists(select * from syscolumns where id=object_id(''NewShowTableID_'
                                        + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                                        + CAST(@BC AS NVARCHAR(2)) + 'B_'
                                        + @SpType + '_' + @YValue
                                        + ''') and name=''W' + NumValue
                                        + 'downValue'') begin ALTER TABLE NewShowTableID_'
                                        + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                                        + CAST(@BC AS NVARCHAR(2)) + 'B_'
                                        + @SpType + '_' + @YValue + ' ADD W'
                                        + NumValue + 'downValue FLOAT; end '
                                        + CHAR(10)
                                        + ' if not exists(select * from syscolumns where id=object_id(''NewShowTableID_'
                                        + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                                        + CAST(@BC AS NVARCHAR(2)) + 'B_'
                                        + @SpType + '_' + @YValue
                                        + ''') and name=''W' + NumValue
                                        + 'upValue'') begin ALTER TABLE NewShowTableID_'
                                        + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                                        + CAST(@BC AS NVARCHAR(2)) + 'B_'
                                        + @SpType + '_' + @YValue + ' ADD W'
                                        + NumValue + 'upValue FLOAT; end'
                                        + CHAR(10)
                               FROM     #Num
                               ORDER BY NumValue ASC
                               FOR XML PATH(''));
        SET @QJZdupdatesql += (   SELECT   'UPDATE NewShowTableID_'
                                           + CAST(@WDCount AS NVARCHAR(2))
                                           + 'W_' + CAST(@BC AS NVARCHAR(2))
                                           + 'B_' + @SpType + '_' + @YValue
                                           + ' SET W' + NumValue
                                           + 'downValue = SUBSTRING(维度'
                                           + NumValue
                                           + '分区区间, 2, CHARINDEX(''-'', 维度'
                                           + NumValue + '分区区间,3) - 2) ,  W'
                                           + NumValue
                                           + 'upValue = SUBSTRING(维度'
                                           + NumValue
                                           + '分区区间 , CHARINDEX(''-'', 维度'
                                           + NumValue + '分区区间,3) + 1,LEN(维度'
                                           + NumValue
                                           + '分区区间) - CHARINDEX(''-'', 维度'
                                           + NumValue + '分区区间,3) - 1) where (w'
                                           + NumValue + 'downValue='''' or w'
                                           + NumValue
                                           + 'downValue is NULL) and (w'
                                           + NumValue + 'upValue='''' or w'
                                           + NumValue + 'upValue is NULL)'
                                           + CHAR(10)
                                  FROM     #Num
                                  ORDER BY NumValue ASC
                                  FOR XML PATH(''));
        --SELECT * FROM NewShowTableID_3W_3B_SinCapsule_SinCapsuleOutPut
        PRINT @QJZdAddsql;
        PRINT @QJZdupdatesql;
        EXEC ( @QJZdAddsql );
        EXEC ( @QJZdupdatesql );


        ---------------------获取表的查询字段列表-----------------------------------------------------------
        DECLARE @CoNameStr NVARCHAR(MAX) = '';
        DECLARE @OutVarCoNameStr NVARCHAR(MAX) = '';
        DECLARE @sqlCoNameStr NVARCHAR(MAX) = 'set @CoNameStr=(   SELECT CoName + '',''
                                       FROM   dbo.Tbl_AnsCom_DIimToTable
                                       WHERE  (   SpType LIKE ''%' + @SpType
                                              + '%'' OR SpType LIKE ''%'
                                              + @SubTable
                                              + '%'' ) AND IsRange = 1
                                       FOR XML PATH(''''))' + CHAR(10)
                                              + '
									   SET @CoNameStr = LEFT(@CoNameStr, LEN(@CoNameStr) - 1)';
        EXEC sp_executesql @sqlCoNameStr ,
                           N'@CoNameStr NVARCHAR(MAX) output' ,
                           @OutVarCoNameStr OUTPUT;
        SET @CoNameStr = @OutVarCoNameStr;
        PRINT '字段列表:' + @CoNameStr;

        ---------------------获取表的字段数量-------------------------------------------------------------------
        DECLARE @OutVarCount INT = 0;
        DECLARE @Count INT = 0;
        DECLARE @sqlCount NVARCHAR(MAX) = ' set @a=( SELECT COUNT(*)
                        FROM   dbo.Tbl_AnsCom_DIimToTable
                         WHERE  (   SpType LIKE ''%' + @SpType
                                          + '%''  OR SpType LIKE ''%'
                                          + @SubTable
                                          + '%'' )
                               AND IsRange = 1)';
        EXEC sp_executesql @sqlCount ,
                           N'@a int output' ,
                           @OutVarCount OUTPUT;
        SET @Count = @OutVarCount;
        PRINT '字段数量：' + CAST(@Count AS NVARCHAR(2));
        ----------------------------------------------输出一个表-------------------------------------------------------
        DECLARE @Table TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL ,
                CoName NVARCHAR(30)
            );
        DECLARE @sqlTable NVARCHAR(MAX) = ' 
            SELECT   CoName  
            FROM   dbo.Tbl_AnsCom_DIimToTable
           WHERE  (   SpType LIKE ''%' + @SpType + '%''  OR SpType LIKE ''%'
                                          + @SubTable
                                          + '%'' )
                   AND IsRange = 1';
        INSERT INTO @Table
        EXEC ( @sqlTable );


        -------------------------------------------------建立表------------------------------------------------------------
        DECLARE @Result NVARCHAR(MAX) = '';
        SET @Result += (   SELECT ' CREATE TABLE #Temp
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL ,
              CoNameID INT ,
              CoName NVARCHAR(50) ,
              ZdValue FLOAT
            );
			insert INTO #Temp SELECT ID,CoName,NUll 
								FROM   dbo.Tbl_AnsCom_DIimToTable
								WHERE  (   SpType LIKE ''%' + @SpType
                                  + '%'' OR SpType LIKE ''%' + @SubTable
                                  + '%'' ) AND IsRange = 1' + CHAR(10)
                                  + ' SELECT ' + @CoNameStr
                                  + ' into #tempBaseTable from ' + CHAR(10)
                                  + JoinTables + ' WHERE  ' + @SpType
                                  + '.ID = ' + CAST(@DataID AS NVARCHAR(5))
                                  + ''
                           FROM   dbo.Tbl_AnsCom_AnaSpConfig
                           WHERE  SpName = @SpType );


        -----------------------------------------------------开始循环更新字段的值----------------------------------------------------
        DECLARE @DataUpdateStr NVARCHAR(MAX) = '';
        DECLARE @Counti INT = 1;
        --SELECT *
        --FROM   @Table;
        WHILE ( @Counti <= @Count )
            BEGIN
                SET @DataUpdateStr += (   SELECT '  UPDATE  #Temp
        SET ZdValue = ( SELECT ' +            CoName
                                                 + ' FROM #tempBaseTable )
        WHERE ID = ''' +                      CAST(@Counti AS NVARCHAR(3))
                                                 + '''' + CHAR(10)
                                          FROM   @Table
                                          WHERE  ID = @Counti );
                SET @Counti += 1;
            END;
        SET @Result += @DataUpdateStr;
        SET @Result += ' select * from #Temp ';
        --PRINT @Result;
        --------------------------------------------------------基础数据源-----------------------------------------------------------------
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @LeftStr NVARCHAR(MAX) = '('
                                         + (   SELECT   ' 维度' + NumValue
                                                        + '编号 = ' + @LeftTarget
                                                        + ' or'
                                               FROM     #Num
                                               ORDER BY NumValue ASC
                                               FOR XML PATH(''));
        SET @LeftStr = LEFT(@LeftStr, LEN(@LeftStr) - 2) + ')';
        DECLARE @RightStr NVARCHAR(MAX) = '('
                                          + (   SELECT   ' 维度' + NumValue
                                                         + '编号 not in ('
                                                         + @RightTarget
                                                         + ') or'
                                                FROM     #Num
                                                ORDER BY NumValue ASC
                                                FOR XML PATH(''));
        SET @RightStr = LEFT(@RightStr, LEN(@RightStr) - 2) + ')';
        DECLARE @InnerStr NVARCHAR(MAX) = '';
        DECLARE @sqlSuper NVARCHAR(MAX) = '';
        SET @sql = ' select * from (SELECT * FROM NewShowTableID_'
                   + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                   + CAST(@BC AS NVARCHAR(2)) + 'B_' + @SpType + '_'
                   + @YValue + ' WHERE ' + @LeftStr + 'and ' + @RightStr
                   + ') TB' + CHAR(10);
        SET @InnerStr += (   SELECT   @sql
                                      + (   SELECT   'inner join #Temp W' + Value
                                                     + ' on 维度' + Value + '编号=W'
                                                     + Value + '.CoNameID and W'
                                                     + Value + '.ZdValue>W'
                                                     + Value + 'downValue and W'
                                                     + Value + '.ZdValue<=W'
                                                     + Value + 'upValue and W'
                                                     + Value + '.CoNameID<>'
                                                     + @LeftTarget + ''
                                                     + CHAR(10)
                                            FROM     #SortResult
                                            WHERE    OldId = NumValue
                                            ORDER BY OldId ASC
                                            FOR XML PATH('')) + ' union all '
                             FROM     #Num
                             ORDER BY NumValue ASC
                             FOR XML PATH(''));
        SET @InnerStr = REPLACE(
                            REPLACE(
                                REPLACE(@InnerStr, '&amp;', '&'), '&lt;', '<') ,
                            '&gt;' ,
                            '>');
        SET @InnerStr = LEFT(@InnerStr, LEN(@InnerStr) - 11);
        PRINT @InnerStr;
        SET @Result += @InnerStr;
        DROP TABLE #Num;
        EXEC ( @Result );
    END;
go

