-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
-- EXEC dbo.MergeDimension  -- nvarchar(max)

CREATE PROCEDURE [dbo].[MergeDimension]
AS
    BEGIN
        DECLARE @Item INT = 1;
        WHILE ( @Item <= ( SELECT   MAX(ID)
                           FROM     dbo.ShowTable_4_1
                         ) )
            BEGIN
              
                IF ( ( SELECT   COUNT(*)
                       FROM     dbo.ShowTable_4_1
                       WHERE    ID = @Item
                     ) > 0 )
                    BEGIN
                        INSERT  INTO dbo.RecordTable
                                ( ID )
                        VALUES  ( @Item  -- ID - int
                                  );
                        DECLARE @GroupItem INT = 1;
                        WHILE ( @GroupItem <= ( SELECT  COUNT(GroupID)
                                                FROM    dbo.ShowTable_4_1
                                                WHERE   ID = @Item
                                              ) )
                            BEGIN
                                PRINT 'ID为' + CAST(@Item AS NVARCHAR(5))
                                    + '开始对比';
                                
                                DECLARE @j INT = 2;
                                WHILE ( @j <= ( SELECT  COUNT(GroupID)
                                                FROM    dbo.ShowTable_4_1
                                                WHERE   ID = @Item
                                              ) )
                                    BEGIN
                                        SELECT  *
                                        INTO    #TempTable
                                        FROM    dbo.ShowTable_4_1
                                        WHERE   ( GroupID = @GroupItem
                                                  OR GroupID = @j
                                                )
                                                AND ShowTable_4_1.ID = @Item
                                                AND floatValue <> 0;
                                        IF ( ( SELECT   COUNT(*)
                                               FROM     ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                          FROM
                                                              dbo.ShowTable_4_1
                                                          WHERE
                                                              GroupID = @GroupItem
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                        ) It
                                                        INNER JOIN ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @j
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                              ) Jt ON Jt.维度1分区区段 = It.维度1分区区段
                                                              AND Jt.维度2分区区段 = It.维度2分区区段
                                                              AND Jt.维度3分区区段 = It.维度3分区区段
                                                              AND ( ABS(( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度4分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度4分区区段,
                                                              ',')
                                                              )) = 1
                                                              OR ABS(( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度4分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度4分区区段,
                                                              ',')
                                                              )) = 1
                                                              )
                                             ) > 0
                                             OR ( SELECT    COUNT(*)
                                                  FROM      ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @GroupItem
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                            ) It
                                                            INNER JOIN ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @j
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                              ) Jt ON Jt.维度1分区区段 = It.维度1分区区段
                                                              AND Jt.维度2分区区段 = It.维度2分区区段
                                                              AND Jt.维度4分区区段 = It.维度4分区区段
                                                              AND ( ABS(( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度3分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度3分区区段,
                                                              ',')
                                                              )) = 1
                                                              OR ABS(( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度3分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度3分区区段,
                                                              ',')
                                                              )) = 1
                                                              )
                                                ) > 0
                                             OR ( SELECT    COUNT(*)
                                                  FROM      ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @GroupItem
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                            ) It
                                                            INNER JOIN ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @j
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                              ) Jt ON Jt.维度1分区区段 = It.维度1分区区段
                                                              AND Jt.维度4分区区段 = It.维度4分区区段
                                                              AND Jt.维度3分区区段 = It.维度3分区区段
                                                              AND ( ABS(( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度2分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度2分区区段,
                                                              ',')
                                                              )) = 1
                                                              OR ABS(( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度2分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度2分区区段,
                                                              ',')
                                                              )) = 1
                                                              )
                                                ) > 0
                                             OR ( SELECT    COUNT(*)
                                                  FROM      ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @GroupItem
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                            ) It
                                                            INNER JOIN ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              GroupID = @j
                                                              AND ShowTable_4_1.ID = @Item
                                                              AND floatValue <> 0
                                                              ) Jt ON Jt.维度4分区区段 = It.维度4分区区段
                                                              AND Jt.维度2分区区段 = It.维度2分区区段
                                                              AND Jt.维度3分区区段 = It.维度3分区区段
                                                              AND ( ABS(( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度1分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度1分区区段,
                                                              ',')
                                                              )) = 1
                                                              OR ABS(( SELECT
                                                              CAST(MAX(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(Jt.维度1分区区段,
                                                              ',')
                                                              )
                                                              - ( SELECT
                                                              CAST(MIN(string) AS INT)
                                                              FROM
                                                              dbo.f_splitSTR(It.维度1分区区段,
                                                              ',')
                                                              )) = 1
                                                              )
                                                ) > 0
                                           )
                                            BEGIN
                                                PRINT CAST(@GroupItem AS NVARCHAR(5))
                                                    + ' : '
                                                    + CAST(@j AS NVARCHAR(5))
                                                    + '可以合并';
                                                DECLARE @GroupQJID NVARCHAR(5)= '';
                                                DECLARE @UpDateStr NVARCHAR(500)= '';
                                                SET @GroupQJID = ( SELECT
                                                              ( CASE
                                                              WHEN a.维度1分区区段 = b.维度1分区区段
                                                              THEN ''
                                                              ELSE a.维度1分区区段
                                                              + ','
                                                              + b.维度1分区区段
                                                              END )
                                                              + ( CASE
                                                              WHEN a.维度2分区区段 = b.维度2分区区段
                                                              THEN ''
                                                              ELSE a.维度2分区区段
                                                              + ','
                                                              + b.维度2分区区段
                                                              END )
                                                              + ( CASE
                                                              WHEN a.维度3分区区段 = b.维度3分区区段
                                                              THEN ''
                                                              ELSE a.维度3分区区段
                                                              + ','
                                                              + b.维度3分区区段
                                                              END )
                                                              + ( CASE
                                                              WHEN a.维度4分区区段 = b.维度4分区区段
                                                              THEN ''
                                                              ELSE a.维度4分区区段
                                                              + ','
                                                              + b.维度4分区区段
                                                              END )
                                                              FROM
                                                              ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段 ,
                                                              ID
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              ID = @Item
                                                              AND GroupID = @GroupItem
                                                              ) a
                                                              LEFT  JOIN ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段 ,
                                                              ID
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              ID = @Item
                                                              AND GroupID = @j
                                                              ) b ON b.ID = a.ID
                                                              );
                                                --更新维度区段的值,其值为合并的合   
                                                SET @UpDateStr = ( SELECT
                                                              ( CASE
                                                              WHEN a.维度1分区区段 = b.维度1分区区段
                                                              THEN ''
                                                              ELSE 'UpDate ShowTable_4_1 set 维度1分区区段='''
                                                              + @GroupQJID
                                                              + ''' where ID = '
                                                              + CAST(@Item AS NVARCHAR(5))
                                                              + ' AND GroupID ='
                                                              + CAST(@GroupItem AS NVARCHAR(5))
                                                              + ''
                                                              END )
                                                              + ( CASE
                                                              WHEN a.维度2分区区段 = b.维度2分区区段
                                                              THEN ''
                                                              ELSE 'UpDate ShowTable_4_1 set 维度2分区区段='''
                                                              + @GroupQJID
                                                              + ''' where ID = '
                                                              + CAST(@Item AS NVARCHAR(5))
                                                              + ' AND GroupID ='
                                                              + CAST(@GroupItem AS NVARCHAR(5))
                                                              + ''
                                                              END )
                                                              + ( CASE
                                                              WHEN a.维度3分区区段 = b.维度3分区区段
                                                              THEN ''
                                                              ELSE 'UpDate ShowTable_4_1 set 维度3分区区段='''
                                                              + @GroupQJID
                                                              + ''' where ID = '
                                                              + CAST(@Item AS NVARCHAR(5))
                                                              + ' AND GroupID ='
                                                              + CAST(@GroupItem AS NVARCHAR(5))
                                                              + ''
                                                              END )
                                                              + ( CASE
                                                              WHEN a.维度4分区区段 = b.维度4分区区段
                                                              THEN ''
                                                              ELSE 'UpDate ShowTable_4_1 set 维度4分区区段='''
                                                              + @GroupQJID
                                                              + ''' where ID = '
                                                              + CAST(@Item AS NVARCHAR(5))
                                                              + ' AND GroupID ='
                                                              + CAST(@GroupItem AS NVARCHAR(5))
                                                              + ''
                                                              END )
                                                              FROM
                                                              ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段 ,
                                                              ID
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              ID = @Item
                                                              AND GroupID = @GroupItem
                                                              ) a
                                                              LEFT  JOIN ( SELECT
                                                              维度1分区区段 ,
                                                              维度2分区区段 ,
                                                              维度3分区区段 ,
                                                              维度4分区区段 ,
                                                              ID
                                                              FROM
                                                              dbo.ShowTable_4_1
                                                              WHERE
                                                              ID = @Item
                                                              AND GroupID = @j
                                                              ) b ON b.ID = a.ID
                                                              );
                                                     --执行合并，先插入合并结果，再删除源数据
                                                     --更新相应字段
                                                DECLARE @UpdatefloatValue DECIMAL(18,
                                                              4);
                                                DECLARE @UpdateGoodValue DECIMAL(18,
                                                              4);
                                                DECLARE @UpdatePercentON NVARCHAR(10);
                                                DECLARE @UpdateDataCount DECIMAL(18,
                                                              4);
                                                              
                                                DECLARE @UpdateQJDiffValue1 DECIMAL(18,
                                                              4)= ( SELECT
                                                              MAX(维度1区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                DECLARE @UpdateQJDiffValue2 DECIMAL(18,
                                                              4)= ( SELECT
                                                              MAX(维度2区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                DECLARE @UpdateQJDiffValue3 DECIMAL(18,
                                                              4)= ( SELECT
                                                              MAX(维度3区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                DECLARE @UpdateQJDiffValue4 DECIMAL(18,
                                                              4)= ( SELECT
                                                              MAX(维度4区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                DECLARE @UpdateQJValue1 NVARCHAR(50)= ( SELECT TOP 1
                                                              维度1分区区间
                                                              FROM
                                                              #TempTable
                                                              );   
                                                DECLARE @UpdateQJValue2 NVARCHAR(50)= ( SELECT TOP 1
                                                              维度2分区区间
                                                              FROM
                                                              #TempTable
                                                              );     
                                                DECLARE @UpdateQJValue3 NVARCHAR(50)= ( SELECT TOP 1
                                                              维度3分区区间
                                                              FROM
                                                              #TempTable
                                                              );  
                                                DECLARE @UpdateQJValue4 NVARCHAR(50)= ( SELECT TOP 1
                                                              维度4分区区间
                                                              FROM
                                                              #TempTable
                                                              );  
                                                              
                                                              
                                                SET @UpdateGoodValue = ( SELECT
                                                              SUM(GoodValue)
                                                              FROM
                                                              #TempTable
                                                              );      
                                                SET @UpdatefloatValue = ( SELECT
                                                              ROUND(CAST(SUM(GoodValue) AS FLOAT)
                                                              / SUM(DataCount),
                                                              4) * 100
                                                              FROM
                                                              #TempTable
                                                              );
                                                SET @UpdatePercentON = ( SELECT
                                                              CAST(ROUND(CAST(SUM(GoodValue) AS FLOAT)
                                                              / SUM(DataCount),
                                                              4) * 100 AS NVARCHAR(10))
                                                              + '%'
                                                              FROM
                                                              #TempTable
                                                              );     
                                                SET @UpdateDataCount = ( SELECT
                                                              SUM(DataCount)
                                                              FROM
                                                              #TempTable
                                                              );
                                                IF ( ( SELECT SUM(维度1区间差值) / 2
                                                       FROM   #TempTable
                                                     ) <> ( SELECT
                                                              MAX(维度1区间差值)
                                                            FROM
                                                              #TempTable
                                                          ) )
                                                    BEGIN
                                                        SET @UpdateQJDiffValue1 = ( SELECT
                                                              SUM(维度1区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                              
                                                        DECLARE @TempStrValue1 NVARCHAR(50)= ( SELECT
                                                              ',' + 维度1分区区间
                                                              FROM
                                                              #TempTable
                                                              FOR
                                                              XML
                                                              PATH('')
                                                              );
                                                        SET @TempStrValue1 = REPLACE(REPLACE(REPLACE(@TempStrValue1,
                                                              '-', ','), ']',
                                                              ''), '[', '');
                                                              

                                                        SET @UpdateQJValue1 = ( SELECT
                                                              '['
                                                              + CAST(MIN(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + '-'
                                                              + CAST(MAX(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + ']'
                                                              FROM
                                                              dbo.f_splitSTR(@TempStrValue1,
                                                              ',')
                                                              WHERE
                                                              string <> ''
                                                              );
                                                              
                                                    END;
                                                IF ( ( SELECT SUM(维度2区间差值) / 2
                                                       FROM   #TempTable
                                                     ) <> ( SELECT
                                                              MAX(维度2区间差值)
                                                            FROM
                                                              #TempTable
                                                          ) )
                                                    BEGIN
                                                          
                                                        SET @UpdateQJDiffValue2 = ( SELECT
                                                              SUM(维度2区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                        DECLARE @TempStrValue2 NVARCHAR(50)= ( SELECT
                                                              ',' + 维度2分区区间
                                                              FROM
                                                              #TempTable
                                                              FOR
                                                              XML
                                                              PATH('')
                                                              );
                                                        SET @TempStrValue2 = REPLACE(REPLACE(REPLACE(@TempStrValue2,
                                                              '-', ','), ']',
                                                              ''), '[', '');
                                                              

                                                        SET @UpdateQJValue2 = ( SELECT
                                                              '['
                                                              + CAST(MIN(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + '-'
                                                              + CAST(MAX(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + ']'
                                                              FROM
                                                              dbo.f_splitSTR(@TempStrValue2,
                                                              ',')
                                                              WHERE
                                                              string <> ''
                                                              );
                                                              
                                                    END;
                                                              
                                                IF ( ( SELECT SUM(维度3区间差值) / 2
                                                       FROM   #TempTable
                                                     ) <> ( SELECT
                                                              MAX(维度3区间差值)
                                                            FROM
                                                              #TempTable
                                                          ) )
                                                    BEGIN
                                                        SET @UpdateQJDiffValue3 = ( SELECT
                                                              SUM(维度3区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                        DECLARE @TempStrValue3 NVARCHAR(50)= ( SELECT
                                                              ',' + 维度3分区区间
                                                              FROM
                                                              #TempTable
                                                              FOR
                                                              XML
                                                              PATH('')
                                                              );
                                                        SET @TempStrValue3 = REPLACE(REPLACE(REPLACE(@TempStrValue3,
                                                              '-', ','), ']',
                                                              ''), '[', '');
                                                              

                                                        SET @UpdateQJValue3 = ( SELECT
                                                              '['
                                                              + CAST(MIN(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + '-'
                                                              + CAST(MAX(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + ']'
                                                              FROM
                                                              dbo.f_splitSTR(@TempStrValue3,
                                                              ',')
                                                              WHERE
                                                              string <> ''
                                                              );
                                                    END;
                                                IF ( ( SELECT SUM(维度4区间差值) / 2
                                                       FROM   #TempTable
                                                     ) <> ( SELECT
                                                              MAX(维度4区间差值)
                                                            FROM
                                                              #TempTable
                                                          ) )
                                                    BEGIN
                                                        SET @UpdateQJDiffValue4 = ( SELECT
                                                              SUM(维度4区间差值)
                                                              FROM
                                                              #TempTable
                                                              );
                                                        DECLARE @TempStrValue4 NVARCHAR(50)= ( SELECT
                                                              ',' + 维度4分区区间
                                                              FROM
                                                              #TempTable
                                                              FOR
                                                              XML
                                                              PATH('')
                                                              );
                                                        SET @TempStrValue4 = REPLACE(REPLACE(REPLACE(@TempStrValue4,
                                                              '-', ','), ']',
                                                              ''), '[', '');
                                                              

                                                        SET @UpdateQJValue4 = ( SELECT
                                                              '['
                                                              + CAST(MIN(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + '-'
                                                              + CAST(MAX(CAST(string AS DECIMAL(18,
                                                              4))) AS NVARCHAR(10))
                                                              + ']'
                                                              FROM
                                                              dbo.f_splitSTR(@TempStrValue4,
                                                              ',')
                                                              WHERE
                                                              string <> ''
                                                              );
                                                    END;
                                                EXEC(@UpDateStr);
                                                
                                                --更新相应的字段值如floatValue,PercentOn等等
                                                UPDATE  dbo.ShowTable_4_1
                                                SET     GoodValue = @UpdateGoodValue ,
                                                        floatValue = @UpdatefloatValue ,
                                                        PercentON = @UpdatePercentON ,
                                                        DataCount = @UpdateDataCount ,
                                                        维度1区间差值 = @UpdateQJDiffValue1 ,
                                                        维度2区间差值 = @UpdateQJDiffValue2 ,
                                                        维度3区间差值 = @UpdateQJDiffValue3 ,
                                                        维度4区间差值 = @UpdateQJDiffValue4 ,
                                                        维度1分区区间 = @UpdateQJValue1 ,
                                                        维度2分区区间 = @UpdateQJValue2 ,
                                                        维度3分区区间 = @UpdateQJValue3 ,
                                                        维度4分区区间 = @UpdateQJValue4
                                                WHERE   ID = @Item
                                                        AND GroupID = @GroupItem;
                                                DELETE  FROM dbo.ShowTable_4_1
                                                WHERE   ID = @Item
                                                        AND GroupID = @j;
                                            END;
                                        SET @j += 1;
                                        DROP TABLE #TempTable; 
                                       
                                    END;
                                SET @GroupItem += 1;
                                SET @j = @GroupItem + 1;
                            END;
                    END;
                SET @Item += 1;
            END;
    END;
go

