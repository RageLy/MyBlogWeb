      
-- =============================================                               
-- Description: 保存我的常用菜单             
-- =============================================                
CREATE PROCEDURE [dbo].[Sp_Sys_EditMyMenu]                
@MyMenuID varchar(500)=''     --主键ID          
,@MenuTitle varchar(500)=''   --名称         
,@EmpID varchar(500)=''   --EmpID    
as                 
Begin                 
set nocount on                
         
 --判断编辑的颜色编码是否和其它重复                                           
 if exists(select * from tbl_sys_myMenu where MenuTitle=@MenuTitle AND EmpID = @EmpID AND MyMenuId<>@MyMenuID )          
 begin                
  select '常用菜单名称不能重复！'              
 end               
        
 --没有重复 则编辑该字段数据      
 else                
 begin                
  update tbl_sys_myMenu set MenuTitle=@MenuTitle where                 
  MyMenuId=@MyMenuID      
  -- 成功返回0       
    select '0'                
 end                
end
go

