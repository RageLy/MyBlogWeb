
Create View VW_DimActTime_part
AS
 SELECT -1 AS Id , '全部集合:[' + CAST((1 + b.CutInt) * b.NumDecimal AS VARCHAR(50)) +'-' + CAST((b.BaseCount + b.CutInt) * b.NumDecimal AS VARCHAR(50))+')' AS Name
,'1' AS istrue ,'属性集合' 选项集合类型
,NULL AS Id2 ,NULL AS [倍数2]
,(1 + b.CutInt) * b.NumDecimal  AS Beginvalue
,(b.BaseCount + b.CutInt) * b.NumDecimal AS Endvalue
FROM Tbl_AnsCom_DIimToTable AS b 
WHERE DimNum='DimActTime'
UNION ALL
SELECT 0 -(a.id * 2) - (b.BaseCount) * (1 - 1)  AS Id 
, '倍数2:[' + CAST((1 + b.CutInt +((a.id-1) * 2)) * b.NumDecimal AS VARCHAR(50)) +'-' + CAST((1 + b.CutInt +(a.id * 
2)) * b.NumDecimal AS VARCHAR(50))+')' AS Name
,'2' AS istrue ,'倍数2' 选项集合类型

,0 -(a.id * 2) - (b.BaseCount) * (1 - 1) AS Id2
,'倍数2:[' + CAST((1 + b.CutInt +((a.id-1) * 2)) * b.NumDecimal AS VARCHAR(50)) +'-' + CAST((1 + b.CutInt +(a.id * 
2)) * b.NumDecimal AS VARCHAR(50))+')' AS [倍数2]

,(1 + b.CutInt +((a.id-1) * 2)) * b.NumDecimal  AS Beginvalue
,(1 + b.CutInt +((a.id) * 2)) * b.NumDecimal AS Endvalue
FROM tbl_base_num AS a
LEFT JOIN Tbl_AnsCom_DIimToTable AS b ON a.id * 2 <= b.BaseCount
WHERE DimNum='DimActTime'
UNION ALL
select a.ID
,':['+cast((b.CutInt +a.id) * b.NumDecimal as varchar(20))+'-'+cast((b.CutInt +a.id+1) * b.NumDecimal as varchar(20))+')' as Name
,'0'  as istrue ,'基础选项' as 选项集合类型
,0-((a.id-1)/2 * 2) - (b.BaseCount) * (1 - 1) -2 AS Id2 ,'倍数2:[' + CAST((1+ b.CutInt +((a.id-2+1)/2 * 2)) * b.NumDecimal AS VARCHAR(50)) +'-' + CAST((1 + b.CutInt +((a.id-1+2)/2 * 2)) * b.NumDecimal AS VARCHAR(50)) +')'AS [倍数2]
,(b.CutInt +a.id) * b.NumDecimal  as Beginvalue
,(b.CutInt +a.id+1) * b.NumDecimal as Endvalue
from tbl_base_num as a
left join Tbl_AnsCom_DIimToTable as b on a.id < b.BaseCount
WHERE DimNum='DimActTime'

------------------------------------------
go

