  
/****** Script for SelectTopNRows command from SSMS  ******/  
-- =============================================  
-- Author:  余文杰  
-- Create date: 2011-09  
-- Description: 处理配套件维度的查询器 L3 LOAD  
-- =============================================  
/****** Script for SelectTopNRows command from SSMS  ******/  
-- =============================================  
-- Author:  余文杰  
-- Create date: 2013-05-21  
-- Description: 时间纬度 L3 LOAD  
-- =============================================     
   
  CREATE proc [dbo].[sp_Dim_7_Level_3_web]   
    @AppliedFilters       varchar(8000) = '',  
    @DayCount int=30,  
    @WeekCount int=20,  
    @MonthCount int=20,  
    @QuarterCount int=12,  
    @YearCount int =5,  
    @WeekEnd int=7  
as  
    set @AppliedFilters = replace(replace(@AppliedFilters,'filter:',''),':endfilter','')  
 --[sp_Dim_7_Level_3_web] '年^日历年'  
 declare @sqlcol     varchar(8000)  
 declare @sqltype    varchar(8000)  
    declare @sql        varchar(8000)  
 declare @CharID     int  
 declare @CharName   varchar(50)  
 declare @sqlfname        varchar(8000)  
 declare @sqlfvalue        varchar(8000)  
 declare @sqlfilterVal        varchar(8000)  
 declare @sqltemp varchar(8000)  
 set @sqltemp=@AppliedFilters  
 create table #tmpPart ([FName] [varchar](50) NOT NULL,[FValue] [varchar](500) NOT NULL)  
 while @AppliedFilters<>''  
  begin  
   if charindex('|',@AppliedFilters)>0  
   begin  
    set @sqlfilterVal = substring(@AppliedFilters,1,charindex('|',@AppliedFilters)-1)  
    set @AppliedFilters=substring(@AppliedFilters,charindex('|',@AppliedFilters)+1,LEN(@AppliedFilters)-charindex('|',@AppliedFilters))  
   end  
   else  
   begin  
    set @sqlfilterVal = @AppliedFilters  
    set @AppliedFilters=''  
   end    
     
   begin  
    set @sqlfname = substring(@sqlfilterVal,1,charindex('^',@sqlfilterVal)-1)  
    set @sqlfvalue = substring(@sqlfilterVal,charindex('^',@sqlfilterVal)+1,LEN(@sqlfilterVal)-charindex('^',@sqlfilterVal))  
    insert into #tmpPart   
    select @sqlfname, @sqlfvalue  
      
    --select @sqlfname, @sqlfvalue  
   end  
   --print @sqlfname + ' ' + @sqlfvalue + ' ' + @sqlfilterVal  
     end  
    
 create table #tmpTime([FName] [varchar](200) NOT NULL,[FValue] [varchar](500) NOT NULL  
  ,[FDate] [varchar](200) NOT NULL,[FDateType] [varchar](200) NOT NULL,[BeginDate] datetime not Null,[EndDate] datetime not null)   
 --从函数中取得完整的日期表  
 insert into #tmpTime   
  select [FName]  
  ,[FValue]  
  ,[FDate]  
  ,[FDateType]  
  ,[BeginDate]  
  ,[EndDate] from dbo.sp_Dim_GetDim7All()  
   
 if @sqltemp=''  
 select 'Id' [Id],'Name' [Name],'BeginDate' BeginDate,'EndDate' EndDate  
 union all  
 select 'int' [Id],'varchar(50)' [Name],'datetime' BeginDate,'datetime' EndDate  
 union all  
 select FName [Id],FValue [Name],cast(CONVERT(varchar(20), BeginDate, 20)  as varchar(50)),cast(CONVERT(varchar(20), EndDate, 20) as varchar(50)) from #tmpTime  
 else  
 Begin  
  declare @time varchar(200)  
  declare @timeType varchar(200)  
  set @sql='  
  select ''Id'' [Id],''Name'' [Name],''BeginDate'' BeginDate,''EndDate'' EndDate  
  union all  
  select ''int'' [Id],''varchar(50)'' [Name],''datetime'' BeginDate,''datetime'' EndDate  
  union all  
    
  select FName Id,FValue  Name,cast(CONVERT(varchar(20), BeginDate, 20)  as varchar(50)),cast(CONVERT(varchar(20), EndDate, 20) as varchar(50)) from #tmpTime  where '  
  declare cur cursor  
  for   
        select [FName],[FValue]  from #tmpPart  
  open cur   
  fetch next from cur into @time,@timeType  
  while @@FETCH_STATUS=0  
  Begin  
    set @sql= @sql+' FDate='''+@time+''' and FDateType='''+@timeType+''''  
    fetch next from cur into @time,@timeType  
    if @@FETCH_STATUS=0  
       set @sql=@sql+' or '  
  End  
  --print @sql  
  exec(@sql)     
    
  --select * from #t  
 End
go

