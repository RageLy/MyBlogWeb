-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-23>
-- Description:	<表格新增/编辑政治面貌>
-- =============================================
CREATE PROCEDURE [dbo].Sp_Com_PoliticalStatus_Save
	@PoliticalStatusName varchar(500)='' ,
	@PoliticalStatusID varchar(500)=''
AS
BEGIN
	SET NOCOUNT ON;
if(@PoliticalStatusName='' )
   begin
     select '职位名称不能为空！'
     return
   end 
	if(exists(select 1 from Tbl_Com_PoliticalStatus where PoliticalStatusName=@PoliticalStatusName and PoliticalStatusID<>@PoliticalStatusID))
    begin
        select '职位名称不能重复！'
        return
    end
   if(@PoliticalStatusID ='' ) ---新增
   begin

          -- 保存数据
          insert into Tbl_Com_PoliticalStatus (PoliticalStatusName)
          values(@PoliticalStatusName)
          select '0'

   end
   else             --------------------编辑
   begin

          -- 修改数据
          update Tbl_Com_PoliticalStatus set PoliticalStatusName=@PoliticalStatusName
          where PoliticalStatusID=@PoliticalStatusID
          select '0'

   end

END
go

