
CREATE View VW_DimDataTypeDataType_partAll
AS
SELECT  Id AS VWID ,Id ,Name
FROM    VW_DimDataTypeDataType_part
WHERE   istrue = 0
UNION ALL
SELECT -1,notall.Id,(SELECT Name FROM VW_DimDataTypeDataType_part WHERE istrue = 1 )  FROM
(SELECT  Id AS VWID ,Id ,Name
FROM    VW_DimDataTypeDataType_part
WHERE   istrue = 0) notall

------------------------------------------
go

