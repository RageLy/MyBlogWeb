






-- =============================================            
-- Author:  <hjl>            
-- Create date: <2014-8-18>            
-- Description: <基础配置 删除颜料釜>                
-- =============================================            
CREATE PROCEDURE [dbo].[Sp_Base_ModuleAssembly_ModuleDelete]
 @ID varchar(500)=''    --该表的主键ID 
AS
BEGIN
	SET NOCOUNT ON;
	DECLARE @count int = ''
	--判断颜料釜是否在颜料底表被使用
    set @count=(select COUNT(*) from Bs_ModuleAssembly
                WHERE ModuleID=@ID)
    
   if(@ID<>'' and @count=0)                 
    begin      
    DELETE FROM Tbl_Base_Module WHERE ID = @ID 
     INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (1, GETDATE(), 'FuDelete',
        'Fu','ID = '+@ID,'DELETE FROM Tbl_Base_Module WHERE [ID] ='+@ID)
    select '0'
    end
	else                 
    begin                   
        select '该编号已被引用,不能删除'   return;                 
    end
END
go

