/****** Script for SelectTopNRows command from SSMS  ******/
-- =============================================
-- Author:		余文杰
-- Create date: 2013-05-21
-- Description:	时间纬度 L2 LOAD
-- ============================================= 

CREATE proc [dbo].[sp_Dim_7_Level_2_web]
  @SelectField varchar(200)='天',
  @AppliedFilters varchar(4000)=null
as
Begin
	select 'Id' [Id],'Name' [Name]
	union all
	select 'int' [Id],'varchar(50)' [Name]
	union all
	
  select cast(TimeID as varchar(50)) [Id],TimeName [Name] from dbo.Tbl_Com_Dim7_TimeType
  where TypeId=(select CharID from dbo.Tbl_Dim7_Level
  where CharName=@SelectField)
End
go

