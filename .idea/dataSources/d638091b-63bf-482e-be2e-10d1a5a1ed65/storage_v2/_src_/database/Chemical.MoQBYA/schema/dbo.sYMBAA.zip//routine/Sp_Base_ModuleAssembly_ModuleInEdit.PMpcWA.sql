

-- =============================================            
-- Author:  <hjl>            
-- Create date: <2014-8-18>            
-- Description: <基础配置 粒子釜 新增编辑>                
-- =============================================            
CREATE PROCEDURE [dbo].[Sp_Base_ModuleAssembly_ModuleInEdit]         
 @ID varchar(500)=''    --该表的主键ID            
 ,@Name varchar(500)=''
 ,@IsBan varchar(500)=''  
    /*  编辑修改的字段      
            。。。后面添加        
            配置中的TextBoxColumn DropdownList      
            都会传入到此存储过程中 参数名为      
            @+列表中所对应的列名      
          */             
as             
Begin             

	set nocount on  ;          
	--判断新增修改字段是否为空        
	if(isnull(@Name,'')='')         
	begin            
	 select '批号不能为空！'           
	 return
	end


	--判断主键ID  有值则为编辑，反之则为新增       
	if(@ID <> '')
	begin
	 --判断项目名称是否重复
	 if exists(select 1 from Tbl_Base_Module where Code=@Name and ID <> @ID )            
	 begin
	  select '批号不能重复！'        
	  RETURN;
	 end
	
	 --修改该字段数据       
	 else
		 begin
		  update Tbl_Base_Module set Code=@Name where             
		  ID = @ID
		  select '0'
		  return
		 end
	end
	 
	 --  新增
	 
	  else            
		  begin
		   --判断项目名称是否重复      
		   if exists(select 1 from Tbl_Base_Module where Code=@Name)            
		   begin            
		   select '批号不能重复！'         
		   return         
		   end            
		   --不重复新增数据       
		   else            
		   begin            
			insert into Tbl_Base_Module (Code) values (@Name)            
		 select '0'            
		 return      
	  end        
	  end     
	          
end
go

