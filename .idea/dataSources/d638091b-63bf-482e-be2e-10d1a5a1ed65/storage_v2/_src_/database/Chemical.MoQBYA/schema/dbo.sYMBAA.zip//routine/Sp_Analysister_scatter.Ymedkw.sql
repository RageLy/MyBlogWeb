





-- =============================================                          
-- Author: hjl
-- Create Date: 2016年11月3日
-- Descript: 统一的散点图分析器
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_scatter]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-1%DimSinTemp25:-244|-246|-248|-250|-252|-254%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1',
    @OtherCond VARCHAR(MAX) = '%温度41%温度8%温度25%scatter%平均值', --'%时间%温度8%产值%line%数量'
    @Type VARCHAR(10) = '图',                                -- '图' or '列表' or '明细'
    @SpName VARCHAR(50) = 'SinCapsule',
    @OrderFields VARCHAR(50) = 'id',
    @EmpID INT = 1,
                                                            -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1',
    @PageSize VARCHAR(5) = '10',
    @XValue VARCHAR(50) = '',
    @DSValue VARCHAR(50) = ''
AS
BEGIN

    ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue = REPLACE(@condition, '|', ',');

    DECLARE @Usertitle VARCHAR(200) = ''; -- 标题            
    DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                
    --DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
    --DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                
    --DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式                  
	DECLARE @ErrorRecord NVARCHAR(MAX)='';
    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        String NVARCHAR(50)
    );

    INSERT INTO @OtherCondTbl
    SELECT string
    FROM dbo.f_splitSTR(@OtherCond, '%');

    SET @Usertitle =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 1
    );
    SET @XName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 2
    );
    SET @DSName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 3
    );
    SET @YName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 4
    );
    --SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
    --SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)

    -- 
    IF EXISTS
    (
        SELECT 1
        FROM Tbl_AnsCom_SelfY
        WHERE YName = @YName
              AND SpName = @SpName
              AND isPercent = 1
    )
    BEGIN
        SELECT '' AS Dimx;
        SELECT '比例计算型Y轴无法显示散点图！' AS title;
        RETURN;
    END;



    -- OtherCond解析完毕
    -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

    ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       

    -- 时间表 时间临时表必然需要
    CREATE TABLE #time
    (
        id VARCHAR(200),
        beginDate DATETIME,
        endDate DATETIME,
        beginDate_Lp DATETIME,
        endDate_Lp DATETIME,
        beginDate_Ly DATETIME,
        endDate_Ly DATETIME
    );

    -- 如果有其它需要用 #时间表的必须在这里添加

    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段                        
    DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500); -- 用于拼接@Sql中 指标计算方式的Sql语句            
    DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句

    -- 读取转化 Y轴步骤 主要设置 @InnerSelect 内部 select 提取字段部分 还有 外部 select 的算法 @CountType            
    SET @NumSql = ',' + @CountType + '([' + @YName + '])';

    -- 处理维度临时表
    CREATE TABLE #Dims
    (
        DimName VARCHAR(50),
        DimValues VARCHAR(MAX),
        ChName VARCHAR(50),
        Isneed VARCHAR(50),
        DimOrdersql VARCHAR(50),
        DimYsql VARCHAR(50),
        isrange VARCHAR(50)
    );

    EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue,
                                    @XName = @XName,
                                    @DsName = @DSName;

    -- 判断有非数字化的维度被放到 横轴或Y轴上面 则报错并返回
    IF EXISTS
    (
        SELECT 1
        FROM #Dims
        WHERE (
                  ChName = @XName
                  OR ChName = @YName
              )
              AND isrange = 0
    )
    BEGIN
        SELECT '' AS Dimx;
        SELECT '非数值类型的维度不能放在散点图横轴上！' AS title;
        RETURN;
    END;


    -- 拼接创建维度临时表的语句

    SET @sql += ISNULL(
                (
                    SELECT 'CREATE TABLE #' + DimName
                           +
                        -- 非范围维度类型3列
                        CASE
                            WHEN isrange
        =               0 THEN
                                '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                            -- 范围维度类型5列
                            WHEN isrange = 1 THEN
                                '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'
                        END
                    FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')
                ),
                ''
                      );

    DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
    -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析

    -- 用 Dims 临时表拼接需要解析的 维度字符串
    SET @NeedSiftvalue = ISNULL(
                         (
                             SELECT '%' + DimName + ':' + DimValues
                             FROM #Dims
                             WHERE Isneed <> 'ND'
                             FOR XML PATH('')
                         ),
                         ''
                               );

    -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
    SET @NeedSiftvalue = CASE
                             WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                 'Dim7:' + dbo.GetDimValue(@SiftValue, 'Dim7') + @NeedSiftvalue
                             ELSE
                                 SUBSTRING(@NeedSiftvalue, 2, LEN(@NeedSiftvalue))
                         END;

    -- 解析维度
    SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = '
                + CAST(@EmpID AS VARCHAR(50)) + ';';

    ---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        

    ------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             

    -- 结果集表
    CREATE TABLE #Result_B
    (
        id INT IDENTITY(1, 1),
        DsName VARCHAR(500),
        value VARCHAR(500)
    );

    DECLARE @Dims VARCHAR(50);

    DECLARE @TimeName VARCHAR(50); -- 用于判断时间的标志

	if((SELECT COUNT(*) FROM #Dims GROUP BY ChName HAVING COUNT(ChName)>1)>0)
		 BEGIN
		  SET @ErrorRecord += 'X轴当前选择的维度中文名称重复，请检查；';

	INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Scatter' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		
		RETURN;
         END
    --set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig  WHERE SpName = @SpName)
    IF (@XName = '无横轴')
        SET @TimeName =
    (
        SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE @SpName = SpName
    )   ;
    ELSE
        SET @TimeName =
    (
        SELECT MainTable + '.OptDate'
        FROM dbo.Tbl_AnsCom_DIimToTable
        WHERE DimNum =
        (
            SELECT DimName FROM #Dims WHERE ChName = @XName
        )
    )   ;


    IF (@TimeName = '' OR @TimeName IS NULL)
    BEGIN
         set @ErrorRecord+='查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '+@SpName+'为空,请检查;';
		 INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Scatter' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;

    -------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              

    -- 基础版本的 select段Sql语句
    SET @sql += '
		INSERT INTO #Result_B(DsName,value)
		SELECT ';

    -- 按照 是否需要维度 拼装选择的维度字段

    DECLARE @GDatas VARCHAR(MAX) = ''; -- 用于判断时间的标志

    DECLARE @XDatas VARCHAR(MAX) = '';
    -- 时间在分组拿出来

    IF (@DSName = '时间')
        SET @GDatas += 'dbo.GetTimeName(t.begindate,t.enddate)';
    -- 否则分组上面的取值也要拿出来，分组拿名称
    ELSE IF (@DSName = '无分组')
        SET @GDatas += '无分组';
    ELSE
        SET @GDatas += ISNULL(
                       (
                           SELECT DimName + '.Name' FROM #Dims WHERE Isneed = 'G'
                       ),
                       ''
                             );
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名


    -- Value 段即 X和Y拼接的部分拿出来
    DECLARE @XYSQL VARCHAR(MAX);

    -- 存放Y轴的取值
    DECLARE @YSqlUse VARCHAR(200) = (
                                        SELECT DimYsql FROM #Dims WHERE ChName = @YName
                                    );

    -- 如果维度里面没有Y，就从自定义Y轴表中获取
    IF (@YSqlUse IS NULL)
	BEGIN
        SET @YSqlUse =
    (
        SELECT Ycolumn
        FROM Tbl_AnsCom_SelfY
        WHERE YName = @YName
              AND SpName = @SpName
    )   ;
	IF (   @YSqlUse = ''
       OR @YSqlUse IS NULL
   )
    BEGIN
         SET @ErrorRecord += '查询select Ycolumn FROM Tbl_AnsCom_SelfY
        WHERE SpName = '+@SpName+'
              AND YName = '+@YName+'为空,可能导致报错,请检查!';
		 INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Scatter' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;
	end
    -- 从维度表中取出Y轴上面的维度 如果是时间单独取
    SELECT @XYSQL = ',''['' + cast(' + ISNULL(   CASE
                                                     WHEN @XName = '无横轴' THEN
                                                         '''1'''
                                                     ELSE
    (
        SELECT DimYsql FROM #Dims WHERE Isneed = 'X'
    )
                                                 END,
                                                 ''
                                             ) + ' AS varchar(100))' -- 横轴取值
                    + ' + '','' + cast(' + ISNULL(@YSqlUse, '') + ' AS varchar(100))' -- Y轴取值
                    -- count(*) 是当x和Y数值完全重复时计算起泡大小
                    + ' + '','' + cast(count(*) as varchar(20)) + '']'' ';

    -- 分组提取段加入
    SET @sql += @GDatas;

    -- value段加入
    SET @sql += @XYSQL;

    DECLARE @FromSql VARCHAR(MAX) = (
                                        SELECT JoinTables + ' ' + BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = @SpName
                                    );

    IF (@FromSql IS NULL OR @FromSql = '')
    BEGIN
        SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables, BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = '+@SpName+'结果为空 ,可能导致报错,请检查;';
		 INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Scatter' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;

    SET @sql += ISNULL(@InnerSelect, '') + ' FROM ' + @FromSql;

    -- 按照是否需要的表格拼装对应的表格

    -- 时间维表一定需要 放在可能会取到时间的表之后 
    IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';

    -- 临时存储拼接的SQL语句
    DECLARE @sql1 VARCHAR(MAX) = '';

    -- 将INNER JOIN 维度临时表段拼接起来
    SET @sql1
        = ISNULL(
          (
              SELECT ' INNER JOIN #' + DimName + ' AS ' + DimName + ' on '
                     +
                  -- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
                  CASE
                      WHEN isrange = 1 THEN
                          DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
                      -- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
                      ELSE
                          DimName + '.ID = ' + DimYsql
                  END
              FROM #Dims
              WHERE Isneed <> 'ND'
              FOR XML PATH('')
          ),
          ''
                );

    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @sql1 = REPLACE(REPLACE(@sql1, '&lt;', '<'), '&gt;', '>');

    -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'
    SET @sql += @sql1;

    -- 如果分组是无分组 则拼接无分组列用于group	
    IF (@DSName = '无分组')
        SET @sql += ' cross join ( select ''无分组'' AS 无分组) wfz ';

    IF (@XName = '无横轴')
        SET @sql += ' cross join ( select 1 AS 无横轴) whz ';


    SET @sql += ' GROUP BY '
                -- 	GROUP BY 分组，以及 x数值和Y数值
                + @GDatas + ',' + ISNULL(   CASE
                                                WHEN @XName = '无横轴' THEN
                                                    '无横轴'
                                                ELSE
                                            (
                                                SELECT DimYsql FROM #Dims WHERE Isneed = 'X'
                                            )
                                            END,
                                            ''
                                        ) + ',' + ISNULL(@YSqlUse, '');


    -- 注销临时表
    SET @sql += ';
	';

	SET @sql+=' if((select count(*) from #Result_B)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_Scatter'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister @condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@Type='''''+@Type+''''',@SpName='''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(5))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END '


	SET @sql +=ISNULL((SELECT ' if((select count(*) from #'+DimName+')=0) BEGIN INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_Scatter'',''表#'+DimName+'数据为空,可能造成报错请检查'',''Exec Sp_Analysister @condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@Type='''''+@Type+''''',@SpName='''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(5))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END ' FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')),'')
    SET @sql += ISNULL(
                (
                    SELECT 'DROP TABLE #' + DimName + ';'
                    FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')
                ),
                ''
                      );

    PRINT ' CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME
    );
     ' + @sql;
    EXEC (@sql);

    IF NOT EXISTS (SELECT 1 FROM #Result_B)
    BEGIN
        SELECT '' AS Dimx;
        SELECT '此条件下没有数据，请重新选择' AS title;
        RETURN;
    END;

    --SELECT * FROM #Result_B
    --RETURN;
    ------------------------------------------------------------ 各比较类型数据计算 ----------------------------------------------------------------------                  

    -- 给予输出列
    DECLARE @FormatSql1 VARCHAR(MAX) = '';
    DECLARE @FormatSql2 VARCHAR(MAX) = '';
    DECLARE @FormatSql VARCHAR(MAX) = '';

    -- 拼接 取表 段 第一个表不需要拼接 FULL JOIN
    SET @FormatSql1 = ISNULL(
                      (
                          SELECT ',T' + CAST(id AS VARCHAR(10)) + '.value AS ''' + DsName + ''''
                          FROM
                          (
                              SELECT ROW_NUMBER() OVER (ORDER BY DsName) AS id,
                                     DsName
                              FROM
                              (SELECT DISTINCT DsName FROM #Result_B) x
                          ) xx
                          FOR XML PATH('')
                      ),
                      ''
                            );

    SET @FormatSql2
        = ISNULL(
          (
              SELECT
                  -- 拼接 FULL JOIN 段 第一个表不需要拼接 FULL JOIN
                  CASE
                      WHEN id = 1 THEN
                          ''
                      ELSE
                          ' FULL JOIN '
                  END + ' ( SELECT ROW_NUMBER() OVER(ORDER BY id) AS nn,* FROM #Result_B WHERE DsName = ''' + DsName
                  + ''') AS T' + CAST(id AS VARCHAR(10)) + -- 拼接ON段
                  -- 如果id = 1 第一个表不需要拼接 on 段
                  CASE
                      WHEN id = 1 THEN
                          ''
                      ELSE
                  (' ON T' + CAST(id AS VARCHAR(10)) + '.nn = T' + CAST(id - 1 AS VARCHAR(10)) + '.nn')
                  END
              FROM
              (
                  SELECT ROW_NUMBER() OVER (ORDER BY DsName) AS id,
                         DsName
                  FROM
                  (SELECT DISTINCT DsName FROM #Result_B) x
              ) xx
              FOR XML PATH('')
          ),
          ''
                );


    SET @FormatSql = ' SELECT ' + SUBSTRING(@FormatSql1, 2, LEN(@FormatSql1)) -- 去掉 @FormatSql1 中的第一个逗号
                     + ' FROM ' + @FormatSql2;

    --PRINT @FormatSql;
    EXEC (@FormatSql);
    IF (@Usertitle = '' OR @Usertitle IS NULL)
    BEGIN
        DECLARE @TimeStr NVARCHAR(100) = (
                                             SELECT dbo.GetTimeName(beginDate, endDate) + ','
                                             FROM #time
                                             FOR XML PATH('')
                                         );
        SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1);
        IF ((SELECT COUNT(*) FROM #time) > 5)
        BEGIN
            SET @TimeStr =
            (
                SELECT TOP 5
                    dbo.GetTimeName(beginDate, endDate) + ','
                FROM #time
                FOR XML PATH('')
            );
            SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
        END;
        SET @Usertitle = @TimeStr + ' [' + @XName + ']在[' + @DSName + ']上的[' + @YName + ']';
        IF ((SELECT COUNT(*) FROM #Dims WHERE Isneed = 'F') <> 0)
        BEGIN
            DECLARE @WDFilter NVARCHAR(500)
                =   (
                        SELECT '[' + ChName + '],' FROM #Dims WHERE Isneed = 'F' FOR XML PATH('')
                    );
            SET @WDFilter = ',另筛选' + LEFT(@WDFilter, LEN(@WDFilter) - 1);
            SET @Usertitle += @WDFilter;
        END;
    END;

    DECLARE @XMax DECIMAL(18, 2);
    DECLARE @XMin DECIMAL(18, 2);
    DECLARE @YMax DECIMAL(18, 2);
    DECLARE @YMin DECIMAL(18, 2);

    ------ 下面是查找Y轴和X轴最大最小值
    SELECT @XMax = MAX(CAST(SUBSTRING(value, CHARINDEX('[', value) + 1, CHARINDEX(',', value) - 2) AS DECIMAL(18, 2))),
           @XMin = MIN(CAST(SUBSTRING(value, CHARINDEX('[', value) + 1, CHARINDEX(',', value) - 2) AS DECIMAL(18, 2))),
           @YMax
               = MAX(CAST(SUBSTRING(
                                       value,
                                       CHARINDEX(',', value) + 1,
                                       CHARINDEX(',', value, CHARINDEX(',', value) + 1) - (CHARINDEX(',', value) + 1)
                                   ) AS DECIMAL(18, 2))
                    ),
           @YMin
               = MIN(CAST(SUBSTRING(
                                       value,
                                       CHARINDEX(',', value) + 1,
                                       CHARINDEX(',', value, CHARINDEX(',', value) + 1) - (CHARINDEX(',', value) + 1)
                                   ) AS DECIMAL(18, 2))
                    )
    FROM #Result_B;

    DECLARE @Yma VARCHAR(MAX);
    DECLARE @Ymi VARCHAR(MAX);
    DECLARE @Xma VARCHAR(MAX);
    DECLARE @Xmi VARCHAR(MAX);

    DECLARE @YTbl TABLE
    (
        Yma VARCHAR(MAX),
        Ymi VARCHAR(MAX)
    );

    DECLARE @XTbl TABLE
    (
        Xma VARCHAR(MAX),
        Xmi VARCHAR(MAX)
    );

    INSERT INTO @YTbl
    EXEC [dbo].[Sp_Y_min_max] @maxY = @YMax, @minY = @YMin;
    SET @Yma =
    (
        SELECT Yma FROM @YTbl
    );
    SET @Ymi =
    (
        SELECT Ymi FROM @YTbl
    );

    INSERT INTO @XTbl
    EXEC [dbo].[Sp_Y_min_max] @maxY = @XMax, @minY = @XMin;
    SET @Xma =
    (
        SELECT Xma FROM @XTbl
    );
    SET @Xmi =
    (
        SELECT Xmi FROM @XTbl
    );

    IF (@XMax = @XMin)
    BEGIN
        SET @XMax = @XMax * 1.2;
        SET @XMin = @XMin * 0.8;
    END;

    SELECT CASE
               WHEN @Usertitle = '' THEN
                   @XName + ' - ' + @YName + ' 在分组 ' + @DSName + '上的分布'
               ELSE
                   @Usertitle
           END AS title,
           @XName AS XName,
           @YName AS YName,
           '' AS YName_Second,
           '' AS XUnit,
           '' AS YUnit,
           '' AS YUnit_Second,
           @XMax AS XMax,
           @XMin AS XMin,
           @YMax AS YMax,
           @YMin AS YMin;


    -- RETURN;
    -- 注销临时表
    DROP TABLE #Result_B;
    DROP TABLE #time;
    DROP TABLE #Dims;

    -- 拼接标题等配置


    -- 插入日志记录
    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        EmpName,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter
    )
    VALUES
    (   @EmpID,
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
        GETDATE(),
        'Sp_Analysister_scatter',
        '' + @SpName + '多维分析器散点图',
        @condition,
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=' + @OtherCond
    );
	
END;
go

