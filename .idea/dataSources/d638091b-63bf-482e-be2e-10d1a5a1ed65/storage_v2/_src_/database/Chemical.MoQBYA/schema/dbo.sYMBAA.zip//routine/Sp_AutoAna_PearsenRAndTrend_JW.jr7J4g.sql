











-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 多维度降维SP
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_PearsenRAndTrend_JW]
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(max) = 'DimSinOutValue:,DimOilSeries:,DimSinTemp8:倍数2,DimDIYTemp25:,DimDIYSpeed:,DimDIYSpeed580:,DimDIYOilVis:'
	,@XDim VARCHAR(50) = 'DimDDLps'
	,@YDim VARCHAR(50) = 'DimSinOutValue'
	,@diyMin VARCHAR(50) = -100 --极差目标区间下限
	,@diyMax VARCHAR(50) = 1400 --极差目标区间上限
	,@stepn VARCHAR(50) = 15 --极差区间个数
	,@bzdiyMin VARCHAR(50) = -100 --标准差目标区间下限
	,@bzdiyMax VARCHAR(50) = 1400 --标准差目标区间上限
	,@bzstepn VARCHAR(50) = 15 --标准差区间个数
	,@IsCountR BIT = 0 -- 是否计算 相关系数R
	,@RWhere VARCHAR(MAX) = ' AND DimOilSeries = 3 '   -- 计算相关系数的筛选条件
	,@IsCountTrend INT  = 0
	,@TrendR DECIMAL(18,6) = 0.7
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
 
    -- 分解维度插入零时表
    INSERT INTO #DimsPearSen
    SELECT SUBSTRING(string,1,CHARINDEX(':',string) - 1)
    ,CASE WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @XDim THEN 'X'  -- 变量dim
	      WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @YDim THEN 'Y'  -- 目标dim
		  ELSE 'F' END   -- 条件Dim
    ,ta.IsRange
    ,ta.ViewName
    ,ta.AtYSql
    ,SUBSTRING(string,CHARINDEX(':',string) + 1,Len(string))
    ,NUll
    FROM dbo.Split(@Dims,',') s
    INNER JOIN dbo.Tbl_AnsCom_DIimToTable ta ON SUBSTRING(string,1,CHARINDEX(':',string) - 1) = ta.DimNum
    
    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #DimsPearSen WHERE Dim = @YDim;
    
    -- 数据源sql段
    DECLARE @TName VARCHAR(500);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
   
    -- 计算所有条件 Dim 的数据量
    DECLARE @CreateT VARCHAR(max) = '';
    
    SET @CreateT += ( SELECT 'CREATE TABLE #' +  Dim + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') );
    

    -- 根据维度值取维度刻度
	DECLARE @InsertT VARCHAR(max) = '';

	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where ' + 
				CASE WHEN ISNULL(DimValue,'') = '' THEN 'istrue = 0;'
						  ELSE '[选项集合类型] = ''' + DimValue + ''';' END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') )

    -- 拼接计算列

    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' LEFT JOIN #' +  Dim + ' AS ' + Dim + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN Dim + '.BeginValue <= ' + DimYsql + ' AND ' + Dim + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE Dim + '.ID = ' + DimYsql END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	
	-- 拼接SiftValue段
    DECLARE @SiftValue VARCHAR(max);
    SET @SiftValue = ( SELECT '''%' +  Dim + ':'' + CAST( isnull(' + Dim + '.ID,0) AS Varchar(10)) + '
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个 % 和最后一个 +
	SET @SiftValue = '''' + SUBSTRING(@SiftValue,3,LEN(@SiftValue) - 3);
	
	-- 拼接 group by 段
    DECLARE @GroupBy VARCHAR(max);
    SET @GroupBy = ( SELECT ',' + Dim + '.ID'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	-- 去掉第一个,
	SET @GroupBy = SUBSTRING(@GroupBy,2,LEN(@GroupBy));
	
	-- 设置目标表格
	--DECLARE @ResultTable VARCHAR(max);
	--SET @ResultTable = '#Result1';
	
	-- 拼接 维度条件列名段
    DECLARE @CName VARCHAR(max);
    SET @CName = ( SELECT ',' + Dim + ' INT'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));

	-- 建立结果表
    DECLARE @CreateTable VARCHAR(max);
    set @CreateTable=(select 'CREATE TABLE #Result1
	   (spName varchar(50),
		DataCount int,
		MaxY Decimal(18,6),
		MinY Decimal(18,6),
		AVGY Decimal(18,6),
		SQtY Decimal(18,6),
		Siftvalue varchar(Max),
		PearSenR DECIMAL(18,6),
		Slope DECIMAL(18,6),
		LineCons DECIMAL(18,6),
		ChangePoint int ,
		Trend Varchar(Max)
		'
		+ @CName +
		')'
		)

    --置信度计算
    DECLARE @zxd VARCHAR(max);
    set @zxd=' SELECT COUNT(*) AS 所有组数,COUNT(CASE WHEN datacount > 1 THEN 1 END) AS 有比较组数,CAST(CAST(COUNT(CASE WHEN datacount > 1 THEN 1 END) AS DECIMAL(18,4)) / COUNT(*) * 100 as DECIMAL(18,2)) AS 组数占比
                ,SUM(datacount) AS 所有生产数,SUM(CASE WHEN datacount > 1 THEN datacount END) AS 有比较生产数,cast(CAST(SUM(CASE WHEN datacount > 1 THEN datacount END) AS DECIMAL(18,4)) / SUM(datacount) * 100 as DECIMAL(18,2)) AS 生产数占比
                FROM #Result1
                WHERE datacount IS NOT null '+@RWhere

    --极差计算
    DECLARE @jc VARCHAR(max);
    set @jc=' ;WITH CTE AS (
	                select ID,Name AS 极差范围 ,ncount AS 组数
	                ,cast(CAST(ncount AS DECIMAL(18,4)) / (SUM(ncount) OVER() ) * 100 as DECIMAL(18,2)) AS 组比例
	                ,Sumn AS 生产数
	                ,cast(CAST(Sumn AS DECIMAL(18,4)) / (SUM(Sumn) OVER() ) * 100 as DECIMAL(18,2)) AS 生产比例
	                FROM
	                    (
		                SELECT b.ID,b.Name,COUNT(*) AS ncount,SUM(datacount) AS Sumn
		                FROM #Result1 a
		                LEFT JOIN fn_getAreaTable('+@diyMin+','+@diyMax+','+@stepn+') b ON a.MaxY - a.MInY > b.beginvalue AND a.MaxY - a.MInY <= b.endvalue
		                WHERE datacount > 1 ' +@RWhere+
		                ' GROUP BY b.ID,b.NAME,b.beginvalue
	                        ) x
                            )
                    SELECT b.*
                    ,(SELECT SUM(组比例) FROM CTE a WHERE a.ID <= b.ID ) AS 累进组比例值
                    ,(SELECT SUM(生产比例) FROM CTE a WHERE a.ID <= b.ID ) AS 累进生产比例值
                    FROM CTE b'

    --标准差计算
    DECLARE @bzc VARCHAR(max);
    set @bzc=' ;WITH CTE AS (
	            select ID,Name AS 标准差范围 ,ncount AS 组数
	            ,cast(CAST(ncount AS DECIMAL(18,4)) / (SUM(ncount) OVER() ) * 100 as DECIMAL(18,2)) AS 组比例
	            ,Sumn AS 生产数
	            ,cast(CAST(Sumn AS DECIMAL(18,4)) / (SUM(Sumn) OVER() ) * 100 as DECIMAL(18,2)) AS 生产比例
	            FROM
	            (
		            SELECT b.ID,b.Name,COUNT(*) AS ncount,SUM(datacount) AS Sumn
		            FROM #Result1 a
		            LEFT JOIN fn_getAreaTable('+@bzdiyMin+','+@bzdiyMax+','+@bzstepn+') b ON a.SqtY > b.beginvalue AND a.SqtY <= b.endvalue
		            WHERE datacount > 1 '+@RWhere+' 
		            GROUP BY b.ID,b.NAME,b.beginvalue
	            ) x
                )
                SELECT b.*
                ,(SELECT SUM(组比例) FROM CTE a WHERE a.ID <= b.ID ) AS 累进比例值
                ,(SELECT SUM(生产比例) FROM CTE a WHERE a.ID <= b.ID ) AS 累进生产比例值
                FROM CTE b'
    
    --主副因素验证
    --限制条件
       DECLARE @CKON VARCHAR(max);
        set @CKON=(
        select ' AND ABS(a.' + Dims +' - '+ ' b.' + Dims + ')<=' + cast(bs as varchar(max)) from (
        select replace(DimYsql,'.','') Dims,
        case when charindex('倍数',DimValue)>0 then right(DimValue,LEN(DimValue)-2)*tnd.NumDecimal
        when  charindex('倍数',DimValue)=0 then 1*tnd.NumDecimal end as bs
        from #DimsPearSen dp
        inner join Tbl_AnsCom_DIimToTable tnd
        on dp.Dim=tnd.DimNum
        where DType='F' and dp.isrange=1
        ) aa FOR XML PATH(''));
    set @CKON=REPLACE(@CKON,'&lt;','<');
   
   --where 条件
    DECLARE @CKWhere1 VARCHAR(max);
    DECLARE @CKWhere2 VARCHAR(max);
    if(select charindex('Dim',@RWhere))>0
    begin
    set @CKWhere1=
    (select substring(AtYSql,charindex('.',AtYSql)+1,LEN(AtYSql)-charindex('.',AtYSql)+1) from Tbl_AnsCom_DIimToTable
    where DimNum=(select substring(replace(@RWhere,' ',''),charindex('Dim',replace(@RWhere,' ','')),charindex('=',replace(@RWhere,' ',''))-charindex('Dim',replace(@RWhere,' ',''))))
    );
    set @CKWhere2=(select substring(replace(' AND DimOilSeries = 3 ',' ',''),charindex('=',replace(' AND DimOilSeries = 3 ',' ',''))+1,charindex('=',replace(' AND DimOilSeries = 3 ',' ',''))))
    set @CKWhere1=(select ' AND '+@CKWhere1+'='+@CKWhere2)
    end;

    DECLARE @CK VARCHAR(max);
    DECLARE @CKData VARCHAR(max);
    DECLARE @CKY VARCHAR(max);
    set @CKY=(select right(DimYsql,len(DimYsql)-charindex('.',DimYsql)) from #DimsPearSen where DType='Y');
    set @CKData=(select DimYsql+' as '+REPLACE(DimYsql,'.','')+',' from #DimsPearSen where isrange=1 and DType='F' FOR XML PATH(''));
    set @CKData=(select LEFT(@CKData,LEN(@CKData)-1))

    set @CK=' ;WITH CTEs AS
	            (
		        SELECT '+@SpName+'.*,' + @CKData +' 
		        FROM  ' + @TName + ' 
		        WHERE ' + @Ysql + ' IS NOT null ' + @CKWhere1 + ' 
	            ),
	        CTEs1 AS
	            (
		        select ID,Name AS 绝对差 ,n AS 对比数,SUM(n) OVER() AS 对比总数
		        ,CAST(n AS DECIMAL(18,4)) / (SUM(n) OVER() ) * 100 AS 比例
		        FROM
		        ( 
			        SELECT b.ID,b.Name,COUNT(*) AS n FROM 
			        (
				        SELECT ABS(a.' + @CKY + ' - b.' + @CKY + ') AS cha FROM CTEs a
				        INNER JOIN CTEs B
				        ON a.ID > b.ID '+@CKON+' 
			        ) x LEFT JOIN fn_getAreaTable('+@diyMin+','+@diyMax+','+@stepn+') b ON x.cha > b.beginvalue AND x.cha <= b.endvalue
			        GROUP BY b.ID,b.Name
		            ) xx
	            )
	        SELECT b.*
	        ,(SELECT SUM(比例) FROM CTEs1 a WHERE a.ID <= b.ID ) AS 累进比例值
	        FROM CTEs1 b
	        ORDER BY b.ID'

	DECLARE @ResultDataSql VARCHAR(500);
	SET @ResultDataSql = '''' + @SpName + ''',SUM(CASE WHEN ' + @Ysql + ' is not null THEN 1 ELSE 0 END ),MAX(' + @Ysql + '),MIN(' + @Ysql + '),AVG(' + @Ysql + '),stdev(' + @Ysql + '),'
	
	EXEC (@CreateTable+@CreateT + @InsertT + 'INSERT INTO #Result1 '  + ' SELECT ' + @ResultDataSql + @SiftValue + ',NULL,NULL,NULL,NULL,NULL,' + @GroupBy + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy + @zxd + @jc + @bzc + @CK);
	

	---- 如需计算相关系数
	--IF(@IsCountR = 1)
	--BEGIN
		
	--	-- 打印总数据
	--	EXEC  ('DECLARE @VDataCount int,@AllDataCount int;
	--	select @AllDataCount = SUM(CASE WHEN DataCount > 0 THEN 1 ELSE 0 END),@VDataCount = SUM(CASE WHEN DataCount > 1 THEN 1 ELSE 0 END) FROM #Result1 '  + ' WHERE 1 = 1 ' + @RWhere + ';
	--	PRINT ( ''有数据总组数：'' + Cast(@AllDataCount AS Varchar(10)) + '' -----  两条以上数据总组数：'' +  Cast(@VDataCount AS Varchar(10)) ) ' )
		
	--	DECLARE @UpdateR VARCHAR(MAX);
		
	--	SET @UpdateR = '
	--	DECLARE @N INT = 1;
	--	DECLARE @SV VARCHAR(MAX);
	--	DECLARE Cur CURSOR FOR
	--	SELECT Siftvalue FROM #Result1 '  + ' WHERE DataCount > 1 ' + @RWhere + '
	--	OPEN Cur
	--	FETCH NEXT FROM Cur INTO @SV
	--	WHILE @@FETCH_STATUS =0
	--	BEGIN
			
	--		EXEC [Sp_AutoAna_DataPearsen_LC]
	--		@SiftValue = @SV
	--		,@SpName = ''' + @SpName + '''
	--		,@XDim = ''' + @XDim + '''
	--		,@YDim = ''' + @YDim + '''
			
			
	--		IF( ' + CAST(@IsCountTrend AS VARCHAR(10)) + ' = 1 )
	--		BEGIN
	--			IF EXISTS( select 1 FROM #Result1'  + ' WHERE SiftValue = @SV AND Abs(PearSenR) < + ' + CAST(@TrendR AS VARCHAR(20)) + ' )
	--				EXEC [Sp_AutoAna_DataTrend_LC]
	--				@SiftValue = @SV
	--				,@SpName = ''' + @SpName + '''
	--				,@XDim = ''' + @XDim + '''
	--				,@YDim = ''' + @YDim + '''
					
			
	--		END
			
	--		Print ( ''执行完:'' + Cast(@N AS Varchar(10)) )
			
	--		SET @N = @N + 1
			
	--		FETCH NEXT FROM Cur INTO @SV
	--	END	
	--	CLOSE Cur
	--	DEALLOCATE Cur
	--	'
		
	--	--PRINT (@UpdateR);
	--	EXEC (@UpdateR);
		
	--END
	
END
go

