-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-28>
-- Description:	<系统账户信息 一个员工只对应一个权限>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Permission_User_GetByID]
@EmpID varchar(50)='-1'
 as 
 Begin 
set nocount on

 select  
	a.EmpID
	,b.UserID
 ,b.UserAccount
 ,c.RoleID
  from 
  Tbl_Com_Employee a
  left join Tbl_Sys_User b on a.UserID=b.UserID
  left join Tbl_Sys_UserRoleRelation c on b.UserID=c.UserID
  where a.EmpID=@EmpID


 End
go

