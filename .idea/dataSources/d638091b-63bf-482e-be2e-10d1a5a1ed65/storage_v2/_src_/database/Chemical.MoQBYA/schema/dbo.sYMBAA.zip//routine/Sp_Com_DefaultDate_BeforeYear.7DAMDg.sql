    
/*    
刘轶  2014-7-1 查询列表默认添加查询条件到本月至今    
*/    
CREATE proc [dbo].[Sp_Com_DefaultDate_BeforeYear]      
as      
BEGIN      
select 'BeginDate' BeginDate            
,'EndDate' EndDate              
union all              
select 'varchar 200'           
,'varchar 200'               
union all              
--select substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)      
select Convert(varchar(10),DateAdd(YY,-1,GETDATE()),23)
		,CONVERT(varchar(50),GETDATE(),23)       
END
go

