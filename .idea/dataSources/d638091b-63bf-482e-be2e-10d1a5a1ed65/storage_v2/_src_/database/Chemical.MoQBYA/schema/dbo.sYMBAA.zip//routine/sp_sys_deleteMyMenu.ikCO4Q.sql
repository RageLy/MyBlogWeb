    
    
    
    
-- =============================================    
-- Author:  曹乐平    
-- Create date: 2014-4-10    
-- Description: 删除“我的常用菜单”    
-- =============================================    
CREATE proc[dbo].[sp_sys_deleteMyMenu]    
 @TableName varchar(max)='tbl_sys_mymenu'    
 ,@KeyName varchar(max)='MyMenuId'    
 ,@KeyValue varchar(max) --主键ID    
AS    
BEGIN    
    
 delete from tbl_sys_myMenu where MyMenuId=@KeyValue    
 select '0';    
END
go

