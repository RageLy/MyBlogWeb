          
--======================================        
-- 员工编辑新增保存
--===================================      
CREATE PROC [dbo].[Sp_Sys_EmpSave]          
@EmpID VARCHAR(100)=''          
,@EmpNo VARCHAR(100)=''  --员工工号          
,@EmpName VARCHAR(100)='' --员工姓名          
,@Sex VARCHAR(100)=''  --性别                 
,@Telephone VARCHAR(100)='' --电话           
,@Status VARCHAR(100)=''--状态   
    
AS           
BEGIN          
--输入判断          
            
          
IF(@EmpName ='')          
BEGIN          
 SELECT '员工姓名不能为空！'          
 RETURN           
END           
         
          
IF(@EmpID = '')          
BEGIN          
 if ( Exists ( select 1 from Tbl_Com_Employee where EmpName = @EmpName) )            
 begin             
  select '员工姓名不能有重复!';            
  return;            
 END          
           
 INSERT INTO dbo.Tbl_Com_Employee          
         ( EmpName ,          
           EmpNo ,          
           Sex ,           
       
           Telephone ,            
           [Status] 
           ,ZJM     
    
         )          
 VALUES  (          
   @EmpName,          
   @EmpNo,          
   @Sex,         
          
   @Telephone,             
   @Status   
   ,dbo.fn_GetPy(@EmpName)         
         )          
           
           
END          
ELSE           
BEGIN          
  --select * from Tbl_Com_Employee          
 if ( Exists ( select * from Tbl_Com_Employee where EmpName = @EmpName and EmpID <> @EmpID) )            
 begin             
  select '员工姓名不能有重复!';            
  return;            
 END          
           
 UPDATE dbo.Tbl_Com_Employee SET           
 EmpName = @EmpName          
 ,EmpNo = @EmpNo          
 ,Sex = @Sex          
         
 ,Telephone = @Telephone                
 ,[Status] = @Status  
 ,ZJM = dbo.fn_GetPy(@EmpName)     
      
 WHERE EmpID = @EmpID          
END          
          
          
SELECT '0'          
          
END
go

