



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_DataManagement_Add_Edit_ParticalData]
	@ID NVARCHAR(50) = ''
	,@Code NVARCHAR(50) = ''
	,@Series NVARCHAR(50) = ''
	,@OptDate NVARCHAR(50) = ''
	,@PType NVARCHAR(50) = ''
	,@Kettle NVARCHAR(50) = ''
	,@TOutput NVARCHAR(50) = ''
	,@FOutput NVARCHAR(50) = ''
	,@PigmentCode NVARCHAR(50) = ''
	,@Viscosity NVARCHAR(50) = ''
	,@Zeta NVARCHAR(50) = ''
	,@Organic NVARCHAR(50) = ''
	,@PSize05 NVARCHAR(50) = ''
	,@PSize09 NVARCHAR(50) = ''
	,@Remark NVARCHAR(500) = ''
	,@Action NVARCHAR(50) = ''
	,@ReactBACode NVARCHAR(50) = '',
	@ReactBECode NVARCHAR(50) = '',
	@SolventG NVARCHAR(50) = '',
	@PCRSpeed NVARCHAR(50) = NULL,
	@PCTime NVARCHAR(50) = NULL,
	@WBTempSet NVARCHAR(50) = NULL, 
	@WBTempActually NVARCHAR(50) = NULL, 
	@WBRSpeedSet NVARCHAR(50) = NULL,
	@WBRSpeedActually NVARCHAR(50) = NULL,
	@Ini1JoinTime NVARCHAR(50) = NULL, 
	@Ini1SpeedSet NVARCHAR(50) = NULL, 
	@Ini1Speed NVARCHAR(50) = NULL,
	@Ini1TempSet NVARCHAR(50) = NULL,
	@Ini1Temp NVARCHAR(50) = NULL,
	@Ini2BTime NVARCHAR(50) =NULL, 
	@Ini2JoinTime NVARCHAR(50) = NULL,
	@Ini2SpeedSet NVARCHAR(50) = NULL,
	@Ini2Speed NVARCHAR(50) = NULL,
	@OffC1SpeedSet NVARCHAR(50) = NULL,
	@OffC1Speed NVARCHAR(50) = NULL,
	@OffC1Time NVARCHAR(50) = NULL,
	@OffC2SpeedSet NVARCHAR(50) = NULL,
	@OffC2Speed NVARCHAR(50) = NULL,
	@OffC2Time NVARCHAR(50) = NULL,
	@OffC3SpeedSet NVARCHAR(50) = NULL,
	@OffC3Speed NVARCHAR(50) = NULL,
	@OffC3Time NVARCHAR(50) = NULL,
	@OffC4SpeedSet NVARCHAR(50) = NULL,
	@OffC4Speed NVARCHAR(50) = NULL,
	@OffC4Time NVARCHAR(50) = NULL,
	@OffC5SpeedSet NVARCHAR(50) = NULL,
	@OffC5Speed NVARCHAR(50) = NULL,
	@OffC5Time NVARCHAR(50) = NULL,
	@EmpID NVARCHAR(5) = '1'
AS
BEGIN
	
	DECLARE @Class NVARCHAR(50) = '',
		@Ppole NVARCHAR(10) = '',
		@Npole NVARCHAR(10) = ''
		
	IF @PType = '黑色粒子'
	BEGIN
		SET @Class = '1号旧工艺黑色粒子'
		SET @Ppole = '无色'
		SET @Npole = '黑色'
	END
	ELSE IF @PType = '白色粒子'
	BEGIN
		SET @Class = '3号白色粒子'
		SET @Ppole = '白色'
		SET @Npole = '无色'
	END
	
	IF @Action  = 'Insert'
	BEGIN
		IF @ID IS NULL OR @ID=''
		BEGIN
			IF exists(select 1 from dbo.Bs_Partical where Code=rtrim(ltrim(@Code)))                      
			BEGIN
				SELECT '粒子编号不能重复！'
				RETURN
			END
			IF @Code = '' 
			BEGIN
				SELECT '粒子编号不能为空' 
				RETURN  
			END
		
			INSERT dbo.Bs_Partical
			        ( Code ,Series, OptDate , PType , Class , Kettle , 
			        TOutput , FOutput , PigmentID , PigmentCode , 
			        ReactBACode , ReactBECode , SolventG , 
			        PCRSpeed , PCTime , WBTempSet , WBTempActually , WBRSpeedSet , WBRSpeedActually , 
			        Ini1JoinTime , Ini1SpeedSet , Ini1Speed , Ini1TempSet , Ini1Temp , 
			        Ini2BTime , Ini2JoinTime , Ini2SpeedSet , Ini2Speed , 
			        OffC1SpeedSet , OffC1Speed , OffC1Time , OffC2SpeedSet , OffC2Speed , OffC2Time , 
			        OffC3SpeedSet , OffC3Speed , OffC3Time , OffC4SpeedSet , OffC4Speed , OffC4Time ,
			        OffC5SpeedSet , OffC5Speed , OffC5Time , 
			        Viscosity , Zeta , Organic , PSize05 , PSize09 , 
			        Ppole , Npole , RemarK , info
			        )
			VALUES  ( LTRIM(RTRIM(@Code)) , -- Code - nchar(20)
			        @Series,
					@OptDate , -- OptDate - datetime
					@PType , -- PType - varchar(50)
					@Class , -- Class - varchar(50)
					@Kettle , -- Kettle - varchar(50)
					CASE WHEN @TOutput = '' THEN NULL ELSE @TOutput END, --  TOutput - decimal
					CASE WHEN @FOutput = '' THEN NULL ELSE @FOutput END, --  FOutput - decimal
					NULL , -- PigmentID, will be updated by trigger Tri_DataManagement_UpdatePigmentCode
					@PigmentCode , -- PigmentCode - varchar(50)
					CASE WHEN @ReactBACode = '' THEN NULL ELSE @ReactBACode END , -- ReactBACode - varchar(50) 
					CASE WHEN @ReactBECode = '' THEN NULL ELSE @ReactBECode END, -- ReactBECode - varchar(50) 
					CASE WHEN @SolventG ='' THEN NULL ELSE @SolventG END, -- SolventG - varchar(50) 
					CASE WHEN @PCRSpeed = '' THEN NULL ELSE @PCRSpeed END, --  PCRSpeed - decimal 
					CASE WHEN @PCTime = '' THEN NULL ELSE @PCTime END, --  PCTime - decimal 
					CASE WHEN @WBTempSet = '' THEN NULL ELSE @WBTempSet END, --  WBTempSet - decimal 
					CASE WHEN @WBTempActually = '' THEN NULL ELSE @WBTempActually END, --  WBTempActually - decimal 
					CASE WHEN @WBRSpeedSet = '' THEN NULL ELSE @WBRSpeedSet END, --  WBRSpeedSet - decimal 
					CASE WHEN @WBRSpeedActually = '' THEN NULL ELSE @WBRSpeedActually END, --  WBRSpeedActually - decimal 
					CASE WHEN @Ini1JoinTime = '' THEN NULL ELSE @Ini1JoinTime END, --  Ini1JoinTime - decimal 
					CASE WHEN @Ini1SpeedSet = '' THEN NULL ELSE @Ini1SpeedSet END, --  Ini1SpeedSet - decimal 
					CASE WHEN @Ini1Speed = '' THEN NULL ELSE @Ini1Speed END, --  Ini1Speed - decimal 
					CASE WHEN @Ini1TempSet = '' THEN NULL ELSE @Ini1TempSet END, --  Ini1TempSet - decimal 
					CASE WHEN @Ini1Temp = '' THEN NULL ELSE @Ini1Temp END, --  Ini1Temp - decimal 
					CASE WHEN @Ini2BTime = '' THEN NULL ELSE @Ini2BTime END, --  Ini2BTime - decimal 
					CASE WHEN @Ini2JoinTime = '' THEN NULL ELSE @Ini2JoinTime END, --  Ini2JoinTime - decimal 
					CASE WHEN @Ini2SpeedSet = '' THEN NULL ELSE @Ini2SpeedSet END, --  Ini2SpeedSet - decimal 
					CASE WHEN @Ini2Speed = '' THEN NULL ELSE @Ini2Speed END, --  Ini2Speed - decimal 
					CASE WHEN @OffC1SpeedSet = '' THEN NULL ELSE @OffC1SpeedSet END, --  OffC1SpeedSet - decimal 
					CASE WHEN @OffC1Speed = '' THEN NULL ELSE @OffC1Speed END, --  OffC1Speed - decimal 
					CASE WHEN @OffC1Time = '' THEN NULL ELSE @OffC1Time END, --  OffC1Time - decimal 
					CASE WHEN @OffC2SpeedSet = '' THEN NULL ELSE @OffC2SpeedSet END, --  OffC2SpeedSet - decimal 
					CASE WHEN @OffC2Speed = '' THEN NULL ELSE @OffC2Speed END, --  OffC2Speed - decimal 
					CASE WHEN @OffC2Time = '' THEN NULL ELSE @OffC2Time END, --  OffC2Time - decimal 
					CASE WHEN @OffC3SpeedSet = '' THEN NULL ELSE @OffC3SpeedSet END, --  OffC3SpeedSet - decimal 
					CASE WHEN @OffC3Speed = '' THEN NULL ELSE @OffC3Speed END, --  OffC3Speed - decimal 
					CASE WHEN @OffC3Time = '' THEN NULL ELSE @OffC3Time END, --  OffC3Time - decimal 
					CASE WHEN @OffC4SpeedSet = '' THEN NULL ELSE @OffC4SpeedSet END, --  OffC4SpeedSet - decimal 
					CASE WHEN @OffC4Speed = '' THEN NULL ELSE @OffC4Speed END, --  OffC4Speed - decimal 
					CASE WHEN @OffC4Time = '' THEN NULL ELSE @OffC4Time END, --  OffC4Time - decimal 
					CASE WHEN @OffC5SpeedSet = '' THEN NULL ELSE @OffC5SpeedSet END, --  OffC5SpeedSet - decimal 
					CASE WHEN @OffC5Speed = '' THEN NULL ELSE @OffC5Speed END, --  OffC5Speed - decimal 
					CASE WHEN @OffC5Time = '' THEN NULL ELSE @OffC5Time END, --  OffC5Time - decimal 
					CASE WHEN @Viscosity = '' THEN NULL ELSE @Viscosity END, --  Viscosity - decimal 
					CASE WHEN @Zeta = '' THEN NULL ELSE @Zeta END, --  Zeta - decimal 
					CASE WHEN @Organic = '' THEN NULL ELSE @Organic END, --  Organic - decimal 
					CASE WHEN @PSize05 = '' THEN NULL ELSE @PSize05 END, --  PSize05 - decimal 
					CASE WHEN @PSize09 = '' THEN NULL ELSE @PSize09 END, --  PSize09 - decimal 
					@Ppole , -- Ppole - varchar(10) 
					@Npole , -- Npole - varchar(10) 
					@RemarK , -- RemarK - varchar(200) 
					NULL  -- info - varchar(200)
			        )
			-- Update PigmentID
			
			
			
			INSERT INTO dbo.Tbl_Log_AnaUseLog
			        ( EmpID ,
			          freshTime ,
			          spName ,
			          AnaName ,
			          siftvalue ,
			          OherParemeter
			        )
			VALUES (@EmpID,GETDATE(),'Sp_DataManagement_Add_Edit_ParticalData','新增粒子数据', 
			          'insert',Isnull(@ID,'')
	                +','+Isnull(@Code,'')
	                +','+Isnull(@OptDate,'')
	                +','+Isnull(@PType,'')
	                +','+Isnull(@Kettle,'')
	                +','+Isnull(@TOutput,'')
	                +','+Isnull(@FOutput,'')
	                +','+Isnull(@PigmentCode,'')
	                +','+Isnull(@Viscosity,'')
	                +','+Isnull(@Zeta,'')
	                +','+Isnull(@Organic,'')
	                +','+Isnull(@PSize05,'')
	                +','+Isnull(@PSize09,'')
	                +','+Isnull(@Remark,'')
	                +','+Isnull(@Action,'')
	                +','+Isnull(@ReactBACode,'')+','+
	                Isnull(@ReactBECode,'')+','+
	                Isnull(@SolventG,'')+','+
	                Isnull(@PCRSpeed,'') +','+
	                Isnull(@PCTime,'') +','+
	                Isnull(@WBTempSet,'') +','+ 
	                Isnull(@WBTempActually,'') +','+ 
	                Isnull(@WBRSpeedSet,'') +','+
	                Isnull(@WBRSpeedActually,'') +','+
	                Isnull(@Ini1JoinTime,'') +','+ 
	                Isnull(@Ini1SpeedSet,'') +','+ 
	                Isnull(@Ini1Speed,'') +','+
	                Isnull(@Ini1TempSet,'') +','+
	                Isnull(@Ini1Temp,'') +','+
	                Isnull(@Ini2BTime,'') +','+ 
	                Isnull(@Ini2JoinTime,'') +','+
	                Isnull(@Ini2SpeedSet,'') +','+
	                Isnull(@Ini2Speed,'') +','+
	                Isnull(@OffC1SpeedSet,'') +','+
	                Isnull(@OffC1Speed,'') +','+
	                Isnull(@OffC1Time,'') +','+
	                Isnull(@OffC2SpeedSet,'') +','+
	                Isnull(@OffC2Speed,'') +','+
	                Isnull(@OffC2Time,'') +','+
	                Isnull(@OffC3SpeedSet,'') +','+
	                Isnull(@OffC3Speed,'') +','+
	                Isnull(@OffC3Time,'') +','+
	                Isnull(@OffC4SpeedSet,'') +','+
	                Isnull(@OffC4Speed,'') +','+
	                Isnull(@OffC4Time,'') +','+
	                Isnull(@OffC5SpeedSet,'') +','+
	                Isnull(@OffC5Speed,'') +','+
	                Isnull(@OffC5Time,'') +','+
	                Isnull(@EmpID,''))
		END
		ELSE
		BEGIN
			UPDATE dbo.Bs_Partical
			SET [Code] = LTRIM(RTRIM(@Code))
			,[Series] =LTRIM(RTRIM(@Series))
			    ,[OptDate] = CASE WHEN @OptDate = '' THEN NULL ELSE @OptDate END
                ,[PType] = CASE WHEN @PType = '' THEN NULL ELSE @PType END
                ,[Class] = CASE WHEN @Class = '' THEN NULL ELSE @Class END
                ,[Kettle] = CASE WHEN @Kettle = '' THEN NULL ELSE @Kettle END
                ,[TOutput] = CASE WHEN @TOutput = '' THEN NULL ELSE @TOutput END
                ,[FOutput] = CASE WHEN @FOutput = '' THEN NULL ELSE @FOutput END
                ,[PigmentCode] = CASE WHEN @PigmentCode = '' THEN NULL ELSE @PigmentCode END
                ,[ReactBACode] = CASE WHEN @ReactBACode = '' THEN NULL ELSE @ReactBACode END
                ,[ReactBECode] = CASE WHEN @ReactBECode = '' THEN NULL ELSE @ReactBECode END
                ,[SolventG] = CASE WHEN @SolventG = '' THEN NULL ELSE @SolventG END
                ,[PCRSpeed] = CASE WHEN @PCRSpeed = '' THEN NULL ELSE @PCRSpeed END
                ,[PCTime] = CASE WHEN @PCTime = '' THEN NULL ELSE @PCTime END
                ,[WBTempSet] = CASE WHEN @WBTempSet = '' THEN NULL ELSE @WBTempSet END
                ,[WBTempActually] = CASE WHEN @WBTempActually = '' THEN NULL ELSE @WBTempActually END
                ,[WBRSpeedSet] = CASE WHEN @WBRSpeedSet = '' THEN NULL ELSE @WBRSpeedSet END
                ,[WBRSpeedActually] = CASE WHEN @WBRSpeedActually = '' THEN NULL ELSE @WBRSpeedActually END
                ,[Ini1JoinTime] = CASE WHEN @Ini1JoinTime = '' THEN NULL ELSE @Ini1JoinTime END
                ,[Ini1SpeedSet] = CASE WHEN @Ini1SpeedSet = '' THEN NULL ELSE @Ini1SpeedSet END
                ,[Ini1Speed] = CASE WHEN @Ini1Speed = '' THEN NULL ELSE @Ini1Speed END
                ,[Ini1TempSet] = CASE WHEN @Ini1TempSet = '' THEN NULL ELSE @Ini1TempSet END
                ,[Ini1Temp] = CASE WHEN @Ini1Temp = '' THEN NULL ELSE @Ini1Temp END
                ,[Ini2BTime] = CASE WHEN @Ini2BTime = '' THEN NULL ELSE @Ini2BTime END
                ,[Ini2JoinTime] = CASE WHEN @Ini2JoinTime = '' THEN NULL ELSE @Ini2JoinTime END
                ,[Ini2SpeedSet] = CASE WHEN @Ini2SpeedSet = '' THEN NULL ELSE @Ini2SpeedSet END
                ,[Ini2Speed] = CASE WHEN @Ini2Speed = '' THEN NULL ELSE @Ini2Speed END
                ,[OffC1SpeedSet] = CASE WHEN @OffC1SpeedSet = '' THEN NULL ELSE @OffC1SpeedSet END
                ,[OffC1Speed] = CASE WHEN @OffC1Speed = '' THEN NULL ELSE @OffC1Speed END
                ,[OffC1Time] = CASE WHEN @OffC1Time = '' THEN NULL ELSE @OffC1Time END
                ,[OffC2SpeedSet] = CASE WHEN @OffC2SpeedSet = '' THEN NULL ELSE @OffC2SpeedSet END
                ,[OffC2Speed] = CASE WHEN @OffC2Speed = '' THEN NULL ELSE @OffC2Speed END
                ,[OffC2Time] = CASE WHEN @OffC2Time = '' THEN NULL ELSE @OffC2Time END
                ,[OffC3SpeedSet] = CASE WHEN @OffC3SpeedSet = '' THEN NULL ELSE @OffC3SpeedSet END
                ,[OffC3Speed] = CASE WHEN @OffC3Speed = '' THEN NULL ELSE @OffC3Speed END
                ,[OffC3Time] = CASE WHEN @OffC3Time = '' THEN NULL ELSE @OffC3Time END
                ,[OffC4SpeedSet] = CASE WHEN @OffC4SpeedSet = '' THEN NULL ELSE @OffC4SpeedSet END
                ,[OffC4Speed] = CASE WHEN @OffC4Speed = '' THEN NULL ELSE @OffC4Speed END
                ,[OffC4Time] = CASE WHEN @OffC4Time = '' THEN NULL ELSE @OffC4Time END
                ,[OffC5SpeedSet] = CASE WHEN @OffC5SpeedSet = '' THEN NULL ELSE @OffC5SpeedSet END
                ,[OffC5Speed] = CASE WHEN @OffC5Speed = '' THEN NULL ELSE @OffC5Speed END
                ,[OffC5Time] = CASE WHEN @OffC5Time = '' THEN NULL ELSE @OffC5Time END
                ,[Viscosity] = CASE WHEN @Viscosity = '' THEN NULL ELSE @Viscosity END
                ,[Zeta] = CASE WHEN @Zeta = '' THEN NULL ELSE @Zeta END
                ,[Organic] = CASE WHEN @Organic = '' THEN NULL ELSE @Organic END
                ,[PSize05] = CASE WHEN @PSize05 = '' THEN NULL ELSE @PSize05 END
                ,[PSize09] = CASE WHEN @PSize09 = '' THEN NULL ELSE @PSize09 END
                ,[Ppole] = CASE WHEN @Ppole = '' THEN NULL ELSE @Ppole END
                ,[Npole] = CASE WHEN @Npole = '' THEN NULL ELSE @Npole END
                ,[RemarK] = CASE WHEN @RemarK = '' THEN NULL ELSE @RemarK END
			WHERE [ID] = @ID
			
			INSERT INTO dbo.Tbl_Log_AnaUseLog
			        ( EmpID ,
			          freshTime ,
			          spName ,
			          AnaName ,
			          siftvalue ,
			          OherParemeter
			        )
			VALUES  ( @EmpID,GETDATE(),'Sp_DataManagement_Add_Edit_ParticalData', '编辑粒子数据' ,'ID=' + @ID ,Isnull(@ID,'')
	                +','+Isnull(@Code,'')
	                +','+Isnull(@OptDate,'')
	                +','+Isnull(@PType,'')
	                +','+Isnull(@Kettle,'')
	                +','+Isnull(@TOutput,'')
	                +','+Isnull(@FOutput,'')
	                +','+Isnull(@PigmentCode,'')
	                +','+Isnull(@Viscosity,'')
	                +','+Isnull(@Zeta,'')
	                +','+Isnull(@Organic,'')
	                +','+Isnull(@PSize05,'')
	                +','+Isnull(@PSize09,'')
	                +','+Isnull(@Remark,'')
	                +','+Isnull(@Action,'')
	                +','+Isnull(@ReactBACode,'')+','+
	                Isnull(@ReactBECode,'')+','+
	                Isnull(@SolventG,'')+','+
	                Isnull(@PCRSpeed,'') +','+
	                Isnull(@PCTime,'') +','+
	                Isnull(@WBTempSet,'') +','+ 
	                Isnull(@WBTempActually,'') +','+ 
	                Isnull(@WBRSpeedSet,'') +','+
	                Isnull(@WBRSpeedActually,'') +','+
	                Isnull(@Ini1JoinTime,'') +','+ 
	                Isnull(@Ini1SpeedSet,'') +','+ 
	                Isnull(@Ini1Speed,'') +','+
	                Isnull(@Ini1TempSet,'') +','+
	                Isnull(@Ini1Temp,'') +','+
	                Isnull(@Ini2BTime,'') +','+ 
	                Isnull(@Ini2JoinTime,'') +','+
	                Isnull(@Ini2SpeedSet,'') +','+
	                Isnull(@Ini2Speed,'') +','+
	                Isnull(@OffC1SpeedSet,'') +','+
	                Isnull(@OffC1Speed,'') +','+
	                Isnull(@OffC1Time,'') +','+
	                Isnull(@OffC2SpeedSet,'') +','+
	                Isnull(@OffC2Speed,'') +','+
	                Isnull(@OffC2Time,'') +','+
	                Isnull(@OffC3SpeedSet,'') +','+
	                Isnull(@OffC3Speed,'') +','+
	                Isnull(@OffC3Time,'') +','+
	                Isnull(@OffC4SpeedSet,'') +','+
	                Isnull(@OffC4Speed,'') +','+
	                Isnull(@OffC4Time,'') +','+
	                Isnull(@OffC5SpeedSet,'') +','+
	                Isnull(@OffC5Speed,'') +','+
	                Isnull(@OffC5Time,'') +','+
	                Isnull(@EmpID,'') )
			
		END
		
		SELECT 0
	END
	
	
	
	
END
go

