
-- =============================================
-- Author:		<hjl >
-- Create date: <2016 / 8 / 9,>
-- Description:	<用于三温 + 电导率智能控制系统的检索sp>
-- =============================================
CREATE PROCEDURE [dbo].[sp_SerchOutputAplc_3tempDDL]
@DDLps VARCHAR(50) = '148'  -- 是否需要清除原有表
AS
BEGIN
	
	
	SET NOCOUNT ON;
	------------------- 建立临时表区域、插入数据 ---------------------------
	
	IF(ISNUMERIC(@DDLps) = 0)
	BEGIN
		SELECT 'msg' AS 异常信息 UNION ALL SELECT 'varchar 500';
		SELECT '请输入数字！' AS msg;
		RETURN;
	END

	SELECT TOP 1
	t25.Beginvalue AS t25 ,t41.Beginvalue AS t41,t8.Beginvalue AS t8
	,Datacount
	,CAST(cast(GoodRst AS DECIMAL(18,2)) / Datacount * 100 AS DECIMAL(18,2)) AS Good
	,CAST(cast(MiddleRst AS DECIMAL(18,2)) / Datacount * 100 AS DECIMAL(18,2)) AS Middle
	,CAST(cast(BadRst AS DECIMAL(18,2)) / Datacount * 100 AS DECIMAL(18,2)) AS Bad
	INTO #Result
	FROM dbo.T_OutputAplc_3tempDDL SC
	Left JOIN dbo.vw_DimSinTemp25_Part t25 ON SC.DimSinTemp25ID = t25.Id
	Left JOIN vw_DimSinTemp8_Part t8 ON SC.DimSinTemp8ID = t8.Id
	Left JOIN vw_DimSinTemp41_Part t41 ON SC.DimSinTemp41ID = t41.Id
	Left JOIN dbo.vw_DimSinDDLps_Part DD ON SC.DimSinDDLpsID = DD.Id
	WHERE @DDLps >= DD.Beginvalue AND @DDLps < DD.Endvalue
	AND Datacount >= 5 -- 至少5条数据
	ORDER BY cast(GoodRst AS DECIMAL(18,2)) / Datacount DESC
	
	IF(@@ROWCOUNT = 0)
	BEGIN
		SELECT 'msg' AS 异常信息 UNION ALL SELECT 'varchar 500';
		SELECT '未查找到推荐信息，该电导率历史生产数据过小' AS msg;
		RETURN;
	END
	
	
	SELECT 't41' AS [推荐温度41] ,'t8' AS [推荐温度8] ,'t25' AS [推荐温度25] ,'Datacount' AS [以前总生产次数] ,'Good' AS [好产值(大于700)比例] ,'Middle' AS [中等产值(400-700)比例],'Bad' AS [好产值(小于400)比例]               
     union all    
     select 'varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500' 
  
	SELECT * FROM #Result;
	------------------------------------ 查询出结果表格 -------------------------------
	
END
go

