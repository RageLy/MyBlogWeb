




CREATE PROCEDURE [dbo].[Sp_Com_ShowDimsList]
    @AnaName varchar(500) = '油相到单层胶囊分析器'
    ,@DimNum varchar(500) = '油相到单层胶囊分析器'
    ,@DimName varchar(500) = ''
    ,@Type varchar(500) = '列表' -- '编辑加载'
AS
    BEGIN
        --select * from Tbl_AnsCom_SelfDims

	DECLARE @selectdim varchar(Max);
	DECLARE @Allselectdim varchar(Max);

	select @selectdim = selectdim,@Allselectdim = Allselectdim from Tbl_AnsCom_SelfDims
	where Name = @AnaName;

	IF(@Type = '列表')
		select  TableName_ch as belong,@AnaName AS SpType,a.string AS DimNum, b.StartIndex as showindex , c.Name_ch as  ChName, CASE WHEN b.string IS null THEN '是' else '否' END as IsBan
		from
		Split(@Allselectdim,',') a
		left join  Split(@selectdim,',') b on a.string = b.string
		left join Tbl_AnsCom_DIimToTable c on a.string = c.DimNum
		where a.string <> 'Dim7'
		AND c.Name_ch like '%' + @DimName + '%'
		order by isnull(b.StartIndex,a.StartIndex + 1000);
	
	ELSE IF(@Type = '编辑加载')
				select  @AnaName AS SpType,a.string AS DimNum, b.StartIndex as showindex , c.Name_ch as  ChName, CASE WHEN b.string IS null THEN '是' else '否' END as IsBan
		from
		Split(@Allselectdim,',') a
		left join  Split(@selectdim,',') b on a.string = b.string
		left join Tbl_AnsCom_DIimToTable c on a.string = c.DimNum
		where a.string <> 'Dim7' AND a.string = @DimNum;

    END;
go

