CREATE PROCEDURE BatchExecSp_Analysister_JW_new @sptype NVARCHAR(20)
AS
    BEGIN
        SELECT  ID,DimNum
        FROM    dbo.Tbl_AnsCom_DIimToTable
        WHERE   SpType LIKE '%' + @sptype + '%';
        EXEC Sp_Analysister_JW_new @condition = N'DimTbMsKzWd:285%Dim7:Y:This10%DimDTCode:-1%DimMpSeries:10|8|11|9%DimMsFSJLLCode:-1%DimMsLpjLLCode:-1%DimCoatingMsLpjCode:6%DimCoatingMsWaterType:-1%DimJsDs:-1%DimMsDs:-1%DimITOCode:-1%DimJsCode:-1%DimJsType:-1%DimCoatingTJXLCode:-1%Dim401G:-1%DimD207E:-1%DimP100T:-1%DimMsNHJPZDate:-1',
            @OtherCond = N'%无须选择%无选项%桔皮%列表%主副因素分析%undefined%undefined',
            @SpName = N'Coating', @TB = N'4', @EmpID = N'1', @PageSize = N'20',
            @PageIndex = N'1';
            CREATE  TABLE #Result
            (ID INT,
            Name NVARCHAR(10)
            )
    END;
go

