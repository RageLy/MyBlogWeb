CREATE PROC [dbo].[sp_help_Columns]  
@TableName VARCHAR(500)= 'Tbl_base_car'  
AS  
BEGIN  
SELECT DISTINCT o.name AS 表名,c.name AS 列名,t.NAME AS 数据类型,c.max_length AS 数据长度,d.value AS 列说明  
FROM sys.extended_properties  AS d  
LEFT JOIN sys.objects AS o ON o.object_id = d.major_id  
LEFT JOIN sys.columns AS c ON d.minor_id = c.column_id AND c.object_id = o .object_id  
LEFT JOIN sys.types AS t ON c.system_type_id = t.system_type_id  
WHERE o.NAME LIKE '%'+ @TableName + '%' AND o.type in ('u','v')  AND t.name <>'sysname' 
ORDER BY o.name ,c.name,d.value 
END
go

