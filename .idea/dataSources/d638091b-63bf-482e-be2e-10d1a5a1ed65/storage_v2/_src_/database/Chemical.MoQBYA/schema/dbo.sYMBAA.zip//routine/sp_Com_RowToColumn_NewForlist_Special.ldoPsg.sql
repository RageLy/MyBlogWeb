          
          
                        
/*                              
if OBJECT_ID('tempdb.dbo.#tt') is not null                              
drop table #tt           
if OBJECT_ID('tempdb.dbo.#dd') is not null                              
drop table #dd           
                              
create table #tt                              
(                              
name1 varchar(50)                              
,lev varchar(50)                               
,core int                              
)                              
CREATE TABLE #dd          
(          
name1 VARCHAR(50)          
,ty VARCHAR(50)          
,td VARCHAR(50)          
)          
                              
insert into #tt(name1,lev,core)                              
values('A','X',10)                              
,('A','Y',20)                              
,('B','Z',30)                              
,('B','Y',40)                              
,('C','Y',50)                              
,('C','Z',60)                              
,('C','X',70)          
,('A','Z',80)                               
,('B','X',90)                              
insert into #dd(name1,ty,td)                              
values('A','M','10')                              
 ,('B','N','20')                              
 ,('C','L','30')          
                          
EXEC  dbo.sp_Com_RowToColumn_Forlist @table='#tt',@title='lev',@data='core',@groupBy='name1',@orderBy='name1',@type=3          
, @joinTbl ='#dd',@joinCol ='name1',  @showCol ='name1,ty,td'                           
*/                              
                              
                              
--特殊处理                               
CREATE proc [dbo].[sp_Com_RowToColumn_NewForlist_Special]                              
(                                    
 @table varchar(50)='#table',-------  需要转换的table名字，table是3列                                    
 @title varchar(50)='col',   -------  需要把数据转换为列的列名                                 
 @data varchar(50)='col2',   -------  需要取值的列名                        
 @groupBy varchar(200)='col3',  ----  需要分组的列                                
 @orderBy varchar(500)='col3',   ----  排序                       
 @type int=0, ---@type=0 无合计，1，列合计，2，行合计 ，3.行列合计                             
 @joinTbl VARCHAR(max)='',          
 @joinCol VARCHAR(200)='', --需要显示的列使用,分隔          
 @showCol VARCHAR(max)=''          
)                                      
as                              
begin                                      
                      
              
                                       
------- 需要转的列信息                              
create table #tbcol                              
(                              
name nvarchar(500)                              
)          
insert into #tbcol exec( 'select distinct '+ @title +' from ' +@table)                              
CREATE TABLE #jointbcol          
(          
name NVARCHAR(500)          
)          
insert into #jointbcol (name) SELECT string FROM dbo.Split(@showCol,',')            
          
PRINT '------------------------------1----------------'          
          
--出表头===============================================================          
/*          
@colname=          
select 'n' 序号, 'name1' name1,'X' AS [X],'Y' AS [Y],'Z' AS [Z],'列合计' 列合计          
@colname1=          
select 'varchar,500','varchar,500','varhcar,500','varhcar,500','varhcar,500', 'varchar,500'          
          
*/          
declare @colname nvarchar(max),@colname1 nvarchar(max) ,@colname2 nvarchar(max)                     
          
PRINT '------------------------------2----------------'          
          
           
PRINT @colname +CHAR(10)+'----------------------------------------'                       
                      
set @colname='select ''n'' AS 序号, '          
set @colname2='select ''n'' AS 序号, '          
          
--判断是否需要连接其它表          
IF(@joinTbl!='' AND @joinCol!='' AND @showCol!='')          
BEGIN          
set @colname +=(select ''''+name+''' AS '+ quotename(name)+',' from #jointbcol  WHERE NAME <> @joinCol for xml path('')) ;          
set @colname2 +=(select ''''+name+'1'+''' AS '+ quotename(name)+',' from #jointbcol  WHERE NAME <> @joinCol for xml path('')) ;          
          
END          
ELSE BEGIN          
set @colname +=' '''+@groupBy+''' AS '+@groupBy+',';          
set @colname2 +=' '''+@groupBy+'1'+''' AS '+@groupBy+',';          
END          
          
          
PRINT '------------------------------3----------------'        
          
set @colname +=(select ''''+name+''' AS '+ quotename(name)+',' from #tbcol WHERE NAME <> @joinCol for xml path('')) ;          
set @colname2 +=(select ''''+name+'1'+''' AS '+ quotename(name)+',' from #tbcol WHERE NAME <> @joinCol for xml path('')) ;          
 --需要列合计则添加列 "列合计"                     
if(@type=1 or @type=3)          
set @colname +='''列合计'' AS 列合计1' ;                     
else                
begin             
set @colname=LEFT(@colname,LEN(@colname)-1)            
set @colname2=LEFT(@colname2,LEN(@colname2)-1)          
END           
--------------------------------------------------------------------------           
          
set @colname1='select ''varchar,500'',';          
--判断是否需要连接其它表          
IF(@joinTbl!='' AND @joinCol!='' AND @showCol!='')          
BEGIN          
set @colname1+=( select '''varhcar,500'',' from #jointbcol  WHERE NAME <> @joinCol for xml path('')) ;          
END          
ELSE BEGIN          
SET @colname1+='''varchar,500'',';          
END          
          
SET @colname1 +=( select '''varhcar,500'',' from #tbcol  WHERE NAME <> @joinCol for xml path('')) ;          
          
--需要列合计则添加列 多拼接一列                     
if(@type=1 or @type=3)                      
set @colname1 +=' ''varchar,500'''                      
else                      
set @colname1=LEFT(@colname1,LEN(@colname1)-1)            
                                 
--------------------------------------------------------------------------             
          
          
set   @colname2=@colname2+char(10)+'union all'+CHAR(10)+ @colname1                      
 PRINT @colname2          
         PRINT '-----------------4----------------'        
exec (@colname2)                      
                              
--出表头结束==============================================================================          
-----------行转列            
declare @sql varchar(max)='' ,@sql_sumcol nvarchar(max)=''  ,@sql_sumrow NVARCHAR(max)                
                            
set @sql =(                              
select 'Max(case  when a.'+ @title+'='''+convert(varchar(500),name)   --isnull(       
  +''' then a.'+convert(varchar(500),@data) +' end) AS ['+convert(varchar(500),name)+'1],'    -- ,0)     
  +CHAR(10) from #tbcol for xml path('') )             
                                                
set @sql=left(@sql, len(@sql)-2)            
                            
print @sql                              
            
--------列合计                              
--set @sql_sumcol =(                              
--select '+isnull(SUM(case  when a.'+ @title+'='''+convert(varchar(500),name)          
--   +''' then a.'+convert(varchar(500),@data) +' end),0) '          
--   +CHAR(10) from #tbcol for xml path('') )                              
                              
--set @sql_sumcol=',('+stuff(@sql_sumcol, 1,1,'')+') as 列合计1'              
                      
--print  '************************************************'+CHAR(10)+ @sql_sumcol               
          
-- 行合计             
--IF(@joinTbl!='' AND @joinCol!='' AND @showCol!='')          
--BEGIN          
--set @sql_sumrow=( select  'null,' from #jointbcol for xml path('') )          
--END ELSE          
--BEGIN          
--set @sql_sumrow='null,'          
--END          
          
          
--set @sql_sumrow+=( select  'sum('+quotename(name)+'),' from #tbcol for xml path('') )              
          
--set @sql_sumrow=LEFT(@sql_sumrow,LEN(@sql_sumrow)-1)          
           
--print  '************************************************'+CHAR(10)+ @sql_sumrow             
-----------------------------------------------------------------------------------                     
declare @tablename varchar(500)                      
set @tablename='##page'                      
                       
if OBJECT_ID('tempdb.dbo.##page') is not null          
drop table ##page                   
          
          
--PRINT '------------------------------5----------------'             
          
if @orderBy='n'          
set @orderBy=@groupBy          
          
DECLARE @joinSql1 VARCHAR(max)='' , @joinSql2 VARCHAR(max)='', @joinSql3 VARCHAR(max)=''          
IF(@joinTbl!='' AND @joinCol!='' AND @showCol!='')          
BEGIN          
SET @joinSql1 = ( select 'b.['+name+'] ,' from #jointbcol for xml path('')) ;          
SET @joinSql2 = 'LEFT JOIN '+@joinTbl+' AS b ON a.'+@groupBy +' = b.'+@joinCol;          
SET @joinSql3 = ( select 'b.['+name+'] as '+quotename(name+'1')+',' from #jointbcol for xml path('')) ;       
END          
ELSE BEGIN          
SET @joinSql1 = 'a.'+@groupBy +',';          
END          
--print '--------------------'+@sql          
--PRINT  '123'          
--PRINT @joinSql1          
--PRINT  '234'          
--PRINT  @joinSql3           
                              
set @sql='select convert(varchar(500),row_number() over (order by '+@orderBy +'))n,* into ##page from ('          
  +CHAR(10)+'select '          
  +CHAR(10)+@joinSql3          
  +CHAR(10)+@sql    
        
  --+CHAR(10)+@sql_sumcol          
  +CHAR(10)+' from '+@table+  ' AS a '          
  +CHAR(10)+@joinSql2        
    
  +CHAR(10)+'group by '+LEFT(@joinSql1,LEN(@joinSql1)-1)            
  +CHAR(10)+')C '     --where isnull(列合计1,0)<>0                      
print '--------------------'+@sql           
                              
exec( @sql)                              
--根据结果需求处理并输出----------------------------------------------------          
--没有列行合计                      
if @type=0                      
BEGIN          
          
PRINT '------------------------------7----------------'            
          
--set @sql='alter table '+@tablename+' drop column 列合计1'            
--exec(@sql)            
          
PRINT '------------------------------8----------------'           
                      
exec('select * from '+ @tablename )          
end            
                          
              
                                 
end
go

