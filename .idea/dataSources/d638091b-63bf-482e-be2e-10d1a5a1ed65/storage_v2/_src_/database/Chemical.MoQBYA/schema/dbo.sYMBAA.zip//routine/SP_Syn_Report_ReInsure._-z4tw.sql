-- =============================================                
-- Author:  杨艺                
-- Create date: 2014-10-20                
-- Description: 综合报表_续保综合报表                
-- =============================================                
CREATE PROCEDURE [dbo].[SP_Syn_Report_ReInsure]                 
                
@Condition varchar(max)='Dim7:MRL:1%Dim4:1000'                                             
,@OrderFields varchar(100) = ''                                              
,@Type NVARCHAR(10) = '合计' -- 车系、保险公司、销售顾问、合计                
AS                
BEGIN                
                
-- 默认值                 
IF (@Condition = '')                
BEGIN                
 SET @Condition = 'Dim7:MRL:1%Dim4:1000'                
END                
                
IF (@OrderFields = '')                
BEGIN                
 SET @OrderFields = ''                
END                
                
                
                
-- 时间表  Dim7                
CREATE TABLE #time                
(                
 id              VARCHAR(500)                
 ,beginDate      DATETIME                
 ,endDate        DATETIME                
 ,beginDate_Lp   DATETIME                
 ,endDate_Lp     DATETIME                
 ,beginDate_Ly   DATETIME                
 ,endDate_Ly     DATETIME                
);                
                
-- 车系  Dim4                
create table #CarSeries                
(                
 VWID INT                
 ,[ID] INT                
 ,Name VARCHAR(500) DEFAULT ''                
);                
                
                
                
                
--解析维度数据                
exec [dbo].[Sp_Com_Getdimensions] @SIFtValue = @Condition                
                
-- 同比环比时间临时表                
CREATE TABLE #lplyTime                
(                
 ltype VARCHAR(10),                
 BeginDate DATETIME,                
 EndDate DATETIME                
)                
                
-- 保险数据临时表                
CREATE TABLE #TempData                
(                
 id INT IDENTITY,                
 ltype VARCHAR(5),                
 car INT,                
 channel INT,                
 Insure INT,                
 Emp INT,                
 cCount INT,                
 newInsureFee DECIMAL(18,2),                
 IsReInsure INT                
                 
)                
                
-- 最终结果数据                
CREATE TABLE #Result                
(                
 cType NVARCHAR(500), -- 名称                
 curCount INT, -- 当期台次                
 lyCount DECIMAL(18,2), -- 环比台次                
 lpCount DECIMAL(18,2), -- 同比台次                
 curNewInsureFee DECIMAL(18,2), -- 当期手续费                
 lyNewInsureFee DECIMAL(18,2), -- 环比手续费                
 lpNewInsureFee DECIMAL(18,2), -- 同比手续费                
 newInsureFeeGp decimal(18,2), -- 手续费组内占比                
 lyGrown decimal(18,2), -- 手续费同增                
 lpGrown decimal(18,2), -- 手续费环增                
 curNewInsurePercent DECIMAL(18,2), -- 新保台次占比                
 lyNewInsurePercent DECIMAL(18,2), -- 新保占比环增                
 lpNewInsurePercent DECIMAL(18,2), -- 新保占比同增                
 curBusInsure varchar(10),  -- 当期商业险渗透率                
 lyBusInsure varchar(10),  -- 环比商业险渗透率                
 lpBusInsure varchar(10),  -- 同比商业险渗透率                
)                
                
-- 排序结果集                
CREATE TABLE #ResultOrder                
(                
 id INT,                
 cType NVARCHAR(500), -- 名称                
 curCount INT, -- 当期台次                
 lyCount DECIMAL(18,2), -- 环比台次                
 lpCount DECIMAL(18,2), -- 同比台次                
 curNewInsureFee DECIMAL(18,2), -- 当期手续费                
 lyNewInsureFee DECIMAL(18,2), -- 环比手续费                
 lpNewInsureFee DECIMAL(18,2), -- 同比手续费                
 newInsureFeeGp decimal(18,2), -- 手续费组内占比                
 lyGrown decimal(18,2), -- 手续费同增                
 lpGrown decimal(18,2), -- 手续费环增                
 curNewInsurePercent DECIMAL(18,2), -- 新保台次占比                
 lyNewInsurePercent DECIMAL(18,2), -- 新保占比环增                
 lpNewInsurePercent DECIMAL(18,2), -- 新保占比同增                
 curBusInsure varchar(10),  -- 当期商业险渗透率                
 lyBusInsure varchar(10),  -- 环比商业险渗透率                
 lpBusInsure varchar(10),  -- 同比商业险渗透率              
)                
                
                
CREATE TABLE #ResultSales                
(                
 ltype  VARCHAR(10) NULL,                
 carSeriesID INT NULL,                
 carName  NVARCHAR(50),                
 InsurerID INT NULL,         
 InsureName  NVARCHAR(50) NULL,                
 EmpID  INT NULL,                
 EmpName  NVARCHAR(50)                
                 
)                
                
                
                
-- 得到环比同比时间表                
INSERT #lplyTime  ( ltype ,BeginDate ,EndDate )                
SELECT 'cur',BeginDate,endDate FROM #time                
UNION ALL                
SELECT 'lp',beginDate_Lp,endDate_Lp FROM #time                
UNION ALL                
SELECT 'ly',beginDate_Ly,endDate_Ly FROM #time                
                
--SELECT * FROM #time                
--SELECT * FROM #lplytime                
--SELECT * FROM #CarSeries                
--SELECT * FROM #SaleChannel                
--RETURN                
            
--车系维度            
UPDATE CS SET CS.Name = isnull(TCS.Name,'未知')                          
FROM #CarSeries AS CS                          
LEFT JOIN Tbl_Base_CarSeries AS TCS ON TCS.CarSeriesID = CS.ID                  
                
                
-- 统计各分组的销售数据   (保险到期数)             
INSERT #ResultSales  ( ltype ,carSeriesID,carName ,EmpID ,EmpName,InsurerID,InsureName )                
SELECT t.ltype,cs.ID AS CarSeriesID,cs.Name,css.EmpID,e.EmpName,css.InsurerID,bis.Name                
FROM                 
(SELECT i.FrameNum,i.InsureBegin--,i.Date InsureEnd    
,i.EmpID,i.InsurerID,i.InsureEnd 
FROM dbo.Tbl_Sales_Insure i                
 UNION ALL                
 SELECT ai.FrameNum,ai.InsureBegin--,ai.Date InsureEnd    
 ,ai.EmpID,ai.InsurerID,ai.InsureEnd     
 FROM dbo.Tbl_Sales_AftsInsure ai     
 ) AS css                
LEFT JOIN dbo.Tbl_Base_Car bc ON css.FrameNum = bc.FrameNum                
INNER JOIN #lplyTime AS t ON css.InsureEnd BETWEEN t.beginDate AND t.endDate    
--INNER JOIN #lplyTime AS t ON  css.InsureEnd <= t.beginDate             
INNER JOIN #CarSeries AS cs ON ISNULL(bc.CarSeriesID,0) = cs.ID                
LEFT JOIN dbo.Tbl_Com_Employee e ON e.EmpID = css.EmpID                 
LEFT JOIN dbo.Tbl_Base_Insurer bis ON css.InsurerID = bis.InsurerID     

--
SELECT t.ltype,cs.ID AS CarSeriesID,cs.Name as CarSeriesName,css.EmpID,e.EmpName,css.InsurerID,bis.Name
into #Result_All                
FROM                 
(SELECT i.FrameNum,i.InsureBegin,i.Date InsureEnd    
,i.EmpID,i.InsurerID--,i.InsureEnd 
FROM dbo.Tbl_Sales_Insure i                
 UNION ALL                
 SELECT ai.FrameNum,ai.InsureBegin,ai.Date InsureEnd    
 ,ai.EmpID,ai.InsurerID--,ai.InsureEnd     
 FROM dbo.Tbl_Sales_AftsInsure ai     
 ) AS css                
LEFT JOIN dbo.Tbl_Base_Car bc ON css.FrameNum = bc.FrameNum                
INNER JOIN #lplyTime AS t ON css.InsureEnd BETWEEN t.beginDate AND t.endDate    
--INNER JOIN #lplyTime AS t ON  css.InsureEnd <= t.beginDate             
INNER JOIN #CarSeries AS cs ON ISNULL(bc.CarSeriesID,0) = cs.ID                
LEFT JOIN dbo.Tbl_Com_Employee e ON e.EmpID = css.EmpID                 
LEFT JOIN dbo.Tbl_Base_Insurer bis ON css.InsurerID = bis.InsurerID 


           
                
 --SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur'               

--select * from #lplyTime

                
-- 得到计算所需要的数据，再根据转入的TYPE进行具体的分组聚合计算                
INSERT #TempData  ( ltype ,car 
,Insure ,Emp ,cCount ,newInsureFee ,IsReInsure)                
                
SELECT                 
 t.ltype AS ltype,                
 cs.ID AS car,                
 si.InsurerID AS Insure,                
 si.EmpID AS Emp,                
 1 AS cCount,                
 ISNULL(si.BusInsureAmount,0) * ISNULL(si.BusInsureRate,0) + ISNULL(si.TrafficInsureAmount,0) * ISNULL(si.TrafficInsureRate,0) AS newInsureFee,                
 CASE WHEN ISNULL(si.BusInsureAmount,0) + ISNULL(si.TrafficInsureAmount,0) > 0 THEN 1 ELSE 0 END AS IsReInsure                
                 
FROM dbo.Tbl_Sales_AftsInsure AS si                 
LEFT JOIN dbo.Tbl_Sales_CarSales css ON si.FrameNum = css.FrameNum                
LEFT JOIN dbo.Tbl_Base_Car bc ON si.FrameNum = bc.FrameNum                
INNER JOIN #lplyTime AS t ON Date BETWEEN t.beginDate AND t.endDate                
INNER JOIN #CarSeries AS cs ON ISNULL(bc.CarSeriesID,0) = cs.ID         --SP_Syn_Report_ReInsure      
      
 --select  SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END) from #TempData    
 --select * from   #TempData
       
 -- SELECT                 
 --  '续保率'                
 --  -- 商业险                
 -- ,CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2) )      
 -- /NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur')),0) * 100       
 --from #TempData      
                
                
-- 得到组内所有手续费用总和                
DECLARE @curTotalInsureFee DECIMAL(18,2)                
,  @lyTotalInsureFee DECIMAL(18,2)                
,  @lpTotalInsureFee DECIMAL(18,2)                
                
SELECT @curTotalInsureFee = SUM(ISNULL(newInsureFee,0)) FROM #TempData WHERE ltype = 'cur'                
SELECT @lpTotalInsureFee = SUM(ISNULL(newInsureFee,0)) FROM #TempData WHERE ltype = 'lp'                
SELECT @lyTotalInsureFee = SUM(ISNULL(newInsureFee,0)) FROM #TempData WHERE ltype = 'ly'                
                
                
IF (@Type = '车系')                
BEGIN                
                
 INSERT #Result ( cType ,curCount ,lyCount ,lpCount ,curNewInsureFee ,lyNewInsureFee ,lpNewInsureFee, newInsureFeeGp,lyGrown,lpGrown ,curBusInsure ,lyBusInsure ,lpBusInsure )                
 SELECT                 
  ISNULL(cs.Name,'未知车系')                
                  
  -- 台次                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0))                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0))                
                  
  -- 手续费用                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0))                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0))                
                  
                 
  -- 手续费组内占比                
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@curTotalInsureFee),0) * 100 AS DECIMAL(18,2))                
  -- 手续费组内占比同增                
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@curTotalInsureFee),0) * 100 AS DECIMAL(18,2)) -                
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2))  / NULLIF(ABS(@lpTotalInsureFee),0) * 100 AS DECIMAL(18,2))                
-- 手续费组内占比环增                
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@curTotalInsureFee),0) * 100 AS DECIMAL(18,2)) -                
  CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0) AS DECIMAL(18,2)) / NULLIF(ABS(@lyTotalInsureFee),0) * 100 AS DECIMAL(18,2))                
                  
                 
  -- 续保率                
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND carName = cs.Name),0)) * 100 AS DECIMAL(18,2))                
                 
 , ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND carName = cs.Name),0)) * 100 AS DECIMAL(18,2)),0) -                
  ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly' AND carName = cs.Name),0)) * 100 AS DECIMAL(18,2)),0)                
                 
 , ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND carName = cs.Name),0)) * 100.00 AS DECIMAL(18,2)),0) -                
  ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp' AND carName = cs.Name),0)) * 100.00 AS DECIMAL(18,2)),0)                
                  
 FROM #TempData t             
 LEFT JOIN #CarSeries cs ON t.car = cs.ID                
 GROUP BY cs.Name                
                 
END                
ELSE IF (@Type = '保险公司')                
BEGIN                
                 
 DECLARE @curCount INT                
   ,@lyCount INT                
   ,@lpCount INT                
 -- 提前计算出要使用的分母 提高运行速度                
 SELECT @curCount = COUNT(1) FROM #tempData WHERE ltype = 'cur'                
 SELECT @lyCount = COUNT(1) FROM #tempData WHERE ltype = 'ly'                
 SELECT @lpCount = COUNT(1) FROM #tempData WHERE ltype = 'lp'                
                 
 INSERT #Result ( cType ,curCount ,lyCount ,lpCount ,curNewInsureFee ,lyNewInsureFee ,lpNewInsureFee, curNewInsurePercent, lpNewInsurePercent, lyNewInsurePercent,curBusInsure ,lyBusInsure ,lpBusInsure )                
 SELECT --newInsureFeeGp lyGrown lpGrown                
  ISNULL(bi.Name,'未知保险公司')                
  -- 台次                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0))                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0))                
  -- 手续费用                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0))                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0))                
                 
  -- 续保台次占比                
, ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@curCount,0))                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@curCount,0)) -                
  ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@lyCount,0))                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@curCount,0)) -                
  ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0) * 100.00 / ABS(NULLIF(@lpCount,0))                 
                  
  -- 续保率                
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND InsureName = bi.Name),0) * 100 AS DECIMAL(18,2))                
                 
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND InsureName = bi.Name),0) * 100 AS DECIMAL(18,2)) -                
  ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly' AND InsureName = bi.Name),0) * 100 AS DECIMAL(18,2)),0)                
                 
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND InsureName = bi.Name),0) * 100 AS DECIMAL(18,2)) -                 
  ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp' AND InsureName = bi.Name),0) * 100 AS DECIMAL(18,2)),0)                
                 
 FROM #TempData t LEFT JOIN dbo.Tbl_Base_Insurer bi on t.Insure = bi.InsurerID                
 --WHERE bi.Name IS NOT NULL                
 GROUP BY bi.Name                
                 
END                
ELSE IF (@Type = '销售顾问')                
BEGIN                
                 
 INSERT #Result ( cType ,curCount ,lyCount ,lpCount ,curNewInsureFee ,lyNewInsureFee ,lpNewInsureFee ,curBusInsure ,lyBusInsure ,lpBusInsure )                
 SELECT                 
  ISNULL(e.EmpName,'未知销售顾问')                
  -- 台次                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0)                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0))                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0))                
  -- 手续费用                
 , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0))                
 , (ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
  / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0))                
  -- 续保率                
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND EmpName = e.EmpName),0) * 100 AS DECIMAL(18,2))                
                 
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND EmpName = e.EmpName),0)) * 100 AS DECIMAL(18,2)) -                
  ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly' AND EmpName = e.EmpName),0)) * 100 AS DECIMAL(18,2)),0)                
                 
 , CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur' AND EmpName = e.EmpName),0)) * 100 AS DECIMAL(18,2)) -                 
  ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
  / ABS(NULLIF((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp' AND EmpName = e.EmpName),0)) * 100 AS DECIMAL(18,2)),0)                
                 
 FROM #TempData t LEFT JOIN dbo.Tbl_Com_Employee e ON t.Emp = e.EmpID                
 --WHERE e.EmpName IS NOT NULL                 
 GROUP BY e.EmpName                
                 
END                
          
                
IF (@Type = '合计')                
BEGIN                
                 
 SELECT  '续保台次' AS '指标名称'                
   -- 台次                
  , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) AS '数值'                
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) * 100.00                 
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2)),0) AS '同比'                
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN cCount ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) * 100.00                 
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN cCount ELSE 0 END),0)) AS DECIMAL(18,2)),0) AS '环比'                
 FROM #TempData                
                 
 UNION ALL                
                 
 SELECT                 
   '手续费用'                
   -- 手续费用                
  , ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0)                
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'ly' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2)),0)                
  , ISNULL(CAST((ISNULL(SUM(CASE WHEN ltype = 'cur' THEN newInsureFee ELSE 0 END),0) - ISNULL(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) * 100.00                 
   / ABS(NULLIF(SUM(CASE WHEN ltype = 'lp' THEN newInsureFee ELSE 0 END),0)) AS DECIMAL(18,2)),0)                
 FROM #TempData                
                 
 UNION ALL                 
                 
 SELECT                 
   '续保率'                
   -- 商业险                
  , ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur')),0) * 100 AS DECIMAL(18,2)),0)                
                  
  , (ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur')),0) * 100 AS DECIMAL(18,2))       
   -                 
   ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly')),0) * 100 AS DECIMAL(18,2)),0),0)      
   )        
   --/      
   --Nullif(ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'ly' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   --/ NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'ly')),0) * 100 AS DECIMAL(18,2)),0),0)              
         
                  
  , (ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'cur' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'cur')),0) * 100 AS DECIMAL(18,2))       
   -                 
   ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   / NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp')),0) * 100 AS DECIMAL(18,2)),0),0)                
   )      
   --/       
   --Nullif(ISNULL(CAST(CAST(ISNULL(SUM(CASE WHEN ltype = 'lp' THEN IsReInsure ELSE 0 END),0) AS DECIMAL(18,2))                 
   --/ NULLIF(ABS((SELECT COUNT(1) FROM #ResultSales WHERE ltype = 'lp')),0) * 100 AS DECIMAL(18,2)),0),0)              
 FROM #TempData          
         
   insert into Tbl_Com_AnaUseLog                              
(EmpID,freshTime,spName,AnaName,siftvalue,OherParemeter)                              
values (0,GETDATE(),'SP_Syn_Report_ReInsure','续保综合报表',@Condition                              
,'@Type='+@Type+',@EmpID='+'0')                
                 
END                
ELSE                
BEGIN               
                
 IF (@OrderFields = '')                
 BEGIN                
  SET @OrderFields = 'cType'                
 END                
                
 DECLARE @sql VARCHAR(MAX)                
                
 SET @sql = 'INSERT #ResultOrder                
    SELECT                 
    ROW_NUMBER() OVER (ORDER BY ' + @OrderFields + '),*                
    FROM #Result'                 
                
 --PRINT @sql                
 EXEC (@sql)                
                 
 -- 输出结果                
                
 SELECT * FROM #ResultOrder ORDER BY id                
                 
                 
END                
                
                
                
                
                
                
            
                
-- 释放临时表空间 -----------------------------------------                
                
IF OBJECT_ID('tempdb..#lylptime') IS NOT NULL                
BEGIN                
 DROP TABLE #lylptime                
END                
                
IF OBJECT_ID('tempdb..#time') IS NOT NULL                
BEGIN                
 DROP TABLE #time                
END                
                
IF OBJECT_ID('tempdb..#CarSeries') IS NOT NULL                
BEGIN                
 DROP TABLE #CarSeries                
END                
                
                
IF OBJECT_ID('tempdb..#TempData') IS NOT NULL                
BEGIN                
 DROP TABLE #TempData                
END                
                
IF OBJECT_ID('tempdb..#Result') IS NOT NULL                
BEGIN                
 DROP TABLE #Result                
END                
                
                
IF OBJECT_ID('tempdb..#ResultOrder') IS NOT NULL                
BEGIN                
 DROP TABLE #ResultOrder                
END                
                
END
go

