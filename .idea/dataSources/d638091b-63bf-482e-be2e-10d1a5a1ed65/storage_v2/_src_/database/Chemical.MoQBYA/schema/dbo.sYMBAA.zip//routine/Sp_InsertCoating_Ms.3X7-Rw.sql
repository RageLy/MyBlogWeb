
-- =============================================                            
-- Author: hmw                                            
-- Create Date: 2017年5月26日                                                  
-- Descript: 从Excel插入白色颜料  
-- =============================================                   
--   exec [Sp_InsertCoating_Ms]  
CREATE PROCEDURE [dbo].[Sp_InsertCoating_Ms]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_CoatingMs
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_CoatingMs
                            GROUP BY 墨水批次
                        );

        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_CoatingMs
                           );
        PRINT '开始插入Tbl_Base_401G数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_401G ( Ms401G )
                    SELECT DISTINCT [来料批次401G]
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_401G
                                          WHERE  [来料批次401G] = Ms401G
                                      )
                           AND [来料批次401G] IS NOT NULL;
        PRINT '表Tbl_Base_401G数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_D207E数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_D207E (   D207E ,
                                           D207EGHL ,
                                           D207END ,
                                           D207EPH
                                       )
                    SELECT DISTINCT D207E来料批次 ,
                           D207E固含量 ,
                           D207E粘度 ,
                           D207EpH值
                    FROM   dbo.TempTb_CoatingMs_D207E
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_D207E
                                          WHERE  D207E来料批次 = D207E
                                      )
                           AND D207E来料批次 IS NOT NULL;
        PRINT '表Tbl_Base_D207E数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_P100T数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_P100T (   P100T ,
                                           P100TGHL ,
                                           P100TND ,
                                           P100TPH
                                       )
                    SELECT DISTINCT P100T配制时间 ,
                           P100T固含量 ,
                           P100T粘度 ,
                           P100TpH值
                    FROM   dbo.TempTb_CoatingMs_P100T
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_P100T
                                          WHERE  P100T配制时间 = P100T
                                      )
                           AND P100T配制时间 IS NOT NULL;
        PRINT '表Tbl_Base_P100T数据插入完毕，继续下一步';



        PRINT '开始插入Tbl_Base_MpSeries数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MpSeries ( MpSeries )
                    SELECT DISTINCT 墨水系列
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MpSeries
                                          WHERE  墨水系列 = MpSeries
                                      )
                           AND 墨水系列 IS NOT NULL;
        PRINT '表Tbl_Base_MpSeries数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_NhjType数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_NhjType ( NhjType )
                    SELECT DISTINCT 黏合剂类型
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_NhjType
                                          WHERE  黏合剂类型 = NhjType
                                      )
                           AND 黏合剂类型 IS NOT NULL;
        PRINT '表Tbl_Base_NhjType数据插入完毕，继续下一步';

		 PRINT '开始插入Tbl_Base_NhjType数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_ZcjType ( ZcjType )
                    SELECT DISTINCT 增稠剂类型
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_ZcjType
                                          WHERE  增稠剂类型 = ZcjType
                                      )
                           AND 增稠剂类型 IS NOT NULL;
        PRINT '表Tbl_Base_NhjType数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsLpjCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MsLpjCode ( MsLpjCode )
                    SELECT DISTINCT 流平剂类型
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MsLpjCode
                                          WHERE  流平剂类型 = MsLpjCode
                                      )
                           AND 流平剂类型 IS NOT NULL;
        PRINT '表Tbl_Base_MsLpjCode数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsWaterType数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MsWaterType ( MsWaterType )
                    SELECT DISTINCT 配墨水类型
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MsWaterType
                                          WHERE  配墨水类型 = MsWaterType
                                      )
                           AND 配墨水类型 IS NOT NULL;
        PRINT '表Tbl_Base_MsWaterType数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsZCJLLCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MsZCJLLCode ( MsZCJLLCode )
                    SELECT DISTINCT 增稠剂来料批次
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MsZCJLLCode
                                          WHERE  增稠剂来料批次 = MsZCJLLCode
                                      )
                           AND 增稠剂来料批次 IS NOT NULL;
        PRINT '表Tbl_Base_MsZCJLLCode数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsFSJLLCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MsFSJLLCode ( MsFSJLLCode )
                    SELECT DISTINCT 分散剂来料批次
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MsFSJLLCode
                                          WHERE  分散剂来料批次 = MsFSJLLCode
                                      )
                           AND 分散剂来料批次 IS NOT NULL;
        PRINT '表Tbl_Base_MsFSJLLCode数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsLpjLLCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MsLpjLLCode ( MsLpjLLCode )
                    SELECT DISTINCT 流平剂来料批次
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MsLpjLLCode
                                          WHERE  流平剂来料批次 = MsLpjLLCode
                                      )
                           AND 流平剂来料批次 IS NOT NULL;
        PRINT '表Tbl_Base_MsLpjLLCode数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsNHJPZDate数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MsNHJPZDate ( MsNHJPZDate )
                    SELECT DISTINCT 黏合剂配制时间
                    FROM   dbo.TempTb_CoatingMs
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MsNHJPZDate
                                          WHERE  黏合剂配制时间 = MsNHJPZDate
                                      )
                           AND 黏合剂配制时间 IS NOT NULL;
        PRINT '表Tbl_Base_MsNHJPZDate数据插入完毕，继续下一步';
        UPDATE dbo.Tbl_Base_D207E
        SET    D207EGHL = D207E固含量 ,
               D207END = D207E粘度 ,
               D207EPH = D207EpH值
        FROM   dbo.TempTb_CoatingMs_D207E
        WHERE  D207E = D207E来料批次;
        UPDATE dbo.Tbl_Base_P100T
        SET    P100TGHL = P100T固含量 ,
               P100TND = P100T粘度 ,
               P100TPH = P100TpH值
        FROM   dbo.TempTb_CoatingMs_P100T
        WHERE  P100T = P100T配制时间;

        UPDATE dbo.Bs_Coating_MS
        SET    Optdate = 配墨日期 ,
               MpSeries = MpSeries.ID ,
			   CapsuleDynamicCode=CapsuleDynamic.Code,
               DouCapsule1 = DouCapsule1.ID ,
               DouCapsule2 = DouCapsule2.ID ,
               DouCapsule3 = DouCapsule3.ID ,
               DouCapsule4 = DouCapsule4.ID ,
               DouCapsule5 = DouCapsule5.ID ,
               DouCapsule6 = DouCapsule6.ID ,
               NhjType = NhjType.ID ,
               NhjGHL = 黏合剂固含量 ,
               NhjND = 黏合剂粘度 ,
               NhjPH = 黏合剂pH值 ,
               ZcjND = 增稠剂浓度 ,
               ZcjGHL = 增稠剂固含量 ,
               ZcjPH = 增稠剂pH值 ,
               MsFsjUse = 分散剂SF0001加入量 ,
               MsLpjCode = MsLpjCode.ID ,
               MsLpjUse = 流平剂加入量 ,
               MsNhjUse = 黏合剂加入量 ,
               MsZcjUse = 增稠剂BG0013加入量 ,
               MsXpjUse = 消泡剂SF0011加入量 ,
               MsCapsulePH = 配墨胶囊pH ,
               MsWaterType = MsWaterType.ID ,
               MsWaterPH = 配墨水pH ,
               MsWaterDDlps = 配墨水电导率 ,
               MsLPH = 料pH ,
               MsPH1 = 配墨中pH1 ,
               MsPH2 = 配墨中pH2 ,
               MsOverPH = 墨水收集时pH ,
               MsOverND = 墨水粘度 ,
               MsOverGHL = 墨水固含量 ,
               MsOverZL = 墨水张力 ,
               MsNdBe = 涂前墨水粘度 ,
               MsGhlBe = 涂前墨水固含量 ,
               Remark = 备注 ,
               ZCJNID = 增稠剂粘度 ,
			   ZCJSUse=增稠剂S加入量,
               CapsuleDynamicId = CapsuleDynamic.ID ,
               ZCJPZDate = 增稠剂配制时间 ,
			   ZCJType=ZcjType.ID,
               MsZCJLLCode = MsZCJLLCode.ID ,
               MsFSJLLCode = MsFSJLLCode.ID ,
               MsLpjLLCode = MsLpjLLCode.ID ,
               Ms401G = Ms401G.ID ,
               D207E = D207E.ID ,
               P100T = P100T.ID ,
			   LL401Use=来料401加入量,
			   WEQUse=戊二醛加入量,
               MsNHJPZDate = MsNHJPZDate.ID ,
               updateDate = GETDATE()
        FROM   dbo.TempTb_CoatingMs
               LEFT JOIN dbo.Bs_CapsuleDynamic CapsuleDynamic ON CapsuleDynamic.Code = TempTb_CoatingMs.墨水批次
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule1 ON DouCapsule1.ID = CapsuleDynamic.DouCapsule1
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule2 ON DouCapsule2.ID = CapsuleDynamic.DouCapsule2
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule3 ON DouCapsule3.ID = CapsuleDynamic.DouCapsule3
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule4 ON DouCapsule4.ID = CapsuleDynamic.DouCapsule4
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule5 ON DouCapsule5.ID = CapsuleDynamic.DouCapsule5
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule6 ON DouCapsule6.ID = CapsuleDynamic.DouCapsule6
               LEFT JOIN dbo.Tbl_Base_MpSeries MpSeries ON MpSeries.MpSeries = TempTb_CoatingMs.墨水系列
               LEFT JOIN Tbl_Base_NhjType NhjType ON NhjType.NhjType = TempTb_CoatingMs.黏合剂类型
			   LEFT JOIN Tbl_Base_ZcjType ZcjType ON ZcjType.zcjType = TempTb_CoatingMs.增稠剂类型
               LEFT JOIN Tbl_Base_MsLpjCode MsLpjCode ON MsLpjCode.MsLpjCode = TempTb_CoatingMs.流平剂类型
               LEFT JOIN Tbl_Base_MsWaterType MsWaterType ON MsWaterType.MsWaterType = TempTb_CoatingMs.配墨水类型
               LEFT JOIN Tbl_Base_MsZCJLLCode MsZCJLLCode ON MsZCJLLCode.MsZCJLLCode = TempTb_CoatingMs.增稠剂来料批次
               LEFT JOIN Tbl_Base_MsFSJLLCode MsFSJLLCode ON MsFSJLLCode.MsFSJLLCode = TempTb_CoatingMs.分散剂来料批次
               LEFT JOIN Tbl_Base_MsLpjLLCode MsLpjLLCode ON MsLpjLLCode.MsLpjLLCode = TempTb_CoatingMs.流平剂来料批次
               LEFT JOIN Tbl_Base_401G Ms401G ON Ms401G.Ms401G = TempTb_CoatingMs.[来料批次401G]
               LEFT JOIN Tbl_Base_D207E D207E ON D207E.D207E = TempTb_CoatingMs.D207E来料批次
               LEFT JOIN Tbl_Base_P100T P100T ON P100T.P100T = TempTb_CoatingMs.P100T配制时间
               LEFT JOIN Tbl_Base_MsNHJPZDate MsNHJPZDate ON MsNHJPZDate.MsNHJPZDate = TempTb_CoatingMs.黏合剂配制时间
        WHERE  Bs_Coating_MS.Code = 墨水批次;
        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_Coating_MS
                                            INNER JOIN dbo.TempTb_CoatingMs ON TempTb_CoatingMs.墨水批次 = Bs_Coating_MS.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;
        INSERT INTO dbo.Bs_Coating_MS (   Optdate ,
                                          Code ,
										  CapsuleDynamicCode,
                                          MpSeries ,
                                          DouCapsule1 ,
                                          DouCapsule2 ,
                                          DouCapsule3 ,
                                          DouCapsule4 ,
                                          DouCapsule5 ,
                                          DouCapsule6 ,
                                          NhjType ,
                                          NhjGHL ,
                                          NhjND ,
                                          NhjPH ,
                                          ZcjND ,
                                          ZcjGHL ,
                                          ZcjPH ,
                                          MsFsjUse ,
                                          MsLpjCode ,
                                          MsLpjUse ,
                                          MsNhjUse ,
                                          MsZcjUse ,
                                          MsXpjUse ,
                                          MsCapsulePH ,
                                          MsWaterType ,
                                          MsWaterPH ,
                                          MsWaterDDlps ,
                                          MsLPH ,
                                          MsPH1 ,
                                          MsPH2 ,
                                          MsOverPH ,
                                          MsOverND ,
                                          MsOverGHL ,
                                          MsOverZL ,
                                          MsNdBe ,
                                          MsGhlBe ,
                                          Remark ,
                                          ZCJNID ,
                                          CapsuleDynamicId ,
                                          ZCJPZDate ,
										  ZcjType,
										  ZCJSUse,
                                          MsZCJLLCode ,
                                          MsFSJLLCode ,
                                          MsLpjLLCode ,
                                          Ms401G ,
                                          D207E ,
                                          P100T ,
										  LL401Use,
										  WEQUse,
                                          MsNHJPZDate ,
                                          updateDate
                                      )
                    SELECT 配墨日期 ,
                           墨水批次 ,
						   CapsuleDynamic.Code,
                           MpSeries.ID ,
                           DouCapsule1.ID ,
                           DouCapsule2.ID ,
                           DouCapsule3.ID ,
                           DouCapsule4.ID ,
                           DouCapsule5.ID ,
                           DouCapsule6.ID ,
                           NhjType.ID ,
                           黏合剂固含量 ,
                           黏合剂粘度 ,
                           黏合剂pH值 ,
                           增稠剂浓度 ,
                           增稠剂固含量 ,
                           增稠剂pH值 ,
                           分散剂SF0001加入量 ,
                           MsLpjCode.ID ,
                           流平剂加入量 ,
                           黏合剂加入量 ,
                           增稠剂BG0013加入量 ,
                           消泡剂SF0011加入量 ,
                           配墨胶囊pH ,
                           MsWaterType.ID ,
                           配墨水pH ,
                           配墨水电导率 ,
                           料pH ,
                           配墨中pH1 ,
                           配墨中pH2 ,
                           墨水收集时pH ,
                           墨水粘度 ,
                           墨水固含量 ,
                           墨水张力 ,
                           涂前墨水粘度 ,
                           涂前墨水固含量 ,
                           备注 ,
                           增稠剂粘度 ,
                           CapsuleDynamic.ID ,
                           增稠剂配制时间 ,
						   ZcjType.ID,
						   增稠剂S加入量,
                           MsZCJLLCode.ID ,
                           MsFSJLLCode.ID ,
                           MsLpjLLCode.ID ,
                           Ms401G.ID ,
                           D207E.ID ,
                           P100T.ID ,
						   来料401加入量,
						   戊二醛加入量,
                           MsNHJPZDate.ID ,
                           GETDATE()
                    FROM   dbo.TempTb_CoatingMs
                           LEFT JOIN dbo.Bs_CapsuleDynamic CapsuleDynamic ON CapsuleDynamic.Code = TempTb_CoatingMs.墨水批次
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule1 ON DouCapsule1.ID = CapsuleDynamic.DouCapsule1
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule2 ON DouCapsule2.ID = CapsuleDynamic.DouCapsule2
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule3 ON DouCapsule3.ID = CapsuleDynamic.DouCapsule3
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule4 ON DouCapsule4.ID = CapsuleDynamic.DouCapsule4
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule5 ON DouCapsule5.ID = CapsuleDynamic.DouCapsule5
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule6 ON DouCapsule6.ID = CapsuleDynamic.DouCapsule6
                           LEFT JOIN dbo.Tbl_Base_MpSeries MpSeries ON MpSeries.MpSeries = TempTb_CoatingMs.墨水系列
						   LEFT JOIN Tbl_Base_ZcjType ZcjType ON ZcjType.zcjType = TempTb_CoatingMs.增稠剂类型
                           LEFT JOIN Tbl_Base_NhjType NhjType ON NhjType.NhjType = TempTb_CoatingMs.黏合剂类型
                           LEFT JOIN Tbl_Base_MsLpjCode MsLpjCode ON MsLpjCode.MsLpjCode = TempTb_CoatingMs.流平剂类型
                           LEFT JOIN Tbl_Base_MsWaterType MsWaterType ON MsWaterType.MsWaterType = TempTb_CoatingMs.配墨水类型
                           LEFT JOIN Tbl_Base_MsZCJLLCode MsZCJLLCode ON MsZCJLLCode.MsZCJLLCode = TempTb_CoatingMs.增稠剂来料批次
                           LEFT JOIN Tbl_Base_MsFSJLLCode MsFSJLLCode ON MsFSJLLCode.MsFSJLLCode = TempTb_CoatingMs.分散剂来料批次
                           LEFT JOIN Tbl_Base_MsLpjLLCode MsLpjLLCode ON MsLpjLLCode.MsLpjLLCode = TempTb_CoatingMs.流平剂来料批次
                           LEFT JOIN Tbl_Base_401G Ms401G ON Ms401G.Ms401G = TempTb_CoatingMs.[来料批次401G]
                           LEFT JOIN Tbl_Base_D207E D207E ON D207E.D207E = TempTb_CoatingMs.D207E来料批次
                           LEFT JOIN Tbl_Base_P100T P100T ON P100T.P100T = TempTb_CoatingMs.P100T配制时间
                           LEFT JOIN Tbl_Base_MsNHJPZDate MsNHJPZDate ON MsNHJPZDate.MsNHJPZDate = TempTb_CoatingMs.黏合剂配制时间
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_Coating_MS
                                          WHERE  Code = 墨水批次
                                      )
                           AND 墨水批次 IS NOT NULL;

    END;
go

