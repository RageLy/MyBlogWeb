      
/*            
行转列通用 sp    yind            
            
调用示例            
            
            
if OBJECT_ID('tempdb.dbo.#tt') is not null            
drop table #tt            
            
create table #tt            
(            
name1 varchar(50)            
,lev varchar(50)             
,core int            
)            
            
--insert into #tt(name1,lev,core)            
--values('ss','1fd',93)            
--,('ss','fds',193)            
--,('ss','ghgg',3)            
--,('kk','ghgg',13)            
--,('ff','ghgg',173)            
--,('ff','fds',133)            
--,('ff','1fd',23)            
          
            
EXEC  dbo.RowToColumn_ForBoardChat @table='#tt',@title='lev',@data='core',@groupBy='name1',@orderBy='name1'            
            
            
            
*/            
            
            
            
CREATE proc [dbo].[RowToColumn_ForBoardChat]            
(                  
 @table varchar(50)='#table',-------  需要转换的table名字，table是3列                  
 @title varchar(50)='col',   -------  需要把数据转换为列的列名               
 @data varchar(50)='col2',   -------  需要取值的列名      
 @groupBy varchar(200)='',  ----  需要分组的列              
 @orderBy varchar(200)=''   ----  排序             
)                    
as            
begin                    
         
declare @sql varchar(max)='' ,@Sql_Columns   varchar(max)=''          
       
------- 需要转的列信息            
create table #tbcol            
(            
name nvarchar(500)            
)            
insert into #tbcol            
exec( 'select distinct '+ @title +' from ' +@table)            
  print 2          
set @Sql_Columns            
=(            
select   'isnull(max(case  when '+ @title+'='''+convert(varchar(500),name)+''' then '+convert(varchar(500),@data) +'   end),0) ['+convert(varchar(50),name)+'],'+CHAR(10) from #tbcol for xml path('') )            
          
set @Sql_Columns=left(@Sql_Columns, len(@Sql_Columns)-2)
            
      
            
            
  set @sql=@sql+'if not exists(select 1 from '+@table+')'
  set @sql=@sql+CHAR(10)+'BEGIN'
  set @sql=@sql+CHAR(10)+' select '
	IF(@groupBy<>'')
	BEGIN
		set @sql=@sql+''' '' as '+@groupBy +',' 
	END	
	set @sql=@sql+ ''' '' as Value'	
	
  set @sql=@sql+CHAR(10)+'END'
  set @sql=@sql+CHAR(10)+'ELSE'
  set @sql=@sql+CHAR(10)+'BEGIN'

	set @sql=@sql+CHAR(10)+'select '
	IF(@groupBy<>'')
	BEGIN
		set @sql=@sql+@groupBy +',' 
	END
	set @sql=case when isnull(@Sql_Columns,'')='' and @groupBy <> '' then LEFT(@sql,LEN(@sql)-1) 
			      when isnull(@Sql_Columns,'')='' and @groupBy = ''  then @sql+' '' '' as Value'
				  else  @sql+@Sql_Columns end
	
	set @sql=@sql+CHAR(10)+' from '+@table  

	IF(@groupBy<>'')
	BEGIN
		set @sql=@sql+' group by '+@groupBy +CHAR(10)+'order by '+@orderBy            
	END
set @sql=@sql+CHAR(10)+'END'          
          
print @sql          
exec( @sql)            
            
        
        
        
        
            
           
            
            
end
go

