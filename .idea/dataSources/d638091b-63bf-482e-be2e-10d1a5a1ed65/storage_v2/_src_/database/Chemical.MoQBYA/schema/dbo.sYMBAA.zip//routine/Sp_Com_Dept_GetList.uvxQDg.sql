

-- =============================================
-- Author:  <曹乐平>
-- Create date:<2014-06-24>
-- Description:<部门列表>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Com_Dept_GetList]
    @PageIndex varchar(50)='1',
    @PageSize varchar(50)='10',
    @OrderFields varchar(50)='DeptID desc'
as 
Begin 
set nocount on
if @OrderFields = ''
	set @OrderFields = 'DeptID desc'
select 
	cast(DeptID as varchar(500))   DeptID   ,
	DeptName as    DeptName  
	into #Result
	from Tbl_Com_Dept
declare @pageCount int =@@ROWCOUNT 
exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize   	  

End
go

