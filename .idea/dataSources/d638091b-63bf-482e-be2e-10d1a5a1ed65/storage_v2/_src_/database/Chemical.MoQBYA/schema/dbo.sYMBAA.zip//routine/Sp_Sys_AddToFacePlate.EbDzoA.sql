-- =============================================  
-- Author:  <龚炎>  
-- Update date: <2012-05-15>  
-- Description: <添加到面板>  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_AddToFacePlate]  
 @PageID Varchar(50),  
 @GroupID Varchar(500),  
 @GroupName varchar(500),  
 @Condition varchar(max)='',  
 @hStr varchar(max)='',  
 @OtherCond varchar(max)='',  
 @SpParams varchar(500),  
 @form varchar(50)='',  
 @UserTitle varchar(200)=''  
AS  
BEGIN  
 -- SET NOCOUNT ON added to prevent extra result sets from  
 -- interfering with SELECT statements.  
 SET NOCOUNT ON;  
  if(@PageID=null or @PageID = 'null'or @PageID = '')  
 begin  
  select '请先在首页添加一个面板';  
  return   
 end  
 if(@GroupName is null or @GroupName=''or @GroupName='null')  
   begin  
     select '请输入在面板显示的标题'  
     return   
   end  
    -- Insert statements for procedure here  
    if((select COUNT(0) from Tbl_Sys_PageGroup where @PageID=PageID and GroupID=@GroupID and GroupName=@GroupName and Condition= @Condition and SpParams = @SpParams )>0 )  
    begin  
  select '你已经添加过一个相同配置的面板';  
  return  
    end  
    else  
    begin  
  insert into Tbl_Sys_PageGroup (PageID,GroupID,GroupName,Condition,HumenString,FullCondition,OtherCond,SpParams,form,UserTitle)  
  values(@PageID,@GroupID,@GroupName,@Condition,@hStr,@Condition,@OtherCond,@SpParams,@form,@UserTitle)  
   if(exists(select 1 from Tbl_sys_PageGrouppos where PageID = @PageID))
   begin
   declare @pageGroupID int 
   select @pageGroupID = SCOPE_IDENTITY()
   UpDate Tbl_sys_PageGrouppos
   set sortGroupids =sortGroupids +','+ cAST(@pageGroupID AS VARCHAR(200))
   where pageID = @pageid
   end 
  select 0;  
 end  
END  
  
  
SET ANSI_PADDING OFF
go

