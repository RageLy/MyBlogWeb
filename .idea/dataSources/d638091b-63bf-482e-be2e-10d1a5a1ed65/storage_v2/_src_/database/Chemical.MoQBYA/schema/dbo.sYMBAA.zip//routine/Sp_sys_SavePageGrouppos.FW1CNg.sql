
-- =============================================
-- Author:		夏祖宏
-- Create date: 2012-12-12
-- Description:	保存面板group位置顺序
-- =============================================
CREATE PROCEDURE [dbo].[Sp_sys_SavePageGrouppos]
	@userid int,
	@pageid int,
	@sortgroupids varchar(500)
AS
BEGIN
	-- [Sp_sys_SavePageGrouppos] 2,'111'
	-- interfering with SELECT statements. select * from Tbl_sys_PageGrouppos where posid=1
	-- delete from test_tbl_savepagepos where posid=2
	SET NOCOUNT ON;
	if((select COUNT(*) from dbo.Tbl_sys_PageGrouppos where userid=@userid)=0)
	begin
		insert into dbo.Tbl_sys_PageGrouppos(userid,pageid,sortgroupids) values(@userid,@pageid,@sortgroupids)
	end
	else if((select COUNT(*) from dbo.Tbl_sys_PageGrouppos where userid=@userid and pageid=@pageid)=0)
	begin
		insert into dbo.Tbl_sys_PageGrouppos(userid,pageid,sortgroupids) values(@userid,@pageid,@sortgroupids)
	end
	else
	begin
		update dbo.Tbl_sys_PageGrouppos set sortgroupids=@sortgroupids where userid=@userid and pageid=@pageid
	end
	

END
go

