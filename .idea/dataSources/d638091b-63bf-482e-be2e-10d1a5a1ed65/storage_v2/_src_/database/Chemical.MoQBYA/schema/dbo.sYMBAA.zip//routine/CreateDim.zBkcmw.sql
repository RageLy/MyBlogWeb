

--获取数据库创建数值维度的字符串        
CREATE PROC [dbo].[CreateDim]        
@CoName NVARCHAR(500) = 'ParticalZeta', --如果 DimNum =null 则默认 = 'Dim_'+@DimTableName   注意：该字符串不能包含“_” eg: DimTHMCS  或者 DimCS 
@TableName NVARCHAR(50)='',   
@TableName_ch NVARCHAR(50)='',
@Name_ch NVARCHAR(500) ='粒子Zeta电位值',   --维度中文现在名称      
@DimLevel Nvarchar(500) ='0,2,5,10', --数值维度 选项集合类型和倍数； 0 选项集合类型  
@SpName NVARCHAR(50)='',
@BaseCount NVARCHAR(500) = 61 , --基础选项 个数+1 ；+1 扩大其1个取值范围防止边界值越界  
@CutInt NVARCHAR(500) = -1 , --最小值距离0的刻度大小-1   
@NumDecimal NVARCHAR(500) = 1 ,  --最小刻度  
@AtYSql NVARCHAR(500) = 'Partical.Zeta',  -- 表上面的取值
@MainTable NVARCHAR(500) = '',  -- 用于什么地方的指标
@tag NVARCHAR(50)=''
AS        
BEGIN        

SET NOCOUNT ON;
DECLARE @DimNum NVARCHAR(100)='Dim'+@TableName+@CoName
--DECLARE @Name_ch NVARCHAR(500) =''
DECLARE @DimLevel_str NVARCHAR(500)
IF EXISTS (SELECT 1 FROM Tbl_AnsCom_DIimToTable WHERE DimNum = RTRIM(LTRIM(@DimNum)) )
BEGIN
	SELECT '维度已存在！'
	--RETURN;
END
DECLARE @DimLevelTable TABLE (ID INT IDENTITY(1,1) NOT null,Name NVARCHAR(2) )
INSERT @DimLevelTable
(
    Name
)
SELECT string
FROM dbo.f_splitSTR(@DimLevel, ',');
--SELECT * FROM @DimLevelTable
SET @DimLevel_str=(SELECT CASE WHEN Name=0 THEN '选项集合类型' ELSE  '倍数'+Name END+',' FROM @DimLevelTable FOR XML PATH(''))
SET @DimLevel_str=LEFT(@DimLevel_str,LEN(@DimLevel_str)-1)
 --PRINT @DimLevel_str
 IF(@Name_ch='')
SET  @Name_ch=(SELECT Name_ch FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum=@DimNum)

    
PRINT '-- DELETE Tbl_AnsCom_DIimToTable WHERE DimNum ='''+@DimNum+''''        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
     
PRINT 'Drop View VW_'+@DimNum+'_part'        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
PRINT 'Drop View VW_'+@DimNum+'_partAll'        

PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
--========================================================================================        

DECLARE @Sql_DimToTable NVARCHAR(max)=''
--SET @Sql_DimToTable += CHAR(10) +'/*'

-- 验证存不存在 不存在则添加
SET @Sql_DimToTable += CHAR(10) +'IF NOT EXISTS (SELECT 1 FROM dbo.Tbl_AnsCom_DIimToTable where DimNum = ''' + @DimNum + ''') 
BEGIN ';

-- 添加配置行
SET @Sql_DimToTable += CHAR(10) +'INSERT INTO dbo.Tbl_AnsCom_DIimToTable '         
SET @Sql_DimToTable += CHAR(10) +'( DimNum,ViewName,Name_ch,CoName,TableName,TableName_ch,AllValue,DimLevel,BaseCount,CutInt,NumDecimal,SpType,isrange,AtYSql,IsDimBan,MainTable)'        
SET @Sql_DimToTable += CHAR(10) +'VALUES  ( '''+ @DimNum +''','''+ @DimNum +''','''+@Name_ch+''','''+@CoName+''','''+@TableName+''','''+@TableName_ch+''',-1,'  
SET @Sql_DimToTable += CHAR(10) +''''+@DimLevel_str+''','''+@BaseCount+''','''+@CutInt+''','''+@NumDecimal + ''','''+@SpName+''',1,''' + @AtYSql + ''',0,'''+@MainTable+''')'


SET @Sql_DimToTable += ' 
END 
ELSE 
BEGIN '

SET @Sql_DimToTable += CHAR(10) +'UPDATE dbo.Tbl_AnsCom_DIimToTable SET ViewName = ''' + @DimNum + ''',Name_ch = ''' + @Name_ch + ''',CoName='''+@CoName+''',TableName='''+@TableName+''',TableName_ch='''+@TableName_ch+''',AllValue = -1,DimLevel = ''' 
+ @DimLevel_str + ''',BaseCount = ''' + @BaseCount + ''',CutInt = '''+@CutInt+''',NumDecimal = '''+@NumDecimal + ''',SpType='''+@SpName+''',isrange = 1,AtYSql = ''' + @AtYSql + ''',IsDimBan=0,MainTable='''+@MainTable+'''';

SET @Sql_DimToTable += CHAR(10) +'WHERE DimNum = ''' + @DimNum + '''';
SET @Sql_DimToTable += ' 
END
'
-- SET @Sql_DimToTable += CHAR(10) +'*/'       
PRINT @Sql_DimToTable  -- sp_Help_GetCreateDimString        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        


DECLARE @Sql_VWPart VARCHAR(max)=''        
        
    SET @Sql_VWPart += CHAR(10) + 'Create View VW_'+@DimNum+'_part'        
SET @Sql_VWPart += CHAR(10) + 'AS'        
        
DECLARE  @Index INT =3,@Num INT = 5 ,@count INT  = 1        
        
SELECT @count=COUNT(1) FROM dbo.Split(@DimLevel,',')        
        
declare auth_cur cursor for select StartIndex,string FROM dbo.Split(@DimLevel,',')  -- 定义游标        
open auth_cur --打开游标        
fetch next from auth_cur into @Index,@Num --执行到下一句        
while (@@fetch_status=0) --当游标状态=0 时执行        
BEGIN        
-------------------------------------------------------------------        
    IF(@Num=0)        
    BEGIN---------------
		
		SET @Sql_VWPart += CHAR(10) +  ' SELECT -1 AS Id , ''全部集合:['' + CAST((1 + b.CutInt) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((b.BaseCount + b.CutInt) * b.NumDecimal AS VARCHAR(50))+'')'' AS Name'        
		SET @Sql_VWPart += CHAR(10) +  ',''1'' AS istrue ,''属性集合'' 选项集合类型'
		SET @Sql_VWPart += CHAR(10) + (SELECT ',NULL AS Id'+string+' ,NULL AS [倍数'+string+']' FROM dbo.Split(@DimLevel,',') WHERE string >0 FOR XML PATH(''))        
		--SET @Sql_VWPart += CHAR(10) +  ',-1 AS IdAll ,''全部集合:'' + CAST((1 + b.CutInt) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((b.BaseCount + b.CutInt) * b.NumDecimal AS VARCHAR(50)) AS 区间所有'        
		SET @Sql_VWPart += CHAR(10) +  ',(1 + b.CutInt) * b.NumDecimal  AS Beginvalue'        
		SET @Sql_VWPart += CHAR(10) +  ',(b.BaseCount + b.CutInt) * b.NumDecimal AS Endvalue'        
		SET @Sql_VWPart += CHAR(10) +  'FROM Tbl_AnsCom_DIimToTable AS b '        
		SET @Sql_VWPart += CHAR(10) + 'WHERE DimNum=''' + @DimNum + ''''        
        
    END------------------  
          
    ELSE   
    BEGIN------------------        
    
		SET @Sql_VWPart += CHAR(10) + 'UNION ALL'
		SET @Sql_VWPart += CHAR(10) + 'SELECT 0 -(a.id * '+CAST(@Num AS VARCHAR(10))+') - (b.BaseCount) * ('+CAST(@Index AS VARCHAR(10))+' - 1)  AS Id '        
		SET @Sql_VWPart += CHAR(10) + ', ''倍数'+CAST(@Num AS VARCHAR(10))+':['' + CAST((1 + b.CutInt +((a.id-1) * '+CAST(@Num AS VARCHAR(10))+')) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((1 + b.CutInt +(a.id * '    
		SET @Sql_VWPart += CHAR(10) + CAST(@Num AS VARCHAR(10))+')) * b.NumDecimal AS VARCHAR(50))+'')'' AS Name'        
		SET @Sql_VWPart += CHAR(10) + ',''' + CAST(@Num AS VARCHAR(10)) +''' AS istrue ,''倍数'+CAST(@Num AS VARCHAR(10))+''' 选项集合类型'        
		
		SET @Sql_VWPart += CHAR(10) + ISNULL((SELECT ',NULL AS Id'+string+' ,NULL AS [倍数'+string+']' FROM dbo.Split(@DimLevel,',') WHERE CAST(string AS INT) >0 AND CAST(string AS INT) < @Num FOR XML PATH('')),'')        
		        
		SET @Sql_VWPart += CHAR(10) +',0 -(a.id * '+CAST(@Num AS VARCHAR(10))+') - (b.BaseCount) * ('+CAST(@Index AS VARCHAR(10))+' - 1) AS Id'+CAST(@Num AS VARCHAR(10))+''         
		SET @Sql_VWPart += CHAR(10) +',''倍数'+CAST(@Num AS VARCHAR(10))+':['' + CAST((1 + b.CutInt +((a.id-1) * '+CAST(@Num AS VARCHAR(10))+')) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((1 + b.CutInt +(a.id * '    
		SET @Sql_VWPart += CHAR(10)+CAST(@Num AS VARCHAR(10))+')) * b.NumDecimal AS VARCHAR(50))+'')'' AS [倍数'+CAST(@Num AS VARCHAR(10))+']'        
		        
		SET @Sql_VWPart += CHAR(10) + ISNULL((SELECT ',NULL AS Id'+string+' ,NULL AS [倍数'+string+']' FROM dbo.Split(@DimLevel,',') WHERE CAST(string AS INT) > @Num FOR XML PATH('')),'')        
		        
		        
		--SET @Sql_VWPart += CHAR(10) + ',NULL AS IdAll ,NULL AS 区间所有'        
		SET @Sql_VWPart += CHAR(10) + ',(1 + b.CutInt +((a.id-1) * '+CAST(@Num AS VARCHAR(10))+')) * b.NumDecimal  AS Beginvalue'        
		SET @Sql_VWPart += CHAR(10) + ',(1 + b.CutInt +((a.id) * '+CAST(@Num AS VARCHAR(10))+')) * b.NumDecimal AS Endvalue'        
		SET @Sql_VWPart += CHAR(10) + 'FROM tbl_base_num AS a'        
		SET @Sql_VWPart += CHAR(10) + 'LEFT JOIN Tbl_AnsCom_DIimToTable AS b ON a.id * '+CAST(@Num AS VARCHAR(10))+' <= b.BaseCount'        
		SET @Sql_VWPart += CHAR(10) + 'WHERE DimNum=''' + @DimNum + ''''         
        
    END------------------        
            
-------------------------------------------------------------------        
    fetch next from auth_cur into @Index,@Num  --执行到下一句        
end        
close auth_cur  --关闭游标        
deallocate auth_cur --释放游标        
        
SET @Sql_VWPart += CHAR(10) + 'UNION ALL'        
        
 SET @Sql_VWPart += CHAR(10) + 'select a.ID'        
 SET @Sql_VWPart += CHAR(10) + ','':[''+cast((b.CutInt +a.id) * b.NumDecimal as varchar(20))+''-''+cast((b.CutInt +a.id+1) * b.NumDecimal as varchar(20))+'')'' as Name'        
 SET @Sql_VWPart += CHAR(10) + ',''0''  as istrue ,''基础选项'' as 选项集合类型'        
         
 SET @Sql_VWPart += CHAR(10) + (SELECT ',0-((a.id-1)/'+string+' * '+string+') - (b.BaseCount) * ('+CAST(StartIndex AS VARCHAR(10))+' - 1) -'+string+' AS Id'+string+' '         
  + ',''倍数'+string+':['' + CAST((1+ b.CutInt +((a.id-'+string+'+1)/'+string+' * '+string+')) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((1 + b.CutInt +((a.id-1+'+string+')/'+string+' * '+string+')) * b.NumDecimal AS VARCHAR(50)) +'')''AS [倍数'+string+']'        
 FROM dbo.Split(@DimLevel,',') WHERE CAST(string AS INT) >0 FOR XML PATH (''))        
 ----SET @Sql_VWPart += CHAR(10) + ',0-((a.id-1)/@Num * @Num) - (b.BaseCount) * (@Index - 1) -@Num AS Id2 '        
 ----SET @Sql_VWPart += CHAR(10) + ',''2倍:'' + CAST((1+ b.CutInt +((a.id-@Num+1)/@Num * @Num)) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((1 + b.CutInt +((a.id-1+@Num)/@Num * @Num)) * b.NumDecimal AS VARCHAR(50)) AS [倍数2]'        
        
 --SET @Sql_VWPart += CHAR(10) + ',-1 AS IdAll ,''全部集合:'' + CAST((1 + b.CutInt) * b.NumDecimal AS VARCHAR(50)) +''-'' + CAST((b.BaseCount + b.CutInt) * b.NumDecimal AS VARCHAR(50)) AS 区间所有'        
 SET @Sql_VWPart += CHAR(10) + ',(b.CutInt +a.id) * b.NumDecimal  as Beginvalue'        
 SET @Sql_VWPart += CHAR(10) + ',(b.CutInt +a.id+1) * b.NumDecimal as Endvalue'        
 SET @Sql_VWPart += CHAR(10) + 'from tbl_base_num as a'        
 SET @Sql_VWPart += CHAR(10) + 'left join Tbl_AnsCom_DIimToTable as b on a.id < b.BaseCount'        
 SET @Sql_VWPart += CHAR(10) + 'WHERE DimNum=''' + @DimNum + ''''          
        
PRINT @Sql_VWPart  --  sp_Help_GetCreateDimString        
PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
        
--========================================================================================        
DECLARE @Sql_VWPartALL VARCHAR(max)=''        
        
	SET @Sql_VWPartALL += CHAR(10) + 'Create View VW_'+@DimNum+'_partAll'        
	SET @Sql_VWPartALL += CHAR(10) + 'AS'        
	        
	--SET @Sql_VWPartALL += CHAR(10) + 'SELECT  Id AS VWID ,ID ,Name ,''0'' AS istrue ,选项集合类型 '   
	SET @Sql_VWPartALL += CHAR(10) + 'SELECT  Id AS VWID ,ID ,Name'  
	--SET @Sql_VWPartALL += CHAR(10) + (SELECT ',倍数'+string+',ID'+string+'' FROM dbo.Split(@DimLevel,',') WHERE string > 0 FOR XML path(''))        
	--SET @Sql_VWPartALL += CHAR(10) + ',区间所有,IDAll,Beginvalue,Endvalue FROM vw_'+@DimNum+'_Part WHERE istrue = 0'        
	SET @Sql_VWPartALL += CHAR(10) + ',Beginvalue,Endvalue FROM vw_'+@DimNum+'_Part WHERE istrue = 0'    
 
	DECLARE @Index_all INT =1,@Num_all INT = 1 ,@count_all INT  = 1        
        
	SELECT @count_all = COUNT(1) FROM dbo.Split(@DimLevel,',')        
    
	declare auth_cur_all cursor for select StartIndex,string FROM dbo.Split(@DimLevel,',')  -- 定义游标        
	
	open auth_cur_all --打开游标        
	fetch next from auth_cur_all into @Index_all,@Num_all --执行到下一句        
	
	while (@@fetch_status=0) --当游标状态=0 时执行        
	BEGIN        
	 SET @Sql_VWPartALL += CHAR(10) + 'UNION ALL'
	 
	 IF(@Num_all = 0)  --union all 所有选项集合
	 BEGIN
		 --SET @Sql_VWPartALL += CHAR(10) + 'SELECT  part.Id ,notAll.Id ,part.Name ,''1'' AS IsTrue ,part.选项集合类型'                
		 SET @Sql_VWPartALL += CHAR(10) + 'SELECT -1 , notAll.Id , ( SELECT Name FROM vw_'+@DimNum+'_Part WHERE istrue = 1 ) '
		 --SET @Sql_VWPartALL += CHAR(10) + (SELECT ',part.倍数'+string+',part.ID'+string+'' FROM dbo.Split(@DimLevel,',') WHERE string >0 FOR XML path(''))           
		 -- SET @Sql_VWPartALL += CHAR(10) + ',part.区间所有,part.IDAll'
		 SET @Sql_VWPartALL += CHAR(10) + ',notAll.Beginvalue,notAll.Endvalue'
		 SET @Sql_VWPartALL += CHAR(10) + 'FROM ( SELECT * FROM vw_'+@DimNum+'_Part WHERE istrue = 0 ) AS notAll'
		 --SET @Sql_VWPartALL += CHAR(10) + 'INNER JOIN ( SELECT * FROM vw_'+@DimNum+'_Part WHERE istrue = 0 ) AS notAll'
	 END
	 
	 ELSE --Union all 其它倍数集合
	 BEGIN
		 SET @Sql_VWPartALL += CHAR(10) + 'SELECT  part.Id ,notAll.Id ,part.Name'
		 --SET @Sql_VWPartALL += CHAR(10) + (SELECT ',part.倍数'+string+',part.ID'+string+'' FROM dbo.Split(@DimLevel,',') WHERE string >0 FOR XML path(''))
		 --SET @Sql_VWPartALL += CHAR(10) + ',part.区间所有,part.IDAll'
		 SET @Sql_VWPartALL += CHAR(10) + ',notAll.Beginvalue,notAll.Endvalue'
		 SET @Sql_VWPartALL += CHAR(10) + 'FROM ( SELECT * FROM vw_'+@DimNum+'_Part WHERE istrue = ' + CAST(@Num_ALL AS VARCHAR(10)) + ' ) part'
		 SET @Sql_VWPartALL += CHAR(10) + 'INNER JOIN ( SELECT * FROM vw_'+@DimNum+'_Part WHERE istrue = 0 ) AS notAll ON part.ID'+CAST(@Num_ALL AS VARCHAR(10))+' = notAll.ID'+CAST(@Num_ALL AS VARCHAR(10))+''         
	 END 
		 fetch next from auth_cur_all into @Index_all,@Num_all  --执行到下一句
	          
	END   
	     
	close auth_cur_all  --关闭游标        
	deallocate auth_cur_all --释放游标        
	        
	PRINT @Sql_VWPartALL        
	PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
	PRINT 'select * from VW_'+@DimNum+'_part'      
    PRINT CHAR(10)+'------------------------------------------'+CHAR(10) +'GO'        
    
   PRINT 'UPDATE dbo.Tbl_AnsCom_SelfDims SET selectdim=selectdim+'','+@DimNum+''',Allselectdim=Allselectdim+'','+@DimNum+''' where tag like ''%'+@tag+'%'''
END -- sp_Help_GetCreateDimString        


go

