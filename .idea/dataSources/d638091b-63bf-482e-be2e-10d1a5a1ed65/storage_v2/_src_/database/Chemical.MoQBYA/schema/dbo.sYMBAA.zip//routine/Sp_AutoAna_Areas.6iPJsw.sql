
-- =============================================
-- Author:		 hjl
-- Create date:  2017.6.6
-- Description:	 计算分区及其明细
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_Areas]
	-- Add the parameters for the stored procedure here
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(max) = 'DimSinOutValue:,DimSinTemp8:倍数2,DimDIYTemp25:,DimDIYSpeed:,DimDIYSpeed580:,DimDIYOilVis:'
	,@XDim VARCHAR(50) = 'DimDDLps'
	,@YDim VARCHAR(50) = 'DimSinOutValue'
    ,@Where VARCHAR(max) = ' AND Oil.Series = 3' -- 维度筛选条件
    ,@OrderBy VARCHAR(max) = '目标平均值 desc' -- 排序条件
AS
BEGIN
	SET NOCOUNT ON;

	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
 
    -- 分解维度插入零时表
    INSERT INTO #DimsPearSen
    SELECT SUBSTRING(string,1,CHARINDEX(':',string) - 1)
    ,CASE WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @XDim THEN 'X'  -- 变量dim
	      WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @YDim THEN 'Y'  -- 目标dim
		  ELSE 'F' END   -- 条件Dim
    ,ta.IsRange
    ,ta.ViewName
    ,ta.AtYSql
    ,SUBSTRING(string,CHARINDEX(':',string) + 1,Len(string))
    ,NUll
    FROM dbo.Split(@Dims,',') s
    INNER JOIN dbo.Tbl_AnsCom_DIimToTable ta ON SUBSTRING(string,1,CHARINDEX(':',string) - 1) = ta.DimNum
    
    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #DimsPearSen WHERE Dim = @YDim;
    

    DECLARE @Xsql VARCHAR(500);
    SELECT @Xsql = DimYsql FROM #DimsPearSen WHERE Dim = @XDim;
    IF(@Xsql IS NULL)  -- 如果X值没有选则取0
		SET @Xsql = '0';
    
    -- 数据源sql段
    DECLARE @TName VARCHAR(500);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
   

    -- 计算所有条件 Dim 的数据量
    DECLARE @CreateT VARCHAR(max) = '';
    
    SET @CreateT += ( SELECT 'CREATE TABLE #' +  Dim + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') );
    
    -- 根据维度值取维度刻度
	DECLARE @InsertT VARCHAR(max) = '';

	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where ' + 
				CASE WHEN ISNULL(DimValue,'') = '' THEN 'istrue = 0;'
						  ELSE '[选项集合类型] = ''' + DimValue + ''';' END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') )

   --print @InsertT;
    -- 拼接计算列
    
    -- Select 段
    
    DECLARE @Select varchar(Max) = '';
    
    SET @Select = 'select SUM(CASE WHEN ' + @Ysql + ' is not null THEN 1 ELSE 0 END ) AS 目标值数量
    ,MAX(' + @Ysql + ') AS 目标最大值
    ,MIN(' + @Ysql + ') AS 目标最小值
    ,AVG(' + @Ysql + ') AS 目标平均值
    ,Max(' + @Ysql + ') - Min(' + @Ysql + ') AS 目标极差
    ,stdev(' + @Ysql + ') AS 目标标准差'
	
    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' LEFT JOIN #' +  Dim + ' AS ' + Dim + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN Dim + '.BeginValue <= ' + DimYsql + ' AND ' + Dim + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE Dim + '.ID = ' + DimYsql END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	
	-- 拼接SiftValue段
    DECLARE @SiftValue VARCHAR(max);
    SET @SiftValue = ( SELECT '''%' +  Dim + ':'' + CAST( isnull(' + Dim + '.ID,0) AS Varchar(10)) + '
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个 % 和最后一个 +
	SET @SiftValue = '''' + SUBSTRING(@SiftValue,3,LEN(@SiftValue) - 3);
	
	-- 拼接 group by 段
    DECLARE @GroupBy VARCHAR(max);
    SET @GroupBy = ( SELECT ',' + Dim + '.ID'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个,
	SET @GroupBy = SUBSTRING(@GroupBy,2,LEN(@GroupBy));
	
	
	-- Drop 临时表
	DECLARE @DropT varchar(Max);
	SET @DropT = ( SELECT 'Drop Table #' + Dim + ';'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	
	----------------- 统计结果表
	
	DECLARE @CountSql varchar(max);
	
	--select * FROM dbo.fn_getAreaTable(0,1,10)
	
	Set @CountSql = '
	DECLARE @MaxY decimal(18,4) = (select MAX(目标极差) FROM #R);
	
	select b.Name as 极差范围,Count(*) 组数,Sum(目标值数量) 生产数
	From #R r
	INNER JOIN dbo.fn_getAreaTable(0 - ( [dbo].[GetMaxRange](@MaxY) / 10 ) , [dbo].[GetMaxRange](@MaxY) , 11 ) b 
	on r.目标值数量 > 1 AND r.目标极差 > Beginvalue AND r.目标极差 <= Endvalue
	group by b.Name,b.ID 
	order by b.ID;'
	
	
	
	-- 执行语句
	
	--SET @SqlCount += 'SELECT COUNT(*),' + @SiftValue + ' FROM ' + @SqlJoin;
	
	--select @CreateT + @InsertT + ' ' + @Select + ',' + @SiftValue + ' AS 参数 INTO #R FROM ' + @TName + @SqlJoin + ' WHERE 1=1 ' + @Where + ' Group by ' + @GroupBy + ';' + @DropT;
	EXEC (@CreateT + @InsertT + ' ' + @Select + ',' + @SiftValue + ' AS 参数 INTO #R FROM ' + @TName + @SqlJoin + ' WHERE 1=1 ' + @Where + ' Group by ' + @GroupBy + ';' + @DropT + ' SELECT * FROM #R Order by ' + @OrderBy + @CountSql);
	
	--SELECT @SiftValue;
	
END
go

