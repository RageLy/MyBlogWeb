
--****************************************
--作者:hmw
--创建时间:2017-08-24
--说明:使用分位数方法将两两维度对比
--****************************************




CREATE PROCEDURE [dbo].[Sp_Analysister_Quantile_Partition_3]
    @Condition VARCHAR(MAX) = '',
    @DataType INT,
    @YValue NVARCHAR(50),
    @ReferenceValue INT,
    @WDCount INT,
    @COUNTi INT,
    @SpName NVARCHAR(50)
AS
BEGIN
    --PRINT @ReferenceValue;

    DECLARE @sql NVARCHAR(MAX) = '';
    CREATE TABLE #Num
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        NumValue INT
    );
    DECLARE @tempNum INT = @DataType;
    WHILE (@tempNum > 0)
    BEGIN
        --PRINT @tempNum;
        INSERT INTO #Num
        (
            NumValue
        )
        VALUES
        (@tempNum);

        SET @tempNum -= 1;
    END;

    CREATE TABLE #NumWD
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        NumValue INT
    );
    DECLARE @tempNumWD INT = @WDCount;
    WHILE (@tempNumWD > 0)
    BEGIN
        --PRINT @tempNum;
        INSERT INTO #NumWD
        (
            NumValue
        )
        VALUES
        (@tempNumWD);

        SET @tempNumWD -= 1;
    END;
    --SELECT * FROM #Num
    --获取维度
    CREATE TABLE #ConTable
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        DimID NVARCHAR(4),
        DimNum NVARCHAR(50),
        DimYSQL NVARCHAR(50),
        AtYsql NVARCHAR(50),
        --TableName NVARCHAR(50),
        --CoName NVARCHAR(50),
        isRange INT
    );
    INSERT INTO #ConTable
    (
        DimID
    )
    SELECT string
    FROM dbo.f_splitSTR(@Condition, ',');


    UPDATE #ConTable
    SET DimYSQL = Tbl_AnsCom_DIimToTable.TableName + Tbl_AnsCom_DIimToTable.CoName,
        DimNum = Tbl_AnsCom_DIimToTable.DimNum,
        AtYsql = Tbl_AnsCom_DIimToTable.AtYSql,
        isRange = Tbl_AnsCom_DIimToTable.IsRange
    FROM Tbl_AnsCom_DIimToTable
    WHERE CAST(#ConTable.DimID AS INT) = Tbl_AnsCom_DIimToTable.ID;

    --SELECT  *
    --FROM    #ConTable; 

    DECLARE @SelectStr NVARCHAR(MAX)
        = @YValue + ' is not NULL ' + CHAR(10) +
          (
              SELECT CASE
                         WHEN #ConTable.isRange = 1 THEN
                             ' and ' + DimYSQL + ' Is not NULL ' + CHAR(10)
                         ELSE
                             ' and ' + REPLACE(#ConTable.AtYsql, '.', '') + ' IS NOT NULL '
                     END
              FROM #ConTable
              --LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
              FOR XML PATH('')
          );
    -------------------------------------------------------------筛选数-----------------------------------------------------------------
    SET @sql += 'select ' + @YValue +
                (
                    SELECT CASE
                               WHEN #ConTable.isRange
        =               1 THEN
                                   ',' + DimYSQL
                               ELSE
                                   ',' + REPLACE(#ConTable.AtYsql, '.', '')
                           END
                    FROM #ConTable
                    --LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
                    FOR XML PATH('')
                ) + ',GY into #TempQuantileResult from QuantileResult_' + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                + CAST(@DataType AS NVARCHAR(5)) + 'B_' + @SpName + '_' + @YValue + ' where ' + @SelectStr;
    --PRINT @sql 
    --DECLARE @count INT = (   SELECT MAX(ID)
    --                         FROM   #ConTable );
    --WHILE ( @count > 0 )
    --    BEGIN
    --        --PRINT @count
    --        DECLARE @DimNumTemp NVARCHAR(50) = (   SELECT DimNum
    --                                               FROM   #ConTable
    --                                               WHERE  ID = @count );
    --        DECLARE @DimID NVARCHAR(50) = (   SELECT DimID
    --                                          FROM   #ConTable
    --                                          WHERE  ID = @count );
    --        DECLARE @DimName NVARCHAR(50) = (   SELECT CASE WHEN IsRange = 1 THEN
    --                                                            DimYSQL
    --                                                        ELSE
    --                                                            REPLACE(
    --                                                                AtYSql ,
    --                                                                '.' ,
    --                                                                '')
    --                                                   END
    --                                            FROM   #ConTable
    --                                             WHERE  ID = @count);
    ------------------------------------------------创建维度临时表-------------------------------------------------------        
    --SET @sql += 'CREATE TABLE #' + @DimNumTemp
    --            + '([ID] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY, 
    --    DimNum NVARCHAR(50),
    --     DimQJ NVARCHAR(50),
    --    Name NVARCHAR(500) DEFAULT '''',
    --    BeginValue DECIMAL(18,4), 
    --    EndValue DECIMAL(18,4),DiffValue decimal(18,4));'
    --            + CHAR(10);


    --     SET @sql += 'insert into #' + @DimNumTemp
    --                 + ' select DimNum ,
    --DimQJ ,
    --Name ,
    --BeginValue ,
    --EndValue ,
    --DiffValue from StorageFQData_'+ CAST(@WDCount AS NVARCHAR(2))
    --                                  + 'W_'
    --                                  + CAST(@DataType AS NVARCHAR(5))
    --                                  + 'B_' + @SpName + '_' + @YValue+' where DimID=' + @DimID + ''+CHAR(10);
    --PRINT @sql
    --    SET @count -= 1;
    ----PRINT @count;
    ----SET @sql=''
    --END;
    --PRINT @sql;
    --SELECT @sql
    DECLARE @Resultdata VARCHAR(MAX);
    DECLARE @ResultName VARCHAR(MAX) = '';
    SET @ResultName =
    (
        SELECT ',' + DimNum + ' varchar(100),' + DimNum + 'QJ varchar(100),' + DimNum + 'DiffValue decimal(18,4)'
        FROM #ConTable
        FOR XML PATH('')
    );
    --PRINT '结果数据：' + @ResultName;

    SET @Resultdata =
    (
        SELECT 'CREATE TABLE #Resultdata
	   (ID int IDENTITY(1, 1) NOT NULL PRIMARY KEY
		' + ISNULL(@ResultName, '') + ',GY INT,' + @YValue + ' varchar(100) )'
    );
    --PRINT @Resultdata;

    DECLARE @Resultzj VARCHAR(MAX);
    SET @Resultzj
        = (@Resultdata + ' insert into #Resultdata select ' +
           (
               SELECT DimNum + '.Name,' + DimNum + '.DimQJ,' + DimNum + '.DiffValue AS ' + DimNum + 'DiffValue,'
               FROM #ConTable
               FOR XML PATH('')
           ) + 'GY,' + @YValue + ' from #TempQuantileResult ' + CHAR(10)
           +
           (
               SELECT CASE
                          WHEN isRange = 1 THEN
                              ' Left join ' + DimNum + '_' + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                              + CAST(@DataType AS NVARCHAR(5)) + 'B_' + @SpName + '_' + @YValue
                              + ' AS '+DimNum+' on #TempQuantileResult.' + DimYSQL + '>=' + DimNum
                              + '.BeginValue and #TempQuantileResult.' + DimYSQL + '<' + DimNum + '.EndValue'
                              + CHAR(10)
                          ELSE
                              ' Left join ' + DimNum + '_' + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                              + CAST(@DataType AS NVARCHAR(5)) + 'B_' + @SpName + '_' + @YValue
                              + ' as '+DimNum+' on #TempQuantileResult.' + REPLACE(AtYsql, '.', '') + '>=' + DimNum
                              + '.BeginValue and #TempQuantileResult.' + REPLACE(AtYsql, '.', '') + '<' + DimNum
                              + '.EndValue' + CHAR(10)
                      END
               FROM #ConTable
               FOR XML PATH('')
           ) + 'where ' +
           (
               SELECT DimNum + '.Name is not NULL And ' FROM #ConTable FOR XML PATH('')
           )
          );
    --   +'1=1'+ CHAR(10) + ' Group by ' + CHAR(10)
    --+ ( SELECT    DimNum + '.Name,' + DimNum
    --              + '.DiffValue,'
    --    FROM      #ConTable
    --  FOR
    --    XML PATH('')
    --  ) + 'GY,' + @YValue + CHAR(10) );
    SET @Resultzj = LEFT(@Resultzj, LEN(@Resultzj) - 4);
    SET @Resultzj = REPLACE(REPLACE(REPLACE(@Resultzj, '&amp;', '&'), '&gt;', '>'), '&lt;', '<');
    SET @sql += @Resultzj;
    --PRINT @sql;
    -----------------------------------------------创建存储最终结果的表并将结果写入表内--------------------------------------
    DECLARE @CreateTable VARCHAR(MAX);

    SET @CreateTable =
    (
        SELECT ' CREATE TABLE #Result1
	   (GoodValue int,
	    floatValue decimal(18,4),
	    PercentON NVARCHAR(10),
	    ComCount int,
		DataCount int
		' + ISNULL(@ResultName, '') + ')' + CHAR(10)
    );
    DECLARE @ONRelation NVARCHAR(MAX) = '';

    SET @ONRelation +=
    (
        SELECT ' and a.' + DimNum + '=b.' + DimNum FROM #ConTable FOR XML PATH('')
    );

    DECLARE @GroupBy VARCHAR(700);
    --SELECT * FROM #DimsTb
    SET @GroupBy =
    (
        SELECT ',' + DimNum + ',' + DimNum + 'QJ,' + DimNum + 'DiffValue'
        FROM #ConTable
        FOR XML PATH('')
    );
    DECLARE @GroupBy1 VARCHAR(700);
    --SELECT * FROM #DimsTb
    SET @GroupBy1 =
    (
        SELECT DimNum + ',' + DimNum + 'QJ,' + DimNum + 'DiffValue,'
        FROM #ConTable
        FOR XML PATH('')
    );
    SET @GroupBy = ISNULL(@GroupBy, '');
    SET @ONRelation = ISNULL(@ONRelation, '');
    SET @GroupBy1 = ISNULL(@GroupBy1, '');
    IF (@GroupBy1 <> '')
        DECLARE @groupBy2 NVARCHAR(700) = 'Group by ' + LEFT(@GroupBy1, LEN(@GroupBy1) - 1);
    ELSE
        SET @groupBy2 = '';
    DECLARE @YValueName NVARCHAR(50) = '';
    SET @YValueName = 'CAST(' + @YValue + ' AS FLOAT)';
    SET @sql += @CreateTable
                + 'INSERT  INTO #Result1
        SELECT  ISNULL(a.DataCount,0) GoodValue ,
                ROUND(CAST(ISNULL(a.DataCount,0) AS FLOAT)
                      / ( CASE WHEN ISNULL(b.DataCount,0) = 0 THEN 1
                               ELSE ISNULL(b.DataCount,0)
                          END ) * 100, 4) floatValue ,
                CAST(ROUND(CAST(ISNULL(a.DataCount,0) AS FLOAT)
                           / ( CASE WHEN ISNULL(b.DataCount,0) = 0 THEN 1
                                    ELSE ISNULL(b.DataCount,0)
                               END ) * 100, 4) AS NVARCHAR(8)) +''%'' PercentON ,
                               c.DataCount ComCount,
                               
                b.*
        FROM    ( SELECT    
                            SUM(CASE WHEN ' + @YValueName
                + ' IS NOT NULL THEN 1
                                     ELSE 0
                                END) DataCount 
                            ' + @GroupBy
                + '
                  FROM      #Resultdata
                  WHERE     GY = 1
                  GROUP BY  ' + @GroupBy1
                + '
                            GY
                ) a
                RIGHT JOIN ( SELECT  
                                    SUM(CASE WHEN ' + @YValueName
                + ' IS NOT NULL
                                             THEN 1
                                             ELSE 0
                                        END) DataCount 
                                    ' + @GroupBy
                + '
                            FROM    #Resultdata
                            ' + @groupBy2
                + '
                          ) b ON 1 = 1
                                 ' + @ONRelation + '
                 CROSS JOIN (select  SUM(CASE WHEN ' + @YValueName
                + ' IS NOT NULL
                                             THEN 1
                                             ELSE 0
                                        END) DataCount  from #Resultdata) c' + CHAR(10);
    --PRINT @ReferenceValue;
    DECLARE @Detail VARCHAR(MAX)
        = 'select GoodValue,floatValue,DataCount ,PercentON,ComCount' + @GroupBy + ' INTO #RDetail From #Result1'
          + CHAR(10);
    --------------------------------------------将所有满足结果的数据写入到展示表里--------------------------------------------
    DECLARE @NameCh NVARCHAR(100) = (
                                        SELECT '''' + DimID + ''',''' + Name_ch + ''',' --'黏合剂pH值',配墨中PH1','
                                        FROM #ConTable
                                            LEFT JOIN dbo.Tbl_AnsCom_DIimToTable
                                                ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
                                        FOR XML PATH('')
                                    );
    SET @NameCh = RIGHT(@NameCh, LEN(@NameCh) - 1);
    DECLARE @NameChSet NVARCHAR(100) = '''' +
                                       (
                                           SELECT DimID + ',' --'黏合剂pH值',配墨中PH1','
                                           FROM #ConTable
                                               LEFT JOIN dbo.Tbl_AnsCom_DIimToTable
                                                   ON Tbl_AnsCom_DIimToTable.DimNum = #ConTable.DimNum
                                           FOR XML PATH('')
                                       ) + '''';
    --PRINT @NameChSet
    --SET @NameChSet = LEFT(@NameChSet, LEN(@NameChSet) - 1);
    SET @sql += @Detail;
    DECLARE @ResultSet NVARCHAR(MAX) = '';
    --DECLARE @sql1 NVARCHAR(MAX)=''
    SET @ResultSet += 'insert into NewShowTableID_' + CAST(@WDCount AS NVARCHAR(2)) + 'W_'
                      + CAST(@DataType AS NVARCHAR(5)) + 'B_' + @SpName + '_' + @YValue + ' SELECT '
                      + CAST(@COUNTi AS NVARCHAR(8)) + ',''' + @NameCh
                      + 'GoodValue,floatValue,PercentON,DataCount,ComCount,''' + CONVERT(VARCHAR(100), GETDATE(), 21)
                      + ''',' + @NameChSet + @GroupBy + '' +
                      (
                          SELECT ',NULL,NULL' FROM #NumWD FOR XML PATH('')
                      ) + ' from #RDetail' + CHAR(10);
    --SELECT * FROM #NumWD
    --PRINT @GroupBy
    SET @sql += @ResultSet;
    --PRINT '详细: ' + @ResultSet;
    DECLARE @DropTable NVARCHAR(500)
        = 'DROP TABLE #RDetail' + CHAR(10) + 'DROP TABLE #Result1' + CHAR(10) + 'DROP TABLE #Resultdata' + CHAR(10);


    EXEC (@sql + @DropTable);
--SELECT @sql + @DropTable;
--FOR     XML PATH('');

END;
go

