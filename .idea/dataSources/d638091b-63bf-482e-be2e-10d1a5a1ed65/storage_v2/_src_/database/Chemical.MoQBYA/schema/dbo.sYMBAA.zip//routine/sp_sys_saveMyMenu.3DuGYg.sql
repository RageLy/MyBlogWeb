  
-- =============================================  
-- Author:  吴国锋  
-- Create date: 2011-11-21  
-- Description: 保存“我的常用菜单”  
-- =============================================  
CREATE proc[dbo].[sp_sys_saveMyMenu]  
 @EmpID  int,  
 @menuId  varchar(200),  
 @menuTitle varchar(200),  
 @menuIcon varchar(200)  
AS  
BEGIN  
 INSERT INTO [tbl_sys_myMenu] ([EmpID],[menuId],[menuTitle],[menuIcon])  
 VALUES (@empId,@menuId,@menuTitle,@menuIcon)  
END
go

