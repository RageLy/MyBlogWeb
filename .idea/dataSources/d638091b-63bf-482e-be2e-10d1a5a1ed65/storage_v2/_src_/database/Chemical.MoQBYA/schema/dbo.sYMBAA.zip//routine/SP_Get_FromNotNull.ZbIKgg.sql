
/*********************************
 * 创建人：thm 
 * 获取必填字段
 *********************************/
Create PROC [dbo].[SP_Get_FromNotNull]
@FormID VARCHAR(200)='',
@EmpID VARCHAR(50)=''
AS
BEGIN

Select FromID,GroupID,Controls,Controlstr
FROM dbo.Tbl_Config_FromNotNull
WHERE FromID  = @FormID
END


go

