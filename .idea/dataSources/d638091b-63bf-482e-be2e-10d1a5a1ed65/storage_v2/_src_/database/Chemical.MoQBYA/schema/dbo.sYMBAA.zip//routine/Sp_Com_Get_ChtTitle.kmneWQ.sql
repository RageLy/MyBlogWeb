  
--==========================================
--获取图形的表头
--==========================================
CREATE proc [dbo].[Sp_Com_Get_ChtTitle]        
@TitleNames  varchar(200)='#Time,#Carseries'        
,@EndStrTitle varchar(200)=''      
,@YName varchar(max)  =''      
,@Unit varchar(max) = ''  
,@YMax varchar(max) = ''  
,@YMin varchar(max) = ''  
,@YMax_Second varchar(max) = ''  
,@YMin_Second varchar(max) = ''  
as        
begin        
select ROW_NUMBER() over(order by String) as n,String  into #TableNames from dbo.split(@TitleNames,',');        
declare @Sql varchar(max)=''       
,@index int =1      
,@count int       
, @TableName varchar(50)=''      
,@SqlTitle varchar(max)=''       
,@SqlTime varchar(Max) =''      
select @count = COUNT(1) from #TableNames        
while (@index<=@count)        
begin        
 select @TableName=String from #TableNames where n=@index        
  Print @TableName      
 if(@TableName ='#Time')        
 Begin          
  set @Sql +=CHAR(10)+' declare @'+REPLACE( @TableName,'#','')+' varchar(max) '        
  +CHAR(10)+'select @'++REPLACE( @TableName,'#','')++'= dbo.GetTimeName(MIN(begindate),Max(enddate)) from #time;'        
          
  set @SqlTime += '@'+REPLACE( @TableName,'#','')+'+ '        
 END        
 else        
 BEGIn        
  set @Sql +=CHAR(10)+' declare @'+REPLACE( @TableName,'#','')+' varchar(max) '        
  +CHAR(10)+CHAR(10)+' set @'+REPLACE( @TableName,'#','')+' =( select distinct top 2 Name+'','' from '+@TableName+' for xml path('''') );'     
         
  set @Sql +='set @'+REPLACE( @TableName,'#','')+' =cast( SUBSTRING(@'+REPLACE( @TableName,'#','')+',0,LEN(@'+REPLACE( @TableName,'#','')+')) as varchar(50));'     
         
  set @SqlTitle += '@'+REPLACE( @TableName,'#','')+'+(case when (select COUNT(distinct Name) from '+@TableName+')>=2 then ''等 '' else '''' end)+'        
 END     
        
 Set @index +=1        
end        
     
 set @Sql +=CHAR(10)+'select '+@SqlTime+''' ''+'+ @SqlTitle+''' '+@EndStrTitle+''' as Title'      
     
 if(@YName <>'')      
 BEGIN      
 set @Sql +=','''+@YName +''' as YName'      
 END     
      
 IF(@Unit<>'')      
 BEGIN      
 set @Sql +=' ,'''+@Unit +''' as Unit '       
 END     
   
   
  IF(@YMax<>'')      
 BEGIN      
 set @Sql +=' ,'''+@YMax +''' as YMax '       
 END    
  IF(@YMin<>'')      
 BEGIN      
 set @Sql +=' ,'''+@YMin +''' as YMin '       
 END    
  IF(@YMax_Second<>'')      
 BEGIN      
 set @Sql +=' ,'''+@YMax_Second +''' as YMax_Second '       
 END    
  IF(@YMin_Second<>'')      
 BEGIN      
 set @Sql +=' ,'''+@YMin_Second +''' as YMin_Second '       
 END    
      
 print @sql        
 exec (@Sql)        
end        
        
        
        
-- Sp_Com_Get_ChtTitle        
go

