

-- =============================================
-- Author:		<唐华明>
-- create date: <2016年3月15日>
-- Description:	获取vw_Dim511_Part 数据
-- =============================================
CREATE function [dbo].[fn_GetDimPart](
@Type varchar(MAX) = '数值',
@Name varchar(MAX)
)returns @Result table(Name varchar(200),ID int,istrue int,[选项集合类型] nvarchar(200),Beginvalue decimal(18,2),Endvalue decimal(18,2))
as
begin
if(@Type ='数值')
Begin
	insert @Result 
	select * from
	(
		select  '全部集合:所有'+ Name Name,-1 ID
				,'1' istrue,'属性集合' 选项集合类型
				,minvalue as Beginvalue
				,maxvalue as Endvalue
		from Tbl_Dim_Setting
		where Name = @Name		
			
		union all
		
		select cast(b.Value * a.id as varchar(20))+'-'+cast(b.Value * (a.id+1) as varchar(20)) as Name
		,a.ID
		,'0'  as istrue ,'基础选项' as 选项集合类型
		,b.Value * a.id as Beginvalue,b.Value * (a.id+1) as Endvalue
		from tbl_base_num as a
		left join Tbl_Dim_Setting as b on b.Value * a.id >= b.minvalue and b.Value * a.id <= b.maxvalue
		where Name = @Name
		
		union all
		
		select  '未知' Name,0 ID
				,'1' istrue,'属性集合' 选项集合类型
				,maxvalue as Beginvalue
				,minvalue as Endvalue
		from Tbl_Dim_Setting
		where Name = @Name
	) as a
END



 return
end
go

