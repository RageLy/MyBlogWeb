-- =============================================
-- Author:		白冰
-- Create date: 2016-06-06
-- Description:	获取数据库中关于某特定ID的粒子数据，便于在Web展现
-- =============================================
CREATE PROCEDURE [dbo].[Sp_DataManagement_Get_ParticalData]
	@ID NVARCHAR(50) = ''
AS
BEGIN
	
	SET NOCOUNT ON
	
	IF @ID IS NOT NULL AND LEN(@ID) <> 0
	BEGIN
		SELECT 
		Code
		 ,CONVERT(NVARCHAR(50), OptDate, 23) AS OptDate
		 ,PType
		 ,Class
		 ,Kettle
		,TOutput
		,FOutput
		,PigmentCode, ReactBACode, ReactBECode, SolventG
		,PCRSpeed
		,PCTime
		,WBTempSet
		,WBTempActually
		,WBRSpeedSet
		,WBRSpeedActually
		,Ini1JoinTime
		,Ini1SpeedSet
		,Ini1Speed
		,Ini1TempSet
		,Ini1Temp
		,Ini2BTime
		,Ini2JoinTime
		,Ini2SpeedSet
		,Ini2Speed
		,OffC1SpeedSet
		,OffC1Speed
		,OffC1Time
		,OffC2SpeedSet
		,OffC2Speed
		,OffC2Time
		,OffC3SpeedSet
		,OffC3Speed
		,OffC3Time
		,OffC4SpeedSet
		,OffC4Speed
		,OffC4Time
		,OffC5SpeedSet
		,OffC5Speed
		,OffC5Time
		,Viscosity
		,Zeta
		,Organic
		,PSize05
		,PSize09
		 ,Ppole
		 ,Npole
		 ,Remark
		FROM dbo.Bs_Partical
		WHERE ID=@ID
	END
		
END
go

