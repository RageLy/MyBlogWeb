-- =============================================    
-- Description: 通过容器名字获取相关信息进行加载(隐藏列、查询器condition)    
-- =============================================    
CREATE proc [dbo].[Sp_Sys_GetTableCfg]     
 @FormID varchar(500),    
 @EmpID int=0    
AS    
BEGIN    
 select * from tbl_sys_TableCfg where FormID = @FormID and EmpID = @EmpID  
END
go

