

/*
刘轶 2014--7-7 行转列 函数
*/
create function [dbo].[RowToColumn](  
@table varchar(50)
,@title varchar(50)
,@data varchar(50)
,@groupBy varchar(200)
,@orderBy varchar(200)
,@titleOrderBy varchar(200))    
returns varchar(max)     
as     
begin    
     
 declare @s varchar(max)=''  
 declare @titleOrderBy_cl varchar(50)='',@titleOrderBy_ob varchar(50)=''
 ,@into2 varchar(50)=''
 if(@titleOrderBy!='')
 begin
	set @into2=',@t1'
	set @titleOrderBy_cl = ','+@titleOrderBy
	set @titleOrderBy_ob = ' order by '+@titleOrderBy
 end
 --set @sql='select * into #t from '+@table    
 set @s='    
 declare  ctem cursor    
 for    
 select distinct '+@title+@titleOrderBy_cl+' from '+@table+@titleOrderBy_ob+'    
 open ctem    
     
 declare @SubName varchar(200),@t1 varchar(200)  
    
 fetch next from ctem into @SubName'+@into2+'    
 declare @sql varchar(max)    
 set @sql='' select '+@groupBy+'  as [ ],''    
 while @@FETCH_STATUS=0    
 Begin    
      
 set @sql =@sql+'' sum( case when '+@title+'=''''''+@SubName+'''''' then case when '+@data+' is null then 0 else '+@data+' end else 0 end) as ''''''+@SubName+'''''',''    
     
 fetch next from ctem into @SubName'+@into2+'     
 End    
 set @sql = SUBSTRING(@sql,0,len(@sql))    
 set @sql = @sql +''  into #t1 from '+@table+'  group by '+@groupBy+'; select * from #t1 order by '+@orderBy+'''    

 exec(@sql)    
     
 close ctem    
 deallocate ctem '    
     
 return @s    
end
go

