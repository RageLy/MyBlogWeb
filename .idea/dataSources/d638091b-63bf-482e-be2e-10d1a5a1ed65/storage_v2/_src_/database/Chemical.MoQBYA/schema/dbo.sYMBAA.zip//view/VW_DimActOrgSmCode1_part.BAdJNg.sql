

CREATE VIEW [dbo].[VW_DimActOrgSmCode1_part]
AS
SELECT  -1 AS Id ,
'全部集合'AS Name ,
'1' AS istrue ,
'属性集合' 选项集合类型
 FROM    Tbl_AnsCom_DIimToTable AS b
 WHERE   DimNum = 'DimActOrgSmCode1'
 UNION ALL
 SELECT dbo.RandData(1000,9999) ID, Bs_Base_CompType.Name,'2' istrue,'化合物类型' 选项集合类型 FROM  Tbl_Base_Compound 
 LEFT JOIN dbo.Bs_Base_CompType ON Bs_Base_CompType.Id = Tbl_Base_Compound.Type
 WHERE Tbl_Base_Compound.Name IS NOT NULL
 UNION ALL
 SELECT  x.ID AS Id ,
 CAST(x.Name AS VARCHAR(20)) AS Name ,
'0' AS istrue ,
'基础刻度' 选项集合类型
 FROM Tbl_AnsCom_DIimToTable b
 CROSS JOIN ( SELECT DISTINCT 
Name ,ID
 FROM Tbl_Base_Compound  WHERE Name IS NOT NULL ) x
 WHERE DimNum = 'DimActOrgSmCode1'

------------------------------------------

go

