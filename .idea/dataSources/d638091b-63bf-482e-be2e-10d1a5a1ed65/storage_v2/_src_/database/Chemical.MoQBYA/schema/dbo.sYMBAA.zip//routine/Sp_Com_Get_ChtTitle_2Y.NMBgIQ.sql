





  
--==========================================
--获取图形的表头
--==========================================
CREATE PROC [dbo].[Sp_Com_Get_ChtTitle_2Y]
    @TitleNames VARCHAR(200) = '#Time,#Carseries' ,
    @EndStrTitle VARCHAR(200) = '' ,
    @YName VARCHAR(MAX) = '' ,
    @YName_Second VARCHAR(MAX) = '' ,
    @Unit VARCHAR(MAX) = '' ,
    @XName VARCHAR(MAX) = '' ,
    @YMax VARCHAR(MAX) = '' ,
    @YMin VARCHAR(MAX) = '' ,
    @YMax_Second VARCHAR(MAX) = '' ,
    @YMin_Second VARCHAR(MAX) = ''
    ,@splitNumber VARCHAR(MAX) = ''-----新加splitNumber
    ,@ChartType_bar VARCHAR(MAX) = '' -- 新加柱线混合图中 柱子的选取
    ,@SecondYColumn VARCHAR(MAX) = '' -- 新加柱线混合图中 柱子的选取
AS
    BEGIN  
        PRINT ( '@TitleNames:' + @TitleNames + '   @EndStrTitle:'
                + @EndStrTitle + '   @YName:' + @YName + '   @YName_Second:'
                + @YName_Second + '   @XName:' + @XName + '   @YMax:' + @YMax
                + '   @YMin:' + @YMin + '   @YMax_Second:' + @YMax_Second
                + '   @YMin_Second:' + @YMin_Second
                + '   @splitNumber:' + @splitNumber );      
        SELECT  ROW_NUMBER() OVER ( ORDER BY String ) AS n ,
                String
        INTO    #TableNames
        FROM    dbo.split(@TitleNames, ',');        
        DECLARE @Sql VARCHAR(MAX)= '' ,
            @index INT = 1 ,
            @count INT ,
            @TableName VARCHAR(50)= '' ,
            @SqlTitle VARCHAR(MAX)= '' ,
            @SqlTime VARCHAR(MAX) = ''      
        SELECT  @count = COUNT(1)
        FROM    #TableNames        
        WHILE ( @index <= @count )
            BEGIN        
                SELECT  @TableName = String
                FROM    #TableNames
                WHERE   n = @index        
                PRINT @TableName      
                IF ( @TableName = '#Time' )
                    BEGIN          
                        SET @Sql += CHAR(10) + ' declare @'
                            + REPLACE(@TableName, '#', '') + ' varchar(max) '
                            + CHAR(10) + 'select @' + +REPLACE(@TableName, '#',
                                                              '')
                            + +'= dbo.GetTimeName_SpecialID(MIN(id),Max(id)) from #time;'        
          
                        SET @SqlTime += '@' + REPLACE(@TableName, '#', '')
                            + '+ '        
                    END        
                ELSE
                    BEGIN        
                        SET @Sql += CHAR(10) + ' declare @'
                            + REPLACE(@TableName, '#', '') + ' varchar(max) '
                            + CHAR(10) + CHAR(10) + ' set @'
                            + REPLACE(@TableName, '#', '')
                            + ' =( select distinct top 2 Name+'','' from '
                            + @TableName + ' for xml path('''') );'     
         
                        SET @Sql += 'set @' + REPLACE(@TableName, '#', '')
                            + ' =cast( SUBSTRING(@' + REPLACE(@TableName, '#',
                                                              '') + ',0,LEN(@'
                            + REPLACE(@TableName, '#', '')
                            + ')) as varchar(50));'     
         
                        SET @SqlTitle += '@' + REPLACE(@TableName, '#', '')
                            + '+(case when (select COUNT(distinct Name) from '
                            + @TableName + ')>=2 then ''等 '' else '''' end)+'        
                    END     
        
                SET @index += 1        
            END        
     
        SET @Sql += CHAR(10) + 'select '''  + @EndStrTitle + ''' as Title'      
     
        IF ( @YName <> '' )
            BEGIN      
                SET @Sql += ',''' + @YName + ''' as yName'
            END 
     
        IF ( @YName_Second <> '')
            BEGIN
            	SET @Sql += ',''' + @YName_Second + ''' as yName_Second'
            END
     
        IF ( @Unit <> '' )
            BEGIN      
                SET @Sql += ' ,''' + @Unit + ''' as Unit '       
            END     
     
        IF ( @XName <> '' )
            BEGIN      
                SET @Sql += ' ,''' + @XName + ''' as xName '       
            END     
   
	    IF ( @ChartType_bar <> '' )
            BEGIN      
                SET @Sql += ' ,''' + @ChartType_bar + ''' as ChartType_bar '       
            END     
            
        IF ( @SecondYColumn <> '' )
            BEGIN      
                SET @Sql += ' ,''' + @SecondYColumn + ''' as SecondYColumn '       
            END   
   
   

        --IF ( @YMax <> '' )
        --    BEGIN      
        --        SET @Sql += ' ,''' + @YMax + ''' as yMax '       
        --    END    
        --IF ( @YMin <> '' )
        --    BEGIN      
        --        SET @Sql += ' ,''' + @YMin + ''' as yMin '       
        --    END    
        --IF ( @YMax_Second <> '' )
        --    BEGIN      
        --        SET @Sql += ' ,''' + @YMax_Second + ''' as yMax_Second '       
        --    END    
        --IF ( @YMin_Second <> '' )
        --    BEGIN      
        --        SET @Sql += ' ,''' + @YMin_Second + ''' as yMin_Second '       
        --    END    
      
        PRINT @sql  
        EXEC (@Sql)      
       
    END        
        
        
        
-- Sp_Com_Get_ChtTitle        
go

