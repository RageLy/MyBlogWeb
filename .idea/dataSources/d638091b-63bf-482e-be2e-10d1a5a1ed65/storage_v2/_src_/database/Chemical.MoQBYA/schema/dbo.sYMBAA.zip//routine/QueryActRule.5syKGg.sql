CREATE PROCEDURE QueryActRule
    @Code int ,
    @OrderFields VARCHAR(100) = '' ,
    @SpName VARCHAR(50) = '' ,
    @EmpID INT = 1 ,
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15'
AS
    BEGIN
        SELECT  'ID' AS 'ID','n' AS '序号' ,
                'BaseCompoundID' AS '化合物ID' ,
                'BaseCompoundName' AS '化合物Smiles编码'
        UNION ALL
        SELECT  'Varchar 500','Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500';
        SELECT  @Code ID,Bs_BaseCompound.ID BaseCompoundID ,
                Bs_BaseCompound.Name BaseCompoundName
        INTO    #Result
        FROM    dbo.Bs_BaseCompound
                LEFT JOIN dbo.Bs_ActRulers ON Bs_BaseCompound.ID = Bs_ActRulers.CompoundID
                LEFT JOIN dbo.Tbl_Base_ActRules ON Tbl_Base_ActRules.ID = Bs_ActRulers.ActSmiles
        WHERE   Tbl_Base_ActRules.ID = @Code;
        
        
        
        
        IF ( @OrderFields IS NULL
             OR @OrderFields = ''
           )
            SET @OrderFields = 'BaseCompoundID';
        DECLARE @totalRow INT = ( SELECT    COUNT(1)
                                  FROM      #Result
                                );
        EXEC dbo.Sp_Sys_Page @tblName = '#Result', @fldName = @OrderFields,
            @rowcount = @totalRow, @PageIndex = @PageIndex,
            @PageSize = @PageSize, @SumType = 0, @SumColumn = '',
            @AvgColumn = '';  
        DROP TABLE #Result;
    END;
go

