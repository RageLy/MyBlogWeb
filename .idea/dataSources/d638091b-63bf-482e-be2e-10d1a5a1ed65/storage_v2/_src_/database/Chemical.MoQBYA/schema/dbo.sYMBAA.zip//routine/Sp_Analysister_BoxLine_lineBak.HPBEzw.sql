



-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 箱线图的2.0替代sp

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_BoxLine_lineBak]
  @condition VARCHAR(MAX)='Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-1%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1'
 ,@OtherCond VARCHAR(MAX) ='温度与产值%温度8%时间%胶囊产值%line%极差%胶囊产值%数量'
 ,@Type VARCHAR(10) = '图' -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
 ,@OrderFields VARCHAR(50) = 'id'
 ,@SpName VARCHAR(50) = 'SinCapsule'
 ,@EmpID INT = 1

 -- 以下参数只在出明细时使用
 ,@PageIndex VARCHAR(5)='1'
 ,@PageSize VARCHAR(5)='10'
 ,@XValue VARCHAR(50) = ''
 ,@DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
BEGIN

---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue=REPLACE(@condition,'|',',');
    
    DECLARE @Usertitle VARCHAR(200) = ''          -- 标题
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称
    DECLARE @YName VARCHAR(50) = ''               -- @OtherCond  传入的Y轴名称
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称
    DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式

    DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式                  
	DECLARE @ErrorRecord NVARCHAR(MAX)='';
    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)            
	 )            
  
    INSERT INTO @OtherCondTbl
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')

     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)
     
     -- OtherCond解析完毕            
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            
    
----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       
    

	-- 时间表 时间临时表必然需要
    CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME            
    )
	
	-- 如果有其它需要用 #时间表的必须在这里添加
	
    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500);      -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500);     -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句            
	DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	
    set @XOrder = ',1 as X排序';
    set @DsOrder = ',1 as G排序';
    

	-- 先输出最标志
	SET @NumSql = ',MIN(['+@YName+']) 最小值,
					dbo.UDA_UpQuartile(['+@YName+']) 下四分位数,
					 dbo.UDA_median(['+@YName+']) 中位数,
					 dbo.UDA_DownQuartile(['+@YName+']) 上四分位数,
					 MAX(['+@YName+']) 最大值,
					 COUNT(['+@YName+']) 数量';
	
	-- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable]
     @SiftValue = @SiftValue
	,@XName = @XName
	,@DsName = @DsName;
     
     -- 拼接创建维度临时表的语句
	  IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @YName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'ND' ,
                                   '' ,
                                   AtYSql ,
                                   IsRange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @YName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
            END;

    SET @sql += isnull(( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') ),'');
    
		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析
     
     -- 用 Dims 临时表拼接需要解析的 维度字符串
     SET @NeedSiftvalue = isnull(( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('')),'');
     
     
     
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;

	
	
     -- 解析维度
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';
     
     
---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        
      
------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
     
     -- 结果集表
	 CREATE TABLE #Result_B
	 (
	  DimX varchar(50)
	  ,OrderX int
	  --,DimG varchar(50)
	  ,OrderG int
	  ,MinValue decimal(18,4)
	  ,DownValue decimal(18,4)
	  ,MiddleValue decimal(18,4)
	  ,UpValue decimal(18,4)
	  ,MaxValue decimal(18,4)
	  ,num int
	 );

    DECLARE @Dims varchar(50);
    
	declare @TimeName varchar(50);   -- 用于判断时间的标志

	IF ( CHARINDEX('时间',@Xname) <> 0 )
		SET @XOrder = 'CAST(t.beginDate as INT) AS X排序';
	ELSE IF ( @Xname = '无横轴' )
		SET @XOrder = 	'1 AS X排序';
	ELSE 
		SELECT  @XOrder = ( CASE WHEN DimOrdersql = '' THEN DimName + '.VWID'
								-- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS X排序'
							 WHEN DimOrdersql <> '' THEN DimOrdersql
								-- 有特殊排序字符则使用特殊的
							 ELSE '1' END
						  + ' AS X排序' )  -- 都没有则用默认
		FROM #Dims 
		WHERE Isneed = 'X';
		
		SET @DsOrder = '1 AS G排序'
	
	SET @InnerSelect += ',' + @XOrder + ',' + @DsOrder ;            
    	  
    
    	 if((SELECT COUNT(*) FROM #Dims GROUP BY ChName HAVING COUNT(ChName)>1)>0)
		 BEGIN
		  SET @ErrorRecord += 'X轴当前选择的维度中文名称重复，请检查；';

	INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_BoxLine_lineBak' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
         END
         
	--set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName)
	IF (   (   SELECT ISNULL(MainTable, '')
           FROM   dbo.Tbl_AnsCom_DIimToTable
           WHERE  DimNum = (   SELECT DimName
                               FROM   #Dims
                               WHERE  ChName = @YName
                           )
       ) = ''
   )
    BEGIN
        SET @ErrorRecord += '查询SELECT MainTable FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = '''+( SELECT DimName
                               FROM   #Dims
                               WHERE  ChName = @YName)+'''为空,请检查;';

	INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_BoxLine_lineBak' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
		end
	IF(@XName = '时间' OR @XName = '无横轴')
		set @TimeName = (SELECT MainTable+'.OptDate' FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = (SELECT DimName FROM #Dims WHERE ChName = @YName) )
	ELSE
		SET @TimeName=  (SELECT MainTable+'.OptDate' FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = (SELECT DimName FROM #Dims WHERE ChName = @XName))
	
	--PRINT @TimeName;
	
	IF(@TimeName = '' OR @TimeName IS NULL)
	BEGIN
		  set @ErrorRecord+='查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '+@SpName+'为空,请检查;';
		INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_BoxLine_lineBak' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
	END
	
	-- Group by段的
    set @Dims = '[' + @XName + '],X排序 '  + ',G排序'  -- 横轴排序字段            
    
	DECLARE @PieColumn VARCHAR(100)
	SET @PieColumn = '';

-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              

  -- 基础版本的 select段Sql语句

  DECLARE @Xcolumn VARCHAR(50) = ISNULL( (SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'X'),'dbo.GetTimeName(t.begindate,t.enddate)');  -- 横轴在本表上面的列名,如果没有说明是时间维度
  
  IF(@XName = '无横轴')
	set @Xcolumn = '''无横轴''';
  
  
  DECLARE @Gcolumn VARCHAR(50) = ISNULL( (SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'G'),'dbo.GetTimeName(t.begindate,t.enddate)');  -- 分组在本表上面的列名，如果没有说明是时间维度
  DECLARE @Ycolumn VARCHAR(50) = ISNULL( (SELECT DimYsql FROM #Dims WHERE ChName = @YName ),'');  -- Y轴在本表上面的列名
	
	
	--select @Ycolumn;
  
  set @sql += 
  '
  INSERT INTO #Result_B(DimX,OrderX,OrderG,MinValue ,
            DownValue ,
            MiddleValue ,
            UpValue ,
            MaxValue,num)
   SELECT ' + @Dims + @NumSql + ' 
   FROM
   (
   SELECT ';
  --去掉了Partition by后的@Gcolumn分组,修改时间2017-7-13原始语句如下,
   --SET @sql += ' Row_Number() OVER(Partition by ' + @Xcolumn + ',' + @Gcolumn + ' Order BY ' + @Ycolumn + ') AS nIndex ,
   --COUNT(1) OVER(Partition by ' + @Xcolumn + ',' + @Gcolumn + ') AS nCount ,';
   --  SET @sql += ' Row_Number() OVER(Partition by ' + @Xcolumn + ' Order BY ' + @Ycolumn + ') AS nIndex ,
   --COUNT(1) OVER(Partition by ' + @Xcolumn + ') AS nCount ,';
   
   
   
   -- 按照 是否需要维度 拼装选择的维度字段

	-- 如果有时间则取出时间  这里可能有特殊的时间维度需要特殊提出
	IF(CHARINDEX('Dim7',@SiftValue) <> 0)
		SET @sql += 'dbo.GetTimeName(t.begindate,t.enddate) AS 时间'
	
	-- 横轴上面的取值要拿出来,时间维度则不取出
	IF( @Xcolumn <> 'dbo.GetTimeName(t.begindate,t.enddate)')
		SET @sql += ',' + @Xcolumn + ' AS [' + @XName + ']';
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名

	-- 分组上面的取值也要拿出来,时间维度则不取出
		--DECLARE @fwsStr NVARCHAR(200)=''
		--SET @sql+=@fwsStr
		--SET @sql += ',分位数类型 AS 分位数标志';
	-- Y 轴上面的取值要拿出来
	
	DECLARE @YSQL VARCHAR(100);
	
	-- 从维度表中取出Y轴上面的维度
	SELECT @YSQL = ',' + @Ycolumn + ' AS [' + @YName + ']';
	-- 实例： ',data.Temp8 AS 温度8';
	
	-- 如果Y轴上面的选取数据是非维度化的内容，则需要在此处注册
	--IF ( @YSQL IS NULL) 
	--	SET @YSQL = CASE 
	--			WHEN @YName = '举例' THEN ',data.exp' + @YName    -- 这一句是注册样例
	--			ELSE ',1 AS [Y轴] ' END;
	
	SET @sql += @YSQL;
	
      
     DECLARE @FromSql VARCHAR(max) = (SELECT JoinTables + ' ' + BaseTable FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName);
     
     IF(@FromSql IS NULL OR @FromSql = '')
     BEGIN
		  SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables, BaseTable FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '+@SpName+'结果为空 ,可能导致报错,请检查;';
		 INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_BoxLine_lineBak' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
     END
     
     SET @sql += ISNULL(@InnerSelect,'') + ' FROM '  + @FromSql;
	 --PRINT @sql
   -----------------------------------------------------
   -- 按照是否需要的表格拼装对应的表格
  
   -- 时间维表一定需要 放在可能会取到时间的表之后 
  IF(CHARINDEX('Dim7',@SiftValue) <> 0)           
	SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';            
  
  -- 临时存储拼接的SQL语句
  DECLARE @sql1 VARCHAR(max) = '';
  
  -- 将INNER JOIN 维度临时表段拼接起来
  SET @sql1 = isnull(( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE DimName + '.ID = ' + DimYsql END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('')),'');
		
   -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
  SET @sql1 = REPLACE(REPLACE(@sql1,'&lt;','<'),'&gt;','>') ;
  
  -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'
  SET @sql += @sql1 ;
  
  set @sql += '
  WHERE ' + @Ycolumn + ' IS NOT NULL 
  ) x
  GROUP BY ' + @Dims;

  -- 排序段
  SET @sql += ' Order By X排序,G排序;
  '

  SET @sql+=' if((select count(*) from #Result_B)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_BoxLine_lineBak'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister @condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@Type='''''+@Type+''''',@SpName='''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(5))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END '


  --插入错误提示的判断语句
	 SET @sql +=ISNULL((SELECT ' if((select count(*) from #'+DimName+')=0) BEGIN INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_BoxLine_lineBak'',''表#'+DimName+'数据为空,可能造成报错请检查'',''Exec Sp_Analysister @condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@Type='''''+@Type+''''',@SpName='''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(5))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END ' FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')),'')
  -- 注销临时表
	SET @sql += isnull(( SELECT 'DROP TABLE #' +  DimName + ';'
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') ),'');
  --SELECT @sql
  -- 逐步替换Y轴并将5个分组加入计算表
  
  -- 1.最小值
  DECLARE @timeStr NVARCHAR(100)=''
  --SET @sql = REPLACE(@sql,'Y轴标志','MIN([' + @YName + '])');
  --SET @sql = REPLACE(@sql,'分位数类型','''最小值''');
  print @sql
  EXEC(@sql);
  SET @timeStr=(SELECT dbo.GetTimeName(beginDate,endDate)+',' FROM #time FOR XML PATH(''))
   SET @timeStr=left(@timeStr,LEN(@timeStr)-1)
    IF ((SELECT COUNT(*) FROM #time) > 5)
BEGIN
    SET @TimeStr =
    (
        SELECT TOP 5
            dbo.GetTimeName(beginDate, endDate) + ','
        FROM #time
        FOR XML PATH('')
    );
    SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
END;
  
  TRUNCATE TABLE #time;

  
--  -- 2.下四分卫
--  SET @sql = REPLACE(@sql,'MIN([' + @YName + '])','SUM(CASE WHEN nIndex = ( CASE WHEN nCount in (1,2) THEN 1 ELSE cast( 0.25 * (nCount + 1) AS INT) END ) THEN [' + @YName + '] ELSE 0 END )');
--  SET @sql = REPLACE(@sql,'''最小值''','''下四分位''');
--  SET @sql = REPLACE(@sql,'1 AS G排序','2 AS G排序');
--  PRINT @sql
--  EXEC(@sql);
--  SET @timeStr=(SELECT dbo.GetTimeName(beginDate,endDate)+',' FROM #time FOR XML PATH(''))
--   SET @timeStr=left(@timeStr,LEN(@timeStr)-1)
--    IF ((SELECT COUNT(*) FROM #time) > 5)
--BEGIN
--    SET @TimeStr =
--    (
--        SELECT TOP 5
--            dbo.GetTimeName(beginDate, endDate) + ','
--        FROM #time
--        FOR XML PATH('')
--    );
--    SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
--END;
--  TRUNCATE TABLE #time;
  
--  -- 3.中位数
--  SET @sql = REPLACE(@sql,'SUM(CASE WHEN nIndex = ( CASE WHEN nCount in (1,2) THEN 1 ELSE cast( 0.25 * (nCount + 1) AS INT) END ) THEN [' + @YName + '] ELSE 0 END )','SUM(CASE WHEN nIndex = ( CASE WHEN nCount in (1) THEN 1 ELSE cast( 0.5 * (nCount + 1) AS INT) END ) THEN [' + @YName + '] ELSE 0 END )');
--  SET @sql = REPLACE(@sql,'''下四分位''','''中位数''');
--  SET @sql = REPLACE(@sql,'2 AS G排序','3 AS G排序');
--  EXEC(@sql);
--   SET @timeStr=(SELECT dbo.GetTimeName(beginDate,endDate)+',' FROM #time FOR XML PATH(''))
--   SET @timeStr=left(@timeStr,LEN(@timeStr)-1)
--    IF ((SELECT COUNT(*) FROM #time) > 5)
--BEGIN
--    SET @TimeStr =
--    (
--        SELECT TOP 5
--            dbo.GetTimeName(beginDate, endDate) + ','
--        FROM #time
--        FOR XML PATH('')
--    );
--    SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
--END;

--  TRUNCATE TABLE #time;
  
--  -- 4.上四分卫
--  SET @sql = REPLACE(@sql,'SUM(CASE WHEN nIndex = ( CASE WHEN nCount in (1) THEN 1 ELSE cast( 0.5 * (nCount + 1) AS INT) END ) THEN [' + @YName + '] ELSE 0 END )','SUM(CASE WHEN nIndex = ( CASE WHEN nCount in (1) THEN 1 ELSE cast( 0.75 * (nCount + 1) AS INT) END ) THEN [' + @YName + '] ELSE 0 END )');
--  SET @sql = REPLACE(@sql,'''中位数''','''上四分位''');
--  SET @sql = REPLACE(@sql,'3 AS G排序','4 AS G排序');
--  EXEC(@sql);
--    SET @timeStr=(SELECT dbo.GetTimeName(beginDate,endDate)+',' FROM #time FOR XML PATH(''))
--   SET @timeStr=left(@timeStr,LEN(@timeStr)-1)
--    IF ((SELECT COUNT(*) FROM #time) > 5)
--BEGIN
--    SET @TimeStr =
--    (
--        SELECT TOP 5
--            dbo.GetTimeName(beginDate, endDate) + ','
--        FROM #time
--        FOR XML PATH('')
--    );
--    SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
--END;
--  TRUNCATE TABLE #time;
  
--  -- 5.最大值
--  SET @sql = REPLACE(@sql,'SUM(CASE WHEN nIndex = ( CASE WHEN nCount in (1) THEN 1 ELSE cast( 0.75 * (nCount + 1) AS INT) END ) THEN [' + @YName + '] ELSE 0 END )','MAX([' + @YName + '])');
--  SET @sql = REPLACE(@sql,'''上四分位''','''最大值''');
--  SET @sql = REPLACE(@sql,'4 AS G排序','5 AS G排序');
--  EXEC(@sql);
--   SET @timeStr=(SELECT dbo.GetTimeName(beginDate,endDate)+',' FROM #time FOR XML PATH(''))
--   SET @timeStr=left(@timeStr,LEN(@timeStr)-1)
--    IF ((SELECT COUNT(*) FROM #time) > 5)
--BEGIN
--    SET @TimeStr =
--    (
--        SELECT TOP 5
--            dbo.GetTimeName(beginDate, endDate) + ','
--        FROM #time
--        FOR XML PATH('')
--    );
--    SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
--END;
--  TRUNCATE TABLE #time;
  
--  -- 6.数量
--  SET @sql = REPLACE(@sql,'MAX([' + @YName + '])','COUNT([' + @YName + '])');
--  SET @sql = REPLACE(@sql,'''最大值''','''数量''');
--  SET @sql = REPLACE(@sql,'5 AS G排序','6 AS G排序');
--  EXEC(@sql);
--   SET @timeStr=(SELECT dbo.GetTimeName(beginDate,endDate)+',' FROM #time FOR XML PATH(''))
--   SET @timeStr=left(@timeStr,LEN(@timeStr)-1)
--    IF ((SELECT COUNT(*) FROM #time) > 5)
--BEGIN
--    SET @TimeStr =
--    (
--        SELECT TOP 5
--            dbo.GetTimeName(beginDate, endDate) + ','
--        FROM #time
--        FOR XML PATH('')
--    );
--    SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
--END;
--	TRUNCATE TABLE #time;
  --print @sql;
  --SELECT * FROM #Result_B;
  --RETURN;
  ------ 11.21 增加 连接到自动计算记录参数
  DECLARE @TrendSql VARCHAR(max) = '';
  DECLARE @XView VARCHAR(max) = '';
  DECLARE @GView VARCHAR(max) = '';

  SELECT @XView = 'VW_' + DimName + '_Part' FROM #Dims WHERE isNeed = 'X';
  SELECT @GView = 'VW_' + DimName + '_Part' FROM #Dims WHERE isNeed = 'G';
  
 -- SET @TrendSql += ' DECLARE @Data T_TrandAna_DataSource;'
  
 -- SET @TrendSql += '
 -- Insert into @Data select OrderX,OrderG,num FROM #Result_B
 -- ORDER BY OrderX,OrderG ;' 

 -- SET @TrendSql += '
	--EXEC [Sp_Analysister_TrendAna] 
	-- @condition = ''' + @condition + '''
	--,@OtherCond = ''' + @OtherCond + '''
	--,@dataSource = @Data
	--,@AnaName = ''' + @SpName + '''
   --'
   
IF (@Usertitle = '' OR @Usertitle IS NULL)
BEGIN
    SET @Usertitle = @timeStr + ' [' + @XName + ']上的[' + @YName + ']箱线图';
    IF ((SELECT COUNT(*) FROM #Dims WHERE Isneed = 'F') <> 0)
    BEGIN
        DECLARE @WDFilter NVARCHAR(500)
            =   (
                    SELECT '[' + ChName + '],' FROM #Dims WHERE Isneed = 'F' FOR XML PATH('')
                );
        SET @WDFilter = ',另筛选' + LEFT(@WDFilter, LEN(@WDFilter) - 1);
        SET @Usertitle += @WDFilter;
    END;
END;
  --PRINT '!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!'
  --PRINT @TrendSql;
  PRINT '不报错'
 -- IF(@Type = '仅计算')
 -- BEGIN
	--EXEC(@TrendSql)
	--RETURN;
 -- END
 ---- 增加END
  

          
------------------------------------------------------------ 各比较类型数据计算 ----------------------------------------------------------------------                  
              
  -- 结果临时表，写在外面方便后面调用            
              
  CREATE TABLE #Result_Final            
    (    
	  DimXOrder DECIMAL(18,2),      
      OrderX INT ,            
      DimX VARCHAR(max) ,            
      DimG VARCHAR(max) ,            
      OrderG INT ,            
     MinValue decimal(18,4)
	  ,DownValue decimal(18,4)
	  ,MiddleValue decimal(18,4)
	  ,UpValue decimal(18,4)
	  ,MaxValue decimal(18,4) 
	  ,num int          
    )             
                 
     CREATE TABLE #Result_All            
    (            
      DimX VARCHAR(max) ,            
      OrderX INT ,            
      DimG VARCHAR(max) ,            
      OrderG INT            
      ,MinValue decimal(18,4)
	  ,DownValue decimal(18,4)
	  ,MiddleValue decimal(18,4)
	  ,UpValue decimal(18,4)
	  ,MaxValue decimal(18,4)
	  ,num int
    )
	--SELECT * FROM     #Result_B;
	   

     ---数值类型插入时直接取数字排序
IF (   (   SELECT isrange
           FROM   #Dims
           WHERE  Isneed = 'X'
       ) = 1
   )
INSERT INTO #Result_Final (   DimXOrder ,
                              DimX ,
                              OrderX ,
                              OrderG ,
                              MinValue ,
                              DownValue ,
                              MiddleValue ,
                              UpValue ,
                              MaxValue ,
                              num
                          )
            SELECT CAST(LEFT(( REPLACE(
                                          REPLACE(
                                                     REPLACE(
                                                                RIGHT(DimX, LEN(DimX)
                                                                            - CHARINDEX(
                                                                                           ':' ,
                                                                                           DimX ,
                                                                                           0
                                                                                       )) ,
                                                                ':' ,
                                                                ''
                                                            ) ,
                                                     '[' ,
                                                     ''
                                                 ) ,
                                          ')' ,
                                          ''
                                      )
                             ) ,CHARINDEX(
                                             '-' ,
                                             REPLACE(
                                                        REPLACE(
                                                                   REPLACE(
                                                                              RIGHT(DimX, LEN(DimX)
                                                                                          - CHARINDEX(
                                                                                                         ':' ,
                                                                                                         DimX ,
                                                                                                         0
                                                                                                     )) ,
                                                                              ':' ,
                                                                              ''
                                                                          ) ,
                                                                   '[' ,
                                                                   ''
                                                               ) ,
                                                        ')' ,
                                                        ''
                                                    ) ,
                                             0
                                         ) - 1) AS DECIMAL(18, 4)) ,
                   DimX ,
                   OrderX ,
                   OrderG ,
                   MinValue ,
                   DownValue ,
                   MiddleValue ,
                   UpValue ,
                   MaxValue ,
                   num
            FROM   #Result_B;

ELSE ---非数值类型的无需排序
INSERT INTO #Result_Final (   DimXOrder ,
                              DimX ,
                              OrderX ,
                              OrderG ,
                              MinValue ,
                              DownValue ,
                              MiddleValue ,
                              UpValue ,
                              MaxValue ,
                              num
                          )
            SELECT NULL ,
                   DimX ,
                   OrderX ,
                   OrderG ,
                   MinValue ,
                   DownValue ,
                   MiddleValue ,
                   UpValue ,
                   MaxValue ,
                   num
            FROM   #Result_B;
	PRINT '-----------------0008'
	--SELECT * FROM #Result_Final
	
	DECLARE @YMax DECIMAL(18,2),@YMin DECIMAL(18,2), @YMax2 DECIMAL(18,2),@YMin2 DECIMAL(18,2)
  
	--SELECT @YMax = MAX(num),@YMin = MIN(num) FROM #Result_B WHERE DimG <> '数量';
	--SELECT @YMax2 = MAX(num),@YMin2 = 0 FROM #Result_B WHERE DimG = '数量';
  
	IF(@YMax = @YMin) 
		SELECT   @YMin = @YMin -2 ,@YMax =@YMax+3 
		
	IF(@YMax2 = @YMin2) 
		SELECT   @YMax2 = 2
		
------------------------------------------------------------------------------------- 图形输出格式计算 -------------------------------------------------------------------                
                
    DECLARE @Rsql VARCHAR(MAX);            
    DECLARE @FinalColumn NVARCHAR(1000);

    CREATE TABLE #Result_C            
  ( OrderX INT,DimX VARCHAR(50),DimG VARCHAR(50),num VARCHAR(50))            
    CREATE TABLE #Result_D            
  ( OrderX INT,DimX VARCHAR(50),DimG VARCHAR(50),num VARCHAR(50))            
    CREATE TABLE #Result_F            
  ( OrderX INT,DimX VARCHAR(50),DimG VARCHAR(50),num VARCHAR(50))       
                
    -- 为输出时不带OrderG这一列，要不前端不识别这一列 现在去掉是因为分组在输出时也需要排序，所以先排序然后再去掉这一列输出            
   -- IF (@ChatType IN ('pie','Pie2D','Pie3D'))            
   -- BEGIN            
   --ALTER TABLE #Result_Final DROP COLUMN OrderG            

   -- END

    -- 表 拼接标题用变量            
    DECLARE @title TABLE (cName NVARCHAR(100))            
    DECLARE @titleSql VARCHAR(max)            
                
  -- 行转列输出数据               
            --SELECT * FROM #Result_Final
  IF (SELECT COUNT(1) FROM #Result_Final)>0            
	BEGIN            
		IF (@ChatType IN ('pie','Pie2D','Pie3D'))            
	BEGIN            
    -- 如果是饼图不需要行转列直接输出            
    SET @Rsql = 'SELECT DimX,MinValue 最小值,DownValue 下四分位数,MiddleValue 中位数,UpValue 上四分位数,MaxValue 最大值,num 数量 FROM #Result_Final order by DimXOrder'      
      
  END           
  ELSE            
  BEGIN       


  SET @Rsql = 'SELECT DimX,MinValue 最小值,DownValue 下四分位数,MiddleValue 中位数,UpValue 上四分位数,MaxValue 最大值,num 数量 FROM #Result_Final order by DimXOrder' 
  PRINT @Rsql;            
  EXEC (@Rsql);            
    END                
   IF ( @Type = '图' )            
   BEGIN            
                  
       IF (@ChatType IN ('pie','Pie2D','Pie3D'))            
       BEGIN            
        SET @Rsql = ' SELECT DimX,Num FROM #Result_Final';            
       END            
       ELSE            
       BEGIN            
        
		SET @Rsql += ' SELECT DimX,' + @FinalColumn + ' FROM #RRR order By DimXOrder';

       END            
                      
          PRINT '结果：'+@Rsql;          
       exec(@Rsql);            

                END   
                         
   ELSE IF ( @Type = '表' )            
   BEGIN                
                   
       IF (@ChatType IN ('pie','Pie2D','Pie3D'))            
       BEGIN            
                          
		   INSERT @title SELECT distinct DimX FROM #Result_Final            
	                       
		   SET @titleSql = 'Select ''OrderX'' AS OrderX,''DimX'' AS '' '' ,''num'' AS [' + @YName + '] '            
		   SET @titleSql += ' UNION ALL SELECT ''varchar,500'',''varchar,500'',''varchar,500'' '            
	               
       END      
              
       ELSE            
       BEGIN            
                         
			INSERT @title SELECT distinct DimG FROM #Result_Final            
			set @titleSql = 'Select ''OrderX'' AS ''OrderX'',''DimX'' AS '' '''             
			 + (SELECT ',''' + cName +''' AS [' + cName + ']' FROM @title c FOR XML PATH(''))            
			SET @titleSql += ' UNION ALL SELECT ''varchar,500'',''varchar,500''' + (SELECT ',''varchar,500''' FROM @title c FOR XML PATH(''))            
	                                  
        END            
                   
        PRINT @titleSql            
        EXEC (@titleSql)

       IF (@OrderFields IS NULL OR @OrderFields ='')            
       BEGIN            
        SET @OrderFields = 'OrderX';            
       END            
                         
       IF (CHARINDEX('asc',@OrderFields) > 0)            
       BEGIN            
        SET @OrderFields = '[' + LEFT(@OrderFields,LEN(@OrderFields) - 3) + '] asc'             
       END            
                         
       IF (CHARINDEX('desc',@OrderFields) > 0)           
       BEGIN            
		SET @OrderFields = '[' + LEFT(@OrderFields,LEN(@OrderFields) - 4) + '] desc'             
       END
       
        SET @Rsql += ' select * from #RRR ORDER BY ' + @OrderFields ;            
        PRINT '结果:'+@Rsql            
        EXEC (@Rsql);            
                                        
       END            

   END            
  -- 没有数据的情况            
  ELSE             
  BEGIN            
              
   IF (@ChatType IN ('pie','Pie2D','Pie3D'))            
   BEGIN            
    SELECT '' DimX,'0'           
   END            
   ELSE            
   BEGIN            
    SELECT '' AS DimX        
   END            
               
  END            
               
  --  图形标题拼接            
                
    IF ( @Type = '图')            
    BEGIN                             
		DECLARE @t VARCHAR(100)            

		-- 按是否需要来拼接要出标题的 维度            
		SET @t = '#time'            
          
		-- 如果用户没有定义标题 则拼接   
		declare @Yma varchar(max)
		declare @Ymi varchar(max)

	declare @YTbl TABLE
	(
	  Yma varchar(max)
	  ,Ymi varchar(max)
	 ) 
   
	INSERT INTO @YTbl exec [dbo].[Sp_Y_min_max] @maxY=@YMax,@minY=@YMin
	set @Yma=(select Yma from @YTbl)
	set @Ymi=(select Ymi from @YTbl)
	
	DECLARE @Yma2 decimal(18,2),@Ymi2 decimal(18,2);
	
	DELETE FROM @YTbl;
	INSERT INTO @YTbl exec [dbo].[Sp_Y_min_max] @maxY=@YMax2,@minY=@YMin2
	set @Yma2=(select Yma from @YTbl)
	set @Ymi2=(select Ymi from @YTbl)
	
	
	--print @Yma
	--EXEC Sp_Com_Get_ChtTitle_lc @TitleNames = @t,@EndStrTitle = @Usertitle, @YName = @YName,@XName = @XName,@DSName = @DsName,@Unit = '111',@OTOC=@CTOC ,@YMax = @Yma ,@YMin = @Ymi  

                EXEC Sp_Com_Get_ChtTitle_2Y @TitleNames = @t,
                    @EndStrTitle = @Usertitle, @YName = @YName,@YName_Second = '数量' ,@Unit='',@XName=@XName,
                    @YMax = @Yma, @YMin = @Ymi , @YMax_Second  = @Yma2 , @YMin_Second = @Ymi2,@ChartType_bar = '数量',@SecondYColumn = '数量'
    
   END

	-- 注销临时表
	DROP TABLE #Result_B
    DROP TABLE #Result_Final
    DROP TABLE #Result_All
    DROP TABLE #Result_C
    DROP TABLE #Result_D
    DROP TABLE #Result_F
	DROP TABLE #time;
	DROP TABLE #Dims;
	 -- 插入日志记录
     INSERT INTO Tbl_Log_AnaUseLog    
            ( EmpID ,  
			  EmpName,  
              freshTime ,    
              spName ,    
              AnaName ,    
              siftvalue ,    
              OherParemeter    
            )    
     VALUES ( @EmpID ,
	 (SELECT EmpName from Tbl_Com_Employee WHERE EmpID=@EmpID),    
              GETDATE() ,    
              'Sp_Analysister_BoxLine_LineBak' ,    
              ''+@SpName+'多维分析器模拟箱线图' ,
              @condition ,
              '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='    
              + @OtherCond
            )  


		
END
go

