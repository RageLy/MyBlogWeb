
Create View VW_DimActTemp_partAll
AS
SELECT  Id AS VWID ,ID ,Name
,Beginvalue,Endvalue FROM vw_DimActTemp_Part WHERE istrue = 0
UNION ALL
SELECT -1 , notAll.Id , ( SELECT Name FROM vw_DimActTemp_Part WHERE istrue = 1 ) 
,notAll.Beginvalue,notAll.Endvalue
FROM ( SELECT * FROM vw_DimActTemp_Part WHERE istrue = 0 ) AS notAll
UNION ALL
SELECT  part.Id ,notAll.Id ,part.Name
,notAll.Beginvalue,notAll.Endvalue
FROM ( SELECT * FROM vw_DimActTemp_Part WHERE istrue = 2 ) part
INNER JOIN ( SELECT * FROM vw_DimActTemp_Part WHERE istrue = 0 ) AS notAll ON part.ID2 = notAll.ID2

------------------------------------------
go

