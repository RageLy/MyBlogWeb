-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION Fn_GetSpearmanR
(
	-- Add the parameters for the function here
	@data SpearmanPara READONLY
)
RETURNS DECIMAL(18,6)
AS
BEGIN
	
	DECLARE @r DECIMAL(18,6);
	DECLARE @avgX DECIMAL(18,6);
	DECLARE @avgY DECIMAL(18,6);
	
	
	SELECT @avgX = AVG(x), @avgY = AVG(y) FROM @data;
	
	SELECT @r = FenZis / SQRT( FenMus1 * FenMus2 ) FROM
	(
		select SUM(FenZi) AS FenZis,SUM(FenMux) AS FenMus1,SUM(FenMuY) AS FenMus2  FROM 
		(
			SELECT (x - @avgX) * (y-@avgY) AS FenZi
			, (x - @avgX) * (x - @avgX)  AS FenMux
			, (y - @avgY) * (y - @avgY) AS FenMuY
			FROM @data
		) x
	) xx WHERE FenMus1 <> 0 AND FenMus2 <> 0


	--SET @r = (SELECT COUNT(*) FROM @data );

	-- Return the result of the function
	RETURN @r;

END
go

