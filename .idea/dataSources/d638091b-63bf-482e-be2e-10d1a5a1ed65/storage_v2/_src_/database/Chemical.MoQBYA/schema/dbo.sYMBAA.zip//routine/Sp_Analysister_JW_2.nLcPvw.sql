
--EXEC Sp_Analysister_JW_2 @condition = N'DimDouCapsuleXzWd:136|137%DimStepLength:2%Dim7:Y:this10%DimDouYX:-1%DimOilSeries:3%DimOilDensity:-1%DimOilSTension:-1%DimDDLps:-1%DimOilViscosity:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimOilHJTemp:-1%DimOilHJhumidity:-1%DimDouJNPH:-1%DimDouCapsuleDouLot:-1%DimDouFu:-1%DimDouAF0001:-1%DimDouAF0003:-1%DimDouBG0026:-1%DimDouBG0002:-1%DimDouBG0004:-1%DimDouTemp41:-1%DimDouSpeed400:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDouSpeed500:-1%DimDouUpSw:-1%DimDouDownSw:-1%DimDouOutputValue:-1%DimDouLJ:-1%DimDouLJspan:-1%DimDouJNGHL:-1%DimDouCR:-1%DimDouLBK:-1%DimDouLW:-1%DimDouDeltaBK:-1%DimDouDeltaW:-1%DimDouPH:-1%DimDouPhTemp:-1',
--    @OtherCond = N'%无须选择%无选项%胶囊产值%line%主副因素分析%undefined%undefined',
--    @SpName = N'DouCapsule', @EmpID = N'1', @PageSize = N'20',
--    @PageIndex = N'1', @DataType = N'2', @OrderFields = N'';  


-- =============================================                            
-- Author: hjl                                            
-- Create Date: 2016年7月18日  
-- Edit Date: 2016年7月18日                                                  
-- Descript: 降维sp  
-- =============================================                   

CREATE PROCEDURE [dbo].[Sp_Analysister_JW_2]
    @condition VARCHAR(MAX) = 'DimDouKzWd:-1165|-2380|237%DimDouYX:-1%DimDouLW:-1%DimDouFu:-1%DimDouTemp41:-1%DimDouSpeed500:-1%DimDouSpeed400:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDDLps:-1%DimOilViscosity:-1%DimYXLJ05:-1%DimYXLJ09:-1' ,
    @OtherCond VARCHAR(MAX) = '%无选项%无选项%L白%列表%相关性%undefined%undefined' ,
    @Type VARCHAR(10) = '图' , -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面  
    @OrderFields VARCHAR(50) = '' ,
    @SpName VARCHAR(50) = 'DouCapsule' ,
    @EmpID INT = 1 ,
    @DataType INT ,
                              -- 以下参数只在出明细时使用  
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '10' ,
    @XValue VARCHAR(50) = '' ,
    @DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'  
AS
    BEGIN

        ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------              

        SET NOCOUNT ON;

        DECLARE @SiftValue VARCHAR(MAX);
        SET @SiftValue = REPLACE(@condition, '|', ',');

        DECLARE @Usertitle VARCHAR(50) = ''; -- 标题              
        DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                  
        DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                  
        DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                  
        DECLARE @ChatType VARCHAR(50) = ''; -- 图形名称                  
        DECLARE @CTOC VARCHAR(50) = ''; -- @OtherCond 传入的比较方式                  

        DECLARE @CompareType VARCHAR(50) = ''; -- 比较方式                    
        DECLARE @ErrorRecord NVARCHAR(MAX) = '';
        -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                  

        DECLARE @OtherCondTbl TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                String NVARCHAR(50)
            );

        INSERT INTO @OtherCondTbl
                    SELECT string
                    FROM   dbo.f_splitSTR(@OtherCond, '%');

        SET @Usertitle = (   SELECT String
                             FROM   @OtherCondTbl
                             WHERE  ID = 1
                         );
        SET @XName = '无选项'; --( SELECT String FROM @OtherCondTbl WHERE ID = 2 )  
        SET @DSName = (   SELECT String
                          FROM   @OtherCondTbl
                          WHERE  ID = 3
                      );
        SET @YName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 4
                     );
        SET @ChatType = (   SELECT String
                            FROM   @OtherCondTbl
                            WHERE  ID = 5
                        );
        SET @CTOC = (   SELECT String
                        FROM   @OtherCondTbl
                        WHERE  ID = 6
                    );

        --SELECT *FROM @OtherCondTbl
        ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                         


        -- 时间表 时间临时表必然需要  
        CREATE TABLE #time
            (
                id VARCHAR(200) ,
                beginDate DATETIME ,
                endDate DATETIME ,
                beginDate_Lp DATETIME ,
                endDate_Lp DATETIME ,
                beginDate_Ly DATETIME ,
                endDate_Ly DATETIME
            );

        -- 如果有其它需要用 #时间表的必须在这里添加  

        DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段              
        DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序              
        DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序              
        DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg                
        DECLARE @NumSql VARCHAR(500); -- 用于拼接@Sql中 指标计算方式的Sql语句              
        DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句  

        SET @XOrder = ',1 as X排序';
        SET @DsOrder = ',1 as G排序';

        -- 处理维度临时表  
        CREATE TABLE #Dims
            (
                DimName VARCHAR(50) ,
                DimValues VARCHAR(MAX) ,
                ChName VARCHAR(50) ,
                Isneed VARCHAR(50) ,
                DimOrdersql VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                isrange VARCHAR(50)
            );

        EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue ,
                                        @XName = @XName ,
                                        @DsName = @DSName;
        --SELECT * FROM #Dims  
        IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @YName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'Y' ,
                                   '' ,
                                   AtYSql ,
                                   IsRange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @YName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;


            END;
        ELSE
            UPDATE #Dims
            SET    Isneed = 'Y'
            WHERE  ChName = @YName;
        --from 源表  
        DECLARE @FromSql VARCHAR(MAX) = (   SELECT JoinTables + CHAR(10)
                                                   + BaseTable + CHAR(10)
                                            FROM   Tbl_AnsCom_AnaSpConfig
                                            WHERE  SpName = @SpName
                                        );
        IF (   @FromSql IS NULL
               OR @FromSql = ''
           )
            BEGIN
                SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = ''' + @SpName
                                    + '''结果为空 ,可能导致报错,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JW1' , -- SpName - nvarchar(50)
                           @ErrorRecord ,         -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JW1 @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@dataType=''' + CAST(@DataType AS NVARCHAR(2))
                           + ''',@SpName''' + @SpName + ''',@EmpID='''
                           + CAST(@EmpID AS NVARCHAR(2)) + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()              -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;

        -- 拼接创建维度临时表的语句  
        SET @sql += ISNULL(
                        (   SELECT 'CREATE TABLE #' + DimName
                                   + -- 非范围维度类型3列  
                                CASE WHEN isrange = 0 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                                     -- 范围维度类型5列  
                                     WHEN isrange = 1 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'
                                END   + CHAR(10)
                            FROM   #Dims
                            WHERE  Isneed <> 'ND'
                                   AND Isneed <> 'Y'
                            FOR XML PATH('')
                        ) ,
                        ''
                          );
        DECLARE @NeedSiftvalue VARCHAR(MAX) = '';

        SET @NeedSiftvalue = ISNULL(
                                 (   SELECT '%' + DimName + ':' + DimValues
                                     FROM   #Dims
                                     WHERE  Isneed <> 'ND'
                                            AND Isneed <> 'Y'
                                     FOR XML PATH('')
                                 ) ,
                                 ''
                                   );


        --PRINT @NeedSiftvalue;  

        -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %  
        SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                      'Dim7:'
                                      + dbo.GetDimValue(@SiftValue ,
                                                        'Dim7'
                                                       )
                                      + @NeedSiftvalue
                                  ELSE
                                      SUBSTRING(
                                                   @NeedSiftvalue ,
                                                   2 ,
                                                   LEN(@NeedSiftvalue)
                                               )
                             END;


        -- 解析维度  
        SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''
                    + @NeedSiftvalue + ''', @EmpID = '
                    + CAST(@EmpID AS VARCHAR(50)) + CHAR(10) + '';
        --PRINT 'sql: ' + @sql;  


        -- 创建 where维度  
        DECLARE @whereWD VARCHAR(MAX) = ''; ---提取控制维度名  

        DECLARE @TimeName VARCHAR(50);
        SET @TimeName = (   SELECT TimeName
                            FROM   Tbl_AnsCom_AnaSpConfig
                            WHERE  SpName = @SpName
                        );
        IF (   @TimeName = NULL
               OR @TimeName IS NULL
           )
            BEGIN
                SET @ErrorRecord += '查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '
                                    + @SpName + '为空,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JW1' , -- SpName - nvarchar(50)
                           @ErrorRecord ,         -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JW1 @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@dataType=''' + CAST(@DataType AS NVARCHAR(2))
                           + ''',@SpName''' + @SpName + ''',@EmpID='''
                           + CAST(@EmpID AS NVARCHAR(2)) + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()              -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;
        IF ( CHARINDEX('Dim7', @SiftValue) <> 0 )
            SET @whereWD += ' INNER JOIN #time t on ' + @TimeName
                            + ' >= t.beginDate and ' + @TimeName
                            + ' <= t.endDate';
        SET @whereWD += ISNULL(
                            (   SELECT ' inner JOIN #' + DimName + ' AS '
                                       + DimName + ' on '
                                       + CASE WHEN isrange = 1 THEN
                                                  DimName + '.BeginValue <= '
                                                  + DimYsql + ' AND '
                                                  + DimName + '.EndValue > '
                                                  + DimYsql
                                              ELSE
                                                  DimName + '.ID = '
                                                  + DimYsql
                                         END
                                FROM   #Dims
                                WHERE  Isneed <> 'ND'
                                       AND Isneed <> 'Y'
                                       AND DimYsql <> ''
                                FOR XML PATH('')
                            ) ,
                            ''
                              );
        DECLARE @DimNum NVARCHAR(50) = ISNULL((   SELECT DimName
                                                  FROM   #Dims
                                                  WHERE  ChName = @YName
                                              ) ,
                                              ''
                                             );
        SET @whereWD = REPLACE(REPLACE(@whereWD, '&lt;', '<'), '&gt;', '>');
        PRINT @whereWD;
        ----------------------------------------------创建控制维度的中位数-----------------------------------------------------  
        DECLARE @ChoiceWD TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                String NVARCHAR(100)
            );
        INSERT INTO @ChoiceWD
                    SELECT string
                    FROM   dbo.f_splitSTR((   SELECT DimValues
                                              FROM   #Dims
                                              WHERE  ChName = '数值维度选项'
                                          ) ,
                                          ','
                                         );
        --  SELECT * FROM #Dims  
        --SELECT * FROM @ChoiceWD                          
        CREATE TABLE #TempWD
            (
                Id INT ,
                Istrue BIT ,
                DimName NVARCHAR(50)
            );

        DECLARE @sqltemp NVARCHAR(MAX) = '';

        SET @sqltemp += (   SELECT 'INSERT INTO #TempWD SELECT  ID,Istrue,DimName   from vw_'
                                   + DimName + '_part  '
                            FROM   #Dims
                            WHERE  ChName = '数值维度选项'
                        );

        EXEC ( @sqltemp );
        --PRINT '临时' + @sqltemp;  
        --SELECT * FROM #Dims
        --SELECT  *  
        --FROM    #TempWD;  
        CREATE TABLE #ViewNameTb
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                DimNum NVARCHAR(50) ,
                ViewName NVARCHAR(50) ,
                Table_Name NVARCHAR(50) ,
                CoName NVARCHAR(20) ,
                ChName NVARCHAR(50) ,
                istrue NVARCHAR(1) ,
                Isrange INT ,
                DimYsql NVARCHAR(50) ,
            );
        INSERT INTO #ViewNameTb
                    SELECT Tbl_AnsCom_DIimToTable.DimNum ,
                           Tbl_AnsCom_DIimToTable.ViewName ,
                           Tbl_AnsCom_DIimToTable.TableName ,
                           dbo.Tbl_AnsCom_DIimToTable.CoName ,
                           Tbl_AnsCom_DIimToTable.Name_ch ,
                           WD.Istrue ,
                           IsRange ,
                           Tbl_AnsCom_DIimToTable.AtYSql
                    FROM   #TempWD WD
                           INNER JOIN @ChoiceWD ON [@ChoiceWD].String = WD.Id
                           INNER JOIN Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = WD.DimName
                    WHERE  IsRange = 1 AND [@ChoiceWD].String<>-1;
        SET @DataType = (   SELECT Name
                            FROM   dbo.vw_DimStepLength_partAll
                            WHERE  ID = (   SELECT DimValues
                                            FROM   #Dims
                                            WHERE  ChName = '分区数量'
                                        )
                        );
        IF (   @DataType = ''
               OR @DataType IS NULL
           )
            SET @DataType = 2;
        --PRINT '步长：'+CAST(@DataType AS NVARCHAR(5))
        -------------------------------------------------------------------------------------------------------------------------

        DECLARE @Y NVARCHAR(500) = '';
        SET @Y += (   SELECT DistanceTypeStr + ',' + TableName + '.'
                             + Tbl_AnsCom_DIimToTable.CoName + ' AS '
                             + TableName + '' + Tbl_AnsCom_DIimToTable.CoName
                      FROM   dbo.Tbl_BaseSetDistance
                             LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = Tbl_BaseSetDistance.DimNum
                      WHERE  Name_ch = @YName
                             AND Tbl_BaseSetDistance.SpType = @SpName
                  );
        DECLARE @YColumnValue NVARCHAR(50) = (   SELECT TableName + ''
                                                        + Tbl_AnsCom_DIimToTable.CoName
                                                        + ' decimal(18,4)'
                                                 FROM   dbo.Tbl_BaseSetDistance
                                                        LEFT JOIN dbo.Tbl_AnsCom_DIimToTable ON Tbl_AnsCom_DIimToTable.DimNum = Tbl_BaseSetDistance.DimNum
                                                 WHERE  Name_ch = @YName
                                                        AND Tbl_BaseSetDistance.SpType = @SpName
                                             );
        --PRINT '@Y :' + @Y + @YName;
        --SELECT * FROM #Dims
        --SELECT * FROM #ViewNameTb
        DECLARE @InnerSelectNew2 NVARCHAR(MAX) = '' + @Y + ','
                                                 +   ISNULL((   SELECT Table_Name
                                                                + '.'
                                                                + CoName
                                                                + ' AS '
                                                                + Table_Name
                                                                + '' + CoName
                                                                + ','
                                                         FROM   #ViewNameTb
                                                         WHERE  #ViewNameTb.Isrange = 1
                                                         FOR XML PATH('')
                                                     ),'') + '';
        SET @InnerSelectNew2 = SUBSTRING(
                                            @InnerSelectNew2 ,
                                            1 ,
                                            LEN(@InnerSelectNew2) - 1
                                        );

        --PRINT '@whereWD:'+@whereWD
        --PRINT '@InnerSelectNew2:'+@InnerSelectNew2
		--SELECT * FROM #Dims
        --PRINT '字符串: ' + @InnerSelectNew2 + ' 结尾';   
        --PRINT '查询结果：' + @InnerSelectNew2;
        DECLARE @CreateTableResult NVARCHAR(MAX) = '';
        SET @CreateTableResult += ' Drop table QuantileResult1' + CHAR(10);
        SET @CreateTableResult += (   SELECT '  SELECT ' + @InnerSelectNew2
                                             + ' into QuantileResult1 FROM '
                                             + JoinTables + CHAR(10)
                                             + BaseTable + CHAR(10)
                                             + @whereWD + ' where '
                                             +   (   SELECT DimYsql
                                                     FROM   #Dims
                                                     WHERE  Isneed = 'Y'
                                                 ) + ' is not NULL  '
                                             + CHAR(10)
                                             +  ISNULL((   SELECT ' and '
                                                            + Table_Name
                                                            + '.' + CoName
                                                            + ' IS NOT NULL'
                                                     FROM   #ViewNameTb
                                                     FOR XML PATH('')
                                                 ),'') + CHAR(10)
                                      FROM   dbo.Tbl_AnsCom_AnaSpConfig
                                      WHERE  SpName = @SpName
                                  );
        SET @CreateTableResult += ' if((select count(*) from QuantileResult1)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_JW2'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister_JW2 @condition='''''
                                  + @condition + ''''',@OtherCond='''''
                                  + @OtherCond + ''''',@Type=''''' + @Type
                                  + ''''',@OrderFields=''''' + @OrderFields
                                  + ''''',@dataType=''''' + CAST(@DataType AS NVARCHAR(2))
                                  + ''''',@SpName''''' + @SpName
                                  + ''''',@EmpID=''''' + CAST(@EmpID AS NVARCHAR(2))
                                  + ''''',@PageIndex=''''' + @PageIndex
                                  + ''''',@PageSize=''''' + @PageSize
                                  + ''''',@XValue,=''''' + @XValue
                                  + ''''',@DSValue=''''' + @DSValue
                                  + ''''''','''
                                  + CONVERT(NVARCHAR(20), GETDATE(), 120)
                                  + ''') END ';
        --WHERE Isneed='Y'
        --PRINT '执行基础表查询: ' + @sql;
        EXEC ( @sql + @CreateTableResult + ' delete from #time ' );
        --SELECT  @sql 
        --SELECT @CreateTableResult
             --SELECT  @sql + @CreateTableResult
        --FOR     XML PATH('');
        PRINT '@CreateTableResult: ' + @CreateTableResult;
        ------------------------------------
        --SELECT * FROM dbo.QuantileResult1
        CREATE TABLE #Num
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                NumValue INT
            );
        DECLARE @tempNum INT = @DataType;
        WHILE ( @tempNum > 0 )
            BEGIN
                PRINT @tempNum;
                INSERT INTO #Num ( NumValue )
                VALUES ( @tempNum -- NumValue - int  
                       );

                SET @tempNum -= 1;
            END;

        DECLARE @count INT = (   SELECT MAX(ID)
                                 FROM   #ViewNameTb
                             );
        WHILE ( @count > 0 )
            BEGIN
                --PRINT @count  
                DECLARE @DimNumTemp NVARCHAR(50) = (   SELECT DimNum
                                                       FROM   #ViewNameTb
                                                       WHERE  ID = @count
                                                   );
                DECLARE @DimName NVARCHAR(50) = (   SELECT TableName + ''
                                                           + CoName
                                                    FROM   dbo.Tbl_AnsCom_DIimToTable
                                                    WHERE  DimNum = (   SELECT DimNum
                                                                        FROM   #ViewNameTb
                                                                        WHERE  ID = @count
                                                                    )
                                                );

                PRINT @DimName;

                SET @sql += 'CREATE TABLE #' + @DimNumTemp
                            + 'Tb ([ID] INT IDENTITY(1, 1) NOT NULL PRIMARY KEY, DimNum NVARCHAR(50),DimQJ NVARCHAR(100),Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4),DiffValue decimal(18,4));'
                            + CHAR(10);
                ---------------------------------------------------------------
                SET @sql += 'select X,ID,SumTotal into #' + @DimNumTemp
                            + 'ResultData from (select ' + @DimName
                            + ' AS X, ROW_NUMBER() OVER (ORDER BY '
                            + @DimName
                            + ' ) AS ID from QuantileResult1 WHERE '
                            + @DimName
                            + ' IS NOT NULL) a Cross join (select count(*) SumTotal from QuantileResult1 WHERE '
                            + @DimName + ' IS NOT NULL) b ' + CHAR(10);
                --------------------------------------------------------------------------------
                DECLARE @innerSelectNew NVARCHAR(MAX) = '';
                SET @innerSelectNew = 'SELECT  x0,'
                                      +   (   SELECT 'x'
                                                     + CAST(NumValue AS NVARCHAR(4))
                                                     + ','
                                              FROM   #Num
                                              FOR XML PATH('')
                                          );
                SET @innerSelectNew = LEFT(@innerSelectNew, LEN(@innerSelectNew)
                                                            - 1);
                SET @sql += @innerSelectNew;
                SET @sql += ' into #' + @DimNumTemp
                            + 'result1 FROM      
                (  SELECT MIN(X) x0  
                     FROM   #' + @DimNumTemp
                            + 'ResultData  
                   ) b  
                  CROSS JOIN ( SELECT MAX(X)+1 x'
                            + CAST(@DataType AS NVARCHAR(4))
                            + '  
                     FROM   #' + @DimNumTemp
                            + 'ResultData  
                   ) c'     + CHAR(10);
                SET @sql += (   SELECT 'CROSS JOIN  (select X AS x'
                                       + CAST(NumValue AS NVARCHAR(2))
                                       + ' from #' + @DimNumTemp
                                       + 'ResultData where ID=ROUND(SumTotal*'
                                       + CAST(NumValue AS NVARCHAR(4)) + '/'
                                       + CAST(@DataType AS NVARCHAR(4))
                                       + ',0)) a'
                                       + CAST(NumValue AS NVARCHAR(2))
                                       + CHAR(10)
                                FROM   #Num
                                WHERE  NumValue < @DataType
                                FOR XML PATH('')
                            );
                DECLARE @t1 NVARCHAR(MAX) = '';
                --SET @t1 = ''
                --    + ( SELECT  ' select ''' + @DimNumTemp + ''',''[''+CAST(x'
                --                + CAST(NumValue - 1 AS NVARCHAR(10))
                --                + ' AS NVARCHAR(10))+'',''+ CAST(x'
                --                + CAST(NumValue AS NVARCHAR(10))
                --                + ' AS NVARCHAR(10)) + '')'',x'
                --                + CAST(NumValue - 1 AS NVARCHAR(10)) + ',x'
                --                + CAST(NumValue AS NVARCHAR(10)) + ',x'
                --                + CAST(NumValue AS NVARCHAR(10)) + '-x'
                --                + CAST(NumValue - 1 AS NVARCHAR(10))
                --                + ' from #' + @DimNumTemp
                --                + 'result1 UNION ALL'
                --        FROM    #Num
                --      FOR
                --        XML PATH('')
                --      );  

                SET @t1 = ''
                          +   (   SELECT ' select ''' + @DimNumTemp + ''','
                                         + CAST(NumValue AS NVARCHAR(10))
                                         + ',''[''+CAST(x'
                                         + CAST(NumValue - 1 AS NVARCHAR(10))
                                         + ' AS NVARCHAR(10)) +'',''+ CAST(x'
                                         + CAST(NumValue AS NVARCHAR(10))
                                         + ' AS NVARCHAR(10))+'')'',x'
                                         + CAST(NumValue - 1 AS NVARCHAR(10))
                                         + ',x'
                                         + CAST(NumValue AS NVARCHAR(10))
                                         + ',x'
                                         + CAST(NumValue AS NVARCHAR(10))
                                         + '-x'
                                         + CAST(NumValue - 1 AS NVARCHAR(10))
                                         + ' from #' + @DimNumTemp
                                         + 'result1 UNION ALL'
                                  FROM   #Num
                                  FOR XML PATH('')
                              );
                SET @t1 = LEFT(@t1, LEN(@t1) - 9);
                SET @sql += 'insert into #' + @DimNumTemp +'Tb '+ @t1 + CHAR(10);
                SET @sql += ' DROP TABLE #' + @DimNumTemp + 'ResultData'
                            + CHAR(10) + 'DROP TABLE #' + @DimNumTemp
                            + 'result1' + CHAR(10);
                SET @count -= 1;

            END;
        --EXEC (@sql)
        ---------------------------------------------------------------------------------------------------  
        -- 创建 控制维度筛选项维度  
        DECLARE @KZWD VARCHAR(MAX) = '';
        DECLARE @KZWDName VARCHAR(MAX) = '';
        DECLARE @KZWDViewName VARCHAR(MAX) = '';
        SET @KZWDName = (   SELECT DimName
                            FROM   #Dims
                            WHERE  DimYsql = ''
                                   AND ChName = '数值维度选项'
                        );
        SET @KZWD = (   SELECT DimValues
                        FROM   #Dims
                        WHERE  DimYsql = ''
                               AND DimName = @KZWDName
                    );
        SET @KZWDViewName = (   SELECT ISNULL(ViewName, '')
                                FROM   dbo.Tbl_AnsCom_DIimToTable
                                WHERE  DimNum = @KZWDName
                            );

        --拼select 列名（主表ID+控制维度列）  
        CREATE TABLE #DimsTb
            (
                DimName VARCHAR(50) ,
                viewName VARCHAR(50) ,
                ChName VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                Stp VARCHAR(50)
            );

        INSERT INTO #DimsTb (   DimName ,
                                viewName ,
                                ChName ,
                                DimYsql ,
                                Stp
                            )
                    --SELECT * FROM   
                    SELECT a.DimName ,
                           b.ViewName ,
                           a.ChName ,
                           a.DimYsql ,
                           '1'
                    FROM   #Dims a
                           INNER JOIN dbo.Tbl_AnsCom_DIimToTable b ON a.DimName = b.DimNum
                    WHERE  Isneed <> 'ND'
                           AND DimYsql <> ''
                           AND b.IsRange = 1;


        DECLARE @KZWDDimsTb VARCHAR(MAX) = '';

        SET @KZWDDimsTb = ( SELECT '  
  insert into #DimsTb (DimName,viewName,ChName,DimYsql,Stp)  
  select  dimname,tad.ViewName,Name,AtYSql,istrue   
  from VW_' + @KZWDViewName + '_Part AS kz   
  inner join Tbl_AnsCom_DIimToTable tad  
  on kz.dimname=tad.dimnum  
   where kz.id in (' + @KZWD + ')  
   '                      );

        --PRINT '@KZWDDimsTb' + @KZWDDimsTb;  
        EXEC ( @KZWDDimsTb );


        --SELECT @KZWDDimsTb;  

        --SELECT * FROM #Dims;  
        ------修改的地方---------------------------------------------------------------------------------------修改的地方-----------------------------  
        DECLARE @KZWDinner VARCHAR(MAX) = '';
        SET @KZWDinner = (   SELECT ' INNER join #' + DimNum + 'Tb as '
                                    + DimNum + 'Tb on ' + DimYsql + '>='
                                    + DimNum + 'Tb.beginvalue and ' + DimYsql
                                    + '<' + DimNum + 'Tb.endvalue '
                             FROM   #ViewNameTb
                             WHERE  Isrange = 1
                             FOR XML PATH('')
                         );
        --PRINT '@KZWDinner: ' + @KZWDinner;  

        SET @KZWDinner = REPLACE(
                                    REPLACE(@KZWDinner, '&lt;', '<') ,
                                    '&gt;' ,
                                    '>'
                                );
        SET @KZWDinner = ISNULL(@KZWDinner, '');
        --SELECT * FROM #DimsTb  
        --SELECT @KZWDinner;  
        --拼接控制维度与where维度列  
        DECLARE @KZNamewh VARCHAR(MAX) = '';
        SET @KZNamewh = (   SELECT CASE WHEN Stp <> 1 THEN
                                            DimName + 'Tb.name' + ' as '
                                            + DimName + ',' + DimName
                                            + 'Tb.DimQJ,' + DimName
                                            + 'Tb.DiffValue AS ' + DimName
                                            + 'DiffValue,'
                                   END
                            FROM   #DimsTb
                            FOR XML PATH('')
                        );
        IF ( @KZNamewh <> '' )
            --SET @KZNamewh = RIGHT(@KZNamewh, LEN(@KZNamewh) - 1);
            --Y 列  
            DECLARE @YSQL VARCHAR(100);
        DECLARE @Ycolumn VARCHAR(50) = ISNULL((   SELECT DimYsql
                                                  FROM   #Dims
                                                  WHERE  ChName = @YName
                                              ) ,
                                              ''
                                             ); -- Y轴在本表上面的列名  
        SET @YSQL = ',' + @Ycolumn + ' AS ' + REPLACE(@Ycolumn, '.', '');



        DECLARE @DistanceTypeStr VARCHAR(MAX);
        SET @DistanceTypeStr = (   SELECT DistanceTypeStr
                                   FROM   dbo.Tbl_BaseSetDistance
                                   WHERE  DimNum = @DimNum
                                          AND SpType LIKE '%' +@SpName+'%'
                               );

        IF ( @DistanceTypeStr IS NULL )
            BEGIN
                SELECT 'Info' AS 提示信息
                UNION
                SELECT 'Varchar 500';

                SELECT '请配置目标的优等、差等设置！' AS Info;
                RETURN;

            END;



        SET @InnerSelect = ( SELECT 'select ' + ISNULL(@KZNamewh, '')
                                    + @DistanceTypeStr + @YSQL + ' from '
                           );

        -----------------------------------------------降维计算---------------------------------------------------  
        DECLARE @Resultdata VARCHAR(MAX);
        DECLARE @ResultName VARCHAR(MAX) = '';
        SET @ResultName = (   SELECT ',' + DimName + ' varchar(100),'
                                     + DimName + 'QJ varchar(100),' + DimName
                                     + 'DiffValue decimal(18,4)'
                              FROM   #DimsTb
                              WHERE  Stp <> 1
                              FOR XML PATH('')
                          );

        --PRINT '结果数据：' + @ResultName;  

        SET @Resultdata = ( SELECT 'CREATE TABLE #Resultdata  
    (ID int IDENTITY(1, 1) NOT NULL PRIMARY KEY' + ISNULL(@ResultName, '')
                                   + ',GY INT ,' + REPLACE(@Ycolumn, '.', '')
                                   + ' decimal(18, 6))'
                          );

        --PRINT '结果数据：' + @ResultName;  
        --PRINT '@sql:' + @sql;  
        --数据插入临时表#Resultdata  
        SET @YSQL = '';
        DECLARE @Resultzj VARCHAR(MAX);
        SET @Resultzj = ( @Resultdata + ' insert into  #Resultdata  '
                          + @InnerSelect + @FromSql + @whereWD + @KZWDinner
                          + ' where '
                          + ISNULL((   SELECT DimYsql
                                       FROM   #Dims
                                       WHERE  ChName = @YName
                                   ) ,
                                   ''
                                  ) + ' Is not NULL'
                        ) + CHAR(10);

        PRINT @Resultzj;




        ------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------               
        -- 建立结果表  
        DECLARE @CreateTable VARCHAR(MAX);

        SET @CreateTable = ( SELECT ' CREATE TABLE #Result1  
    (GoodValue int, 
     floatValue decimal(18,4), 
     PercentON NVARCHAR(10),  
     spName varchar(50), 
  DataCount int,  
  MaxY Decimal(18,6),  
  MinY Decimal(18,6),  
  AVGY Decimal(18,6),  
  SQtY Decimal(18,6),  
  Siftvalue varchar(Max),  
  PearSenR DECIMAL(18,6),  
  Slope DECIMAL(18,6),  
  LineCons DECIMAL(18,6),  
  ChangePoint int ,  
  Trend Varchar(Max)  
  ' + ISNULL(@ResultName, '') + ')' );

        --PRINT @CreateTable;  

        --取Y轴列  
        DECLARE @Ycolumnjs VARCHAR(50) = ISNULL(
                                             (   SELECT REPLACE(
                                                                   DimYsql ,
                                                                   '.' ,
                                                                   ''
                                                               )
                                                 FROM   #Dims
                                                 WHERE  ChName = @YName
                                             ) ,
                                             ''
                                               );

        DECLARE @ResultDataSql VARCHAR(800);
        SET @ResultDataSql = '''' + @SpName + ''' spname,SUM(CASE WHEN '
                             + @Ycolumnjs
                             + ' is not null THEN 1 ELSE 0 END ) DataCount,MAX('
                             + @Ycolumnjs + ') MaxY,MIN(' + @Ycolumnjs
                             + ') MinY,AVG(' + @Ycolumnjs + ') AVGY,stdev('
                             + @Ycolumnjs + ') SQtY,';
        --PRINT '@ResultDataSql' + @ResultDataSql;  
        DECLARE @GroupBy VARCHAR(800);
        --SELECT * FROM #DimsTb  
        SET @GroupBy = (   SELECT CASE WHEN Stp <> 1 THEN
                                           ',' + DimName + ',' + DimName
                                           + 'QJ,' + DimName + 'DiffValue'
                                  END
                           FROM   #DimsTb
                           FOR XML PATH('')
                       );
        DECLARE @GroupBy1 VARCHAR(800);
        --SELECT * FROM #DimsTb  
        SET @GroupBy1 = (   SELECT CASE WHEN Stp <> 1 THEN
                                            DimName + ',' + DimName + 'QJ,'
                                            + DimName + 'DiffValue,'
                                   END
                            FROM   #DimsTb
                            FOR XML PATH('')
                        );


        --SET @GroupBy = ( SELECT SUBSTRING(@GroupBy, 2, LEN(@GroupBy) - 1)  
        --               );  

        DECLARE @ONRelation NVARCHAR(MAX) = '';

        SET @ONRelation += (   SELECT ' and a.' + DimName + '=b.' + DimName
                               FROM   #DimsTb
                               WHERE  Stp <> 1
                               FOR XML PATH('')
                           );

        --SET @ONRelation = RIGHT(@ONRelation, LEN(@ONRelation) - 3);   

        --PRINT '@ONRelation: ' + @ONRelation;  

        DECLARE @Result1 VARCHAR(MAX);

        SET @GroupBy = ISNULL(@GroupBy, '');
        SET @ONRelation = ISNULL(@ONRelation, '');
        SET @GroupBy1 = ISNULL(@GroupBy1, '');
        IF ( @GroupBy1 <> '' )
            DECLARE @groupBy2 NVARCHAR(800) = 'Group by '
                                              + LEFT(@GroupBy1, LEN(@GroupBy1)
                                                                - 1);
        ELSE
            SET @groupBy2 = '';
        --PRINT '@Resultzj: ' + @Resultzj;   
        --PRINT '@CreateTable: ' + @CreateTable;   
        --PRINT '@ResultDataSql: ' + @ResultDataSql;   
        --PRINT '@GroupBy: ' + @GroupBy;   
        --PRINT '@GroupBy1: ' + @GroupBy1;  
        --PRINT '@ONRelation: ' + @ONRelation;  
        SET @Result1 = ( @Resultzj + @CreateTable + 'INSERT INTO #Result1 '
                         + 'SELECT isnull(a.DataCount,0)  GoodValue,ROUND(CAST(isnull(a.DataCount,0) AS FLOAT)/(case when b.DataCount=0 then 1 else b.DataCount end)*100 ,4) floatValue,  
                CAST(ROUND(CAST(isnull(a.DataCount,0) AS FLOAT)/(case when b.DataCount=0 then 1 else b.DataCount end)*100 ,4) AS NVARCHAR(8))+''%'' PercentON,  
                b.*   
        FROM    ( SELECT ' + @ResultDataSql
                         + 'NULL Siftvalue,NULL PearSenR,NULL Slope,NULL LineCons,NULL ChangePoint,NULL Trend'
                         + @GroupBy
                         + ' FROM #Resultdata WHERE GY=1 Group by '
                         + @GroupBy1
                         + 'GY)   a  
                  RIGHT JOIN ( SELECT ' + @ResultDataSql
                         + 'NULL Siftvalue,NULL PearSenR,NULL Slope,NULL LineCons,NULL ChangePoint,NULL Trend'
                         + @GroupBy + ' FROM #Resultdata ' + @groupBy2
                         + ') b on 1=1 ' + @ONRelation + ''
                       ) + CHAR(10);

        DECLARE @DimNamesAndChs VARCHAR(MAX);
        SET @DimNamesAndChs = (   SELECT CASE WHEN Stp <> 1 THEN
                                                  ',''' + DimName + ''' ['
                                                  + ChName + '区间],'''
                                                  + DimName + 'QJ'' ['
                                                  + ChName + '区段],'''
                                                  + DimName + 'DiffValue'' ['
                                                  + ChName + '差值]'
                                         END
                                  FROM   #DimsTb
                                  FOR XML PATH('')
                              );

        DECLARE @Var500s VARCHAR(MAX);
        SET @Var500s = (   SELECT ',''Varchar 500'',''Varchar 500'',''Varchar 500'''
                           FROM   #DimsTb
                           WHERE  Stp <> 1
                           FOR XML PATH('')
                       );
        DECLARE @Varchars VARCHAR(MAX) = 'select ''n'' 序号,''GoodValue'' 优等数据量,''BadValue'' 差等数据量,''DataCount'' 组内数据数,''floatValue'' [优等占比(%)],''floatBadValue'' [差等占比(%)],''MaxY'' 最大目标值,''MinY'' 最小目标值,''AVGY'' 平均目标值,''JC'' 极差,''SQtY'' 标准差'
                                         + ISNULL(@DimNamesAndChs, '')
                                         + ' UNION ALL   
    SELECT ''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'''
                                         + ISNULL(@Var500s, '');
        DECLARE @Detail VARCHAR(MAX) = 'select GoodValue,DataCount-GoodValue BadValue,100-floatValue floatBadValue,CAST((100-floatValue) as varchar(10))+''%'' PercentBadON,floatValue,DataCount ,PercentON,MaxY ,MinY ,AVGY ,MaxY - MinY AS JC,SQtY'
                                       + @GroupBy
                                       + ' INTO #RDetail From #Result1';
        IF (   @OrderFields = ''
               OR @OrderFields IS NULL
           )
            SET @OrderFields = 'floatValue desc';

        DECLARE @Pagesql VARCHAR(MAX) = '  DECLARE @totalRow int = (Select count(1) FROM #RDetail) ;  
                                EXEC dbo.Sp_Sys_Page @tblName = ''#RDetail''                          
                                ,@fldName = ''' + @OrderFields
                                        + '''                                 
                                ,@rowcount = @totalRow  
                                ,@PageIndex = ' + @PageIndex
                                        + '      
                                ,@PageSize = ' + @PageSize
                                        + '      
                                ,@SumType = 0  
                                ,@SumColumn = ''''  
                                ,@AvgColumn = ''''' + CHAR(10);


        -----------------------------删除临时表------------------------------------------------------------
        DECLARE @DropTable NVARCHAR(MAX) = '';
        SET @DropTable += (   SELECT ' if((select count(*) from #' + DimName
                                     + ')=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_JW'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister_JW @condition='''''
                                     + @condition + ''''',@OtherCond='''''
                                     + @OtherCond + ''''',@Type=''''' + @Type
                                     + ''''',@OrderFields='''''
                                     + @OrderFields + ''''',@SpName'''''
                                     + @SpName + ''''',@DataType='''''
                                     + CAST(@DataType AS NVARCHAR(2)) + ''''',@EmpID='''''
                                     + CAST(@EmpID AS NVARCHAR(2)) + ''''',@PageIndex='''''
                                     + @PageIndex + ''''',@PageSize='''''
                                     + @PageSize + ''''',@XValue,='''''
                                     + @XValue + ''''',@DSValue='''''
                                     + @DSValue + ''''''','''
                                     + CONVERT(NVARCHAR(20), GETDATE(), 120)
                                     + ''') END  '
                              FROM   #Dims
                              WHERE  Isneed <> 'ND' AND Isneed <> 'Y'
                              FOR XML PATH('')
                          );
        SET @DropTable += 'drop table #time' + CHAR(10)
                          + 'drop TABLE #Resultdata' + CHAR(10)
                          + 'drop table #Result1' + CHAR(10)
                          + 'drop table #RDetail' + CHAR(10)
                          +   (   SELECT 'drop table #' + DimNum + 'Tb'+CHAR(10)
                                  FROM   #ViewNameTb
                                  FOR XML PATH('')
                              );
        SET @DropTable += (   SELECT 'drop table #' + DimName + CHAR(10)
                              FROM   #Dims
                              WHERE  Isneed <> 'ND'
                                     AND Isneed <> 'Y'
                              FOR XML PATH('')
                          );
        PRINT @Varchars;
        EXEC ( @Varchars );
        --SELECT  'CREATE TABLE #time
        --    (
        --      id VARCHAR(200) ,
        --      beginDate DATETIME ,
        --      endDate DATETIME ,
        --      beginDate_Lp DATETIME ,
        --      endDate_Lp DATETIME ,
        --      beginDate_Ly DATETIME ,
        --      endDate_Ly DATETIME
        --    ); ' + @sql + @Result1 + @Detail + @Pagesql + @DropTable
        --FOR     XML PATH('');  
        --SELECT   @sql+@Result1 + @Detail 
		  --SELECT @sql+@Result1 + @Detail + @Pagesql+@DropTable
        EXEC ( @sql + @Result1 + @Detail + @Pagesql + @DropTable );

        --SELECT @sql+@Result1 + @Detail + @Pagesql+@DropTable

        DROP TABLE #TempWD;
        DROP TABLE #Dims;
        DROP TABLE #Num;
        DROP TABLE #DimsTb;
        DROP TABLE #ViewNameTb;
        -- 插入日志记录
        INSERT INTO Tbl_Log_AnaUseLog (   EmpID ,
                                          freshTime ,
                                          spName ,
                                          AnaName ,
                                          siftvalue ,
                                          OherParemeter
                                      )
        VALUES ( @EmpID ,
                 GETDATE(),
                 'Sp_Analysister_JW_2' ,
                 '' + @SpName + '分位数分区统计',
                 @condition ,
                 '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='
                 + @OtherCond
               );
    END;
go

