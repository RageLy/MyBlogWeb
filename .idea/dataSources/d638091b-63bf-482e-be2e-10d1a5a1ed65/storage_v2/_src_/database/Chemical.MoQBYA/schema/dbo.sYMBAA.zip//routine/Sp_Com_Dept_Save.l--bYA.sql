
-- =============================================
-- Author:  <曹乐平>
-- Create date:<2014-06-14>
-- Description:<存储过程调整>
-- =============================================
create PROCEDURE [dbo].[Sp_Com_Dept_Save]
    @DeptID varchar(500)=''
	,@DeptName varchar(500)=''
as 

Begin 
set nocount on
if( @DeptName='')      
begin      
	select '部门名称不能为空！'     
	return     
end 
if exists(select * from Tbl_Com_Dept where DeptName=@DeptName and DeptID!=@DeptID)
begin
	select '该部门已经存在！'
return 
end

if exists(select * from dbo.Tbl_Com_Dept where DeptID=@DeptID)
begin
	update dbo.Tbl_Com_Dept set DeptName=@DeptName
	where DeptID=@DeptID
	select '0'
end
else
begin
	insert into Tbl_Com_Dept(DeptName)values(@DeptName)
	select '0'
end	

end
go

