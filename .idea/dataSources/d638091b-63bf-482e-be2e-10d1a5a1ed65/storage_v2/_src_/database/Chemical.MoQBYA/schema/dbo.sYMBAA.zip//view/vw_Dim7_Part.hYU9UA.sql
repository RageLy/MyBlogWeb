


CREATE VIEW [dbo].[vw_Dim7_Part]
AS    
SELECT fname AS ID,FValue AS Name,'' AS '天','' AS '周',FDateType AS '月','' AS '季','' AS '年' FROM sp_Dim_GetDim7All() WHERE Fdate='月'
UNION ALL 
SELECT fname,FValue,FDateType,'','','','' FROM sp_Dim_GetDim7All() WHERE Fdate='天'
UNION ALL
SELECT fname,FValue,'',FDateType,'','','' FROM sp_Dim_GetDim7All() WHERE Fdate='周'
UNION ALL
SELECT fname,FValue,'','','',FDateType,'' FROM sp_Dim_GetDim7All() WHERE Fdate='季'
UNION ALL
SELECT fname,FValue,'','','','',FDateType FROM sp_Dim_GetDim7All() WHERE Fdate='年'


go

