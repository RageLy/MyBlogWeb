






-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 自动展示数据
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_ShowData]
	-- Add the parameters for the stored procedure here
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(max) = 'DimSinOutValue:,DimOilSeries:,DimSinTemp8:倍数2,DimSinTemp25:倍数2,DimSinTemp41:,DimOilViscosity:倍数5,DimDDLps:倍数5'
	,@XDim VARCHAR(50) = 'DimSinTemp41'
	,@YDim VARCHAR(50) = 'DimSinOutValue'
	,@NameTag VARCHAR(50) = 'hjl'
	,@DataWhere VARCHAR(MAX) = ' AND DimOilSeries = 3 '   -- 筛选数据的条件
	,@OrderBy VARCHAR(max) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,Name_Ch varchar(200)
    );
    
 
    -- 分解维度插入零时表
    INSERT INTO #DimsPearSen
    SELECT SUBSTRING(string,1,CHARINDEX(':',string) - 1)
    ,CASE WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @XDim THEN 'X'  -- 变量dim
	      WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @YDim THEN 'Y'  -- 目标dim
		  ELSE 'F' END   -- 条件Dim
    ,ta.IsRange
    ,ta.ViewName
    ,ta.AtYSql
    ,SUBSTRING(string,CHARINDEX(':',string) + 1,Len(string))
    ,ta.Name_ch
    FROM dbo.Split(@Dims,',') s
    INNER JOIN dbo.Tbl_AnsCom_DIimToTable ta ON SUBSTRING(string,1,CHARINDEX(':',string) - 1) = ta.DimNum
    
    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #DimsPearSen WHERE Dim = @YDim;
    
	-- 拼接 @Select 段
    DECLARE @Select VARCHAR(max);
    SET @Select = ( SELECT ',' + Dim + '.Name AS ' + Name_Ch
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' LEFT JOIN vw_' +  Dim + '_Part AS ' + Dim + ' on ' + Dim + '.ID = Data.' + Dim
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	

	-- 拼接 @OrderBy 段
	--DECLARE @OrderBy VARCHAR(max);
	IF( @OrderBy = '')
	BEGIN	
		SET @OrderBy = ( SELECT ',' + Dim + '.ID' FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
		-- 去掉第一个,
		SET @OrderBy = SUBSTRING(@OrderBy,2,LEN(@OrderBy));
	END

	
	-- 设置目标表格
	DECLARE @ResultTable VARCHAR(max);
	SET @ResultTable = 'T_AutoAnaCountSift_' + ISNULL(@XDim,'') + '_' +  ISNULL(@YDim,'') + '_' +ISNULL(@NameTag,'') + ' AS Data ';
	
	DECLARE @ResultDataSql VARCHAR(500);
	SET @ResultDataSql = 'datacount AS 数据条数, AVGY AS 平均目标值 ,MAXY AS 最大目标值 , MINY AS 最小目标值,MAXY -  MINY AS 极差 ,SQtY AS 标准差,MaxX AS 最大X值 ,MinX AS 最小X值,Xcount AS X展开个数 , PearSenR AS 拟合优度 ,Slope AS 拟合斜率 ,LineCons AS 拟合常数 ,ChangePoint AS 拐点数量 ,Trend AS 拐点情况 '
	
	EXEC ('SELECT ' + @ResultDataSql + @Select + ' ,SiftValue AS 参数 FROM ' + @ResultTable + @SqlJoin + ' WHERE 1 = 1 ' + @DataWhere + ' Order by ' + @OrderBy);
	
	
END
go

