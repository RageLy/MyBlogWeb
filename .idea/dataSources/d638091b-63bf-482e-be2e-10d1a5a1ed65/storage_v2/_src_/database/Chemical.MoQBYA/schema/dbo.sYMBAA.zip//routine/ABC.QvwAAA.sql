

CREATE PROCEDURE ABC @Str NVARCHAR(100)
AS
    BEGIN
        DECLARE @Comptype INT= 0;
        
        SELECT  CompType ,
                CompID,DiffStruct
        INTO    #res
        FROM    dbo.Bs_Compound_DiffStruct
        WHERE   CHARINDEX(Bs_Compound_DiffStruct.DiffStruct, @Str) > 0;
        --IF((SELECT CompType FROM #res) WHERE CompType=2))
        SELECT  *
        FROM    dbo.Bs_Compound_Index
                INNER JOIN #res ON CompID = Layer2
                                   AND CompType = 2;  
                                             
--SET @Str=REPLACE(@Str,,'')

SELECT * FROM #res
LEFT JOIN dbo.Bs_Compound_DiffStruct ON CHARINDEX(Bs_Compound_DiffStruct.DiffStruct, REPLACE(REPLACE(@Str,#res.DiffStruct,''),'()',''))>0

    END;

go

