CREATE PROC [dbo].[Sp_Com_GetOpenMessage]
@EmpID varchar(50)='1'
AS
BEGIN
SELECT TOP 10 * FROM Tbl_Com_OpenMessage WHERE EmpId = @EmpID AND IsRead<>1 ORDER BY ShowTime
END
go

