-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE Sp_help_CreateViewForDIYDim
	@DimNum Varchar(50) = 'DimDIYTemp8'
AS
BEGIN

	SET NOCOUNT ON;

	DECLARE @ViewNamePart VARCHAR(100) = 'VW_' + @DimNum + '_Part';
	DECLARE @ViewNamePartAll VARCHAR(100) = 'VW_' + @DimNum + '_PartAll';


	IF EXISTS( SELECT 1 FROM sys.objects WHERE name = @ViewNamePart) 
	BEGIN
		SELECT '该Dim已经存在!';
		RETURN;
	END
	
    -- Insert statements for procedure here
	DECLARE @CreatePart VARCHAR(MAX);
	
	SET @CreatePart = 'Create View dbo.' + @ViewNamePart + '
	AS
		SELECT -1 AS Id
			,''全部集合''  AS Name
			,''1'' istrue,''全部集合'' 选项集合类型
			,Min(BeginValue) AS Beginvalue
			,Max(EndValue) AS Endvalue
			FROM T_DIYDIMs where DimNum = ''' + @DimNum + '''
		UNION ALL
		SELECT
			DimID
			,DimName
			,''0''
			,''基础选项''
			,BeginValue
			,EndValue
			FROM T_DIYDIMs where DimNum = ''' + @DimNum + '''
	';
	
	EXEC (@CreatePart);
	
	
	DECLARE @CreatePartAll VARCHAR(MAX);
	
	SET @CreatePartAll = 'Create View dbo.' + @ViewNamePartAll + '
	AS
		SELECT  Id AS VWID
			,ID
			,Name
			,Beginvalue
			,Endvalue
		FROM ' + @ViewNamePart + '
	    WHERE   istrue = 0
	    UNION ALL
		SELECT  -1
			,part.Id
			,''全部集合'' 
			,part.Beginvalue
			,part.Endvalue
		FROM    
		( 
			SELECT * FROM   ' + @ViewNamePart + ' WHERE  istrue = 0		                  
		) part 
	';
	
	EXEC (@CreatePartAll);
	
	DECLARE @INSERT VARCHAR(MAX) = ''
	SET @INSERT = 'INSERT INTO Tbl_AnsCom_DIimToTable(
	DimNum
	,ViewName
	,Name_ch
	,AllValue
	,DimLevel
	,IsRange
	,AtYSql
	,Remark
	)
	SELECT MAX(DimNum)
	,MAX(DimNum)
	,MAX(DimChName)
	,-1
	,''选项集合类型''
	,1
	,MAX(AtYsql)
	,''DIYDim Auto Insert''
	FROM T_DIYDIMs where DimNum = ''' + @DimNum + '''
	'
	
	EXEC (@INSERT);
	
	SELECT * FROM Tbl_AnsCom_DIimToTable WHERE DimNum = @DimNum
	EXEC ( ' SELECT * FROM ' + @ViewNamePart )
	EXEC ( ' SELECT * FROM ' + @ViewNamePartAll )
	
	
	
END
go

