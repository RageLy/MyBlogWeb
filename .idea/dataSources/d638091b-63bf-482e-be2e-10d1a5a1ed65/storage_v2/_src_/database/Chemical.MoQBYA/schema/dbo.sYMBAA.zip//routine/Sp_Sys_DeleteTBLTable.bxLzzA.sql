-- =============================================
-- Author:		<吴国锋>
-- Create date: <2011-01-17>
-- Description:	<通用删除存储过程>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Sys_DeleteTBLTable]
    @tableName          varchar(256),
    @IDName             varchar(256),
    @IDValue            varchar(256)
AS
BEGIN try
	
	SET NOCOUNT ON;
	
	declare @sql varchar(8000);
	
	set @sql = 'delete from '+@tableName+' where '+@IDName+' = '''+@IDValue+'''';

    exec(@sql);
    select '0'

    
END try
begin catch

    declare @errMsg varchar(500)='',@columnName varchar(50)=''
    declare @s int=0,@e int=1
    select @errMsg=ERROR_MESSAGE()
    set @s=CHARINDEX('''',@errMsg,0)
    set @e=CHARINDEX('''',@errMsg,@s+1)
    set @columnName=SUBSTRING(@errMsg,@s+1,@e-@s-1)
    select @errMsg msg,@columnName [column],ERROR_NUMBER() errNum
        
end catch
go

