-- =============================================                                
-- Description: <根据维度名称在字符串中获取相应的维度>                  
--获取纬度解析后的表              
-- =============================================              
CREATE proc [dbo].[Sp_Com_GetUp_link_time]                  
@SiftValue   varchar(Max)='Dim7:M:this',   --时间字符串            
@tableNames varchar(200)=''    --接受的表明            
as                  
-- [Sp_Com_GetTime] 'M:2013-4-30'                  
begin                  
    declare @sql varchar(max)=''            
    create table #alltime            
      (            
      id varchar(50),            
      Name varchar(50),            
      beginDate varchar(100),            
      enddate varchar(100)            
      )            
      insert into #alltime            
      exec dbo.sp_Dim_7_Level_3_web            
                  
     create table #ids             
      (            
      id varchar(50)            
      )            
      insert into #ids            
      select String from dbo.Split(@SiftValue,',')            
                  
      create table #yougase              
      (            
         id varchar(200),            
      beginDate datetime,            
      enddate datetime            
      )            
    -- 解析时间纬度             
               
    declare @time varchar(4000)            
   --  if(stuff((select ','+cast(string as varchar(500)) from dbo.GetDim(@SiftValue,'Dim7')            
   -- for xml path('')            
   --),1,1,'')<>'')            
     if exists (select * from #ids)            
     Begin              
     set @time=replace(@SiftValue,'Dim7:','')            
      exec Sp_Com_GetTime @time,'#yougase',1              
     End              
     --select * from #yougase  --[Sp_Com_Getdimensions_child]            
     --return            
    declare @id varchar(50)              
     declare @begindate datetime              
     declare @enddate datetime              
     declare @last_begin datetime              
     declare @last_end datetime              
     declare @last_samebegin datetime              
     declare @last_sameend datetime              
     declare @diff int              
     declare @type varchar(10)              
     declare @tempdate datetime              
     declare @sametempdate datetime              
     declare @IDdate int=1              
     declare cur_time cursor              
     for              
     select id,cast(begindate as datetime),cast(enddate as datetime) from #yougase              
     open cur_time               
     fetch next from cur_time into @id,@begindate,@enddate              
     while @@FETCH_STATUS=0              
     Begin              
     set @diff=datediff(day,@begindate,@enddate)+1              
     if(charindex(':',@id)>0)              
     Begin              
      set @type=substring(@id,1,1)              
      --日历天              
      if(@type='D')              
      Begin              
     set @last_begin=DATEADD(DAY,-1,@begindate)              
     set @last_end=DATEADD(DAY,-1,@enddate)              
     set @last_samebegin=DATEADD(YEAR,-1,@begindate)              
     set @last_sameend=DATEADD(YEAR,-1,@enddate)              
      End              
      --日历周              
      if(@type='W')              
      Begin              
     set @last_begin=DATEADD(WEEK,-1,@begindate)              
     set @last_end=DATEADD(WEEK,-1,@enddate)              
     set @last_samebegin=DATEADD(YEAR,-1,@begindate)              
     set @last_sameend=DATEADD(YEAR,-1,@enddate)              
      End              
      --日历月               
      if(@type='M')              
      Begin              
       --微软的方法前推一个月不能到月底，如2013-04-30前推一个月是3月30日，              
       --而这里需要的是3月31日              
       --1号没问题，但是最后一天有问题，需要特殊处理   
     if(@enddate < DATEADD(SECOND,-1,DateAdd(MM,1,@begindate)))    
     begin  
   set @last_begin= DATEADD(DD,-(DATEDIFF(DD,@begindate,@enddate)+1),@begindate)  
                     
   --set @last_begin=DATEADD(MONTH,-1,@begindate)              
   --set @tempdate=DATEADD(SECOND,-1,@begindate)              
   --set @last_end=@tempdate         
   set @tempdate=DATEADD(SECOND,-1,@begindate)              
   set @last_end=@tempdate   
     end  
     else if(@enddate = DATEADD(SECOND,-1,DateAdd(MM,1,@begindate)))  
     begin  
       set @last_begin=DATEADD(MONTH,-1,@begindate)              
    set @tempdate=DATEADD(SECOND,-1,@begindate)              
    set @last_end=@tempdate   
     end  
            
   set @last_samebegin=DATEADD(YEAR,-1,@begindate)              
     set @sametempdate=DATEADD(YEAR,-1,@enddate)              
     set @last_sameend=@sametempdate              
      End              
      --日历季             
      if(@type='Q')              
      Begin              
     --季度也有同样的问题。              
     --select DATEADD(QUARTER,-1,'2013-04-01 00:00:00')              
     set @last_begin=DATEADD(MONTH,-3,@begindate)              
     set @tempdate=DATEADD(DAY,-1,@begindate)              
     set @last_end=@tempdate              
     set @last_samebegin=DATEADD(YEAR,-1,@begindate)              
     set @sametempdate=DATEADD(YEAR,-1,@enddate)              
     set @last_sameend=@sametempdate              
   End              
      --日历年               
      if(@type='Y')              
      Begin              
     set @last_begin=DATEADD(YEAR,-1,@begindate)              
     set @last_end=DATEADD(YEAR,-1,@enddate)              
     set @last_samebegin=DATEADD(YEAR,-1,@begindate)              
     set @last_sameend=DATEADD(YEAR,-1,@enddate)              
      End              
     End              
     Else              
     Begin              
    set @last_begin=DATEADD(DAY,-@diff,@begindate)              
    set @last_end=DATEADD(DAY,-@diff,@enddate)              
    set @last_samebegin=DATEADD(YEAR,-1,@begindate)              
     set @last_sameend=DATEADD(YEAR,-1,@enddate)              
     End              

     set @sql+='insert into '+@tableNames+' values('''      
     +cast(@IDdate as varchar(100))+''','''    --ID      
     +convert(varchar(100),@begindate,120)+''','''      --BeginDate          
     +convert(  varchar(100),@enddate,120)+''','''  --EndDate      
     +convert(varchar(100),@last_begin,120)+''','''     --BeginDate_Lp           
     +convert(varchar(100),@last_end,23)+' 23:59:59'','''  --EndDate_Lp       
     +convert(varchar(100),@last_samebegin,120 )+''','''--BeginDate_Ly      
     +convert(varchar(100),@last_sameend,120 )+''') '   --EndDate_Ly             
     set @IDdate=@IDdate+1              

     fetch next from cur_time into @id,@begindate,@enddate              
     End               
     CLOSE cur_time            
   DEALLOCATE cur_time            
   --print @sql            
     exec(@sql)            
end
go

