-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-24>
-- Description:	<员工类别>
-- =============================================
CREATE PROCEDURE [dbo].Sp_Com_EmpType_List
	@PageIndex varchar(50)='1',
	@PageSize varchar(50)='5',
	@OrderFields varchar(50)='EmpTypeID Desc'
AS
BEGIN
	SET NOCOUNT ON;

if @OrderFields = ''
	set @OrderFields = 'EmpTypeID desc'
select 
	cast(EmpTypeID as varchar(500))   EmpTypeID   ,
	EmpTypeName as    EmpTypeName  
	into #Result
	from Tbl_Com_EmployeeType
declare @pageCount int =@@ROWCOUNT 
exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize   	  

END
go

