CREATE PROC [dbo].[Sp_Com_GetScrollCompanyAnnouncements]  
AS  
BEGIN  
SELECT TOP 10 * FROM Tbl_Com_CompanyAnnouncement WHERE isnull(Isban,0)<>1 AND (EndTime>GETDATE() OR EndTime IS NULL) ORDER BY SendTime DESC  
END
go

