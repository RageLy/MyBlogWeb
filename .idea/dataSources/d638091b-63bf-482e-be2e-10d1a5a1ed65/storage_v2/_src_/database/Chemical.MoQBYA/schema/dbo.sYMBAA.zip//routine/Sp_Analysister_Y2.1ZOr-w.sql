
-- =============================================                          

-- Update Date: 2016年11月3日
-- 双Y轴图形通用sp
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_Y2]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimWelderID:-1%DimResultType:-1',
    @OtherCond VARCHAR(MAX) = '%无横轴%无分组%平均工作率%line%总和%全时长%数量', --'%时间%温度8%产值%line%数量'
    @Type VARCHAR(10) = '图',                                   -- '图' or '列表' or '明细'
    @SpName VARCHAR(50) = 'WeldTime',
    @OrderFields VARCHAR(50) = 'id',
    @EmpID INT = 1,
                                                               -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1',
    @PageSize VARCHAR(5) = '10',
    @XValue VARCHAR(50) = '',
    @DSValue VARCHAR(50) = ''
AS
BEGIN


    ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            


    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue = REPLACE(@condition, '|', ',');

    DECLARE @Usertitle VARCHAR(200) = ''; -- 标题            
    DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                
    DECLARE @ChatType VARCHAR(50) = ''; -- 图形名称                
    DECLARE @CTOC VARCHAR(50) = ''; -- @OtherCond 传入的比较方式                
    DECLARE @CompareType VARCHAR(50) = ''; -- 比较方式
    ------添加双Y
    DECLARE @YName2 VARCHAR(50) = ''; -- @OtherCond  传入的Y2轴名称
    DECLARE @CTOC2 VARCHAR(50) = ''; -- @OtherCond 传入的比较方式
    DECLARE @ChartType2 VARCHAR(50) = ''; -- 展示图形
    DECLARE @CompareType2 VARCHAR(50) = ''; -- 比较方式                      
	DECLARE @ErrorRecord NVARCHAR(MAX)='';
    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        String NVARCHAR(50)
    );

    SET NOCOUNT ON;

    INSERT INTO @OtherCondTbl
    SELECT string
    FROM dbo.f_splitSTR(@OtherCond, '%');

    SET @Usertitle =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 1
    );
    SET @XName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 2
    );
    SET @YName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 4
    );
    SET @ChatType =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 5
    );
    SET @CTOC =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 6
    );
    SET @YName2 =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 7
    ); ------次Y轴维度
    SET @CTOC2 =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 8
    ); ------次Y轴比较类型      

    -- OtherCond解析完毕            
    -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

    ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       

    ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


    -- 时间表 时间临时表必然需要
    CREATE TABLE #time
    (
        id VARCHAR(200),
        beginDate DATETIME,
        endDate DATETIME,
        beginDate_Lp DATETIME,
        endDate_Lp DATETIME,
        beginDate_Ly DATETIME,
        endDate_Ly DATETIME
    );

    -- 如果有其它需要用 #时间表的必须在这里添加

    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(1000); -- 用于拼接@Sql中 指标计算方式的Sql语句    
    DECLARE @NumSql2 VARCHAR(1000); -- 用于拼接@Sql中 指标计算方式的Sql语句           
    DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句
    DECLARE @CountTypeY2 VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg

    SET @XOrder = ',1 as X排序';

    -- 默认使用 sum 遇到需要 count 或 avg 的Y轴再进行修改      
    IF (@CTOC = '平均值')
        SET @CountType = 'AVG';
    ELSE IF (@CTOC = '数量')
        SET @CountType = 'Count';
    ELSE IF (@CTOC = '最大值')
        SET @CountType = 'MAX';
    ELSE IF (@CTOC = '最小值')
        SET @CountType = 'MIN';
    ELSE IF (@CTOC = '标准差')
        SET @CountType = 'STDEV';
    ELSE IF (@CTOC = '总和')
        SET @CountType = 'SUM';
    ELSE IF (@CTOC = '方差')
        SET @CountType = 'VAR';


    IF (@CTOC2 = '平均值')
        SET @CountTypeY2 = 'AVG';
    ELSE IF (@CTOC2 = '数量')
        SET @CountTypeY2 = 'Count';
    ELSE IF (@CTOC2 = '最大值')
        SET @CountTypeY2 = 'MAX';
    ELSE IF (@CTOC2 = '最小值')
        SET @CountTypeY2 = 'MIN';
    ELSE IF (@CTOC2 = '标准差')
        SET @CountTypeY2 = 'STDEV';
    ELSE IF (@CTOC2 = '总和')
        SET @CountTypeY2 = 'SUM';
    ELSE IF (@CTOC2 = '方差')
        SET @CountType = 'VAR';

    ------------------------------------------------------系列名称开始

    DECLARE @Ynum1 VARCHAR(500) = ''; -- 定义Y1系列           
    DECLARE @Ynum2 VARCHAR(500); -- 定义Y2系列  

    SET @Ynum1 = 'Y轴1:' + @YName + '(' + @CTOC + ')';
    SET @Ynum2 = 'Y轴2:' + @YName2 + '(' + @CTOC2 + ')';


    CREATE TABLE #Yname
    (
        YName1 VARCHAR(200),
        YName2 VARCHAR(200)
    );
    INSERT INTO #Yname
    (
        YName1,
        YName2
    )
    VALUES
    (@Ynum1, @Ynum2);


    -- 处理维度临时表
    CREATE TABLE #Dims
    (
        DimName VARCHAR(50),
        DimValues VARCHAR(MAX),
        ChName VARCHAR(50),
        Isneed VARCHAR(50),
        DimOrdersql VARCHAR(50),
        DimYsql VARCHAR(50),
        isrange VARCHAR(50)
    );

    EXEC [Sp_Com_GetdimensionTable_Y2] @SiftValue = @SiftValue,
                                       @XName = @XName;

    --select * from #Dims;
    ------------------------------------------------------系列名称结束

    -- 读取转化 Y轴步骤 主要设置 @InnerSelect 内部 select 提取字段部分 还有 外部 select 的算法 @CountType            
    --SET @NumSql = ',' + @CountType +'(' + @YName + ') AS num1'+',' + @CountTypeY2 +'(' + @YName2 + ')' ;
	if((SELECT COUNT(*) FROM #Dims GROUP BY ChName HAVING COUNT(ChName)>1)>0)
		 BEGIN
		  SET @ErrorRecord += 'X轴当前选择的维度中文名称重复，请检查；';

	INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
         END
    DECLARE @Xcolumn VARCHAR(50)
        = ISNULL(
          (
              SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'X'
          ),
          'dbo.GetTimeName(t.begindate,t.enddate)'
                ); -- 横轴在本表上面的列名,如果没有说明是时间维度

    IF (@XName = '无横轴')
        SET @Xcolumn = '''无横轴''';

    DECLARE @Ycolumn VARCHAR(50) = ISNULL(
                                   (
                                       SELECT DimYsql FROM #Dims WHERE ChName = @YName
                                   ),
                                   ''
                                         ); -- Y轴1在本表上面的列名
    DECLARE @Ycolumn2 VARCHAR(50) = ISNULL(
                                    (
                                        SELECT DimYsql FROM #Dims WHERE ChName = @YName2
                                    ),
                                    ''
                                          ); -- Y轴2在本表上面的列名


    ----------------- Y轴配置
    -- Y 轴上面的取值要拿出来

    DECLARE @YSQL1 VARCHAR(1000);
    DECLARE @YSQL2 VARCHAR(1000);

    -- 从维度表中取出Y轴上面的维度
    SELECT @YSQL1 = ',' + @Ycolumn + ' AS [' + @YName + ']';
    SELECT @YSQL2 = ',' + @Ycolumn2 + ' AS [' + @YName2 + ']';


    IF (@CTOC IN ( '平均值', '数量', '最大值', '最小值', '标准差', '方差', '总和' ))
        SET @NumSql = ',' + @CountType + '([' + @YName + '])';
    ELSE IF (@CTOC = '极差')
        SET @NumSql = ',' + 'MAX([' + @YName + ']) - MIN([' + @YName + '])';
    ELSE IF (@CTOC = '中位数')
        SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.5 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
    ELSE IF (@CTOC = '上四分位')
        SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.75 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
    ELSE IF (@CTOC = '下四分位')
        SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.25 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
    ELSE IF (@CTOC = '四分位差')
        SET @NumSql
            = ',' + 'ABS( SUM(CASE WHEN nIndex = cast( 0.25 * nCount AS INT) THEN [' + @YName
              + '] ELSE 0 END ) - SUM(CASE WHEN nIndex = cast( 0.75 * nCount AS INT) THEN [' + @YName
              + '] ELSE 0 END ) )';
    ELSE IF(@CTOC = '百分比')
    begin
		SET @CountType=(SELECT  PercentSql FROM  dbo.Tbl_AnsCom_SelfY WHERE SpName=@SpName)
    END

    -- 如果Y轴上面的选取数据是非维度化的内容，则需要在自定义Y轴配置表中寻找
    IF (@Ycolumn IS NULL OR @Ycolumn = '')
    BEGIN

        SELECT @Ycolumn = Ycolumn,
               @YSQL1 = CASE
                            WHEN YSQL = '自动拼接' THEN
                                ',' + Ycolumn + ' AS [' + @YName + '] '
                            ELSE
                                YSQL
                        END,
               @NumSql = CASE
                             WHEN NumSql = '自动拼接' AND isPercent=0 THEN
                                 ',' + @CountType + '([' + @YName + ']) '
                             
                                 WHEN NumSql = '自动拼接' AND isPercent=1 THEN
                                 PercentSql
                                 ELSE NumSql
                         END
        FROM Tbl_AnsCom_SelfY
        WHERE SpName = @SpName
              AND YName = @YName;
IF (   @Ycolumn = ''
       OR @Ycolumn IS NULL
   )
    BEGIN
        SET @ErrorRecord += '查询select Ycolumn FROM Tbl_AnsCom_SelfY
        WHERE SpName = '+@SpName+'
              AND YName = '+@YName+'为空,可能导致报错,请检查!';
		INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;
	IF (   @YSQL1 = ''
       OR @YSQL1 IS NULL
   )
    BEGIN
         SET @ErrorRecord += '查询select YSQL FROM Tbl_AnsCom_SelfY
        WHERE SpName = '+@SpName+'
              AND YName = '+@YName+'为空,可能导致报错,请检查!';
		INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;
IF (   @NumSql = ''
       OR @NumSql IS NULL
   )
    BEGIN
         SET @ErrorRecord += '查询select NumSql FROM Tbl_AnsCom_SelfY
        WHERE SpName = '+@SpName+'
              AND YName = '+@YName+'为空,可能导致报错,请检查!';
		INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;
    END;

    IF (@CTOC2 IN ( '平均值', '数量', '最大值', '最小值', '标准差', '方差', '总和' ))
        SET @NumSql2 = ',' + @CountTypeY2 + '([' + @YName2 + '])';
    ELSE IF (@CTOC2 = '极差')
        SET @NumSql2 += ',' + 'MAX([' + @YName2 + ']) - MIN([' + @YName2 + '])';
    ELSE IF (@CTOC2 = '中位数')
        SET @NumSql2 = ',' + 'SUM(CASE WHEN nIndex2 = cast( 0.5 * nCount2 AS INT) THEN [' + @YName2 + '] ELSE 0 END )';
    ELSE IF (@CTOC2 = '上四分位')
        SET @NumSql2
            = ',' + 'SUM(CASE WHEN nIndex2 = cast( 0.75 * nCount2 AS INT) THEN [' + @YName2 + '] ELSE 0 END )';
    ELSE IF (@CTOC2 = '下四分位')
        SET @NumSql2
            = ',' + 'SUM(CASE WHEN nIndex2 = cast( 0.25 * nCount2 AS INT) THEN [' + @YName2 + '] ELSE 0 END )';
    ELSE IF (@CTOC2 = '四分位差')
        SET @NumSql2
            = ',' + 'ABS( SUM(CASE WHEN nIndex = cast( 0.25 * nCount AS INT) THEN [' + @YName2
              + '] ELSE 0 END ) - SUM(CASE WHEN nIndex = cast( 0.75 * nCount AS INT) THEN [' + @YName2
              + '] ELSE 0 END ) )';

    -- 如果Y轴上面的选取数据是非维度化的内容，则需要在自定义Y轴配置表中寻找
    IF (@Ycolumn2 IS NULL OR @Ycolumn2 = '')
    BEGIN
        SELECT @Ycolumn2 = Ycolumn,
               @YSQL2 = CASE
                            WHEN YSQL = '自动拼接' THEN
                                ',' + Ycolumn + ' AS [' + @YName + '] '
                            ELSE
                                YSQL
                        END,
               @NumSql2 = CASE
                              WHEN NumSql = '自动拼接' THEN
                                  ',' + @CountTypeY2 + '([' + @YName2 + ']) '
                              ELSE
                                  NumSql
                          END
        FROM Tbl_AnsCom_SelfY
        WHERE SpName = @SpName
              AND YName = @YName2;
IF (   @YSQL2 = ''
       OR @YSQL2 IS NULL
   )
    BEGIN
         SET @ErrorRecord += '查询select YSQL FROM Tbl_AnsCom_SelfY
        WHERE SpName = '+@SpName+'
              AND YName = '+@YName+'为空,可能导致报错,请检查!';
		INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;
    END;

    SET @NumSql = @NumSql + @NumSql2;


    -- 拼接创建维度临时表的语句

    --SELECT * FROM #Dims;

    SET @sql += ISNULL(
                (
                    SELECT 'CREATE TABLE #' + DimName
                           +
                        -- 非范围维度类型3列
                        CASE
                            WHEN isrange
        =               0 THEN
                                '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                            -- 范围维度类型5列
                            WHEN isrange = 1 THEN
                                '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'
                        END
                    FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')
                ),
                ''
                      );

    DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
    -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析

    -- 用 Dims 临时表拼接需要解析的 维度字符串
    SET @NeedSiftvalue = ISNULL(
                         (
                             SELECT '%' + DimName + ':' + DimValues
                             FROM #Dims
                             WHERE Isneed <> 'ND'
                             FOR XML PATH('')
                         ),
                         ''
                               );

    -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
    SET @NeedSiftvalue = CASE
                             WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                 'Dim7:' + dbo.GetDimValue(@SiftValue, 'Dim7') + @NeedSiftvalue
                             ELSE
                                 SUBSTRING(@NeedSiftvalue, 2, LEN(@NeedSiftvalue))
                         END;

    -- 解析维度
    SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = '
                + CAST(@EmpID AS VARCHAR(50)) + ';';


    ---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        

    -- 结果集表
    CREATE TABLE #Result_B
    (
        DimX VARCHAR(50),
        OrderX INT,
        num1 DECIMAL(18, 2),
        num2 DECIMAL(18, 2)
    );


    DECLARE @Dims VARCHAR(50);

    DECLARE @TimeName VARCHAR(50); -- 用于判断时间的标志

    IF (CHARINDEX('时间', @XName) <> 0)
        SET @XOrder = 'CAST(t.beginDate as INT) AS X排序';
    ELSE IF (@XName = '无横轴')
        SET @XOrder = '1 AS X排序';
    ELSE
        SELECT @XOrder = (CASE
                              WHEN DimOrdersql = '' THEN
                                  DimName + '.VWID'
                              -- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS X排序'
                              WHEN DimOrdersql <> '' THEN
                                  DimOrdersql
                              -- 有特殊排序字符则使用特殊的
                              ELSE
                                  '1'
                          END + ' AS X排序'
                         ) -- 都没有则用默认
        FROM #Dims
        WHERE Isneed = 'X';

    SET @InnerSelect += ',' + @XOrder;

    --set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName)
	IF (   (   SELECT ISNULL(MainTable, '')
           FROM   dbo.Tbl_AnsCom_DIimToTable
           WHERE  DimNum = (   SELECT DimName
                               FROM   #Dims
                               WHERE  ChName = @YName
                           )
       ) = ''
   )
    BEGIN
         SET @ErrorRecord += '查询SELECT MainTable FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = '''+( SELECT DimName
                               FROM   #Dims
                               WHERE  ChName = @YName)+'''为空,请检查;';

	INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
		end
    IF (@XName = '时间')
        SET @TimeName =
    (
        SELECT MainTable + '.OptDate'
        FROM dbo.Tbl_AnsCom_DIimToTable
        WHERE DimNum =
        (
            SELECT DimName FROM #Dims WHERE ChName = @YName
        )
    )   ;
    ELSE
        SET @TimeName =
    (
        SELECT MainTable + '.OptDate'
        FROM dbo.Tbl_AnsCom_DIimToTable
        WHERE DimNum =
        (
            SELECT DimName FROM #Dims WHERE ChName = @XName
        )
    )   ;

    --PRINT '时间配置字段: '+@TimeName
    IF (@TimeName = '' OR @TimeName IS NULL)
    BEGIN
        SET @TimeName =
        (
            SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName
        );
    END;

    IF (@TimeName = '' OR @TimeName IS NULL)
    BEGIN
       set @ErrorRecord+='查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '+@SpName+'为空,请检查;';
		INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )

        RETURN;
    END;

    -- Group by段的
    SET @Dims = '[' + @XName + '],X排序 '; -- 横轴排序字段             

    DECLARE @PieColumn VARCHAR(100);
    SET @PieColumn = '';

    -------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              

    -- 基础版本的 select段Sql语句


    SET @sql += '
  INSERT INTO #Result_B(DimX,OrderX,num1,num2)
   SELECT ' + @Dims + @NumSql + ' AS num2
   FROM
   (
   SELECT ';
    -- 如果非分位数算法则不需要排序和算总数量 加快效率
    IF (
           @CTOC IN ( '平均值', '数量', '最大值', '最小值', '标准差', '方差', '总和' )
           AND @CTOC2 IN ( '平均值', '数量', '最大值', '最小值', '标准差', '方差', '总和' )
       )
        SET @sql += ' 1 AS [1],';

    IF (@CTOC IN ( '中位数', '上四分位', '下四分位' ))
        SET @sql += ' Row_Number() OVER(Partition by ' + @Xcolumn + ' Order BY ' + @Ycolumn
                    + ') AS nIndex ,
    COUNT(1) OVER(Partition by ' + @Xcolumn + ') AS nCount ,';

    IF (@CTOC2 IN ( '中位数', '上四分位', '下四分位' ))
        SET @sql += ' Row_Number() OVER(Partition by ' + @Xcolumn + ' Order BY ' + @Ycolumn2
                    + ') AS nIndex2 ,
    COUNT(1) OVER(Partition by ' + @Xcolumn + ') AS nCount2 ,';

    IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        SET @sql += 'dbo.GetTimeName(t.begindate,t.enddate) AS 时间';
    ELSE
        SET @sql += 'GetDate() AS 时间';


    -- 时间维一定有 选出

    -- 按照 是否需要维度 拼装选择的维度字段

    -- 横轴上面的取值要拿出来,时间维度则不取出
    IF (@Xcolumn <> 'dbo.GetTimeName(t.begindate,t.enddate)')
        SET @sql += ',' + @Xcolumn + ' AS [' + @XName + ']';
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名


    -- Y 轴上面的取值要拿出来
    DECLARE @YSQL VARCHAR(2000);

    IF (@YSQL1 <> @YSQL2)
    BEGIN
        SELECT @YSQL = @YSQL1 + @YSQL2;
    END;
    ELSE
    BEGIN
        SELECT @YSQL = @YSQL1;
    END;
    -- 实例： ',data.Temp8 AS 温度8';

    SET @sql += @YSQL;

    DECLARE @FromSql VARCHAR(MAX) = (
                                        SELECT JoinTables + ' ' + BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = @SpName
                                    );

    IF (@FromSql IS NULL OR @FromSql = '')
    BEGIN
       SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables, BaseTable FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '+@SpName+'结果为空 ,可能导致报错,请检查;';
		 INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Y2' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@Type='''+@Type+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
        RETURN;
    END;

    SET @sql += ISNULL(@InnerSelect, '') + ' FROM ' + @FromSql;



    -- 时间维表一定需要 放在可能会取到时间的表之后            
    IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';

    -- 临时存储拼接的SQL语句
    DECLARE @sql1 VARCHAR(MAX) = '';

    -- 将INNER JOIN 维度临时表段拼接起来
    SET @sql1 =
    (
        SELECT ' INNER JOIN #' + DimName + ' AS ' + DimName + ' on '
               +
            -- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
            CASE
                WHEN isrange = 1 THEN
                    DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
                -- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
                ELSE
                    DimName + '.ID = ' + DimYsql
            END
        FROM #Dims
        WHERE Isneed <> 'ND'
        FOR XML PATH('')
    );

    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @sql1 = REPLACE(REPLACE(@sql1, '&lt;', '<'), '&gt;', '>');

    SET @sql += ISNULL(@sql1, '');

    SET @sql += '
  WHERE ' + @Ycolumn + ' IS NOT NULL OR ' + @Ycolumn2 + ' IS NOT NULL
  ) x
  GROUP BY ' + @Dims;

    -- 排序段
    SET @sql += ' Order By X排序;';

	SET @sql+=' if((select count(*) from #Result_B)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_Y2'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister @condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@Type='''''+@Type+''''',@SpName='''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(5))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END '

	--插入错误提示的判断语句
	SET @sql +=ISNULL((SELECT ' if((select count(*) from #'+DimName+')=0) BEGIN INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_Y2'',''表#'+DimName+'数据为空,可能造成报错请检查'',''Exec Sp_Analysister @condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@Type='''''+@Type+''''',@SpName='''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(5))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END ' FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')),'')
    -- 注销临时表
    SET @sql += ISNULL(
                (
                    SELECT 'DROP TABLE #' + DimName + ';'
                    FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')
                ),
                ''
                      );

    PRINT '';
    PRINT '-- 全部提取数据语句拼接完毕 运行语句 ：';
    PRINT @sql;
    EXEC (@sql);
    PRINT '';
    PRINT '-- 执行语句完毕 -- ';

    --[Sp_Analysister_Y2]
    ------------------------------------------------------------ 各比较类型数据计算 ----------------------------------------------------------------------                  
    CREATE TABLE #Result_Final
    (
        OrderX INT,
        DimX VARCHAR(MAX),
        num1 DECIMAL(18, 2),
        num2 DECIMAL(18, 2)
    );

    CREATE TABLE #Result_All
    (
        DimX VARCHAR(MAX),
        OrderX INT,
        num1 DECIMAL(18, 2),
        num2 DECIMAL(18, 2)
    );

    INSERT INTO #Result_Final
    (
        OrderX,
        DimX,
        num1,
        num2
    )
    SELECT OrderX,
           DimX,
           num1,
           num2
    FROM #Result_B;

    DECLARE @YMax1 DECIMAL(18, 2),
            @YMin1 DECIMAL(18, 2);
    DECLARE @YMax2 DECIMAL(18, 2),
            @YMin2 DECIMAL(18, 2);

    SELECT @YMax1 = MAX(num1),
           @YMin1 = MIN(num1)
    FROM #Result_B;
    SELECT @YMax2 = MAX(num2),
           @YMin2 = MIN(num2)
    FROM #Result_B;

    IF (@YMax1 = @YMin1)
        SELECT @YMin1 = @YMin1 - 2,
               @YMax1 = @YMax1 + 3;
    IF (@YMax2 = @YMin2)
        SELECT @YMin2 = @YMin2 - 2,
               @YMax2 = @YMax2 + 3;

    ------------------------------------------------------------------------------------- 图形输出格式计算 -------------------------------------------------------------------                

    DECLARE @Rsql VARCHAR(MAX);
    DECLARE @FinalColumn NVARCHAR(1000);


    CREATE TABLE #Result_C
    (
        OrderX INT,
        DimX VARCHAR(50),
        num1 VARCHAR(50),
        num2 VARCHAR(50)
    );
    CREATE TABLE #Result_D
    (
        OrderX INT,
        DimX VARCHAR(50),
        num1 VARCHAR(50),
        num2 VARCHAR(50)
    );
    CREATE TABLE #Result_F
    (
        OrderX INT,
        DimX VARCHAR(50),
        num1 VARCHAR(50),
        num2 VARCHAR(50)
    );

    -- 表 拼接标题用变量
    DECLARE @title TABLE (cName NVARCHAR(100));
    DECLARE @titleSql VARCHAR(MAX);

    -- 行转列输出数据               

    SET @Rsql = ' SELECT DimX,num1 as Y轴1,num2 as Y轴2 FROM #Result_Final ORDER BY abs(OrderX)';
    --SET @Rsql = ' SELECT DimX,num1 as ['+@Ynum1+']'+',num2 as [' +@Ynum2+']'+ ' FROM #Result_Final ORDER BY abs(OrderX)';
    PRINT '';
    PRINT '-- 执行以下输出结果代码 -- ';
    PRINT @Rsql;

    EXEC (@Rsql);
    -----------------------------------------------------自动拼接标题-------------------------------------------------------------------
    IF (@Usertitle = '' OR @Usertitle IS NULL)
    BEGIN

        DECLARE @TimeStr NVARCHAR(100) = (
                                             SELECT dbo.GetTimeName(beginDate, endDate) + ','
                                             FROM #time
                                             FOR XML PATH('')
                                         );
        SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1);
        IF ((SELECT COUNT(*) FROM #time) > 5)
        BEGIN
            SET @TimeStr =
            (
                SELECT TOP 5
                    dbo.GetTimeName(beginDate, endDate) + ','
                FROM #time
                FOR XML PATH('')
            );
            SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
        END;
        SET @Usertitle
            = @TimeStr + ' [' + @XName + ']上的[' + @YName + '-' + @CTOC + ']、[' + @YName2 + '-' + @CTOC2 + ']';
        IF ((SELECT COUNT(*) FROM #Dims WHERE Isneed = 'F') <> 0)
        BEGIN
            DECLARE @WDFilter NVARCHAR(500)
                =   (
                        SELECT '[' + ChName + '],' FROM #Dims WHERE Isneed = 'F' FOR XML PATH('')
                    );
            SET @WDFilter = ',另筛选' + LEFT(@WDFilter, LEN(@WDFilter) - 1);
            SET @Usertitle += @WDFilter;
        END;
    END;
    ---------------------------------------------------------------------------------------------------------------------------------
    --  图形标题拼接            

    IF (@Type = '图')
    BEGIN
        DECLARE @t VARCHAR(100);

        -- 按是否需要来拼接要出标题的 维度            
        SET @t = '#time';

        EXEC Sp_Com_Get_ChtTitle_2Y @TitleNames = @t,
                                    @EndStrTitle = @Usertitle,
                                    @YName = @Ynum1,
                                    @YName_Second = @Ynum2,
                                    @Unit = '',
                                    @XName = @XName,
                                    @YMax = @YMax1,
                                    @YMin = @YMin1,
                                    @YMax_Second = @YMax2,
                                    @YMin_Second = @YMin2,
                                    @splitNumber = '5';
    END;

    --select * from #Yname
    PRINT 'axisLabel:' + @Ynum1;
    -- 注销临时表
    DROP TABLE #Result_B;
    DROP TABLE #Result_Final;
    DROP TABLE #Result_All;
    DROP TABLE #Result_C;
    DROP TABLE #Result_D;
    DROP TABLE #Result_F;
    DROP TABLE #time;
    DROP TABLE #Dims;
    DROP TABLE #Yname;

    -- 插入日志记录
    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        EmpName,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter
    )
    VALUES
    (   @EmpID,
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
        GETDATE(),
        'Sp_Analysister_Y2',
        '' + @SpName + '多维分析器双Y轴图',
        @condition,
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=' + @OtherCond
    );
	
END;
go

