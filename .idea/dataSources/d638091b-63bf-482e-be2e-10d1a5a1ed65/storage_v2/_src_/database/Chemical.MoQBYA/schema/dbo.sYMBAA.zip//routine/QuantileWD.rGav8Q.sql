CREATE PROCEDURE QuantileWD
    @CoNameID NVARCHAR(20) = '' ,
    @date NVARCHAR(10) = ''
AS
    BEGIN
    
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @sqlAdd NVARCHAR(MAX) = '';
        DECLARE @sql1 NVARCHAR(MAX) = '';
        DECLARE @sql1Add NVARCHAR(MAX) = '';
        DECLARE @sql2 NVARCHAR(MAX) = '';
        DECLARE @CoName NVARCHAR(50)= '';
        DECLARE @Name_ch NVARCHAR(50)= '';
        SET @CoName = ( SELECT  TableName+'.'+CoName
                        FROM    dbo.Tbl_AnsCom_DIimToTable
                        WHERE   ID = @CoNameID
                      );
        SET @Name_ch = ( SELECT Name_ch
                         FROM   dbo.Tbl_AnsCom_DIimToTable
                         WHERE  ID = @CoNameID
                       );
                       --CREATE  TABLE QuantileWDTb
                       --(ID INT IDENTITY(1,1) NOT NULL,
                       --Name_ch NVARCHAR(20),
                       --Co_Name NVARCHAR(50),
                       --MinValue DECIMAL(18,4),
                       --DownFourValue DECIMAL(18,4),
                       --MiddleValue DECIMAL(18,4),
                       --UpFourValue DECIMAL(18,4),
                       --MaxValue DECIMAL(18,4),
                       --TimeWD int
                       --)
                       
        SET @sql = 'insert into QuantileWDTb SELECT  ''' + @Name_ch + ''','''
            + @CoName + ''',MIN(' + @CoName + ') 最小值 ,
                dbo.UDA_UpQuartile(' + @CoName + ') 下四分位数 ,
                dbo.UDA_median(' + @CoName + ') 中位数 ,
                dbo.UDA_DownQuartile(' + @CoName + ') 上四分位数 ,
                MAX(' + @CoName + ') 最大值 ,
                CASE WHEN CoatingZJ.OptDate >= ''' + @date + ''' THEN 1
                     WHEN CoatingZJ.OptDate < ''' + @date
            + ''' THEN 0
                END 时间维度
        FROM    dbo.Bs_Coating_ZJ CoatingZJ
        LEFT JOIN dbo.Bs_Coating Coating ON CoatingZJ.CoatingCode = Coating.Code
        LEFT JOIN Bs_Coating_ITO CoatingITO ON Coating.CoatingITOCode = CoatingITO.Code
        LEFT JOIN Bs_Coating_MS CoatingMS ON CoatingMS.Code = Coating.CoatingMsCode
        LEFT JOIN dbo.Bs_CapsuleDynamic CapsuleDynamic ON CapsuleDynamic.Code = CoatingMS.CapsuleDynamicCode
        LEFT JOIN dbo.Bs_DynamicToCapsule ON Bs_DynamicToCapsule.CapsuleDynamicCode = CapsuleDynamic.Code
        LEFT JOIN dbo.Bs_DouCapsule DouCapsule ON DouCapsule.Code = Bs_DynamicToCapsule.DouCapsuleCode
        LEFT JOIN dbo.Bs_Oil Oil ON Oil.Code = DouCapsule.OilCode
        LEFT JOIN Tbl_Base_DouFu DouFu ON DouFu.ID = DouCapsule.Kettle
        LEFT JOIN Tbl_Base_AF0001 AF0001 ON AF0001.ID = DouCapsule.AF0001
        LEFT JOIN Tbl_Base_AF0003 AF0003 ON AF0003.ID = DouCapsule.AF0003
        LEFT JOIN Tbl_Base_BG0002 BG0002 ON BG0002.ID = DouCapsule.BG0002Code
        LEFT JOIN Tbl_Base_BG0004 BG0004 ON BG0004.ID = DouCapsule.BG0004
        LEFT JOIN Tbl_Base_BG0026 BG0026 ON BG0026.ID = DouCapsule.BG0026testDate
        LEFT JOIN Tbl_Base_OilSeries OilSeries ON OilSeries.id = Oil.Series
        LEFT JOIN dbo.Tbl_Base_OilAdditivesA OilAdditivesA ON OilAdditivesA.ID = Oil.AdditivesA
        LEFT JOIN Tbl_Base_OilAdditivesB OilAdditivesB ON OilAdditivesB.ID = Oil.AdditivesB
        LEFT JOIN dbo.Tbl_Base_OilL9Batch OilL9Batch ON OilL9Batch.ID = Oil.L9Batch
        LEFT JOIN dbo.Tbl_Base_OilAdditivesAType OilAdditivesAType ON OilAdditivesAType.ID = Oil.AdditivesAType
        LEFT JOIN Tbl_Base_OilAdditivesBType OilAdditivesBType ON OilAdditivesBType.ID = Oil.AdditivesBType
        LEFT JOIN dbo.Tbl_Base_OilL9BatchType OilL9BatchType ON OilL9BatchType.ID = Oil.L9BatchType
        LEFT JOIN Tbl_Base_BC0001 OilBC0001 ON OilBC0001.ID = Oil.BC0001
        LEFT JOIN dbo.Bs_ParticalToOil ON Bs_ParticalToOil.OilCode = Oil.Code
        LEFT JOIN dbo.Bs_ParticalBK ParticalBK ON ParticalBK.Code = Bs_ParticalToOil.ParticalCode
                                       AND Bs_ParticalToOil.PType = 2
        LEFT JOIN dbo.Bs_ParticalW ParticalW ON ParticalW.Code = Bs_ParticalToOil.ParticalCode
                                      AND Bs_ParticalToOil.PType = 1
        LEFT JOIN dbo.Bs_PigmentBK PigmentBK ON PigmentBK.Code = ParticalBK.PigmentBKCode
        LEFT JOIN dbo.Bs_PigmentW PigmentW ON PigmentW.Code = ParticalW.PigmentWCode
        LEFT JOIN Tbl_Base_PigmentWSolventC PigmentWSolventC ON PigmentWSolventC.ID = PigmentW.SolventC
        LEFT JOIN Tbl_Base_PigmentWSolventE PigmentWSolventE ON PigmentWSolventE.ID = PigmentW.SolventE
        LEFT JOIN Tbl_Base_BC0002 BC0002 ON BC0002.ID = PigmentW.BC0002
        LEFT JOIN Tbl_Base_PigmentWKettle PigmentWKettle ON PigmentWKettle.ID = PigmentW.Kettle
        LEFT JOIN Tbl_Base_PigmentWinnerCode PigmentWInnerCode ON PigmentWInnerCode.ID = PigmentW.InnerCode
        LEFT JOIN dbo.Tbl_Base_BC0013 BC0013 ON BC0013.ID = PigmentW.BC0013'
        
        SET @sqlAdd=' LEFT JOIN Tbl_Base_PigmentBKSolventC PigmentBKSolventC ON PigmentBKSolventC.ID = PigmentBK.SolventC
        LEFT JOIN Tbl_Base_PigmentBKSolventE PigmentBKSolventE ON PigmentBKSolventE.ID = PigmentBK.SolventE
        LEFT JOIN Tbl_Base_PigmentBKSolventD PigmentBKSolventD ON PigmentBKSolventD.ID = PigmentBK.SolventD
        LEFT JOIN Tbl_Base_PigmentBKKettle PigmentBKKettle ON PigmentBKKettle.ID = PigmentBK.Kettle
        LEFT JOIN Tbl_Base_PigmentBKRawCode PigmentBKRawCode ON PigmentBKRawCode.ID = PigmentBK.RawCode
        LEFT JOIN Tbl_Base_PigmentBKOuterCode PigmentBKOuterCode ON PigmentBKOuterCode.ID = PigmentBK.OuterCode
        LEFT JOIN Tbl_Base_PigmentBKSolventF PigmentBKSolventF ON PigmentBKSolventF.ID = PigmentBK.SolventF
        LEFT JOIN Tbl_Base_PigmentBKBC0015 BC0015BK ON BC0015BK.ID = PigmentBK.BC0015
        WHERE   min0LBK IS NOT NULL
                AND ( Coating.Code LIKE ''R5%''
                      OR Coating.Code LIKE ''R6%''
                    )
        GROUP BY CASE WHEN CoatingZJ.OptDate >= ''' + @date + ''' THEN 1
                      WHEN CoatingZJ.OptDate < ''' + @date + '''THEN 0
                 END;';
        SET @sql1 = 'insert into WDFX select ''' + @Name_ch + ''' 维度名称,'''
            + @CoName + ''' 英文字段,stdev(' + @CoName
            + ') 标准差,CASE WHEN CoatingZJ.OptDate >= ''' + @date
            + ''' THEN 1
                      WHEN CoatingZJ.OptDate < ''' + @date
            + '''THEN 0
                 END 时间维度 FROM    dbo.Bs_Coating_ZJ CoatingZJ
        LEFT JOIN dbo.Bs_Coating Coating ON CoatingZJ.CoatingCode = Coating.Code
        LEFT JOIN Bs_Coating_ITO CoatingITO ON Coating.CoatingITOCode = CoatingITO.Code
        LEFT JOIN Bs_Coating_MS CoatingMS ON CoatingMS.Code = Coating.CoatingMsCode
        LEFT JOIN dbo.Bs_CapsuleDynamic CapsuleDynamic ON CapsuleDynamic.Code = CoatingMS.CapsuleDynamicCode
        LEFT JOIN dbo.Bs_DynamicToCapsule ON Bs_DynamicToCapsule.CapsuleDynamicCode = CapsuleDynamic.Code
        LEFT JOIN dbo.Bs_DouCapsule DouCapsule ON DouCapsule.Code = Bs_DynamicToCapsule.DouCapsuleCode
        LEFT JOIN dbo.Bs_Oil Oil ON Oil.Code = DouCapsule.OilCode
        LEFT JOIN Tbl_Base_DouFu DouFu ON DouFu.ID = DouCapsule.Kettle
        LEFT JOIN Tbl_Base_AF0001 AF0001 ON AF0001.ID = DouCapsule.AF0001
        LEFT JOIN Tbl_Base_AF0003 AF0003 ON AF0003.ID = DouCapsule.AF0003
        LEFT JOIN Tbl_Base_BG0002 BG0002 ON BG0002.ID = DouCapsule.BG0002Code
        LEFT JOIN Tbl_Base_BG0004 BG0004 ON BG0004.ID = DouCapsule.BG0004
        LEFT JOIN Tbl_Base_BG0026 BG0026 ON BG0026.ID = DouCapsule.BG0026testDate
        LEFT JOIN Tbl_Base_OilSeries OilSeries ON OilSeries.id = Oil.Series
        LEFT JOIN dbo.Tbl_Base_OilAdditivesA OilAdditivesA ON OilAdditivesA.ID = Oil.AdditivesA
        LEFT JOIN Tbl_Base_OilAdditivesB OilAdditivesB ON OilAdditivesB.ID = Oil.AdditivesB
        LEFT JOIN dbo.Tbl_Base_OilL9Batch OilL9Batch ON OilL9Batch.ID = Oil.L9Batch
        LEFT JOIN dbo.Tbl_Base_OilAdditivesAType OilAdditivesAType ON OilAdditivesAType.ID = Oil.AdditivesAType
        LEFT JOIN Tbl_Base_OilAdditivesBType OilAdditivesBType ON OilAdditivesBType.ID = Oil.AdditivesBType
        LEFT JOIN dbo.Tbl_Base_OilL9BatchType OilL9BatchType ON OilL9BatchType.ID = Oil.L9BatchType
        LEFT JOIN Tbl_Base_BC0001 OilBC0001 ON OilBC0001.ID = Oil.BC0001
        LEFT JOIN dbo.Bs_ParticalToOil ON Bs_ParticalToOil.OilCode = Oil.Code
        LEFT JOIN dbo.Bs_ParticalBK ParticalBK ON ParticalBK.Code = Bs_ParticalToOil.ParticalCode
                                       AND Bs_ParticalToOil.PType = 2
        LEFT JOIN dbo.Bs_ParticalW ParticalW ON ParticalW.Code = Bs_ParticalToOil.ParticalCode
                                      AND Bs_ParticalToOil.PType = 1
        LEFT JOIN dbo.Bs_PigmentBK PigmentBK ON PigmentBK.Code = ParticalBK.PigmentBKCode
        LEFT JOIN dbo.Bs_PigmentW PigmentW ON PigmentW.Code = ParticalW.PigmentWCode
        LEFT JOIN Tbl_Base_PigmentWSolventC PigmentWSolventC ON PigmentWSolventC.ID = PigmentW.SolventC
        LEFT JOIN Tbl_Base_PigmentWSolventE PigmentWSolventE ON PigmentWSolventE.ID = PigmentW.SolventE
        LEFT JOIN Tbl_Base_BC0002 BC0002 ON BC0002.ID = PigmentW.BC0002
        LEFT JOIN Tbl_Base_PigmentWKettle PigmentWKettle ON PigmentWKettle.ID = PigmentW.Kettle
        LEFT JOIN Tbl_Base_PigmentWinnerCode PigmentWInnerCode ON PigmentWInnerCode.ID = PigmentW.InnerCode
        LEFT JOIN dbo.Tbl_Base_BC0013 BC0013 ON BC0013.ID = PigmentW.BC0013'
        SET @sql1Add=' LEFT JOIN Tbl_Base_PigmentBKSolventC PigmentBKSolventC ON PigmentBKSolventC.ID = PigmentBK.SolventC
        LEFT JOIN Tbl_Base_PigmentBKSolventE PigmentBKSolventE ON PigmentBKSolventE.ID = PigmentBK.SolventE
        LEFT JOIN Tbl_Base_PigmentBKSolventD PigmentBKSolventD ON PigmentBKSolventD.ID = PigmentBK.SolventD
        LEFT JOIN Tbl_Base_PigmentBKKettle PigmentBKKettle ON PigmentBKKettle.ID = PigmentBK.Kettle
        LEFT JOIN Tbl_Base_PigmentBKRawCode PigmentBKRawCode ON PigmentBKRawCode.ID = PigmentBK.RawCode
        LEFT JOIN Tbl_Base_PigmentBKOuterCode PigmentBKOuterCode ON PigmentBKOuterCode.ID = PigmentBK.OuterCode
        LEFT JOIN Tbl_Base_PigmentBKSolventF PigmentBKSolventF ON PigmentBKSolventF.ID = PigmentBK.SolventF
        LEFT JOIN Tbl_Base_PigmentBKBC0015 BC0015BK ON BC0015BK.ID = PigmentBK.BC0015
        WHERE   min0LBK IS NOT NULL
                AND ( Coating.Code LIKE ''R5%''
                      OR Coating.Code LIKE ''R6%''
                    )
        GROUP BY CASE WHEN CoatingZJ.OptDate >= ''' + @date + ''' THEN 1
                      WHEN CoatingZJ.OptDate < ''' + @date + '''THEN 0
                 END;';        
        SET @sql2 = 'insert into WDFX select ''' + @Name_ch + ''' 维度名称,'''
            + @CoName + ''' 英文字段,stdev(' + @CoName
            + ') 标准差,1
                  时间维度 from    dbo.Bs_Coating_ZJ
                LEFT JOIN dbo.Bs_Coating ON Bs_Coating.Code = Bs_Coating_ZJ.CoatingCode
                LEFT JOIN dbo.Bs_Coating_MS ON Bs_Coating_MS.Code = Bs_Coating.CoatingMsCode
        WHERE   min0LBK IS NOT NULL and Bs_Coating_ZJ.optdate between ''2018-1-4'' and ''2018-01-17'' 
                AND ( dbo.Bs_Coating.Code LIKE ''R5%''
                      OR dbo.Bs_Coating.Code LIKE ''R6%''
                    )
       ';        
       print @sql+@sqlAdd+' '+@sql1+@sql1Add
        EXEC (@sql+@sqlAdd+' '+@sql1+@sql1Add);
    END;
go

