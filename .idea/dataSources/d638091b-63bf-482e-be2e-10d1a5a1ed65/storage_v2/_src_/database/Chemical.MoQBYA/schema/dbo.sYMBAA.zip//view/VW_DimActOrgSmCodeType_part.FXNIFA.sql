





CREATE VIEW [dbo].[VW_DimActOrgSmCodeType_part]
AS
SELECT  -1 AS Id ,
'全部集合'AS Name ,
'1' AS istrue ,
'属性集合' 选项集合类型
 FROM    Tbl_AnsCom_DIimToTable AS b
 WHERE   DimNum = 'DimActOrgSmCodeType'
 UNION ALL
 SELECT Tbl_Base_Compound.id ID, Tbl_Base_Compound.Name,'2' istrue,Bs_Base_CompType.Name 选项集合类型 FROM  Tbl_Base_Compound 
 LEFT JOIN dbo.Bs_Base_CompType ON Bs_Base_CompType.Id = Tbl_Base_Compound.Type
 WHERE Tbl_Base_Compound.Name IS NOT NULL AND IsOrg=1
 UNION ALL
 SELECT  x.ID AS Id ,
 CAST(x.Name AS VARCHAR(100)) AS Name ,
'0' AS istrue ,
'基础选项' 选项集合类型
 FROM Tbl_AnsCom_DIimToTable b
 CROSS JOIN ( SELECT DISTINCT 
Name ,ID
 FROM Tbl_Base_Compound  WHERE Name IS NOT NULL AND IsOrg=1) x
 WHERE DimNum = 'DimActOrgSmCodeType'

------------------------------------------


go

