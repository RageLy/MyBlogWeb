CREATE proc [dbo].[Sp_Echart_scatter]    
as    
BEGIN    
 create table #tmpSourse    
 (    
  Value1 varchar(50),    
  Value2 varchar(50)    
 )    
 declare @x int = 0 ,@y int =2    
 while (@x<100)    
 BEGIN    
      
   insert into #tmpSourse(Value1,Value2)    
   values ('['+cast(Round(RAND() * 100, 0) as varchar(50))+','+cast(Round(RAND() * 100, 0) as varchar(50))+']'    
   ,'['+cast(Round(RAND() * 100, 0) as varchar(50))+','+cast(Round(RAND() * 100, 0) as varchar(50))+','+cast(Round(RAND() * 20, 0) as varchar(50))+']')    
      
  set @x = @x+1    
 END    
     
 select Value1 试驾销售,Value2 非试驾 from #tmpSourse    
     
 select '散点图测试' as title    
    ,'接待时长' as XName    
    ,'销售台数' as YName    
    ,'Y2 Name' as YName_Second    
    ,'分钟' as XUnit    
    ,'台' as YUnit    
    ,'Y2 Unit' as YUnit_Second    
  
        
END
go

