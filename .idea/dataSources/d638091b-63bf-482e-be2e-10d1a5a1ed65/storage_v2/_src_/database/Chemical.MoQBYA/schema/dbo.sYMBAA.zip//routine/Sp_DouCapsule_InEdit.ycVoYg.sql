











-- =============================================      

-- Description: 全结构查询
-- Auth:hjl
-- Parameter: 1 @CodeType -- 编号类型    
--            2 @CodeValue -- 编号取值
--            3 @ParaType -- 参数类型
--            4 @ParaValueL -- 参数取值下限
--            5 @paraValueH -- 参数取值上限  
--            6 @ResultType -- 结果类型
-- Content:  拼装SQL查询

-- =============================================   

CREATE proc[dbo].[Sp_DouCapsule_InEdit]
@ID varchar(50) = ''
,@Action varchar(50) = 'Select'
,@OptDate  varchar(50) ='' --日期
,@Code	varchar(50) ='test002'
,@OilID	varchar(50) =''
,@SpeType	varchar(50) ='' 
,@Kettle	varchar(50) =''
,@GAA	varchar(50) =''
,@AF0001	varchar(50) =''
,@AF0003	varchar(50) =''
,@BG0002Fa	varchar(50) =''
,@BG0002Code	varchar(50) =''
,@Temp41Set	varchar(50) =''
,@Temp41	varchar(50) =''
,@Time60	varchar(50) =''
,@Rspeed400Set	varchar(50) =''
,@Rspeed400	varchar(50) =''
,@Temp8Set	varchar(50) =''
,@Temp8	varchar(50) =''
,@Time120	varchar(50) =''
,@Temp25Set	varchar(50) =''
,@Temp25	varchar(50) =''
,@Time360	varchar(50) =''
,@Rspeed500Set	varchar(50) =''
,@Rspeed500	varchar(50) =''
,@OutPut	varchar(50) =''
,@Psize	varchar(50) =''
,@PsizeSpan	varchar(50) =''
,@SoildContent	varchar(50) =''
,@CR	varchar(50) =''
,@LBK	varchar(50) =''
,@LW	varchar(50) =''
,@DeltaBK	varchar(50) =''
,@DeltaW	varchar(50) =''
,@PH	varchar(50) =''
,@PHTemp	varchar(50) =''
,@Remark	varchar(500) =''
,@EmpID varchar(50) = '1'
AS
BEGIN
	SET NOCOUNT ON;
	
declare @YTbl TABLE
(
OptDate	varchar(50) --日期
,Code	varchar(50)
,OilID	varchar(50)
,SpeType	varchar(50)
,Kettle	varchar(50)
,GAA	varchar(50)
,AF0001	varchar(50)
,AF0003	varchar(50)
,BG0002Fa	varchar(50)
,BG0002Code	varchar(50)
,Temp41Set	varchar(50)
,Temp41	varchar(50)
,Time60	varchar(50)
,Rspeed400Set	varchar(50)
,Rspeed400	varchar(50)
,Temp8Set	varchar(50)
,Temp8	varchar(50)
,Time120	varchar(50)
,Temp25Set	varchar(50)
,Temp25	varchar(50)
,Time360	varchar(50)
,Rspeed500Set	varchar(50)
,Rspeed500	varchar(50)
,OutPut	varchar(50)
,Psize	varchar(50)
,PsizeSpan	varchar(50)
,SoildContent varchar(50)
,CR	varchar(50)
,LBK	varchar(50)
,LW	varchar(50)
,DeltaBK	varchar(50)
,DeltaW	varchar(50)
,PH	varchar(50)
,PHTemp	varchar(50)
,Remark varchar(500)

 )

IF @Action = 'Insert'  --插入数据
BEGIN
 IF(@ID = '')
    BEGIN
        if exists(select 1 from dbo.Bs_DouCapsule where Code=rtrim(ltrim(@Code)))                      
        begin
        select '胶囊批次不能重复！'
        return
        end
        IF @Code = '' begin SELECT '胶囊批次不能为空' ; RETURN  END
        else
        if exists(select 1 from dbo.Bs_Oil where Code=rtrim(ltrim(@OilID)))
        begin

        insert into @YTbl([OptDate],[Code], [OilID], [SpeType], [Kettle], GAA, [AF0001], [AF0003], [BG0002Fa], [BG0002Code], [Temp41Set], [Temp41], [Time60], [Rspeed400Set], [Rspeed400], [Temp8Set], [Temp8], [Time120], [Temp25Set], [Temp25], [Time360], [Rspeed500Set], [Rspeed500],[OutPut],Psize,PsizeSpan,SoildContent,CR,LBK,LW,DeltaBK,DeltaW,PH,PHTemp,Remark)
        values(rtrim(ltrim(@OptDate)), rtrim(ltrim(@Code)),  rtrim(ltrim(@OilID)), 
        CASE WHEN @SpeType = '' THEN NULL ELSE rtrim(ltrim(@SpeType)) end,
        CASE WHEN @Kettle = '' THEN NULL ELSE rtrim(ltrim(@Kettle)) end , 
        CASE WHEN @GAA = '' THEN NULL ELSE rtrim(ltrim(@GAA)) end , 
        CASE WHEN @AF0001 = '' THEN NULL ELSE rtrim(ltrim(@AF0001)) end, 
        CASE WHEN @AF0003 = '' THEN NULL ELSE rtrim(ltrim(@AF0003)) end, 
        CASE WHEN @BG0002Fa = '' THEN NULL ELSE rtrim(ltrim(@BG0002Fa)) end, 
        CASE WHEN @BG0002Code = '' THEN NULL ELSE rtrim(ltrim(@BG0002Code)) end, 
        CASE WHEN @Temp41Set = '' THEN NULL ELSE rtrim(ltrim(@Temp41Set)) end, 
        CASE WHEN @Temp41 = '' THEN NULL ELSE rtrim(ltrim(@Temp41)) end, 
        CASE WHEN @Time60 = '' THEN NULL ELSE rtrim(ltrim(@Time60)) end, 
        CASE WHEN @Rspeed400Set = '' THEN NULL ELSE rtrim(ltrim(@Rspeed400Set)) end, 
        CASE WHEN @Rspeed400 = '' THEN NULL ELSE rtrim(ltrim(@Rspeed400)) end,
        CASE WHEN @Temp8Set = '' THEN NULL ELSE rtrim(ltrim(@Temp8Set)) end, 
        CASE WHEN @Temp8 = '' THEN NULL ELSE rtrim(ltrim(@Temp8)) end, 
        CASE WHEN @Time120 = '' THEN NULL ELSE rtrim(ltrim(@Time120)) end, 
        CASE WHEN @Temp25Set = '' THEN NULL ELSE rtrim(ltrim(@Temp25Set)) end, 
        CASE WHEN @Temp25 = '' THEN NULL ELSE rtrim(ltrim(@Temp25)) end, 
        CASE WHEN @Time360 = '' THEN NULL ELSE rtrim(ltrim(@Time360)) end, 
        CASE WHEN @Rspeed500Set = '' THEN NULL ELSE rtrim(ltrim(@Rspeed500Set)) end, 
        CASE WHEN @Rspeed500 = '' THEN NULL ELSE rtrim(ltrim(@Rspeed500)) end, 
        CASE WHEN @OutPut = '' THEN NULL ELSE rtrim(ltrim(@OutPut)) end, 
        CASE WHEN @Psize = '' THEN NULL ELSE rtrim(ltrim(@Psize)) end, 
        CASE WHEN @PsizeSpan = '' THEN NULL ELSE rtrim(ltrim(@PsizeSpan)) end, 
        CASE WHEN @SoildContent = '' THEN NULL ELSE rtrim(ltrim(@SoildContent)) end, 
        CASE WHEN @CR = '' THEN NULL ELSE rtrim(ltrim(@CR)) end, 
        CASE WHEN @LBK = '' THEN NULL ELSE rtrim(ltrim(@LBK)) end, 
        CASE WHEN @LW = '' THEN NULL ELSE rtrim(ltrim(@LW)) end, 
        CASE WHEN @DeltaBK = '' THEN NULL ELSE rtrim(ltrim(@DeltaBK)) end, 
        CASE WHEN @DeltaW = '' THEN NULL ELSE rtrim(ltrim(@DeltaW)) end, 
        CASE WHEN @PH = '' THEN NULL ELSE rtrim(ltrim(@PH)) end,
        CASE WHEN @PHTemp = '' THEN NULL ELSE rtrim(ltrim(@PHTemp)) end,
        CASE WHEN @Remark = '' THEN NULL ELSE rtrim(ltrim(@Remark)) end)
 
        insert into dbo.Bs_DouCapsule (OptDate, Code, OilID, SpeType, Kettle, GAA, AF0001, AF0003, BG0002Fa, BG0002Code, Temp41Set, Temp41, Time60, Rspeed400Set, Rspeed400, Temp8Set, Temp8, Time120, Temp25Set, Temp25, Time360, SetRspeed500, Rspeed500, OutPut, Psize, PsizeSpan, SoildContent, CR, LBK, LW, DeltaBK, DeltaW, PH, PHTemp, Remark)
        select ls.[OptDate],ls.[Code], yx.[ID], SpeType, Kettle, GAA, AF0001, AF0003, BG0002Fa, BG0002Code, Temp41Set, Temp41, Time60, Rspeed400Set, Rspeed400, Temp8Set, Temp8, Time120, Temp25Set, Temp25, Time360, Rspeed500Set, Rspeed500, OutPut, Psize, PsizeSpan, SoildContent, CR, LBK, LW, DeltaBK, DeltaW, ls.PH, PHTemp, ls.Remark from @YTbl ls
        left join dbo.Bs_Oil yx
        on ls.OilID=yx.Code

INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_DouCapsule_InEdit',
        '新增双层胶囊', 'insert',@ID
									+','+@Action
									+','+@OptDate
									+','+@Code
									+','+@OilID
									+','+@SpeType 
									+','+@Kettle
									+','+@GAA
									+','+@AF0001
									+','+@AF0003
									+','+@BG0002Fa
									+','+@BG0002Code
									+','+@Temp41Set
									+','+@Temp41
									+','+@Time60
									+','+@Rspeed400Set
									+','+@Rspeed400
									+','+@Temp8Set
									+','+@Temp8
									+','+@Time120
									+','+@Temp25Set
									+','+@Temp25
									+','+@Time360
									+','+@Rspeed500Set
									+','+@Rspeed500
									+','+@OutPut
									+','+@Psize
									+','+@PsizeSpan
									+','+@SoildContent
									+','+@CR
									+','+@LBK
									+','+@LW
									+','+@DeltaBK
									+','+@DeltaW
									+','+@PH
									+','+@PHTemp
									+','+@Remark
									+','+@EmpID)  



        select '数据保存成功！'   return end
        else 
        select '请输入有效的油项批号' return end;

 else
begin
			UPDATE  Bs_DouCapsule
			SET
			OptDate = @OptDate
			,Code = @Code
			,OilID =(select id from dbo.Bs_Oil where @OilID=code)
			,SpeType = CASE WHEN @SpeType = '' THEN NULL ELSE rtrim(ltrim(@SpeType)) end
			,Kettle = CASE WHEN @Kettle = '' THEN NULL ELSE rtrim(ltrim(@Kettle)) end
			,GAA = CASE WHEN @GAA = '' THEN NULL ELSE rtrim(ltrim(@GAA)) end
			,AF0001 = CASE WHEN @AF0001 = '' THEN NULL ELSE rtrim(ltrim(@AF0001)) end
			,AF0003 = CASE WHEN @AF0003 = '' THEN NULL ELSE rtrim(ltrim(@AF0003)) end
			,BG0002Fa = CASE WHEN @BG0002Fa = '' THEN NULL ELSE rtrim(ltrim(@BG0002Fa)) end
			,BG0002Code = CASE WHEN @BG0002Code = '' THEN NULL ELSE rtrim(ltrim(@BG0002Code)) end
			,Temp41Set = CASE WHEN @Temp41Set = '' THEN NULL ELSE rtrim(ltrim(@Temp41Set)) end
			,Temp41 = CASE WHEN @Temp41 = '' THEN NULL ELSE rtrim(ltrim(@Temp41)) end
			,Time60 = CASE WHEN @Time60 = '' THEN NULL ELSE rtrim(ltrim(@Time60)) end
			,Rspeed400Set = CASE WHEN @Rspeed400Set = '' THEN NULL ELSE rtrim(ltrim(@Rspeed400Set)) end
			,Rspeed400 = CASE WHEN @Rspeed400 = '' THEN NULL ELSE rtrim(ltrim(@Rspeed400)) end
			,Temp8Set = CASE WHEN @Temp8Set = '' THEN NULL ELSE rtrim(ltrim(@Temp8Set)) end
			,Temp8 = CASE WHEN @Temp8 = '' THEN NULL ELSE rtrim(ltrim(@Temp8)) end
			,Time120 = CASE WHEN @Time120 = '' THEN NULL ELSE rtrim(ltrim(@Time120)) end
			,Temp25Set = CASE WHEN @Temp25Set = '' THEN NULL ELSE rtrim(ltrim(@Temp25Set)) end
			,Temp25 = CASE WHEN @Temp25 = '' THEN NULL ELSE rtrim(ltrim(@Temp25)) end
			,Time360 = CASE WHEN @Time360 = '' THEN NULL ELSE rtrim(ltrim(@Time360)) end
			,SetRspeed500 = CASE WHEN @Rspeed500Set = '' THEN NULL ELSE rtrim(ltrim(@Rspeed500Set)) end
			,Rspeed500 = CASE WHEN @Rspeed500 = '' THEN NULL ELSE rtrim(ltrim(@Rspeed500)) end
			,OutPut = CASE WHEN @OutPut = '' THEN NULL ELSE rtrim(ltrim(@OutPut)) end
			,Psize = CASE WHEN @Psize = '' THEN NULL ELSE rtrim(ltrim(@Psize)) end
			,PsizeSpan = CASE WHEN @PsizeSpan = '' THEN NULL ELSE rtrim(ltrim(@PsizeSpan)) end
			,SoildContent = CASE WHEN @SoildContent = '' THEN NULL ELSE rtrim(ltrim(@SoildContent)) end
			,CR = CASE WHEN @CR = '' THEN NULL ELSE rtrim(ltrim(@CR)) end
			,LBK = CASE WHEN @LBK = '' THEN NULL ELSE rtrim(ltrim(@LBK)) end
			,LW = CASE WHEN @LW = '' THEN NULL ELSE rtrim(ltrim(@LW)) end
			,DeltaBK = CASE WHEN @DeltaBK = '' THEN NULL ELSE rtrim(ltrim(@DeltaBK)) end
			,DeltaW = CASE WHEN @DeltaW = '' THEN NULL ELSE rtrim(ltrim(@DeltaW)) end
			,PH = CASE WHEN @PH = '' THEN NULL ELSE rtrim(ltrim(@PH)) end
			,PHTemp = CASE WHEN @PHTemp = '' THEN NULL ELSE rtrim(ltrim(@PHTemp)) end
			,Remark = CASE WHEN @Remark = '' THEN NULL ELSE rtrim(ltrim(@Remark)) end
			WHERE ID = @ID
			
			
			INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_DouCapsule_InEdit',
        '编辑双层胶囊', 'UPDATE',@ID
									+','+@Action
									+','+@OptDate
									+','+@Code
									+','+@OilID
									+','+@SpeType 
									+','+@Kettle
									+','+@GAA
									+','+@AF0001
									+','+@AF0003
									+','+@BG0002Fa
									+','+@BG0002Code
									+','+@Temp41Set
									+','+@Temp41
									+','+@Time60
									+','+@Rspeed400Set
									+','+@Rspeed400
									+','+@Temp8Set
									+','+@Temp8
									+','+@Time120
									+','+@Temp25Set
									+','+@Temp25
									+','+@Time360
									+','+@Rspeed500Set
									+','+@Rspeed500
									+','+@OutPut
									+','+@Psize
									+','+@PsizeSpan
									+','+@SoildContent
									+','+@CR
									+','+@LBK
									+','+@LW
									+','+@DeltaBK
									+','+@DeltaW
									+','+@PH
									+','+@PHTemp
									+','+@Remark
									+','+@EmpID) 
			
			
			
			
			
		select '修改成功' return end
end
end

select * from Bs_DouCapsule where Code=@Code
go

