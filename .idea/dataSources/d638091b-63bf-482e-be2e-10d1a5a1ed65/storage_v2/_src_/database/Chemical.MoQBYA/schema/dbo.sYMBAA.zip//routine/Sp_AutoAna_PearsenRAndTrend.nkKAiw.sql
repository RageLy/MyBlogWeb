












-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 自动相关性系数与趋势计算sp
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_PearsenRAndTrend]
	-- Add the parameters for the stored procedure here
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(max) = 'DimSinOutValue:,DimOilSeries:,DimSinTemp8:倍数2,DimDIYTemp25:,DimDIYSpeed:,DimDIYSpeed580:,DimDIYOilVis:'
	,@XDim VARCHAR(50) = 'DimDDLps'
	,@YDim VARCHAR(50) = 'DimSinOutValue'
	,@NameTag VARCHAR(50) = 'hjl'
	,@IsCountR BIT = 0 -- 是否计算 相关系数R
	,@RWhere VARCHAR(MAX) = ' AND DimOilSeries = 3 '   -- 计算相关系数的筛选条件
	,@IsCountTrend INT  = 0
	,@TrendR DECIMAL(18,6) = 0.7
	,@GetLineR DECIMAL(18,2) = 0.5  -- 计算斜率的R条件
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
 
    -- 分解维度插入零时表
    INSERT INTO #DimsPearSen
    SELECT SUBSTRING(string,1,CHARINDEX(':',string) - 1)
    ,CASE WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @XDim THEN 'X'  -- 变量dim
	      WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @YDim THEN 'Y'  -- 目标dim
		  ELSE 'F' END   -- 条件Dim
    ,ta.IsRange
    ,ta.ViewName
    ,ta.AtYSql
    ,SUBSTRING(string,CHARINDEX(':',string) + 1,Len(string))
    ,NUll
    FROM dbo.Split(@Dims,',') s
    INNER JOIN dbo.Tbl_AnsCom_DIimToTable ta ON SUBSTRING(string,1,CHARINDEX(':',string) - 1) = ta.DimNum
    
    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #DimsPearSen WHERE Dim = @YDim;
    

    DECLARE @Xsql VARCHAR(500);
    SELECT @Xsql = DimYsql FROM #DimsPearSen WHERE Dim = @XDim;
    IF(@Xsql IS NULL)  -- 如果X值没有选则取0
		SET @Xsql = '0';
    
    -- 数据源sql段
    DECLARE @TName VARCHAR(500);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
   
    -- 计算所有维度存在数据的条数
    
	--   DECLARE @CountData VARCHAR(max) = '';
	--   SET @CountData = ( SELECT ',Count(' + DimYsql + ')'
	--	FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	--	-- 去掉第一个,
	--SET @CountData = SUBSTRING(@CountData,2,LEN(@CountData));
	
	--EXEC ('select ' + @CountData + ' From ' + @TName);
	--RETURN;
	
   -- SELECT * FROM #DimsPearSen;
    
    -- 计算所有条件 Dim 的数据量
    DECLARE @CreateT VARCHAR(max) = '';
    
    SET @CreateT += ( SELECT 'CREATE TABLE #' +  Dim + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') );
    
    -- 根据维度值取维度刻度
	DECLARE @InsertT VARCHAR(max) = '';

	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where ' + 
				CASE WHEN ISNULL(DimValue,'') = '' THEN 'istrue = 0;'
						  ELSE '[选项集合类型] = ''' + DimValue + ''';' END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') )

	--if(@DimScale='倍数')
	--begin
	--SET @InsertT +=
	--   ( SELECT 'insert into #' + Dim + 
	--	CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'+ ViewName + '_Part where istrue = 0; '
	--	     WHEN isrange = 1 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'+ ViewName + '_Part where istrue = 2; '
	--	     END
	--	FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH('') )
	--end;

   print @InsertT;
    -- 拼接计算列

    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' LEFT JOIN #' +  Dim + ' AS ' + Dim + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN Dim + '.BeginValue <= ' + DimYsql + ' AND ' + Dim + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE Dim + '.ID = ' + DimYsql END
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	
	-- 拼接SiftValue段
    DECLARE @SiftValue VARCHAR(max);
    SET @SiftValue = ( SELECT '''%' +  Dim + ':'' + CAST( isnull(' + Dim + '.ID,0) AS Varchar(10)) + '
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个 % 和最后一个 +
	SET @SiftValue = '''' + SUBSTRING(@SiftValue,3,LEN(@SiftValue) - 3);
	
	-- 拼接 group by 段
    DECLARE @GroupBy VARCHAR(max);
    SET @GroupBy = ( SELECT ',' + Dim + '.ID'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个,
	SET @GroupBy = SUBSTRING(@GroupBy,2,LEN(@GroupBy));
	
	-- 执行语句
	
	--SET @SqlCount += 'SELECT COUNT(*),' + @SiftValue + ' FROM ' + @SqlJoin;
	
	--select @CreateT + @InsertT + 'SELECT COUNT(*),' + @SiftValue + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy
	--EXEC (@CreateT + @InsertT + 'SELECT * FROM ' + @TName + @SqlJoin);
	
	--SELECT @SiftValue;
	
	
	
	-- 设置目标表格
	DECLARE @ResultTable VARCHAR(max);
	SET @ResultTable = 'T_AutoAnaCountSift_' + ISNULL(@XDim,'') + '_' +  ISNULL(@YDim,'') + '_' +ISNULL(@NameTag,'');
	
	-- 拼接 维度条件列名段
    DECLARE @CName VARCHAR(max);
    SET @CName = ( SELECT ',' + Dim + ' INT'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	
	IF exists( SELECT 1 FROM sys.objects where name = @ResultTable )
		EXEC ( 'DROP TABLE ' + @ResultTable );
	
	--SELECT @CName;
	

	EXEC ( 'CREATE TABLE ' + @ResultTable + '
	(	spName varchar(50),
		DataCount int,
		MaxY Decimal(18,6),
		MinY Decimal(18,6),
		AVGY Decimal(18,6),
		SQtY Decimal(18,6),
		MaxX Decimal(18,6),
		MinX Decimal(18,6),
		Xcount int,
		Siftvalue varchar(Max),
		PearSenR DECIMAL(18,6),
		Slope DECIMAL(18,6),
		LineCons DECIMAL(18,6),
		ChangePoint int ,
		Trend Varchar(Max)
		'
		+ @CName +
		'
	)'
	 )
	
	--RETURN;
	DECLARE @ResultDataSql VARCHAR(500);
	SET @ResultDataSql = '''' + @SpName + ''',SUM(CASE WHEN ' + @Ysql + ' is not null THEN 1 ELSE 0 END ),MAX(' + @Ysql + '),MIN(' + @Ysql + '),AVG(' + @Ysql + '),stdev(' + @Ysql + '),Max(' + @Xsql + '),Min(' + @Xsql + '),Count(Distinct ' + @Xsql + '),'
	
	EXEC (@CreateT + @InsertT + 'INSERT INTO ' + @ResultTable + ' SELECT ' + @ResultDataSql + @SiftValue + ',NULL,NULL,NULL,NULL,NULL,' + @GroupBy + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy);
	
	
	--SELECT  (@CreateT + @InsertT + 'INSERT INTO ' + @ResultTable + ' SELECT ' + @ResultDataSql + @SiftValue + ',' + @GroupBy + ' FROM ' + @TName + @SqlJoin + ' Group by ' + @GroupBy);
	
	PRINT 'Create Table: ' + @ResultTable
	-- 拼接 drop table 段 用于debug
    --  DECLARE @Droptable VARCHAR(max);
    --  SET @Droptable = ( SELECT 'Drop table #' + Dim + ' ;'
	--	FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	--SELECT @Droptable;
	
	
	-- 如需计算相关系数
	IF(@IsCountR = 1)
	BEGIN
		
		-- 打印总数据
		EXEC  ('DECLARE @VDataCount int,@AllDataCount int;
		select @AllDataCount = SUM(CASE WHEN DataCount > 0 THEN 1 ELSE 0 END),@VDataCount = SUM(CASE WHEN DataCount > 1 THEN 1 ELSE 0 END) FROM ' + @ResultTable + ' WHERE 1 = 1 ' + @RWhere + ';
		PRINT ( ''有数据总组数：'' + Cast(@AllDataCount AS Varchar(10)) + '' -----  两条以上数据总组数：'' +  Cast(@VDataCount AS Varchar(10)) ) ' )
		
		DECLARE @UpdateR VARCHAR(MAX);
		
		SET @UpdateR = '
		DECLARE @N INT = 1;
		DECLARE @SV VARCHAR(MAX);
		DECLARE Cur CURSOR FOR
		SELECT Siftvalue FROM ' + @ResultTable + ' WHERE DataCount > 1 AND MaxX <> MinX ' + @RWhere + '
		OPEN Cur
		FETCH NEXT FROM Cur INTO @SV
		WHILE @@FETCH_STATUS =0
		BEGIN
			
			EXEC [Sp_AutoAna_DataPearsen]
			@SiftValue = @SV
			,@SpName = ''' + @SpName + '''
			,@XDim = ''' + @XDim + '''
			,@YDim = ''' + @YDim + '''
			,@NameTag = ''' + @NameTag + '''
			,@GetLineR  = ' + CAST(@GetLineR AS VARCHAR(20)) + '
			
			IF( ' + CAST(@IsCountTrend AS VARCHAR(10)) + ' = 1 )
			BEGIN
				IF EXISTS( select 1 FROM ' + @ResultTable + ' WHERE SiftValue = @SV AND Abs(PearSenR) < + ' + CAST(@TrendR AS VARCHAR(20)) + ' )
					EXEC [Sp_AutoAna_DataTrend]
					@SiftValue = @SV
					,@SpName = ''' + @SpName + '''
					,@XDim = ''' + @XDim + '''
					,@YDim = ''' + @YDim + '''
					,@NameTag = ''' + @NameTag + '''
			
			END
			
			Print ( ''执行完:'' + Cast(@N AS Varchar(10)) )
			
			SET @N = @N + 1
			
			FETCH NEXT FROM Cur INTO @SV
		END	
		CLOSE Cur
		DEALLOCATE Cur
		'
		
		--PRINT (@UpdateR);
		EXEC (@UpdateR);
		
	END
	
END
go

