



















-- =============================================   
   
CREATE proc[dbo].[Sp_Bs_List_PigmentW]
 @OptDateB VARCHAR(50) = ''      
 ,@OptDateE VARCHAR(50) = ''   
 ,@Code VARCHAR(50) = ''  
 ,@PageIndex varchar(5) = '1'
 ,@PageSize varchar(5) = '10'
 ,@OrderFields varchar(50) = ''
 ,@Type varchar(50) = ''  -- "查询" "编辑" 类型，是查询的List，还是编辑用的加载    
 ,@ID varchar(50) = ''   
 ,@EmpID varchar(50) = '1' 
AS    
BEGIN    
SET @Code = LTRIM(RTRIM(@Code))
 --------------------- 变量声明  -------------------------
 select jn.ID, CONVERT(varchar(100),jn.OptDate, 23) as OptDate, jn.Code as Code, fu.Name as Kettle, PW.innerCode AS innerCode, sc.SolventC,se.SolventE,CTRSpeedActually, FRSpeedActually, ReactOutput, GrindOutput, PSize05Bef, PSize09Bef, PH, jn.Remark
   INTO #Result
   FROM dbo.Bs_PigmentW AS jn
   LEFT JOIN Tbl_Base_PigmentWinnerCode PW
   ON jn.InnerCode=PW.ID
   left join Tbl_Base_PigmentWKettle fu
   on jn.kettle=fu.ID
   left join Tbl_Base_PigmentWSolventC sc
   on jn.SolventC=sc.id
   left join Tbl_Base_PigmentWSolventE se
   on jn.SolventE=se.id
   where ( @Code = '' or jn.Code like ('%' + @Code + '%') )
      AND ( @OptDateB = '' or jn.[OptDate] >= @OptDateB )       
   AND ( @OptDateE = '' or jn.[OptDate] < DATEAdd(DD,1,@OptDateE ) )    
   AND ( @Type = '查询' OR jn.ID = @ID )
  
    -- 数据分页    
 DECLARE @totalRow int = @@ROWCOUNT ;    
  
    if(@OrderFields='')    
  set @OrderFields ='optdate desc'    

  -- 编辑的加载 
		 INSERT INTO Tbl_Log_AnaUseLog
			(EmpID, freshTime, spName,
				AnaName, siftvalue, OherParemeter)
			VALUES (@EmpID, GETDATE(), 'Sp_Bs_List_PigmentW',
				'查询颜料BK', 'select',@Code)    
     
 IF(@Type = '查询')
 begin
 
  EXEC dbo.Sp_Sys_Page @tblName = '#Result'                      
  ,@fldName = @OrderFields                              
  ,@rowcount = @totalRow     
  ,@PageIndex = @PageIndex     
  ,@PageSize = @PageSize      
  ,@SumType = 0    
  ,@SumColumn = ''    
  ,@AvgColumn = ''    
     
     end
 ELSE     
    SELECT * FROM #Result    
     
  END     
--select * from tbl_sys_myMenu
go

