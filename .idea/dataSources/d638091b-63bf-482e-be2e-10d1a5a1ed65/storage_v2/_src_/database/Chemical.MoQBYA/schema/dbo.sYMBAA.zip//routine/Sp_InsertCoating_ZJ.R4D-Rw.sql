
-- =============================================                            
-- Author: hmw                                            
-- Create Date: 2017年5月26日                                                  
-- Descript: 从Excel插入白色颜料  
-- =============================================                   
--   exec [Sp_InsertBs_Coating_ZJ]
CREATE PROCEDURE [dbo].[Sp_InsertCoating_ZJ]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        DELETE FROM dbo.TempTb_CoatingZJ
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_CoatingZJ
                            GROUP BY 膜片批次
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_CoatingZJ
                           );
        UPDATE dbo.Bs_Coating_ZJ
        SET    OptDate = 检测日期 ,
			   TestDate=测试日期,
               CoatingID = Coating.ID ,
			   CoatingCode=Coating.Code,
               MpTbLv = 膜片涂布利用率 ,
               MpFdLv = 膜片分段利用率 ,
               PointBK = 黑_点 ,
               PointW = 白_点 ,
               PointM = 麻_点 ,
               PointH = 灰阶点 ,
               LineSW = 竖_纹 ,
               LineHW = 横_纹 ,
               LineGS = 刮_伤 ,
               JsGH = 胶水刮痕 ,
               JsQP = 胶_水_气_泡 ,
               ScJP = 桔皮 ,
               ScSc = 色差 ,
               ScKD = 空_点 ,
               ZcZK = 针_孔 ,
               ZcTFBZ = 涂_幅_不_足 ,
               ZcQT = 缺_涂 ,
               ZcHDBZ = 厚_度_不_足 ,
               SYJudge = 生益判定 ,
               OedJudge = OED判定 ,
               Bad1Type = TbBad1.ID ,
               Bad2Type = TbBad2.ID ,
               Bad3Type = TbBad3.ID ,
               min0LBK = L黑均值0min ,
               min2LBK = L黑均值2min ,
               min0LW = L白均值0min ,
               min2LW = L白均值2min ,
               min2detaLBK = LBK2min ,
               min2detaLW = LW2min ,
               Dbd = 对比度 ,
               WBdata = 白色B值2min ,
               Qddl = 单位面积驱动电流 ,
               ReMark = 备注 ,
               UpdateDate = GETDATE()
        FROM   dbo.TempTb_CoatingZJ
               LEFT JOIN Tbl_Base_TbBad TbBad1 ON TbBad1.Type = TempTb_CoatingZJ.第一大_不良项
               LEFT JOIN Tbl_Base_TbBad TbBad2 ON TbBad2.Type = TempTb_CoatingZJ.第二大_不良项
               LEFT JOIN Tbl_Base_TbBad TbBad3 ON TbBad3.Type = TempTb_CoatingZJ.第三大_不良项
               LEFT JOIN dbo.Bs_Coating Coating ON TempTb_CoatingZJ.膜片批次 = Coating.Code
        WHERE  Bs_Coating_ZJ.Code = 膜片批次;

        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_Coating_ZJ
                                            INNER JOIN dbo.TempTb_CoatingZJ ON TempTb_CoatingZJ.膜片批次 = Bs_Coating_ZJ.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;

        INSERT INTO dbo.Bs_Coating_ZJ (   OptDate ,
		TestDate,
                                          CoatingID ,
										  CoatingCode,
                                          Code ,
                                          MpTbLv ,
                                          MpFdLv ,
                                          PointBK ,
                                          PointW ,
                                          PointM ,
                                          PointH ,
                                          LineSW ,
                                          LineHW ,
                                          LineGS ,
                                          JsGH ,
                                          JsQP ,
                                          ScJP ,
                                          ScSc ,
                                          ScKD ,
                                          ZcZK ,
                                          ZcTFBZ ,
                                          ZcQT ,
                                          ZcHDBZ ,
                                          SYJudge ,
                                          OedJudge ,
                                          Bad1Type ,
                                          Bad2Type ,
                                          Bad3Type ,
                                          min0LBK ,
                                          min2LBK ,
                                          min0LW ,
                                          min2LW ,
                                          min2detaLBK ,
                                          min2detaLW ,
                                          Dbd ,
                                          WBdata ,
                                          Qddl ,
                                          ReMark ,
                                          UpdateDate
                                      )
                    SELECT 检测日期 ,
					测试日期,
                           Coating.ID ,
						   Coating.Code,
                           膜片批次 ,
                           膜片涂布利用率 ,
                           膜片分段利用率 ,
                           黑_点 ,
                           白_点 ,
                           麻_点 ,
                           灰阶点 ,
                           竖_纹 ,
                           横_纹 ,
                           刮_伤 ,
                           胶水刮痕 ,
                           胶_水_气_泡 ,
                           桔皮 ,
                           色差 ,
                           空_点 ,
                           针_孔 ,
                           涂_幅_不_足 ,
                           缺_涂 ,
                           厚_度_不_足 ,
                           生益判定 ,
                           OED判定 ,
                           TbBad1.ID ,
                           TbBad2.ID ,
                           TbBad3.ID ,
                           L黑均值0min ,
                           L黑均值2min ,
                           L白均值0min ,
                           L白均值2min ,
                           LBK2min ,
                           LW2min ,
                           对比度 ,
                           白色B值2min ,
                           单位面积驱动电流 ,
                           备注 ,
                           GETDATE()
                    FROM   dbo.TempTb_CoatingZJ
                           LEFT JOIN Tbl_Base_TbBad TbBad1 ON TbBad1.Type = TempTb_CoatingZJ.第一大_不良项
                           LEFT JOIN Tbl_Base_TbBad TbBad2 ON TbBad2.Type = TempTb_CoatingZJ.第二大_不良项
                           LEFT JOIN Tbl_Base_TbBad TbBad3 ON TbBad3.Type = TempTb_CoatingZJ.第三大_不良项
                           LEFT JOIN dbo.Bs_Coating Coating ON TempTb_CoatingZJ.膜片批次 = Coating.Code
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_Coating_ZJ
                                          WHERE  Code = 膜片批次
                                      )
                           AND 膜片批次 IS NOT NULL;

    END;
go

