-- =============================================
-- Author:		<hemw>
-- Create date: <2017-05-25>
-- Description:	<批量生成字段的值种类、值个数、种类占比、非空值种类>
-- =============================================
CREATE PROCEDURE [dbo].[BatchLoad_data]
    @param NVARCHAR(20) ,
    @paramhan NVARCHAR(20) ,
    @paramTable NVARCHAR(20) ,
    @paramdate NVARCHAR(20)
AS
    BEGIN --判断表是否存在
        IF EXISTS ( SELECT  *
                    FROM    dbo.sysobjects
                    WHERE   id = OBJECT_ID(N'BatchLoad')
                            AND OBJECTPROPERTY(id, 'IsTable') = 1 )
            BEGIN --存在插入数据
                IF ( ( SELECT   COUNT(字段名)
                       FROM     BatchLoad
                       WHERE    字段名 = @param
                                AND 表名 = @paramTable
                     ) = 0 )
                    BEGIN
                        DECLARE @sql NVARCHAR(MAX)= '';

                        PRINT '插入数据1';
                        IF ( @paramdate IS NULL
                             OR @paramdate = ''
                           )
                            BEGIN
                                SET @sql = 'insert into BatchLoad(表名,字段名,汉字说明,数值种类,总记录数,非NULL数量,整体占比,有效占比,平均值,标准差,NULL值数量) 
select ' + @paramTable + ''',''' + @param + ''',
''' + @paramhan + ''',
count(distinct ' + @param + '),
count(*),
COUNT(' + @param + '),
cast((count(distinct ' + @param + ')*1.0/COUNT(*)) as decimal(18,5)),
cast((count(distinct ' + @param + ')*1.0/COUNT(' + @param
                                    + ')) as decimal(18,5)),
     avg(' + @param + '),
     stdev(' + @param + '),
	(select COUNT(*) from ' + @paramTable + ' b where ' + @param + ' is null) 
	from ' + @paramTable + '';
                            END;
                        ELSE
                            BEGIN
	--DECLARE @sqlgroup NVARCHAR(MAX)= '';
                                SET @sql = 'insert into BatchLoad(时间,表名,字段名,汉字说明,数值种类,总记录数,非NULL数量,整体占比,有效占比,平均值,标准差,NULL值数量) 
select DATEPART(year,' + @paramdate + '),''' + @paramTable + ''',''' + @param
                                    + ''',
''' + @paramhan + ''',
count(distinct ' + @param + '),
count(*),
COUNT(' + @param + '),
cast((count(distinct ' + @param + ')*1.0/COUNT(*)) as decimal(18,5)),
cast((count(distinct ' + @param + ')*1.0/COUNT(' + @param
                                    + ')) as decimal(18,5)),
     avg(' + @param + '),
     stdev(' + @param + '),
	(select COUNT(*) from ' + @paramTable + ' b where ' + @param + ' is null) 
	from ' + @paramTable + ' group by DATEPART(year,' + @paramdate + ')';
                            END;
                        EXEC(@sql);
                        PRINT @sql;
                        PRINT '插入成功';

                    END;
                ELSE
                    PRINT '无需插入数据';
            END;

        ELSE --不存在,创建新表
            BEGIN
                BEGIN
                    PRINT '创建表';
                    CREATE TABLE BatchLoad
                        (
                          id INT IDENTITY(1, 1)
                                 NOT NULL ,
                          时间 NVARCHAR(4) ,
                          表名 NVARCHAR(20) ,
                          字段名 NVARCHAR(20) ,
                          汉字说明 NVARCHAR(20) ,
                          数值种类 INT ,
                          总记录数 INT ,
                          非NULL数量 INT ,
                          整体占比 DECIMAL(18, 4) ,
                          有效占比 DECIMAL(18, 4) ,
                          平均值 DECIMAL(18, 4) ,
                          标准差 DECIMAL(18, 4) ,
                          NULL值数量 INT
                        );
                END;
                BEGIN --执行插入
                    DECLARE @sql1 NVARCHAR(MAX)= '';

                    PRINT '插入数据1';
                    IF ( @paramdate IS NULL
                         OR @paramdate = ''
                       )
                        BEGIN
                            SET @sql = 'insert into BatchLoad(表名,字段名,汉字说明,数值种类,总记录数,非NULL数量,整体占比,有效占比,平均值,标准差,NULL值数量) 
select ' + @paramTable + ''',''' + @param + ''',
''' + @paramhan + ''',
count(distinct ' + @param + '),
count(*),
COUNT(' + @param + '),
cast((count(distinct ' + @param + ')*1.0/COUNT(*)) as decimal(18,5)),
cast((count(distinct ' + @param + ')*1.0/COUNT(' + @param
                                + ')) as decimal(18,5)),
     avg(' + @param + '),
     stdev(' + @param + '),
	(select COUNT(*) from ' + @paramTable + ' b where ' + @param + ' is null) 
	from ' + @paramTable + '';
                        END;
                    ELSE
                        BEGIN
	--DECLARE @sqlgroup NVARCHAR(MAX)= '';
                            SET @sql = 'insert into BatchLoad(时间,表名,字段名,汉字说明,数值种类,总记录数,非NULL数量,整体占比,有效占比,平均值,标准差,NULL值数量) 
select DATEPART(year,' + @paramdate + '),''' + @paramTable + ''',''' + @param
                                + ''',
''' + @paramhan + ''',
count(distinct ' + @param + '),
count(*),
COUNT(' + @param + '),
cast((count(distinct ' + @param + ')*1.0/COUNT(*)) as decimal(18,5)),
cast((count(distinct ' + @param + ')*1.0/COUNT(' + @param
                                + ')) as decimal(18,5)),
     avg(' + @param + '),
     stdev(' + @param + '),
	(select COUNT(*) from ' + @paramTable + ' b where ' + @param + ' is null) 
	from ' + @paramTable + ' group by DATEPART(year,' + @paramdate + ')';
                        END;
                    EXEC(@sql1);
                    PRINT @sql1;
                    PRINT '插入成功';
                END;

            END;
    END;
-- exec [BatchLoad_data] 'NHJGHL'

--select * from BatchLoad order by 时间,表名,有效占比 desc
--alter table BatchLoad add  时间 nvarchar(4)
--delete from BatchLoad where 表名='Bs_PigmentlSp514'
--DROP TABLE BatchLoad
go

