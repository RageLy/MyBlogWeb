

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Bs_Delete_EntityTable]
    @ID VARCHAR(50) = '', --颜料ID  
    @EmpID VARCHAR(50) = '1',
    @SpName NVARCHAR(50)
AS
BEGIN
    DECLARE @Sptype NVARCHAR(50) = '';
    DECLARE @sql NVARCHAR(200) = '';

    SET @Sptype = (CASE
                       WHEN @SpName = 'PigmentBK' THEN
                           'Bs_PigmentBK'
                       WHEN @SpName = 'PigmentW' THEN
                           'Bs_PigmentW'
                       WHEN @SpName = 'ParticalBK' THEN
                           'Bs_ParticalBK'
                       WHEN @SpName = 'ParticalW' THEN
                           'Bs_ParticalW'
                       WHEN @SpName = 'Oil' THEN
                           'Bs_Oil'
                       WHEN @SpName = 'SinCapsule' THEN
                           'Bs_SinCapsule'
                       WHEN @SpName = 'DouCapsule' THEN
                           'Bs_DouCapsule'
                       WHEN @SpName = 'CapsuleDynamic' THEN
                           'Bs_CapsuleDynamic'
                       WHEN @SpName = 'CoatingMs' THEN
                           'Bs_Coating_Ms'
                       WHEN @SpName = 'CoatingNew' THEN
                           'Bs_Coating'
                       WHEN @SpName = 'CoatingZJ' THEN
                           'Bs_Coating_ZJ'
                   END
                  );
    IF (@ID <> '')
    BEGIN

        SET @sql = 'DELETE FROM ' + @Sptype + '
        WHERE [ID] = ' + @ID;

        EXEC (@sql);
        INSERT INTO Tbl_Log_AnaUseLog
        (
            EmpID,
			EmpName,
            freshTime,
            spName,
            AnaName,
            siftvalue,
            OherParemeter
        )
        VALUES
        (@EmpID,
		(
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
         GETDATE(),
         'Sp_Bs_Delete_EntityTable',
         '删除'+@Sptype+'数据',
         'DELETE',
         'ID =' + @ID
        );

        SELECT '0';
    END;
    ELSE
    BEGIN
        SELECT '请选择一条记录进行删除';
        RETURN;
    END;
END;


go

