-- =============================================      
-- Description: <获取角色新增编辑页面加载>    
-- =============================================    
CREATE PROCEDURE [dbo].[Sp_Sys_RoleEditLoad]     
 @RoleID varchar(500)='-1'  
AS    
BEGIN    
 SET NOCOUNT ON;    
  
   select RoleID  
       ,RoleName  
       ,QueryRange  
       ,CanSeePhone  
       ,RoleDesc     
   from Tbl_Sys_Role where RoleID = @RoleID  
  
END
go

