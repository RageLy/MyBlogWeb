
 --==================================
 -- 功能: 获取区间内的任意一个随机数值
 -- 说明: 具体实现阐述 
 -- 作者: XXX
 -- 创建: yyyy-MM-dd
 -- 修改: yyyy-MM-dd XXX 修改内容描述
 -- 调用: SELECT dbo.ufn_RandNum(0, 1);
 --==================================
 CREATE FUNCTION dbo.ufn_RandNum
 (
     @intMin INT, -- 随机数值的最小值
     @intMax INT -- 随机数值的最大值
 ) RETURNS decimal(18,4)
     --$Encode$--
 AS
 BEGIN
     SET @intMin = ISNULL(@intMin, 0);
     SET @intMax = ISNULL(@intMax, 0);
  
     DECLARE @guidValue AS UNIQUEIDENTIFIER;
  
     set @guidValue = (select top 1 NewRanID from vw_GetNewID);
     
     RETURN ABS(CHECKSUM(@guidValue)) % (@intMax - @intMin + 1) + @intMin;
 END
 go

