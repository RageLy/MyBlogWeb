-- exec [Sp_InsertParticalBK]
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年5月26日                                                
-- Descript: 从Excel插入粒子制作过程数据
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_InsertParticalBK]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_ParticalBK
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_ParticalBK
                            GROUP BY 粒子编号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_ParticalBK
                           );
        /**  插入粒子系列**/
        PRINT '开始插入Tbl_Base_ParticalSeries数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_ParticalSeries (   Series ,
                                                    Ptype
                                                )
                    SELECT DISTINCT [粒子系列] ,
                           ( CASE WHEN [粒子系列] LIKE '%BK%' THEN '黑色粒子'
                                  WHEN [粒子系列] LIKE '%W%' THEN '白色粒子'
                             END
                           ) type
                    FROM   TempTb_ParticalBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_ParticalSeries
                                          WHERE  [粒子系列] = Series
                                      )
                           AND [粒子系列] IS NOT NULL;
        PRINT '表Tbl_Base_ParticalSeries数据插入完毕，继续下一步';


        /**插入粒子反应釜**/
        PRINT '开始插入Tbl_Base_ParticalKettle数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_ParticalKettle ( Name )
                    SELECT DISTINCT [粒子反应釜]
                    FROM   TempTb_ParticalBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_ParticalKettle
                                          WHERE  [粒子反应釜] = Name
                                      )
                           AND [粒子反应釜] IS NOT NULL;
        PRINT '表Tbl_Base_ParticalKettle数据插入完毕，继续下一步';



        /**插入反应BA0001批号**/
        PRINT '开始插入Tbl_Base_ParticalBA0001数据，继续下一步';
        DELETE FROM dbo.TempTb_ParticalBK_BA0001
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_ParticalBK_BA0001
                            GROUP BY BA0001批号
                        );
        INSERT INTO dbo.Tbl_Base_BA0001 (   BA0001 ,
                                            Factory ,
                                            Purity ,
                                            Water,
											RKDate

                                        )
                    SELECT DISTINCT BA0001批号 ,
                           BA0001厂家 ,
                           BA0001纯度 ,
                           BA0001水分含量,
						   入库日期
                    FROM   dbo.TempTb_ParticalBK_BA0001
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BA0001
                                          WHERE  BA0001批号 = BA0001
                                      )
                           AND BA0001批号 IS NOT NULL;
        PRINT '表Tbl_Base_ParticalBA0001数据插入完毕，继续下一步';

        /**插入反应BA0002批号**/
        DELETE FROM dbo.TempTb_ParticalBK_BA0002
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_ParticalBK_BA0002
                            GROUP BY BA0002批号
                        );
        INSERT INTO dbo.Tbl_Base_BA0002 (   BA0002 ,
                                            Purity ,
                                            Water,RKDate
                                        )
                    SELECT DISTINCT BA0002批号 ,
                           BA0002纯度 ,
                           BA0002水分含量,入库日期
                    FROM   dbo.TempTb_ParticalBK_BA0002
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BA0002
                                          WHERE  BA0002批号 = BA0002
                                      )
                           AND BA0002批号 IS NOT NULL;

        /**插入反应BC0001批号**/
        DELETE FROM dbo.TempTb_ParticalBK_BC0001
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_ParticalBK_BC0001
                            GROUP BY BC0001批号
                        );
        INSERT INTO dbo.Tbl_Base_BC0001 (   BC0001 ,
                                            Density ,
                                            Tension ,
                                            Refractivity,RKDate,BigBC0001
                                        )
                    SELECT DISTINCT BC0001批号 ,
                           BC0001密度 ,
                           BC0001表面张力 ,
                           BC0001折射率,入库日期,BC0001大批号
                    FROM   dbo.TempTb_ParticalBK_BC0001
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BC0001
                                          WHERE  BC0001批号 = BC0001
                                      )
                           AND BC0001批号 IS NOT NULL;

        /**插入反应BG0001批号**/
        INSERT INTO dbo.Tbl_Base_BG0001 ( BG0001 )
                    SELECT DISTINCT BG0001批号
                    FROM   dbo.TempTb_ParticalBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BG0001
                                          WHERE  BG0001批号 = BG0001
                                      )
                           AND BG0001批号 IS NOT NULL;

        /**插入反应BE0001批号**/
        PRINT '开始插入Tbl_Base_ParticalBE0001数据，继续下一步';
        DELETE FROM dbo.TempTb_ParticalBK_BE0001
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_ParticalBK_BE0001
                            GROUP BY [BE0001批号]
                        );
        INSERT INTO dbo.Tbl_Base_ParticalBE0001 (   BE0001 ,
                                                    Factory ,
                                                    Purity ,
                                                    Water,RKDate
                                                )
                    SELECT DISTINCT BE0001批号 ,
                           BE0001厂家 ,
                           BE0001纯度 ,
                           BE0001水分,入库日期
                    FROM   TempTb_ParticalBK_BE0001
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_ParticalBE0001
                                          WHERE  [BE0001批号] = BE0001
                                      )
                           AND BE0001批号 IS NOT NULL;
        PRINT '表Tbl_Base_ParticalBE0001数据插入完毕，继续下一步';
        INSERT INTO dbo.Tbl_Base_BC0001_Big ( BC0001 )
                    SELECT DISTINCT [BC0001大批号]
                    FROM   TempTb_ParticalBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BC0001_Big
                                          WHERE  [BC0001大批号] = BC0001
                                      )
                           AND [BC0001大批号] IS NOT NULL;
        /**插入粒子分散液正负极颜色**/
        PRINT '开始插入Tbl_Base_ParticalPole数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_ParticalPole (   Ppole ,
                                                  Npole
                                              )
                    SELECT DISTINCT [粒子分散液正极颜色] ,
                           [粒子分散液负极颜色]
                    FROM   TempTb_ParticalBK
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_ParticalPole
                                          WHERE  [粒子分散液正极颜色] = Ppole
                                                 AND [粒子分散液负极颜色] = Npole
                                      )
                           AND 粒子分散液正极颜色 IS NOT NULL
                           AND 粒子分散液负极颜色 IS NOT NULL;
        PRINT '表Tbl_Base_ParticalPole数据插入完毕，继续下一步';

        /**插入粒子制作过程数据*/
        PRINT '开始插入Bs_ParticalBK数据，继续下一步';
        UPDATE dbo.Tbl_Base_BA0001
        SET    Factory = BA0001厂家 ,
               Purity = BA0001纯度 ,
               Water = BA0001水分含量,
			   RKDate=入库日期
        FROM   dbo.TempTb_ParticalBK_BA0001
        WHERE  BA0001 = BA0001批号;
        UPDATE dbo.Tbl_Base_BA0002
        SET    BA0002 = BA0002批号 ,
               Purity = BA0002纯度 ,
               Water = BA0002水分含量,
			   RKDate=入库日期
        FROM   dbo.TempTb_ParticalBK_BA0002
        WHERE  BA0002 = BA0002批号;
        UPDATE dbo.Tbl_Base_ParticalBE0001
        SET    Factory = BE0001厂家 ,
               Purity = BE0001纯度 ,
               Water = BE0001水分,
			   RKDate=入库日期
        FROM   dbo.TempTb_ParticalBK_BE0001
        WHERE  BE0001 = BE0001批号;
        UPDATE dbo.Tbl_Base_BC0001
        SET    Density = BC0001密度 ,
               Tension = BC0001表面张力 ,
               Refractivity = BC0001折射率,
			   RKDate=入库日期,
			   BigBC0001=BC0001大批号
			  
        FROM   dbo.TempTb_ParticalBK_BC0001
        WHERE  BC0001 = BC0001批号;

        UPDATE Bs_ParticalBK
        SET    OptDate = [粒子制备时间] ,
		PigmentBKCode=Bs_PigmentBK.Code,
               Series = Tbl_Base_ParticalSeries.ID ,
               Kettle = Tbl_Base_ParticalKettle.ID ,
               FBA0001 = FBA0001BK.ID ,
               CleanBA0001 = CleanBA0001BK.ID ,
               CleanBA0002 = CleanBA0002BK.ID ,
               BE0001 = Tbl_Base_ParticalBE0001.ID ,
               BG0001 = BG0001BK.ID ,
               CleanBC0001 = CleanBC0001BK.ID ,
               ConfigBC0001 = ConfigBC0001BK.ID ,
               BC0001Big = BC0001_BigBK.ID ,
               TOutput = [理论产值] ,
               FOutput = [实际产值] ,
               PigmentID = Bs_PigmentBK.ID ,
               Viscosity = [粒子粘度] ,
               Zeta = ABS([粒子Zeta电位值]) ,
               Organic = [有机物含量] ,
               PSize05 = [粒子粒径05] ,
               PSize09 = [粒子粒径09] ,
               Ppole = z.ID ,
               Npole = f.ID ,
               ReactivityTemp = 反应区环境温度 ,
               ReactivityWet = 反应区环境湿度 ,
               ParticalBKRank = 粒子等级 ,
               Remark = [备注] ,
               update_time = GETDATE()
        FROM   [dbo].TempTb_ParticalBK
               LEFT JOIN Tbl_Base_ParticalSeries ON Tbl_Base_ParticalSeries.Series = [粒子系列]
               LEFT JOIN Tbl_Base_ParticalKettle ON Tbl_Base_ParticalKettle.Name = [粒子反应釜]
               LEFT JOIN Tbl_Base_BA0001 FBA0001BK ON FBA0001BK.BA0001 = [反应BA0001批号]
               LEFT JOIN Tbl_Base_BA0001 CleanBA0001BK ON CleanBA0001BK.BA0001 = 清洗BA0001批号
               LEFT JOIN Tbl_Base_BA0002 CleanBA0002BK ON CleanBA0002BK.BA0002 = 清洗BA0002批号
               LEFT JOIN Tbl_Base_ParticalBE0001 ON Tbl_Base_ParticalBE0001.BE0001 = [BE0001批号]
               LEFT JOIN Tbl_Base_BC0001 CleanBC0001BK ON CleanBC0001BK.BC0001 = [清洗BC0001批号]
               LEFT JOIN Tbl_Base_BC0001 ConfigBC0001BK ON ConfigBC0001BK.BC0001 = [配制BC0001批号]
               LEFT JOIN Tbl_Base_BG0001 BG0001BK ON BG0001BK.BG0001 = BG0001批号
               LEFT JOIN dbo.Tbl_Base_BC0001_Big BC0001_BigBK ON BC0001_BigBK.BC0001 = BC0001大批号
               LEFT JOIN Tbl_Base_ParticalPole z ON z.Ppole = [粒子分散液正极颜色]
               LEFT JOIN Tbl_Base_ParticalPole f ON f.Npole = [粒子分散液负极颜色]
               LEFT JOIN Bs_PigmentBK ON Bs_PigmentBK.Code = TempTb_ParticalBK.颜料编号
        WHERE  Bs_ParticalBK.Code = 颜料编号;

        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_ParticalBK
                                            INNER JOIN dbo.TempTb_ParticalBK ON TempTb_ParticalBK.粒子编号 = Bs_ParticalBK.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;
        INSERT INTO dbo.Bs_ParticalBK (   OptDate ,
                                          Code ,
										  PigmentBKCode,
                                          Series ,
                                          Kettle ,
                                          FBA0001 ,
                                          CleanBA0001 ,
                                          CleanBA0002 ,
                                          BE0001 ,
                                          BG0001 ,
                                          CleanBC0001 ,
                                          ConfigBC0001 ,
                                          BC0001Big ,
                                          TOutput ,
                                          FOutput ,
                                          PigmentID ,
                                          Viscosity ,
                                          Zeta ,
                                          Organic ,
                                          PSize05 ,
                                          PSize09 ,
                                          Ppole ,
                                          Npole ,
                                          ReactivityTemp ,
                                          ReactivityWet ,
                                          ParticalBKRank ,
                                          Remark ,
                                          update_time
                                      )
                    SELECT [粒子制备时间] ,
                           [粒子编号] ,
						   Bs_PigmentBK.Code,
                           Tbl_Base_ParticalSeries.ID ,
                           Tbl_Base_ParticalKettle.ID ,
                           FBA0001BK.ID ,
                           CleanBA0001BK.ID ,
                           CleanBA0002BK.ID ,
                           Tbl_Base_ParticalBE0001.ID ,
                           BG0001BK.ID ,
                           CleanBC0001BK.ID ,
                           ConfigBC0001BK.ID ,
                           BC0001_BigBK.ID ,
                           [理论产值] ,
                           [实际产值] ,
                           Bs_PigmentBK.ID ,
                           [粒子粘度] ,
                           ABS([粒子Zeta电位值]) ,
                           [有机物含量] ,
                           [粒子粒径05] ,
                           [粒子粒径09] ,
                           z.ID 正极 ,
                           f.ID 负极 ,
                           反应区环境温度 ,
                           反应区环境湿度 ,
                           粒子等级 ,
                           [备注] ,
                           GETDATE() 更新时间
                    FROM   [dbo].TempTb_ParticalBK
                           LEFT JOIN Tbl_Base_ParticalSeries ON Tbl_Base_ParticalSeries.Series = [粒子系列]
                           LEFT JOIN Tbl_Base_ParticalKettle ON Tbl_Base_ParticalKettle.Name = [粒子反应釜]
                           LEFT JOIN Tbl_Base_BA0001 FBA0001BK ON FBA0001BK.BA0001 = [反应BA0001批号]
                           LEFT JOIN Tbl_Base_BA0001 CleanBA0001BK ON CleanBA0001BK.BA0001 = 清洗BA0001批号
                           LEFT JOIN Tbl_Base_BA0002 CleanBA0002BK ON CleanBA0002BK.BA0002 = 清洗BA0002批号
                           LEFT JOIN Tbl_Base_ParticalBE0001 ON Tbl_Base_ParticalBE0001.BE0001 = [BE0001批号]
                           LEFT JOIN Tbl_Base_BC0001 CleanBC0001BK ON CleanBC0001BK.BC0001 = [清洗BC0001批号]
                           LEFT JOIN Tbl_Base_BC0001 ConfigBC0001BK ON ConfigBC0001BK.BC0001 = [配制BC0001批号]
                           LEFT JOIN Tbl_Base_BG0001 BG0001BK ON BG0001BK.BG0001 = BG0001批号
                           LEFT JOIN dbo.Tbl_Base_BC0001_Big BC0001_BigBK ON BC0001_BigBK.BC0001 = BC0001大批号
                           LEFT JOIN Tbl_Base_ParticalPole z ON z.Ppole = [粒子分散液正极颜色]
                           LEFT JOIN Tbl_Base_ParticalPole f ON f.Npole = [粒子分散液负极颜色]
                           LEFT JOIN Bs_PigmentBK ON Bs_PigmentBK.Code = TempTb_ParticalBK.颜料编号
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_ParticalBK
                                          WHERE  Code = [粒子编号]
                                      )
                           AND [粒子编号] IS NOT NULL;

        PRINT '表Bs_ParticalBK数据插入完毕，继续下一步';
        PRINT '所有过程完成';
    END;
go

