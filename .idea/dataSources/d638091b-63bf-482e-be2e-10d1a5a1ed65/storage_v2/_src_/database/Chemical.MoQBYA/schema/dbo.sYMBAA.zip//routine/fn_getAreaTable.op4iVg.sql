
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE FUNCTION [dbo].[fn_getAreaTable]
(	
	-- Add the parameters for the function here
	@BeginValue DECIMAL(18,4), 
	@EndValue DECIMAL(18,4),
	@Count DECIMAL(18,4)
)
RETURNS @Result TABLE(ID INT ,Name VARCHAR(MAX),Beginvalue FLOAT,Endvalue FLOAT)
AS
BEGIN
	-- Add the SELECT statement with parameter references here
	DECLARE @Scan decimal(18,4) = ( @EndValue - @BeginValue ) / @Count;
	
	INSERT INTO @Result
	SELECT id
	,
	CASE WHEN @BeginValue + @Scan * id = 0 THEN '0' ELSE
	'( ' + CAST( CAST(@BeginValue + @Scan * (id - 1)AS FLOAT) AS VARCHAR(max)) + ' , ' + CAST( CAST(@BeginValue + @Scan * id AS FLOAT) AS VARCHAR(max)) + ' ]' END
	,@BeginValue + @Scan * (id - 1),@BeginValue + @Scan * id FROM dbo.Tbl_Base_Num
	WHERE id <= @Count
	
	RETURN;
END
go

