







-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 降维sp
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_JW_test]
  @condition VARCHAR(MAX)='DimDouKzWd:-1165|-2380|237%DimDouYX:-1%DimDouLW:-1%DimDouFu:-1%DimDouTemp41:-1%DimDouSpeed500:-1%DimDouSpeed400:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDDLps:-1%DimOilViscosity:-1%DimYXLJ05:-1%DimYXLJ09:-1'
 ,@OtherCond VARCHAR(MAX) ='%温度8%无选项%L白%列表%相关性%undefined%undefined'
 ,@Type VARCHAR(10) = '图' -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
 ,@OrderFields VARCHAR(50) = 'id'
 ,@SpName VARCHAR(50) = 'DouCapsule'
 ,@TB int = 2 -- 表格位置
 ,@EmpID INT = 1

 -- 以下参数只在出明细时使用
 ,@PageIndex VARCHAR(5)='1'
 ,@PageSize VARCHAR(5)='10'
 ,@XValue VARCHAR(50) = ''
 ,@DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
BEGIN

---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue=REPLACE(@condition,'|',',');

    DECLARE @Usertitle VARCHAR(50) = ''          -- 标题            
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''               -- @OtherCond  传入的Y轴名称                
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
    DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                

    DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式                  

    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)            
	 )            
  
    INSERT INTO @OtherCondTbl
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')

     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)

     --select * from @OtherCondTbl
     -- OtherCond解析完毕            
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       
    

	-- 时间表 时间临时表必然需要
    CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME            
    )
	
	-- 如果有其它需要用 #时间表的必须在这里添加
	
    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500);      -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500);     -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句            
	DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	
    set @XOrder = ',1 as X排序';
    set @DsOrder = ',1 as G排序';

	-- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable]
     @SiftValue = @SiftValue
	,@XName = @XName
	,@DsName = @DsName;

     --from 源表
     DECLARE @FromSql VARCHAR(max) = (SELECT JoinTables FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName);
     IF(@FromSql IS NULL OR @FromSql = '')
     BEGIN
		SELECT 'sp配置有问题';
		RETURN;
     END
     
    -- 拼接创建维度临时表的语句
     SET @sql += ( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );
		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
     
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;
     -- 解析维度
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';
    
    -- 创建 where维度
    DECLARE @whereWD VARCHAR(MAX) = '';  ---提取控制维度名
    SET @whereWD = ( SELECT ' inner JOIN #' +  DimName + ' AS ' + DimName + ' on ' + 
		CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
		ELSE DimName + '.ID = ' + DimYsql END
		FROM #Dims WHERE Isneed <> 'ND' and DimYsql <> '' FOR XML PATH(''));
		
    SET @whereWD = REPLACE(REPLACE(@whereWD,'&lt;','<'),'&gt;','>')
    
	 -- 创建 控制维度筛选项维度
	 DECLARE @KZWD VARCHAR(MAX) = ''; 
	 DECLARE @KZWDName VARCHAR(MAX) = '';
	 set @KZWDName=(select dimname from #Dims where DimYsql='')
	 set @KZWD=(select dimvalues from #Dims where DimYsql='' and dimname=@KZWDName)

    --拼select 列名（主表ID+控制维度列）
    CREATE TABLE #DimsTb
	  (
		DimName varchar(50)
		,ChName varchar(50)
		,DimYsql varchar(50)
		,Stp varchar(50)
	  );
	  insert into #DimsTb (DimName,ChName,DimYsql,Stp)
	  select DimName,ChName,DimYsql,'1' from #Dims
	  where Isneed <> 'ND' and DimYsql <> ''
	  
	  DECLARE @KZWDDimsTb VARCHAR(MAX) = '';
	 set @KZWDDimsTb =(select  '
	 insert into #DimsTb (DimName,ChName,DimYsql,Stp)
	 select  dimname,Name,AtYSql,istrue 
	 from VW_'+@KZWDName+'_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in ('+@KZWD+')
	  ')
	  exec( @KZWDDimsTb)

    --拼控制维度inner join
    DECLARE @KZWDinner VARCHAR(MAX) = '';
	 set @KZWDinner =(select ' left join vw_'+DimName+'_Part as '+DimName+'part on '+
	 DimName+'part.istrue='+stp+' and '+Dimysql+'>='+DimName+'part'+'.beginvalue and '+Dimysql+'<'+DimName+'part'+'.endvalue '
	  from #DimsTb where stp<>1 FOR XML PATH(''))

    SET @KZWDinner = REPLACE(REPLACE(@KZWDinner,'&lt;','<'),'&gt;','>');

    --拼接控制维度与where维度列
    DECLARE @KZNamewh VARCHAR(MAX) = '';
    set @KZNamewh=(select case when Stp<>1 then ','+DimName+'part.name' +' as '+DimName end
    from #DimsTb FOR XML PATH(''))
    
    --Y 列
    DECLARE @YSQL VARCHAR(100);
	DECLARE @Ycolumn VARCHAR(50) = ISNULL( (SELECT DimYsql FROM #Dims WHERE ChName = @YName ),'');  -- Y轴在本表上面的列名
	SET @YSQL = ',' + @Ycolumn + ' AS ' + replace(@Ycolumn,'.','');
	
	set @InnerSelect=(select 'select '+@SpName+'.ID'+@KZNamewh+@YSQL+' from' )


    -----------------------------------------------降维计算---------------------------------------------------
    DECLARE @Resultdata VARCHAR(max);
    DECLARE @ResultName VARCHAR(max);
    set @ResultName=(select ','+dimname+' varchar(100)' from #DimsTb where Stp<>1 FOR XML PATH(''))

    set @Resultdata=(select 'CREATE TABLE #Resultdata
	   (ID int
		'
		+ @ResultName +','+
		REPLACE(@Ycolumn,'.','')+' decimal(18, 6)
		)'
		)
		
	--数据插入临时表#Resultdata
	DECLARE @Resultzj VARCHAR(max);
	set @Resultzj=(@sql+@Resultdata+' insert into  #Resultdata '+@InnerSelect+@FromSql+@whereWD+@KZWDinner)
	
    --提取验证数据
    DECLARE @Resultyz VARCHAR(max);
    DECLARE @InnerSelectyz VARCHAR(max);
    DECLARE @KZNamewhyz VARCHAR(MAX) = '';
    set @KZNamewhyz=(select case when Stp<>1 then ','+DimYsql+' as '+REPLACE(DimYsql,'.','') end
    from #DimsTb FOR XML PATH(''));
    
    DECLARE @ResultNameyz VARCHAR(max);
    set @ResultNameyz=(select ','+dimname+'yz decimal(18, 6)' from #DimsTb where Stp<>1 FOR XML PATH(''))
    
    DECLARE @Resultdatayz VARCHAR(max);
    set @Resultdatayz=(select 'CREATE TABLE #Resultdatayz
	   (ID int
		'
		+ @ResultNameyz +','+
		REPLACE(@Ycolumn,'.','')+' decimal(18, 6)
		)'
		);
		
    set @InnerSelectyz=(select 'select '+@SpName+'.ID'+@KZNamewhyz+@YSQL+' from' )
	set @Resultyz=(@sql+@Resultdatayz+' insert into  #Resultdatayz '+@InnerSelectyz+@FromSql+@whereWD)
    
    --print @Resultyz
    --print '@Resultyz'
------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
	-- 建立结果表
    DECLARE @CreateTable VARCHAR(max);
    set @CreateTable=(select ' CREATE TABLE #Result1
	   (spName varchar(50),
		DataCount int,
		MaxY Decimal(18,6),
		MinY Decimal(18,6),
		AVGY Decimal(18,6),
		SQtY Decimal(18,6),
		Siftvalue varchar(Max),
		PearSenR DECIMAL(18,6),
		Slope DECIMAL(18,6),
		LineCons DECIMAL(18,6),
		ChangePoint int ,
		Trend Varchar(Max)
		'
		+ @ResultName +
		')'
		)
	
	--取Y轴列
	DECLARE @Ycolumnjs VARCHAR(50) = ISNULL( (SELECT REPLACE(dimysql,'.','') FROM #Dims WHERE ChName = @YName ),'')
	DECLARE @ResultDataSql VARCHAR(500);
	SET @ResultDataSql = '''' + @SpName + ''',SUM(CASE WHEN ' + @Ycolumnjs + ' is not null THEN 1 ELSE 0 END ),MAX(' + @Ycolumnjs + '),MIN(' + @Ycolumnjs + '),AVG(' + @Ycolumnjs + '),stdev(' + @Ycolumnjs + '),'

    DECLARE @GroupBy VARCHAR(500);
    set @GroupBy=(select case when Stp<>1 then ','+DimName end from #DimsTb FOR XML PATH(''))
    set @GroupBy=(select substring(@GroupBy,2,LEN(@GroupBy)-1))
    
    DECLARE @Result1 VARCHAR(max);
    set @Result1=(@Resultzj+@CreateTable+ 'INSERT INTO #Result1 '  + ' SELECT ' + @ResultDataSql +'NULL,NULL,NULL,NULL,NULL,NULL,' + @GroupBy + ' FROM #Resultdata Group by ' + @GroupBy)

    --设置Y轴比较分档
    --极差分档
    DECLARE @jd DECIMAL(18,4)
    DECLARE @jcmin DECIMAL(18,4)
    DECLARE @jcmax DECIMAL(18,4)
    DECLARE @jcn DECIMAL(18,4)
    DECLARE @bzcmin DECIMAL(18,4)
    DECLARE @bzcmax DECIMAL(18,4)
    DECLARE @bzcn DECIMAL(18,4)

    set @jd=(select NumDecimal from #Dims dp
        inner join Tbl_AnsCom_DIimToTable tnd
        on dp.DimName=tnd.DimNum and dp.ChName=@YName)

    set @jcmin=(0-10*@jd)
    set @jcmax=(5*10*@jd)
    set @jcn=6.0000
    set @bzcmin=@jcmin
    set @bzcmax=@jcmax
    set @bzcn=12.0000

    --置信度计算
    DECLARE @zxd VARCHAR(max);
    set @zxd=' SELECT COUNT(*) AS zcount,COUNT(CASE WHEN datacount > 1 THEN 1 END) AS yxzcount,CAST(CAST(COUNT(CASE WHEN datacount > 1 THEN 1 END) AS DECIMAL(18,4)) / COUNT(*) * 100 as DECIMAL(18,2)) AS zlv
                ,SUM(datacount) AS sccount,SUM(CASE WHEN datacount > 1 THEN datacount END) AS yxsccount,cast(CAST(SUM(CASE WHEN datacount > 1 THEN datacount END) AS DECIMAL(18,4)) / SUM(datacount) * 100 as DECIMAL(18,2)) AS sclv
                FROM #Result1
                WHERE datacount IS NOT null '

    --极差计算
    DECLARE @jc VARCHAR(max);
    set @jc=' ;WITH CTE AS (
	                select ID,Name ,ncount AS zcount
	                ,cast(CAST(ncount AS DECIMAL(18,4)) / (SUM(ncount) OVER() ) * 100 as DECIMAL(18,2)) AS zlv
	                ,Sumn AS sccount
	                ,cast(CAST(Sumn AS DECIMAL(18,4)) / (SUM(Sumn) OVER() ) * 100 as DECIMAL(18,2)) AS sclv
	                FROM
	                    (
		                SELECT isnull(b.ID,100) id,isnull(b.Name,''其他'') Name,COUNT(*) AS ncount,SUM(datacount) AS Sumn
		                FROM #Result1 a
		                LEFT JOIN fn_getAreaTable('+cast(@jcmin as varchar(50))+','+cast(@jcmax as varchar(50))+','+cast(@jcn as varchar(50))+') b ON a.MaxY - a.MInY > b.beginvalue  AND a.MaxY - a.MInY <= b.endvalue 
		                WHERE datacount > 1 GROUP BY b.ID,b.NAME,b.beginvalue
	                        ) x
                            )
                    SELECT b.id,b.name,b.zcount,b.zlv,b.sccount,b.sclv
                    ,(SELECT SUM(zlv) FROM CTE a WHERE a.ID <= b.ID ) AS ljzlv
                    ,(SELECT SUM(sclv) FROM CTE a WHERE a.ID <= b.ID ) AS ljsclv
                    FROM CTE b order by b.id'
    --标准差计算
    DECLARE @bzc VARCHAR(max);
    set @bzc=' ;WITH CTE AS (
	            select ID,Name ,ncount AS zcount
	            ,cast(CAST(ncount AS DECIMAL(18,4)) / (SUM(ncount) OVER() ) * 100 as DECIMAL(18,2)) AS zlv
	            ,Sumn AS sccount
	            ,cast(CAST(Sumn AS DECIMAL(18,4)) / (SUM(Sumn) OVER() ) * 100 as DECIMAL(18,2)) AS sclv
	            FROM
	            (
		            SELECT isnull(b.ID,100) id,isnull(b.Name,''其他'') Name,COUNT(*) AS ncount,SUM(datacount) AS Sumn
		            FROM #Result1 a
		            LEFT JOIN fn_getAreaTable('+cast(@bzcmin as varchar(max))+','+cast(@bzcmax as varchar(max))+','+cast(@bzcn as varchar(max))+') b ON a.SqtY > b.beginvalue AND a.SqtY <= b.endvalue
		            WHERE datacount > 1 GROUP BY b.ID,b.NAME,b.beginvalue
	            ) x
                )
                SELECT b.id,b.name,b.zcount,b.zlv,b.sccount,b.sclv
                ,(SELECT SUM(zlv) FROM CTE a WHERE a.ID <= b.ID ) AS ljzlv
                ,(SELECT SUM(sclv) FROM CTE a WHERE a.ID <= b.ID ) AS ljsclv
                FROM CTE b order by b.id'
   
   --主副因素验证
   --维度控制区间
       DECLARE @CKON VARCHAR(max);
        set @CKON=(
        select ' AND ABS(a.' + Dims +' - '+ 'b.' + Dims + ')<=' + cast(bs as varchar(50)) from (
        select DimName+'yz' Dims,
        case when Stp=0 then tnd.NumDecimal
        when  Stp=2 then 2*tnd.NumDecimal 
        when  Stp=3 then 5*tnd.NumDecimal 
        when  Stp=4 then 10*tnd.NumDecimal end as bs
        from #DimsTb dp
        inner join Tbl_AnsCom_DIimToTable tnd
        on dp.DimName=tnd.DimNum
        where Stp<>1
        ) aa FOR XML PATH(''));
    set @CKON=REPLACE(@CKON,'&lt;','<');

   DECLARE @CK VARCHAR(max);
   DECLARE @CKYsql VARCHAR(max); 
   set @CKYsql=ISNULL( (SELECT replace(dimysql,'.','') FROM #Dims WHERE ChName = @YName ),'')

   --数据源不能为null
    DECLARE @notnull VARCHAR(max);
    set @notnull=(select ' and '+DimName+'yz is not null' from #DimsTb where Stp<>1 FOR XML PATH(''))

   set @CK=' ;WITH CTEs AS
	            (
		        SELECT * FROM  #Resultdatayz WHERE ' + @CKYsql + ' IS NOT null'+@notnull+' 
	            ),
	        CTEs1 AS
	            (
		        select ID,Name ,n ,SUM(n) OVER() AS dbcount
		        ,cast(CAST(n AS DECIMAL(18,4)) / (SUM(n) OVER() ) * 100 as DECIMAL(18,2)) AS lv
		        FROM
		        ( 
			        SELECT isnull(b.ID,100) id,isnull(b.Name,''其他'') Name,COUNT(*) AS n FROM 
			        (
				        SELECT ABS(a.' +@CKYsql + ' - ' + 'b.' + @CKYsql +') AS cha FROM CTEs a
				        INNER JOIN CTEs B
				        ON a.ID > b.ID '+@CKON+'  
			        ) x LEFT JOIN fn_getAreaTable('+cast(@jcmin as varchar(50))+','+cast(@jcmax as varchar(50))+','+cast(@jcn as varchar(50))+') b ON x.cha > b.beginvalue AND x.cha <= b.endvalue
			        GROUP BY b.ID,b.Name
		            ) xx
	            )
	        SELECT b.id,b.name,b.n,b.dbcount,b.lv
	        ,(SELECT SUM(lv) FROM CTEs1 a WHERE a.ID <= b.ID ) AS ljlv
	        FROM CTEs1 b
	        ORDER BY b.ID'

       
  
    IF(@TB = 1)
    BEGIN
    exec(@Result1+@zxd)
    END;
    
    IF(@TB = 2)
    BEGIN
    PRINT(@Result1+@jc)
    END;
    
    IF(@TB = 3)
    BEGIN
    exec(@Result1+@bzc)
    END;
    
    IF(@TB = 4)
    BEGIN
    exec(@Resultyz+@CK)
    END;

END
go

