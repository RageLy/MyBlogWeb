








-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 自动相关性系数与趋势计算sp
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_PearsenRAndTrend_Show]
	@SpName VARCHAR(50) = 'DouCapsule'
	,@condition VARCHAR(max)='DimDouKzWd:-1840|-2280%DimOilSeries:3%DimDouOutputValue:-100%DimDouTemp8:-1%DimDouTemp25:-1%DimDouTemp41:-1%DimDouSpeed400:-1%DimDouSpeed500:-1%DimDouLJ:-1%DimDouJNGHL:-1%DimDouCR:-1%DimDouLW:-1%DimDouLBK:-1%DimDouDeltaBK:-1%DimDouDeltaW:-1%DimDouPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimDouLJspan:-1%DimDouPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimOilDensity:-1%DimOilSTension:-1'
    ,@OtherCond  VARCHAR(max)='%温度8%无选项%L白%列表%拟合分析%undefined%undefined'
    ,@EmpID INT = 1
    ,@PageIndex VARCHAR(5)='1'
    ,@PageSize VARCHAR(5)='30'
AS
BEGIN

	SET NOCOUNT ON;
	DECLARE @SiftValueold VARCHAR(MAX);
    SET @SiftValueold=REPLACE(@condition,'|',',');
    DECLARE @Usertitle VARCHAR(50) = ''          -- 标题            
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''               -- @OtherCond  传入的Y轴名称                
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
    DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                
    DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式        
    
    DECLARE @XDim VARCHAR(50)
	DECLARE @YDim VARCHAR(50)
	DECLARE @IsCountR BIT  -- 是否计算 相关系数R
	DECLARE @IsCountTrend INT =1
	DECLARE @TrendR DECIMAL(18,6) = 0.7
	DECLARE @GetLineR DECIMAL(18,2) = 0.5  -- 计算斜率的R条件
    
	DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)            
	 )            
  
    INSERT INTO @OtherCondTbl
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')
     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)
     
	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,Dimname varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
    --维度拆分表
    CREATE TABLE #DimsLS
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable_LS]
     @SiftValue = @SiftValueold
	,@XName = @XName
	,@DsName = @DsName;
    
    -- 创建 控制维度筛选项维度
	 DECLARE @KZWD VARCHAR(MAX) = ''; 
	 DECLARE @KZWDName VARCHAR(MAX) = '';
	 set @KZWDName=(select dimname from #DimsLS where DimYsql='')
	 set @KZWD=(select dimvalues from #DimsLS where DimYsql='' and dimname=@KZWDName)
	 
    --更新#DimsPearSen
	  DECLARE @KZWDDimsTb VARCHAR(MAX) = '';
	 set @KZWDDimsTb =(select  '
	 insert into #DimsPearSen (Dim,Dimname,DType,isrange,ViewName,DimYsql,DimValue,DataCount)
	 select  dimname,tad.Name_ch,''K'',tad.isrange,tad.ViewName,tad.AtYSql
	 ,case when istrue=0 then '''' when istrue=2 then ''倍数2'' when istrue=3 then ''倍数5'' when istrue=4 then ''倍数10'' end as qu  
	 ,''''
	 from VW_'+@KZWDName+'_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in ('+@KZWD+')
	  ')
	  exec( @KZWDDimsTb)

	  insert into  #DimsPearSen(Dim,Dimname,DType,isrange,ViewName,DimYsql,DimValue,DataCount)
	  select DimName,tad.Name_ch,'Y',dm.isrange,tad.ViewName,dm.DimYsql,'','' from #DimsLS dm
	  inner join Tbl_AnsCom_DIimToTable tad
	  on dm.DimName=tad.DimNum
	  where ChName=@YName

      insert into  #DimsPearSen(Dim,Dimname,DType,isrange,ViewName,DimYsql,DimValue,DataCount)
      select DimName,tad.Name_ch,Isneed,dm.isrange,tad.ViewName,dm.DimYsql,'','' from #DimsLS dm
	  inner join Tbl_AnsCom_DIimToTable tad
	  on dm.DimName=tad.DimNum
	  where dm.DimYsql<>'' and Isneed<>'ND' 


    --控制维度排序
	  CREATE TABLE #DimsKzshift
	  (
		DimName varchar(50)
		,DimValues varchar(max)
	  );

	  DECLARE @KZWDshift VARCHAR(MAX) = '';
	 set @KZWDshift =(select  '
	 insert into #DimsKzshift (DimValues)
	 select  kz.ID
	 from VW_'+@KZWDName+'_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in ('+@KZWD+')
	  ')
	  exec( @KZWDshift)
    
    DECLARE @KZshift VARCHAR(MAX) = '';
    set @KZshift=(select cast(DimValues as varchar(50))+',' from #DimsKzshift order by DimValues FOR XML PATH(''))
    set @KZshift=(select @KZWDName+':'+@KZshift)
    set @KZshift=(select LEFT(@KZshift,LEN(@KZshift)-1))
    DECLARE @KZshiftor VARCHAR(MAX) = '';
    set @KZshiftor=(select substring(@SiftValueold,CHARINDEX('%',@SiftValueold),LEN(@SiftValueold)-CHARINDEX('%',@SiftValueold)+1))
    set @KZshift=@KZshift+@KZshiftor
    
	  SET @XDim=(SELECT DIM FROM #DimsPearSen WHERE DType='X')
	  SET @YDim=(SELECT DIM FROM #DimsPearSen WHERE DType='Y')

    --结果显示
    DECLARE @SqlJoinShow VARCHAR(max);
    SET @SqlJoinShow = ( SELECT ' LEFT JOIN vw_' +  Dim + '_Part AS ' + Dim + ' on ' + Dim + '.ID = Data.' + Dim
	FROM #DimsPearSen WHERE DType = 'K' FOR XML PATH(''));

    -- 拼接 @SelectKZ 段
    DECLARE @SelectKZ VARCHAR(max);
    SET @SelectKZ = ( SELECT  ','+Dim + '.Name AS ' + Dim FROM #DimsPearSen WHERE DType = 'K' FOR XML PATH(''));
    
    -- 拼接 @Select 段
    DECLARE @Select VARCHAR(max);
    SET @Select = ( SELECT  'DataCount, MaxY, MinY, AVGY, SQtY, MaxX, MinX, Xcount, PearSenR, Slope, LineCons, ChangePoint, Trend' );

    --条件数据是否已计算
    DECLARE @ResultTable VARCHAR(max);
    if(select COUNT(*) from T_AutoAnaCountSift where Xname=@XName and Yname=@YName and shiftvalue=@KZshift and Update_Time>=GETDATE()-1)>0
    begin
	    SET @ResultTable = (select table_name from T_AutoAnaCountSift where Xname=@XName and Yname=@YName and shiftvalue=@KZshift)

	    DECLARE @ResultTableShow VARCHAR(max);
	    SET @ResultTableShow = @ResultTable + ' AS Data '
	
	    DECLARE @ColumnNames VARCHAR(max);
	    SET @ColumnNames = ( SELECT ','''+ Dim + ''' AS ' + Dimname
		FROM #DimsPearSen WHERE DType ='K' FOR XML PATH(''));

        DECLARE @Varchars VARCHAR(max);
        SET @Varchars = ( SELECT ',''varchar 500'''
		FROM #DimsPearSen WHERE DType ='K' FOR XML PATH(''));

	    DECLARE @ResultTableLname VARCHAR(max);
	    SET @ResultTableLname = 
	    '	select  ''DataCount'' AS 总生产数,''MaxY'' AS '+@YName+'最大值'+',''MinY'' AS '+@YName+'最小值
	    ,''AVGY'' AS '+@YName+'平均值,''SQtY'' AS '+@YName+'标准差,''MaxX'' AS '+@XName+'最大值,''MinX'' AS '+@XName+'最小值,''Xcount'' AS '+@XName+'值个数,''PearSenR'' AS 拟合优度,''Slope'' AS 拟合斜率,''LineCons'' AS 拟合常数,''ChangePoint'' AS 拐点数量,''Trend'' AS 拐点描述'
	     + isnull(@ColumnNames,'')
	     + 
	    '
        union all
        select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'' ,''varchar 500'' ,''varchar 500'' ,''varchar 500'' ,''varchar 500'' ,''varchar 500'' 
         '
        + isnull(@Varchars,'');

        EXEC (@ResultTableLname);

  -------------分页
 --   DECLARE @totalRow INT = 0;
	--set @totalRow = ( select 'COUNT(*) FROM'+ @ResultTable);
	--exec (@totalRow);

 --   DECLARE @pageFy varchar(max);
 --   set @pageFy='
 --   EXEC dbo.Sp_Sys_Page @tblName = #Result_B
	--,@fldName =  ''DataCount desc''
	--,@rowcount = '+@totalRow+'
	--,@PageIndex = '+@PageIndex+'
	--,@PageSize = '+@PageSize+'
	--,@SumType = 0
	--,@SumColumn = ''
	--,@AvgColumn = ''
	--'
    EXEC ('SELECT ' + @Select + @SelectKZ + ' FROM ' + @ResultTableShow + @SqlJoinShow + ' where DATACOUNT>1 Order by DATACOUNT DESC ' );
    end
    else
    begin                   
        SELECT 'msg' AS 异常信息 UNION ALL SELECT 'varchar 500';
		SELECT '请重新保存数据' AS msg;
		RETURN;
    end;

    --select 1 as [PageIndex],3 as [PageCount],40 as [rowCount]

	END
go

