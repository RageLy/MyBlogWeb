CREATE proc [dbo].[sp_ComUse_GetLpLyMonthFuture]                   
(  
@month int=3  
)  
as                  
begin                    
declare  @dt datetime=getdate()  
declare  @BeginDate datetime,@EndDate datetime  
  
set @BeginDate=convert(datetime,left(datepart(YYYY,@dt),10)+'-'+left(datepart(MM,@dt),10)+'-1')  
--set @EndDate=dateadd(SECOND,-1,DATEADD(month,1,@BeginDate))  
  
insert into #tbMonthFurture (Begindate,EndDate)  
select DATEADD(month,num,@BeginDate) begindate,dateadd(SECOND,-1,DATEADD(month,num+1,@BeginDate)) enddate  
from  
(  
select 0 as num  
union all  
select 1 as num  
union all  
select 2  
union all  
select 3  
union all  
select 4  
union all  
select 5  
union all  
select 6  
union all  
select 7  
union all  
select 8  
union all  
select 9  
union all  
select 10  
union all  
select 11  
union all  
select 12  
)  
tb  
where num<@month  
  
  
--values(@BeginDate,@EndDate)  
  
  
  
  
end
go

