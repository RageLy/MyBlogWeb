        
-- =============================================                                        
-- Author:  <冯文强>                                        
-- Create date: <2015-8-3>                                        
-- Description: <新 员工列表>                                                                
-- =============================================                                        
CREATE procedure [dbo].Sp_Com_NewEmp_List_Fu                                        
@PageIndex    varchar(50) = '1'                                        
,@PageSize      varchar(50) = '120'                                        
,@OrderFields   varchar(50) = 'EmpID'                                                                   
,@EmpNo VARCHAR(50)=''          --员工编号                          
,@EmpName VARCHAR(50)=''  --员工姓名                                                                                         
as                                        
begin                                                               
    set nocount on;                                        
if(@OrderFields='')        
begin        
 set @OrderFields = 'EmpID'        
end                    
                                                            
  select                                        
   cast(a.EmpID as varchar(500)) [EmpID]                                        
   ,cast(a.DeptID as varchar(500)) DeptID                                        
   ,cast(a.EmpTypeID as varchar(500)) [EmpTypeID]                                        
   ,cast(a.PostID as varchar(500)) [PostID]                                     
   ,CAST(A.EmployeeStateID as varchar(500) )   [EmployeeStateID]                                                       
   ,cast(a.EducationID as varchar(500)) EducationID                                                                                               
   ,a.EmpNo    --员工工号                          
   ,a.EmpName           --员工姓名    
   ,cast( a.Sex as varchar(500)) SexID                                        
   ,cast(case when a.Sex='1' then '男' when a.Sex IS null then '' else '女' end as varchar(500)) Sex   --性别                       
   ,c.DeptName   --所属部门                        
   ,cast(e.PositionName  as varchar(500)) PositionName --职位                                         
   ,cast(a.Telephone as varchar(500)) Telephone  --联系电话    
   ,case when a.DateLeave is null then D.EmployeeStateName else '离职' end EmployeeStateName --状态       
   into #Result                                    
 from Tbl_Com_Employee a                                  --select * from Tbl_Com_Employee  --select * from tbl_com_EmployeeState    
 --left join Tbl_Com_EmployeeType b  ON a.EmpTypeID = b.EmpTypeID                                        
 left join Tbl_Com_Dept c          on a.DeptID = c.DeptID                                        
 left join tbl_com_EmployeeState D  ON A.EmployeeStateID=D.EmployeeStateID                                        
 left join Tbl_Com_EmployeePosition e         on a.PositionId=e.PositionId                                                                     
 --模糊查询条件                      --select * from Tbl_Com_PoliticalStatus    
 where                                         
 --员工编号                       
 (@EmpNo=NULL OR @EmpNo='' OR a.EmpNo LIKE '%'+@EmpNo+'%')                                    
 --员工姓名                          
 AND (@EmpName=NULL OR @EmpName='' OR a.EmpName LIKE '%'+@EmpName+'%')                                                          
 and  a.EmpID != 1                                
                                                                           
declare @pageCount int =@@ROWCOUNT         
 exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize                                          
end
go

