
-- =============================================                            
-- Author: hmw                                            
-- Create Date: 2017年5月26日                                                  
-- Descript: 从Excel插入白色颜料  
-- =============================================                   
--   exec [Sp_InsertBs_Coating]  
CREATE PROCEDURE [dbo].[Sp_InsertCoating]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;

        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_Coating
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Coating
                            GROUP BY 膜片批次
                        );

        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_Coating
                           );
        PRINT '开始插入Tbl_Base_D207E数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_MSds ( type )
                    SELECT DISTINCT SUBSTRING(膜片批次, 7, 2)
                    FROM   dbo.TempTb_Coating
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_MSds
                                          WHERE  SUBSTRING(膜片批次, 7, 2) = type
                                      )
                           AND (   SUBSTRING(膜片批次, 7, 2) IS NOT NULL
                                   AND SUBSTRING(膜片批次, 7, 2) <> ''
                               );


        INSERT INTO dbo.Tbl_Base_JSds ( type )
                    SELECT DISTINCT SUBSTRING(膜片批次, 9, 2)
                    FROM   dbo.TempTb_Coating
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_JSds
                                          WHERE  SUBSTRING(膜片批次, 9, 2) = type
                                      )
                           AND (   SUBSTRING(膜片批次, 9, 2) IS NOT NULL
                                   AND SUBSTRING(膜片批次, 9, 2) <> ''
                               );
        PRINT '表Tbl_Base_P100T数据插入完毕，继续下一步';



        PRINT '开始插入Tbl_Base_MpSeries数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_JsCode (   JsCode ,
                                            JsType
                                        )
                    SELECT DISTINCT 胶水型号 ,
                           胶水类型
                    FROM   dbo.TempTb_Coating
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_JsCode
                                          WHERE  胶水型号 = JsCode
                                      )
                           AND 胶水型号 IS NOT NULL;
        PRINT '表Tbl_Base_MpSeries数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_NhjType数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_HxFpCode ( HxFpCode )
                    SELECT DISTINCT 胶水风频率
                    FROM   dbo.TempTb_Coating
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_HxFpCode
                                          WHERE  胶水风频率 = HxFpCode
                                      )
                           AND 胶水风频率 IS NOT NULL;
        PRINT '表Tbl_Base_NhjType数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsLpjCode数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_HxFpCode ( HxFpCode )
                    SELECT DISTINCT 墨水风频
                    FROM   dbo.TempTb_Coating
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_HxFpCode
                                          WHERE  墨水风频 = HxFpCode
                                      )
                           AND 墨水风频 IS NOT NULL;
        PRINT '表Tbl_Base_MsLpjCode数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_MsWaterType数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_TJXLCode ( TJXLCode )
                    SELECT DISTINCT 涂胶线路
                    FROM   dbo.TempTb_Coating
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_TJXLCode
                                          WHERE  涂胶线路 = TJXLCode
                                      )
                           AND 涂胶线路 IS NOT NULL;
        PRINT '表Tbl_Base_MsWaterType数据插入完毕，继续下一步';
        UPDATE Bs_Coating
        SET    OptDate = 涂布日期 ,
		CoatingMsCode=CoatingMS.Code,
		CoatingITOCode=CoatingITO.Code,
               Jsds = JSds.ID ,
               Msds = MSds.ID ,
               ITOCode = CoatingITO.ID ,
               JsCode = JsCode.ID ,
               JsType = JsCode.ID ,
			   BHMCode=保护膜批号,
               JsNd = 胶水粘度 ,
               JsGHL = 胶水固含量 ,
               JsZl = 胶水张力 ,
			   JSBatchNO=胶水批次,
               JsNdBe = 涂前胶水粘度 ,
               JsGhlBe = 涂前胶水固含量 ,
               MsTtTemp = 墨水涂头温度 ,
               MsTtSd = 墨水涂头湿度 ,
               MsTtGTemp = 井下罐温度 ,
               MsTtGSd = 井下罐湿度 ,
               MsTtITOhd = ITO厚度 ,
               MsTtSpeed = 墨水泵速 ,
               MsTtKd = 涂幅宽度 ,
               MsTtJx = 墨水涂头间隙 ,
               MsHxFpCode = MsHxFpCode.ID ,
               MsHxFpTemp1 = 墨水烘箱温度1 ,
               MsHxFpTemp2 = 墨水烘箱温度2 ,
               MsHxFpTemp3 = 墨水烘箱温度3 ,
               MsHxFpTemp4 = 墨水烘箱温度4 ,
               MsHxFpTemp5 = 墨水烘箱温度5 ,
               MsHxFpTemp6 = 墨水烘箱温度6 ,
               MsHxFpTemp7 = 墨水烘箱温度7 ,
               MsCjCd = 墨水涂布长度 ,
               MsCjTemp = 墨水车间温度 ,
               MsCjSd = 墨水车间湿度 ,
               MsCjITODown = ITO导电面向下 ,
               MsCjLXM = 墨水传送辊是否覆离型膜 ,
               MsCjSpeed = 墨水车速 ,
               MsCjZhd = 涂墨总厚度 ,
               MsCjMshd = 墨水层厚度 ,
               JsTtTemp = 胶水涂头温度 ,
               JsTtSd = 胶水涂头湿度 ,
               JsTtHd = ITO加胶水厚度 ,
               JsTtSpeed = 胶水泵速 ,
               JsTtKd = 胶水涂幅宽度 ,
               JsTtJx = 胶水涂头间隙 ,
               TJXLCode = TJXLCode.ID ,
               JsHxFpCode = JSHxFpCode.ID ,
               JsHxFpTemp1 = 胶水烘箱温度1 ,
               JsHxFpTemp2 = 胶水烘箱温度2 ,
               JsHxFpTemp3 = 胶水烘箱温度3 ,
               JsHxFpTemp4 = 胶水烘箱温度4 ,
               JsHxFpTemp5 = 胶水烘箱温度5 ,
               JsHxFpTemp6 = 胶水烘箱温度6 ,
               JsHxFpTemp7 = 胶水烘箱温度7 ,
               JsCjCd = 胶水涂布长度 ,
               JsCjTemp = 胶水车间温度 ,
               JsCjSd = 胶水车间湿度 ,
               JsCjLXM = 胶水传送辊是否覆离型膜 ,
               JsCjSpeed = 胶水车速 ,
               JsCjZhd = 涂胶总厚度 ,
               JsCjJshd = 胶水层厚度 ,
               MsCode = CoatingMS.ID ,
               TTckTemp = 涂头唇口温度 ,
               updatedate = GETDATE()
        FROM   dbo.TempTb_Coating
               LEFT JOIN Bs_Coating_ITO CoatingITO ON TempTb_Coating.ITO卷号 = CoatingITO.Code
               LEFT JOIN Bs_Coating_MS CoatingMS ON CoatingMS.Code = TempTb_Coating.墨水批次
               LEFT JOIN Tbl_Base_MSds MSds ON MSds.type = SUBSTRING(
                                                                        TempTb_Coating.膜片批次 ,
                                                                        7 ,
                                                                        2
                                                                    )
               LEFT JOIN Tbl_Base_JSds JSds ON JSds.type = SUBSTRING(
                                                                        TempTb_Coating.膜片批次 ,
                                                                        9 ,
                                                                        2
                                                                    )
               LEFT JOIN Tbl_Base_JsCode JsCode ON JsCode.JsCode = TempTb_Coating.胶水型号
               LEFT JOIN Tbl_Base_HxFpCode MsHxFpCode ON MsHxFpCode.HxFpCode = TempTb_Coating.墨水风频
               LEFT JOIN Tbl_Base_HxFpCode JSHxFpCode ON JSHxFpCode.HxFpCode = TempTb_Coating.胶水风频率
               LEFT JOIN Tbl_Base_TJXLCode TJXLCode ON TJXLCode.TJXLCode = TempTb_Coating.涂胶线路
        WHERE  Bs_Coating.Code = 膜片批次;
        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_Coating
                                            INNER JOIN dbo.TempTb_Coating ON TempTb_Coating.膜片批次 = Bs_Coating.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;

        INSERT INTO dbo.Bs_Coating (   OptDate ,
                                       Code ,
									   CoatingMsCode,CoatingITOCode,
                                       Jsds ,
                                       Msds ,
									   BHMCode,
                                       ITOCode ,
                                       JsCode ,
                                       JsType ,
                                       JsNd ,
                                       JsGHL ,
                                       JsZl ,
									   JSBatchNO,
                                       JsNdBe ,
                                       JsGhlBe ,
                                       MsTtTemp ,
                                       MsTtSd ,
                                       MsTtGTemp ,
                                       MsTtGSd ,
                                       MsTtITOhd ,
                                       MsTtSpeed ,
                                       MsTtKd ,
                                       MsTtJx ,
                                       MsHxFpCode ,
                                       MsHxFpTemp1 ,
                                       MsHxFpTemp2 ,
                                       MsHxFpTemp3 ,
                                       MsHxFpTemp4 ,
                                       MsHxFpTemp5 ,
                                       MsHxFpTemp6 ,
                                       MsHxFpTemp7 ,
                                       MsCjCd ,
                                       MsCjTemp ,
                                       MsCjSd ,
                                       MsCjITODown ,
                                       MsCjLXM ,
                                       MsCjSpeed ,
                                       MsCjZhd ,
                                       MsCjMshd ,
                                       JsTtTemp ,
                                       JsTtSd ,
                                       JsTtHd ,
                                       JsTtSpeed ,
                                       JsTtKd ,
                                       JsTtJx ,
                                       TJXLCode ,
                                       JsHxFpCode ,
                                       JsHxFpTemp1 ,
                                       JsHxFpTemp2 ,
                                       JsHxFpTemp3 ,
                                       JsHxFpTemp4 ,
                                       JsHxFpTemp5 ,
                                       JsHxFpTemp6 ,
                                       JsHxFpTemp7 ,
                                       JsCjCd ,
                                       JsCjTemp ,
                                       JsCjSd ,
                                       JsCjLXM ,
                                       JsCjSpeed ,
                                       JsCjZhd ,
                                       JsCjJshd ,
                                       MsCode ,
                                       TTckTemp ,
                                       updatedate
                                   )
                    SELECT 涂布日期 ,
                           膜片批次 ,
						   CoatingMS.Code,CoatingITO.Code,
                           JSds.ID ,
                           MSds.ID ,
						   保护膜批号,
                           CoatingITO.ID ,
                           JsCode.ID ,
                           JsCode.ID ,
                           胶水粘度 ,
                           胶水固含量 ,
                           胶水张力 ,
						   胶水批次,
                           涂前胶水粘度 ,
                           涂前胶水固含量 ,
                           墨水涂头温度 ,
                           墨水涂头湿度 ,
                           井下罐温度 ,
                           井下罐湿度 ,
                           ITO厚度 ,
                           墨水泵速 ,
                           涂幅宽度 ,
                           墨水涂头间隙 ,
                           MsHxFpCode.ID ,
                           墨水烘箱温度1 ,
                           墨水烘箱温度2 ,
                           墨水烘箱温度3 ,
                           墨水烘箱温度4 ,
                           墨水烘箱温度5 ,
                           墨水烘箱温度6 ,
                           墨水烘箱温度7 ,
                           墨水涂布长度 ,
                           墨水车间温度 ,
                           墨水车间湿度 ,
                           ITO导电面向下 ,
                           墨水传送辊是否覆离型膜 ,
                           墨水车速 ,
                           涂墨总厚度 ,
                           墨水层厚度 ,
                           胶水涂头温度 ,
                           胶水涂头湿度 ,
                           ITO加胶水厚度 ,
                           胶水泵速 ,
                           胶水涂幅宽度 ,
                           胶水涂头间隙 ,
                           TJXLCode.ID ,
                           JSHxFpCode.ID ,
                           胶水烘箱温度1 ,
                           胶水烘箱温度2 ,
                           胶水烘箱温度3 ,
                           胶水烘箱温度4 ,
                           胶水烘箱温度5 ,
                           胶水烘箱温度6 ,
                           胶水烘箱温度7 ,
                           胶水涂布长度 ,
                           胶水车间温度 ,
                           胶水车间湿度 ,
                           胶水传送辊是否覆离型膜 ,
                           胶水车速 ,
                           涂胶总厚度 ,
                           胶水层厚度 ,
                           CoatingMS.ID ,
                           涂头唇口温度 ,
                           GETDATE()
                    FROM   dbo.TempTb_Coating
                           LEFT JOIN Bs_Coating_ITO CoatingITO ON TempTb_Coating.ITO卷号 = CoatingITO.Code
                           LEFT JOIN Bs_Coating_MS CoatingMS ON CoatingMS.Code = TempTb_Coating.墨水批次
                           LEFT JOIN Tbl_Base_MSds MSds ON MSds.type = SUBSTRING(
                                                                                    TempTb_Coating.膜片批次 ,
                                                                                    7 ,
                                                                                    2
                                                                                )
                           LEFT JOIN Tbl_Base_JSds JSds ON JSds.type = SUBSTRING(
                                                                                    TempTb_Coating.膜片批次 ,
                                                                                    9 ,
                                                                                    2
                                                                                )
                           LEFT JOIN Tbl_Base_JsCode JsCode ON JsCode.JsCode = TempTb_Coating.胶水型号
                           LEFT JOIN Tbl_Base_HxFpCode MsHxFpCode ON MsHxFpCode.HxFpCode = TempTb_Coating.墨水风频
                           LEFT JOIN Tbl_Base_HxFpCode JSHxFpCode ON JSHxFpCode.HxFpCode = TempTb_Coating.胶水风频率
                           LEFT JOIN Tbl_Base_TJXLCode TJXLCode ON TJXLCode.TJXLCode = TempTb_Coating.涂胶线路
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_Coating
                                          WHERE  Code = 膜片批次
                                      )
                           AND 膜片批次 IS NOT NULL;

    END;






	--视图添加

	


------------------------------------------
go

