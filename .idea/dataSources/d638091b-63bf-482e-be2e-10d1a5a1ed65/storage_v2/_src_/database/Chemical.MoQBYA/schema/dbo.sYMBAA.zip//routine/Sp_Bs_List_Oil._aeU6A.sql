




      
      
      
      
      
-- =============================================            
      
-- Description: 全结构查询      
-- Auth:hjl      
-- Parameter: 1 @CodeType -- 编号类型          
--            2 @CodeValue -- 编号取值      
--            3 @ParaType -- 参数类型      
--            4 @ParaValueL -- 参数取值下限      
--            5 @paraValueH -- 参数取值上限        
--            6 @ResultType -- 结果类型      
-- Content:  拼装SQL查询      
      
-- =============================================         
         
CREATE proc[dbo].[Sp_Bs_List_Oil]        
@OptDateB VARCHAR(50) = ''      
,@OptDateE VARCHAR(50) = ''      
, @Code VARCHAR(50) = ''  -- 编号取      
 ,@PageIndex varchar(5) = '1'      
 ,@PageSize varchar(5) = '10'      
 ,@OrderFields varchar(50) = ''      
 ,@Type varchar(50) = '查询'  -- "查询" "编辑" 类型，是查询的List，还是编辑用的加载      
 ,@ID varchar(50) = ''      
 ,@EmpID varchar(50) = '1'
AS      
BEGIN      
 --------------------- 变量声明  -------------------------      
       
 --DECLARE @Pagesql VARCHAR(2000) = '' -- 用于分页的sql      
      
      
 select oil.ID ,oil.[Code], ser.[Name], CONVERT(varchar(100), oil.[OptDate], 23) AS [OptDate], oil.[Conductivity]      
       , oil.[Viscosity], oil.[PSize05], oil.[PSize09],oil.[ParticalCodes],oil.Density,oil.STension ,oil.[RemarK]   
      ,pw1.Code AS [ParticalIDW1] ,pw2.Code AS [ParticalIDW2],pw3.Code AS [ParticalIDW3]  
      ,pb1.Code AS [ParticalIDBK1] ,pb2.Code AS [ParticalIDBK2] ,pb3.Code AS [ParticalIDBK3]    
   INTO #Result      
   FROM BS_Oil AS Oil
   --left join dbo.Tbl_Base_OilSolventG sg
   --on oil.SolventG=sg.id
   LEFT JOIN dbo.Bs_ParticalW pw1 ON pw1.ID = Oil.ParticalIDW1  
   LEFT JOIN dbo.Bs_ParticalW pw2 ON pw2.ID = Oil.ParticalIDW2  
   LEFT JOIN dbo.Bs_ParticalW pw3 ON pw3.ID = Oil.ParticalIDW3  
   LEFT JOIN dbo.Bs_ParticalBK pb1 ON pb1.ID = Oil.ParticalIDBK1
   LEFT JOIN dbo.Bs_ParticalBK pb2 ON pb2.ID = Oil.ParticalIDBK2  
   LEFT JOIN dbo.Bs_ParticalBK pb3 ON pb3.ID = Oil.ParticalIDBK3
   left join Tbl_Base_OilSeries ser on Oil.Series=ser.id
   where ( @Code = '' or oil.[Code] like ('%' + @Code + '%') )      
   AND ( @OptDateB = '' or oil.[OptDate] >= @OptDateB )       
   AND ( @OptDateE = '' or oil.[OptDate] < DATEAdd(DD,1,@OptDateE ) )      
   AND ( @Type = '查询' OR Oil.ID = @ID )      
      
   DECLARE @totalRow int = @@ROWCOUNT ;      
         
    if(@OrderFields='')      
		set @OrderFields ='optdate desc'      
          
     INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_Bs_List_Oil',
        '查询油相数据', 'select',@OptDateB+','+@OptDateE+','+@Code)        
          
          
 -- 数据分页      
 
 IF(@Type = '查询')      
  EXEC dbo.Sp_Sys_Page @tblName = '#Result'                        
  ,@fldName = @OrderFields                                
  ,@rowcount = @totalRow       
  ,@PageIndex = @PageIndex       
  ,@PageSize = @PageSize        
  ,@SumType = 0      
  ,@SumColumn = ''      
  ,@AvgColumn = ''      
       
 -- 编辑的加载      
 ELSE       
 SELECT * FROM #Result      
       
END       
--select * from tbl_sys_myMenu      
go

