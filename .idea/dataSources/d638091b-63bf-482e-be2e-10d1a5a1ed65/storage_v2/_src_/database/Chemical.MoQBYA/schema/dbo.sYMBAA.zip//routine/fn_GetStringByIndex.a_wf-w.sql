

/*    
hjl 根据需要的排序序号得到该顺位字符串  
输入3个字符串，选出大小排序为@index的字符串     
*/    
CREATE FUNCTION [dbo].[fn_GetStringByIndex]    
(    
@W1 VARCHAR(8000) ,
@W2 VARCHAR(8000) ,
@W3 VARCHAR(8000) ,
@index int
) 
RETURNS bit
AS    
BEGIN    
	DECLARE @MAX VARCHAR(8000);
	DECLARE @MIN VARCHAR(8000);
	DECLARE @R VARCHAR(8000);
	
	IF( @W1 > @W2 )
	
	set @MAX = @W2;
	
	
	--	set @MAX = CASE WHEN ( CASE WHEN @W1 > @W2 THEN @W1 ELSE @W2 END) > @W3 then ( CASE WHEN @W1 > @W2 THEN @W1 ELSE @W2 END) ELSE @W3 END;
RETURN @MAX;
		--set @MIN = CASE WHEN ( CASE WHEN @W1 < @W2 THEN @W1 ELSE @W2 END) < @W3 then ( CASE WHEN @W1 < @W2 THEN @W1 ELSE @W2 END) ELSE @W3 END
	
			
	--IF(@index = 1)
	--	SET @R = @MAX;
	--ELSE IF  (@index = 3)
	--	SET @R = @MIN;
	--ELSE IF  (@index = 2) 
	--	SET @R = REPLACE(REPLACE(@W1 + @W2 + @W3,@MAX,''),@MIN,'')
	--ELSE 
	--	SET @R = NULL;
	
	--RETURN @R;
	
END
go

