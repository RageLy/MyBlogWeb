                        
/*                        
刘轶  2015-2-3 按揭默认未结算                        
*/                        
CREATE proc [dbo].[Sp_Com_Mortgage]                 
@type VARCHAR(200) = '1'                         
as                          
BEGIN                
IF(@Type = '')                          
BEGIN                          
select                       
'AccountState' AccountState                                
,'A' A                                      
                                
union all                                  
select 'varchar 200'                               
,'varchar 200'                   
                     
                                
union all                                               
select '未结算'    
  ,''     
end 
else if(@type = 1) 
begin
select
'BackTimeBegin' BackTimeBegin                                
,'BackTimeEnd' BackTimeEnd                                      
                                
union all                                  
select 'varchar 200'                               
,'varchar 200'                   
                     
                                
union all                                               
select Convert(varchar(10),GETDATE(),23)    
  ,Convert(varchar(10),GETDATE(),23)   
end
    
              
END
go

