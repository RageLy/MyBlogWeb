

--exec Sp_Distance_List_Add @ID=N'DimSinOutValue'

-- =============================================        
--分析器维度调整
-- =============================================     
     
CREATE PROCEDURE [dbo].[Sp_Distance_List_Add]
    @ID NVARCHAR(50) 
AS
    BEGIN  
  
        DECLARE @SetCoName NVARCHAR(50)= '';
         PRINT @SetCoName+' '+@ID+' '
        SET @SetCoName = ( SELECT   Name_ch
                           FROM     dbo.Tbl_AnsCom_DIimToTable
                           WHERE    DimNum = @ID
                         );
                           PRINT @SetCoName+' '+@ID+' '
        IF ( ( SELECT   COUNT(*)
               FROM     Tbl_BaseSetDistance
               WHERE    DimNum = @ID
             ) = 0 )
            BEGIN

                INSERT  INTO dbo.Tbl_BaseSetDistance
                        ( CoName, DimNum )
                VALUES  ( @SetCoName, -- CoName - varchar(50)
                          @ID -- DimNum - varchar(50)
                          );
                SELECT  ID ,
                        CoName ,
                        DimNum ,
                        GoodUpValue ,
                        GoodDownValue ,
                        BadUpValue ,
                        BadDownValue ,
                        DistanceTypeStr ,
                        SpType
                FROM    Tbl_BaseSetDistance
                WHERE   DimNum = @ID;
            END;
        ELSE
            BEGIN
                SELECT  ID ,
                        CoName ,
                        DimNum ,
                        GoodUpValue ,
                        GoodDownValue ,
                        BadUpValue ,
                        BadDownValue ,
                        DistanceTypeStr ,
                        SpType
                FROM    Tbl_BaseSetDistance
                WHERE   DimNum = @ID;
            
            END;
    END;
go

