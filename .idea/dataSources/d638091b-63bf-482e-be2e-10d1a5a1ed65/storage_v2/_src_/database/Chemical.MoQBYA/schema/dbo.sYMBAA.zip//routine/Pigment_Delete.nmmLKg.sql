-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE  [dbo].[Pigment_Delete]  
 @ID varchar(50)=''  --颜料ID  
,@EmpID varchar(50) = '1'
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
   if(@ID<>'')                 
    begin      
    DELETE FROM Bs_Pigment WHERE [ID] = @ID 
     INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'PigmentAdd',
        '删除颜料数据','ID = '+@ID,'DELETE FROM Bs_Pigment WHERE [ID] ='+@ID)
    
    select '0'
    end
	else                 
    begin                   
        select '请选择一条记录进行删除'   return;                 
    end
END
go

