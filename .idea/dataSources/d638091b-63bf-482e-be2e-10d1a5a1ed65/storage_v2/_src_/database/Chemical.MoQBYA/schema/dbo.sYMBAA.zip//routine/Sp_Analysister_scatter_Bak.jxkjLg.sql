

-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年11月3日                                                
-- Descript: 统一的散点图分析器
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_scatter_Bak]
  @condition VARCHAR(MAX)='Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-1%DimSinTemp25:-244|-246|-248|-250|-252|-254%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1'            
 ,@OtherCond VARCHAR(MAX) ='%温度41%温度8%温度25%scatter%平均值'--'%时间%温度8%产值%line%数量'
 ,@Type VARCHAR(10) = '图' -- '图' or '列表' or '明细'
 ,@SpName VARCHAR(50) = 'SinCapsule'
 ,@OrderFields VARCHAR(50) = 'id'
 ,@EmpID INT = 1

 -- 以下参数只在出明细时使用
 ,@PageIndex VARCHAR(5)='1'
 ,@PageSize VARCHAR(5)='10'
 ,@XValue VARCHAR(50) = ''
 ,@DSValue VARCHAR(50) = ''

AS
BEGIN

---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue=REPLACE(@condition,'|',',');
    
    DECLARE @Usertitle VARCHAR(50) = ''          -- 标题            
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''               -- @OtherCond  传入的Y轴名称                
    --DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
    --DECLARE @CTOC VARCHAR(50) = ''                -- @OtherCond 传入的比较方式                
    --DECLARE @CompareType VARCHAR(50) = ''        -- 比较方式                  

    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)            
	 )
  
    INSERT INTO @OtherCondTbl
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')

     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     --SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     --SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)
                      
     -- OtherCond解析完毕
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       

	-- 时间表 时间临时表必然需要
    CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME
    )
	
	-- 如果有其它需要用 #时间表的必须在这里添加
	
    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段                        
    DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句            
	DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
    
    -- 读取转化 Y轴步骤 主要设置 @InnerSelect 内部 select 提取字段部分 还有 外部 select 的算法 @CountType            
	SET @NumSql = ',' + @CountType +'(' + @YName + ')' ;               

	-- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable]
     @SiftValue = @SiftValue
	,@XName = @XName
	,@DsName = @DsName;
	
	-- 判断有非数字化的维度被放到 横轴或Y轴上面 则报错并返回
	IF EXISTS ( SELECT 1 FROM #Dims WHERE (ChName = @XName OR  ChName = @YName ) AND isrange = 0 )
	BEGIN
		SELECT '' AS Dimx;
		SELECT '非数值类型的维度不能放在 横轴或者Y轴上面！' as title;
		RETURN;
	END
     
     -- 拼接创建维度临时表的语句
     
    SET @sql += ( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );
    
		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析
     
     -- 用 Dims 临时表拼接需要解析的 维度字符串
     SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
     
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;

     -- 解析维度
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';
     

---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        
               
------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
     
     -- 结果集表
	 CREATE TABLE #Result_B
	 (
	  id INT IDENTITY(1,1)
	  ,DsName varchar(500)
	  ,value varchar(500)
	 );
	
    DECLARE @Dims varchar(50);
    
	DECLARE @TimeName varchar(50);   -- 用于判断时间的标志

	set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig  WHERE SpName = @SpName)
	IF(@TimeName = '' OR @TimeName IS NULL)
	BEGIN
		SELECT '找不到时间配置字段'
		RETURN;
	END
	
-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              

  -- 基础版本的 select段Sql语句
	SET @sql +=
		'
		INSERT INTO #Result_B(DsName,value)
		SELECT ';

	-- 按照 是否需要维度 拼装选择的维度字段
	
	DECLARE @GDatas varchar(max) = '';   -- 用于判断时间的标志
	
	DECLARE @XDatas varchar(max) = ''; 
	-- 时间在分组拿出来
	IF(@DsName = '时间')
		SET @GDatas += 'dbo.GetTimeName(t.begindate,t.enddate)';
	-- 否则分组上面的取值也要拿出来，分组拿名称
	ELSE 
		SET @GDatas += ISNULL( (SELECT DimName + '.Name' FROM #Dims WHERE Isneed = 'G'),'');
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名
	
	-- Value 段即 X和Y拼接的部分拿出来
	DECLARE @XYSQL VARCHAR(max);
	-- 从维度表中取出Y轴上面的维度
	SELECT @XYSQL = ',''['' + cast(' + ISNULL( (SELECT DimYsql FROM #Dims WHERE Isneed = 'X'),'') + ' AS varchar(100))' -- 横轴取值
			+ ' + '','' + cast(' + ISNULL( (SELECT DimYsql FROM #Dims WHERE ChName = @YName),'') + ' AS varchar(100))' -- Y轴取值
			-- count(*) 是当x和Y数值完全重复时计算起泡大小
			+ ' + '','' + cast(count(*) as varchar(20)) + '']'' ';
	
	-- 如果Y轴上面的选取数据是非维度化的内容，则需要在此处注册
	IF ( @XYSQL IS NULL)
		SET @XYSQL = CASE
				WHEN @YName = '举例' THEN ',data.exp' + @YName    -- 这一句是注册样例
				ELSE ',1 AS [Y轴] ' END;
	
	-- 分组提取段加入
	SET @sql += @GDatas;
	
	-- value段加入
	SET @sql += @XYSQL;
	
    DECLARE @FromSql VARCHAR(max) = (SELECT JoinTables FROM Tbl_AnsCom_AnaSpConfig  WHERE SpName = @SpName);
     
    IF(@FromSql IS NULL OR @FromSql = '')
    BEGIN
		SELECT 'sp配置有问题';
		RETURN;
    END
     
    SET @sql += ISNULL(@InnerSelect,'') + ' FROM '  + @FromSql;

	-- 按照是否需要的表格拼装对应的表格
  
  -- 时间维表一定需要 放在可能会取到时间的表之后 
  IF(CHARINDEX('Dim7',@SiftValue) <> 0)           
	SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';            
  
  -- 临时存储拼接的SQL语句
  DECLARE @sql1 VARCHAR(max) = '';
  
  -- 将INNER JOIN 维度临时表段拼接起来
  SET @sql1 = ( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE DimName + '.ID = ' + DimYsql END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
  
   -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
  SET @sql1 = REPLACE(REPLACE(@sql1,'&lt;','<'),'&gt;','>') ;
  
  -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'
  SET @sql += @sql1 ;
	
  SET @Sql += ' GROUP BY '
			-- 	GROUP BY 分组，以及 x数值和Y数值
			+ @GDatas + ','
			+ ISNULL( (SELECT DimYsql FROM #Dims WHERE Isneed = 'X'),'') + ',' 
			+ ISNULL( (SELECT DimYsql FROM #Dims WHERE ChName = @YName),'')
	
	
	-- 注销临时表
	--SET @sql += ( SELECT 'DROP TABLE #' +  DimName + ';'
	--	FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );

	print @sql;
	EXEC(@sql);
	
	IF NOT EXISTS ( SELECT 1 FROM #Result_B)
	BEGIN
		SELECT '' AS Dimx;
		SELECT '此条件下没有数据，请重新选择' as title;
		RETURN;
	END
	
	--SELECT * FROM #Result_B
	--RETURN;
	------------------------------------------------------------ 各比较类型数据计算 ----------------------------------------------------------------------                  
  
	-- 给予输出列
	DECLARE @FormatSql1 varchar(max) = ''; 
	DECLARE @FormatSql2 varchar(max) = ''; 
	DECLARE @FormatSql varchar(max) = ''; 
  
	-- 拼接 取表 段 第一个表不需要拼接 FULL JOIN
	SET @FormatSql1 =  ( SELECT ',T' + CAST(id AS VARCHAR(10)) + '.value AS ''' + DsName + '''' FROM 
			(
				SELECT ROW_NUMBER() OVER(ORDER BY DsName) AS id, DsName FROM 
				 ( SELECT DISTINCT DsName FROM #Result_B ) x
			) xx FOR XML PATH('') )

	SET @FormatSql2 = ( SELECT 
			-- 拼接 FULL JOIN 段 第一个表不需要拼接 FULL JOIN
			CASE WHEN id = 1 THEN ''
			     ELSE ' FULL JOIN ' END
			+ ' ( SELECT ROW_NUMBER() OVER(ORDER BY id) AS nn,* FROM #Result_B WHERE DsName = ''' + DsName + ''') AS T' + CAST(id AS VARCHAR(10)) 
			+ -- 拼接ON段
			  -- 如果id = 1 第一个表不需要拼接 on 段
			CASE WHEN id = 1 THEN ''
				 ELSE ( ' ON T' + CAST(id AS VARCHAR(10)) + '.nn = T' + CAST(id - 1 AS VARCHAR(10)) + '.nn' ) END
			FROM
			(
			SELECT ROW_NUMBER() OVER(ORDER BY DsName) AS id, DsName FROM 
				 ( SELECT DISTINCT DsName FROM #Result_B ) x
			) xx FOR XML PATH('') );
	
	
	SET @FormatSql = ' SELECT ' + SUBSTRING(@FormatSql1,2,LEN(@FormatSql1))  -- 去掉 @FormatSql1 中的第一个逗号
	 + ' FROM ' + @FormatSql2 ;

	--PRINT @FormatSql;
    EXEC(@FormatSql);
    
    declare @XMax DECIMAL(18,2);
	declare @XMin DECIMAL(18,2);
    declare @YMax DECIMAL(18,2);
	declare @YMin DECIMAL(18,2);
	
	------ 下面是查找Y轴和X轴最大最小值
	SELECT @XMax = MAX(CAST (SUBSTRING(value,CHARINDEX('[' ,value)+1 ,CHARINDEX(',',value ) - 2 ) as decimal(18,2)))
	,@XMin = MIN(CAST (SUBSTRING(value,CHARINDEX('[' ,value )+1 ,CHARINDEX(',',value  ) - 2 ) as decimal(18,2)))
	,@YMax = MAX(CAST (SUBSTRING(value,CHARINDEX(',',value  ) + 1 , CHARINDEX( ',',value,CHARINDEX(',',value  ) + 1 ) - ( CHARINDEX(',',value  ) + 1) ) as decimal(18,2)))
	,@YMin = MIN(CAST (SUBSTRING(value,CHARINDEX(',',value  ) + 1 , CHARINDEX( ',',value,CHARINDEX(',',value  ) + 1 ) - ( CHARINDEX(',',value  ) + 1) ) as decimal(18,2)))
	FROM #Result_B

    declare @Yma varchar(max);
	declare @Ymi varchar(max);
	declare @Xma varchar(max);
	declare @Xmi varchar(max);
	
	declare @YTbl TABLE
	(
	  Yma varchar(max)
	  ,Ymi varchar(max)
	 )
	 
	 declare @XTbl TABLE
	(
	  Xma varchar(max)
	  ,Xmi varchar(max)
	 )
	 
	INSERT INTO @YTbl exec [dbo].[Sp_Y_min_max] @maxY=@YMax,@minY=@YMin
	set @Yma=(select Yma from @YTbl)
	set @Ymi=(select Ymi from @YTbl)
	
	INSERT INTO @XTbl exec [dbo].[Sp_Y_min_max] @maxY=@XMax,@minY=@XMin
	set @Xma=(select Xma from @XTbl)
	set @Xmi=(select Xmi from @XTbl)
    
    
    
	SELECT CASE WHEN @Usertitle = '' THEN @XName + ' - ' + @YName + ' 在分组 ' + @DSName + '上的分布' ELSE @Usertitle END as title
    ,@XName as XName
    ,@YName as YName
    ,'' as YName_Second
    ,'' as XUnit
    ,'' as YUnit
    ,'' as YUnit_Second
    ,@XMax AS XMax
    ,@XMin AS XMin
    ,@YMax AS YMax
    ,@YMin AS YMin
    
    
   -- RETURN;
	-- 注销临时表
	DROP TABLE #Result_B
	DROP TABLE #time;
	DROP TABLE #Dims;
	
  -- 拼接标题等配置

	
  -- 插入日志记录
     INSERT INTO Tbl_Log_AnaUseLog    
            ( EmpID ,    
              freshTime ,    
              spName ,    
              AnaName ,    
              siftvalue ,    
              OherParemeter    
            )    
     VALUES ( @EmpID ,    
              GETDATE() ,    
              'Sp_Analysister_OY_DouCapsule' ,    
              '双层胶囊多维分析' ,
              @condition ,
              '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='    
              + @OtherCond
            )
END
go

