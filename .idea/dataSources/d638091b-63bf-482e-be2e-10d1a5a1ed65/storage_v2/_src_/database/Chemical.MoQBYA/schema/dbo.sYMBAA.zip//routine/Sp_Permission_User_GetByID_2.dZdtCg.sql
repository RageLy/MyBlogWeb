-- =============================================
-- Author:		白冰
-- Create date: 2016-06-20
-- Description:	根据用户ID获取用户信息，用于用户信息编辑
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Permission_User_GetByID_2]
    @UserID NVARCHAR(5) = '1'
AS
BEGIN
	IF @UserID IS NULL OR @UserID = ''
	BEGIN
	    SELECT '请选择用户'
	    RETURN
	END
	
	SELECT  
	    tUser.UserID,
        tUser.UserName, 
        tUser.UserAccount, 
        tRole.RoleID,
        tRole.RoleName
    FROM tbl_sys_user AS tUser
    LEFT JOIN dbo.Tbl_Sys_UserRoleRelation AS tRelation ON tuser.userid = tRelation.UserID
    LEFT JOIN dbo.Tbl_Sys_Role AS tRole ON tRole.RoleID = tRelation.RoleID
    WHERE tRelation.UserID = @UserID
END
go

