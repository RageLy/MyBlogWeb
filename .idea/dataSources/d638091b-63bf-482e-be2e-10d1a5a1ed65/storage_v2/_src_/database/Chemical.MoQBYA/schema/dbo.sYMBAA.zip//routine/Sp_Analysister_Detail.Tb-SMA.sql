
CREATE PROC [dbo].[Sp_Analysister_Detail]
@Condition varchar(max)='Dim7:Y:this10%DimSinYX:-1%DimSinFu:4|9|10%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-112|-132%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1'
 ,@OtherCond varchar(max) ='%温度8%釜%胶囊产值%line%平均值%胶囊产值%数量'
 --,@OrderFields varchar(50) = ''
 ,@EmpID int =1
 ,@PageIndex varchar(5)='1'
 ,@SpName varchar(50)='SinCapsule'
 ,@PageSize varchar(5)='10'

 
 AS
 BEGIN
    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue=REPLACE(@condition,'|',',');    

    declare @Usertitle varchar(50) = ''          -- 标题        
    declare @XName varchar(50) = ''              -- 横轴维度名称            
    declare @DSName varchar(50) = ''             -- 分组维度名称
    declare @YName varchar(50) = ''               -- @OtherCond  传入的Y轴名称
    declare @ChatType varchar(50) = ''           -- 图形名称
    declare @CTOC varchar(50) = ''                -- @OtherCond 传入的比较方式
    declare @CompareType varchar(50) = ''        -- 比较方式  
	DECLARE @ErrorRecord NVARCHAR(MAX)='';            
    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改            
        
       DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)            
	 )            
  
    INSERT INTO @OtherCondTbl
     SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')
     SET @Usertitle = ( SELECT String FROM @OtherCondTbl WHERE ID = 1 )
     SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
     SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
     SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)
     SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
     SET @CTOC = ( SELECT String FROM @OtherCondTbl WHERE ID = 6)
     -- OtherCond解析完毕        

-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------        
      
 -- 时间表                      
    CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME            
    )

    DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500);      -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500);     -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句            
	DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	DECLARE @DimAll VARCHAR(MAX) = '';  -- 提取计算维度
	DECLARE @DataAll VARCHAR(MAX) = '';  -- 提取全数据计算
	DECLARE @ColName VARCHAR(MAX) = '';  -- 设置列名
	DECLARE @ColVar VARCHAR(MAX) = '';  -- 列数
	DECLARE @ColVarr VARCHAR(MAX) = '';  -- 列varchar
	
    set @XOrder = ',1 as X排序';
    set @DsOrder = ',1 as G排序';
    
    		-- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable]
     @SiftValue = @SiftValue
	,@XName = @XName
	,@DsName = @DsName;

	set @ColVar=(select COUNT(*) from #Dims where isrange=1 and Isneed<>'G')+4
	set @DataAll=(select LEFT((select DimYsql+' AS '+REPLACE(DimYsql,'.','')+',' from #Dims where isrange=1 for XML PATH('')),LEN((select DimYsql+' AS '+REPLACE(DimYsql,'.','')+',' from #Dims where isrange=1  for XML PATH('')))-1))

--select * from #Dims
 -- 默认使用 sum 遇到需要 count 或 avg 的Y轴再进行修改
    IF(@CTOC='平均值')
    begin set @CountType = 'AVG'
          set @DimAll=(select LEFT((select 'AVG('+REPLACE(DimYsql,'.','')+') ' +'AS AVG'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')),LEN((select 'avg('+REPLACE(DimYsql,'.','')+') ' +'AS AVG'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')))-1))
          set @ColName=(select 'select '+'''Xname'''+' AS ['+@XName+'],'+'''Xorder'''+' As X排序'+','+'''DSname'''+' As '+'分组'+@DSName+','+'''Gorder''' +' AS G排序'+','+left((select ''''+'AVG'+DimName +''''+' As [AVG'+ChName+'] ,'  from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')),LEN((select ''''+'AVG'+DimName +''''+' As [AVG'+ChName+'] ,' from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')))-1) +' union all '+'select '+LEFT((select '''varchar 500'''+',' from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')),LEN((select '''varchar 500'''+','  from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')))-1))
          EXEC (@ColName)
    end;
    IF(@CTOC='数量')
    begin set @CountType = 'Count'
          set @DimAll=(select LEFT((select 'Count('+REPLACE(DimYsql,'.','')+') ' +'AS Count'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')),LEN((select 'Count('+REPLACE(DimYsql,'.','')+') ' +'AS Count'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')))-1))
          set @ColName=(select 'select '+'''Xname'''+' AS ['+@XName+'],'+'''Xorder'''+' As X排序'+','+'''DSname'''+' As '+'分组'+@DSName+','+'''Gorder''' +' AS G排序'+','+left((select ''''+'Count'+DimName +''''+' As [Count'+ChName+'] ,'  from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')),LEN((select ''''+'Count'+DimName +''''+' As [Count'+ChName+'] ,' from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')))-1) +' union all '+'select '+LEFT((select '''varchar 500'''+',' from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')),LEN((select '''varchar 500'''+','  from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')))-1))
          EXEC (@ColName)
    end;
    IF(@CTOC='最大值')
    begin set @CountType = 'MAX'
          set @DimAll=(select LEFT((select 'MAX('+REPLACE(DimYsql,'.','')+') ' +'AS MAX'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')),LEN((select 'MAX('+REPLACE(DimYsql,'.','')+') ' +'AS MAX'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')))-1))
          set @ColName=(select 'select '+'''Xname'''+' AS ['+@XName+'],'+'''Xorder'''+' As X排序'+','+'''DSname'''+' As '+'分组'+@DSName+','+'''Gorder''' +' AS G排序'+','+left((select ''''+'MAX'+DimName +''''+' As [MAX'+ChName+'] ,'  from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')),LEN((select ''''+'MAX'+DimName +''''+' As [MAX'+ChName+'] ,' from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')))-1) +' union all '+'select '+LEFT((select '''varchar 500'''+',' from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')),LEN((select '''varchar 500'''+','  from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')))-1))
          EXEC (@ColName)
    end;
    IF(@CTOC='最小值')
    begin SET @CountType = 'MIN'
          set @DimAll=(select LEFT((select 'MIN('+REPLACE(DimYsql,'.','')+') ' +'AS MIN'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')),LEN((select 'MIN('+REPLACE(DimYsql,'.','')+') ' +'AS MIN'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')))-1))
          set @ColName=(select 'select '+'''Xname'''+' AS ['+@XName+'],'+'''Xorder'''+' As X排序'+','+'''DSname'''+' As '+'分组'+@DSName+','+'''Gorder''' +' AS G排序'+','+left((select ''''+'MIN'+DimName +''''+' As [MIN'+ChName+'] ,'  from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')),LEN((select ''''+'MIN'+DimName +''''+' As [MIN'+ChName+'] ,' from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')))-1) +' union all '+'select '+LEFT((select '''varchar 500'''+',' from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')),LEN((select '''varchar 500'''+','  from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')))-1))
          exec (@ColName)
    end;
    IF(@CTOC='标准差')
    begin SET @CountType = 'STDEV'
          set @DimAll=(select LEFT((select 'STDEV('+REPLACE(DimYsql,'.','')+') ' +'AS STDEV'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')),LEN((select 'STDEV('+REPLACE(DimYsql,'.','')+') ' +'AS STDEV'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')))-1))
          set @ColName=(select 'select '+'''Xname'''+' AS ['+@XName+'],'+'''Xorder'''+' As X排序'+','+'''DSname'''+' As '+'分组'+@DSName+','+'''Gorder''' +' AS G排序'+','+left((select ''''+'STDEV'+DimName +''''+' As [STDEV'+ChName+'] ,'  from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')),LEN((select ''''+'STDEV'+DimName +''''+' As [STDEV'+ChName+'] ,' from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')))-1) +' union all '+'select '+LEFT((select '''varchar 500'''+',' from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')),LEN((select '''varchar 500'''+','  from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')))-1))
          EXEC (@ColName)
    end;
    IF(@CTOC='方差')
    begin set @CountType = 'VAR'
          set @DimAll=(select LEFT((select 'VAR('+REPLACE(DimYsql,'.','')+') ' +'AS VAR'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')),LEN((select 'VAR('+REPLACE(DimYsql,'.','')+') ' +'AS VAR'+DimName+',' from #Dims where isrange=1 and isneed<>'G' for XML PATH('')))-1))
          set @ColName=(select 'select '+'''Xname'''+' AS ['+@XName+'],'+'''Xorder'''+' As X排序'+','+'''DSname'''+' As '+'分组'+@DSName+','+'''Gorder''' +' AS G排序'+','+left((select ''''+'VAR'+DimName +''''+' As [VAR'+ChName+'] ,'  from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')),LEN((select ''''+'VAR'+DimName +''''+' As [VAR'+ChName+'] ,' from #Dims where isrange=1 and Isneed<>'G' for XML PATH('')))-1) +' union all '+'select '+LEFT((select '''varchar 500'''+',' from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')),LEN((select '''varchar 500'''+','  from dbo.Tbl_Base_Num where id<@ColVar+1 for XML PATH('')))-1))
          EXEC (@ColName)
          
          --PRINT @ColName
    end;
    -- 读取转化 Y轴步骤 主要设置 @InnerSelect 内部 select 提取字段部分 还有 外部 select 的算法 @CountType          
    IF(@CTOC IN ('平均值','数量','最大值','最小值','标准差','方差'))
    BEGIN
		SET @NumSql = ',' + @CountType +'([' + @YName + '])' ;
	END
	
	ELSE IF( @CTOC = '极差' )
	BEGIN
		SET @NumSql = ',' + 'MAX([' + @YName + ']) - MIN(['  + @YName + '])';
	END
	
	ELSE IF( @CTOC = '中位数' )
	BEGIN
		SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.5 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
	END
	
	ELSE IF( @CTOC = '上四分位' )
	BEGIN
		SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.75 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
	END
	
	ELSE IF( @CTOC = '下四分位' )
	BEGIN
		SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.25 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
	END
	

    SET @sql += ( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );
		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析

     -- 用 Dims 临时表拼接需要解析的 维度字符串
     SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
     SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
     ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;

     -- 解析维度
     SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( @EmpID AS varchar(50)) + ';';

---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------                        

------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
     
     -- 结果集表
	 CREATE TABLE #Result_B
	 (
	  DimX varchar(50)
	  ,OrderX int
	  ,DimG varchar(50)
	  ,OrderG int
	  ,num decimal(18,2)
	 );


    DECLARE @Dims varchar(50);
    
	declare @TimeName varchar(50);   -- 用于判断时间的标志

	IF CHARINDEX('时间',@Xname) <> 0
		--SET @XOrder = 't.id AS X排序'
		SET @XOrder = '1 AS Xorder'
	ELSE 
		SELECT  @XOrder = ( CASE WHEN DimOrdersql = '' THEN DimName + '.VWID'
								-- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS X排序'
							 WHEN DimOrdersql <> '' THEN DimOrdersql
								-- 有特殊排序字符则使用特殊的
							 ELSE '1' END
						  + ' AS Xorder' )  -- 都没有则用默认
		FROM #Dims 
		WHERE Isneed = 'X';
		
	IF(@DSname ='无分组')
	SET @DsOrder=''
	ELSE
    begin
	IF CHARINDEX('时间',@DSname) <> 0
		SET @DsOrder = 't.id AS Gorder'
	ELSE
		SELECT @DsOrder = ( CASE WHEN DimOrdersql = '' THEN DimName + '.VWID'
								-- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS G排序'
							 WHEN DimOrdersql <> '' THEN DimOrdersql
								-- 有特殊排序字符则使用特殊的
							ELSE '1' END
							 + ' AS Gorder' )  -- 都没有则用默认
		FROM #Dims 
		WHERE Isneed = 'G';
	end		
	IF(@DSname ='无分组')
	SET @InnerSelect += ',' + @XOrder + ','+@DataAll ;          
	ELSE
	SET @InnerSelect += ',' + @XOrder + ',' + @DsOrder+','+@DataAll ;            
    	  
	set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig  WHERE SpName = @SpName)
	IF(@TimeName = '' OR @TimeName IS NULL)
	BEGIN
		set @ErrorRecord+='查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '''+@SpName+'''为空,请检查;';
		  INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Detail' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister_Detail @PageIndex = '''+@PageIndex+''' ,
                                @PageSize = '''+@PageSize+''' ,
                                @condition='''+@condition+''',
								@OtherCond='''+@OtherCond+''',
								@SpName'''+@SpName+''',
								@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
	END
	PRINT '查询:'
	--SELECT * FROM #Dims
	-- Group by段的
	IF(@DSname ='无分组')
	  set @Dims = 'Xname' + ',Xorder '  -- 横轴排序字段    
	  else
    set @Dims = 'Xname' + ',Xorder ' + ',' + 'DSname' + ',Gorder'  -- 横轴排序字段            
    
	DECLARE @PieColumn VARCHAR(100)
	SET @PieColumn = '';

print '-------'
print @Dims
-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              

  -- 基础版本的 select段Sql语句

  DECLARE @Xcolumn VARCHAR(50) = ISNULL( (SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'X'),'dbo.GetTimeName(t.begindate,t.enddate)');  -- 横轴在本表上面的列名,如果没有说明是时间维度
  DECLARE @Gcolumn VARCHAR(50) = ISNULL( (SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'G'),'dbo.GetTimeName(t.begindate,t.enddate)');  -- 分组在本表上面的列名，如果没有说明是时间维度
  DECLARE @Ycolumn VARCHAR(50) = ISNULL( (SELECT DimYsql FROM #Dims WHERE ChName = @YName ),'');  -- Y轴在本表上面的列名
 --SELECT '温度8' AS 温度8,'X排序' AS X排序,'釜' AS 釜,'G排序' AS G排序,'AVG温度41' AS AVG温度41,'AVG转速580' AS AVG转速580,'AVG胶囊产值' AS AVG胶囊产值,'AVG温度8' AS AVG温度8,'AVG温度25' AS AVG温度25,'AVG转速400' AS AVG转速400,'AVG粒径' AS AVG粒径,'AVG胶囊固含量' AS AVG胶囊固含量,'AVGCR值' AS AVGCR值,'AVGL黑' AS AVGL黑,'AVGL白' AS AVGL白,'AVGdelta黑' AS AVGdelta黑,'AVGdelta白' AS AVGdelta白,'AVG胶囊PH值' AS AVG胶囊PH值,'AVG电导率' AS AVG电导率,'AVG油相粘度' AS AVG油相粘度,'AVG粒径span' AS AVG粒径span,'AVG胶囊PH温度' AS AVG胶囊PH温度,'AVG油相粒径05' AS AVG油相粒径05,'AVG油相粒径09' AS AVG油相粒径09,'AVG油相密度' AS AVG油相密度,'AVG油相表面张力' AS AVG油相表面张力
 --UNION ALL 
 --SELECT 'varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500','varchar 500';

  set @sql += 
  '
   SELECT ' + @Dims + ',' +@DimAll + '
   FROM
   (
   SELECT ';
  
  -- 如果非分位数算法则不需要排序和算总数量 加快效率
  IF (@CTOC IN ('平均值','数量','最大值','最小值','标准差','方差'))
	SET @sql += ' 1 AS [1],'
	
  ELSE -- 否则分位数算法则加入 排序和总量
    SET @sql += ' Row_Number() OVER(Partition by ' + @Xcolumn + ',' + @Gcolumn + ' Order BY ' + @Ycolumn + ') AS nIndex ,
   COUNT(*) OVER(Partition by ' + @Xcolumn + ',' + @Gcolumn + ') AS nCount ,';
   
   -- 按照 是否需要维度 拼装选择的维度字段




	-- 如果有时间则取出时间  这里可能有特殊的时间维度需要特殊提出
	--IF(CHARINDEX('Dim7',@SiftValue) <> 0)
	--	SET @sql += 'dbo.GetTimeName(t.begindate,t.enddate) AS 时间'
	
	-- 横轴上面的取值要拿出来,时间维度则不取出
	--IF( @Xcolumn <> 'dbo.GetTimeName(t.begindate,t.enddate)')
		--SET @sql += ',' + @Xcolumn + ' AS ' + 'Xname' ;
		SET @sql += '' + @Xcolumn + ' AS ' + 'Xname' ;

	-- 分组上面的取值也要拿出来,时间维度则不取出
	--IF( @Gcolumn <> 'dbo.GetTimeName(t.begindate,t.enddate)')
	IF(@DSName<>'无分组')
		SET @sql += ',' + @Gcolumn + ' AS ' + 'DSname';
    

	-- Y 轴上面的取值要拿出来
	
	DECLARE @YSQL VARCHAR(100);
	
	-- 从维度表中取出Y轴上面的维度
	SELECT @YSQL = ',' + @Ycolumn + ' AS [' + @YName + ']';
	-- 实例： ',data.Temp8 AS 温度8';
	PRINT 'Y轴列'+@Ycolumn+@YName
	-- 如果Y轴上面的选取数据是非维度化的内容，则需要在此处注册
	IF ( @YSQL IS NULL) 
		SET @YSQL = CASE 
				WHEN @YName = '举例' THEN ',data.exp' + @YName    -- 这一句是注册样例
				ELSE ',1 AS [Y轴] ' END;
	SET @sql += @YSQL;
	
     DECLARE @FromSql VARCHAR(max) = (SELECT JoinTables + ' ' + BaseTable FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName);
     
     IF(@FromSql IS NULL OR @FromSql = '')
     BEGIN
		SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables, BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = '''+@SpName+'''结果为空 ,可能导致报错,请检查;';
		 INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Detail' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_Analysister_Detail @PageIndex = '''+@PageIndex+''' ,
                                @PageSize = '''+@PageSize+''' ,
                                @condition='''+@condition+''',
								@OtherCond='''+@OtherCond+''',
								@SpName'''+@SpName+''',
								@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
     END
     
     
     DECLARE @sqlJoin VARCHAR(max) = '';
     SET @sqlJoin += ISNULL(@InnerSelect,'') + ' FROM '  + @FromSql;
   -----------------------------------------------------
   -- 按照是否需要的表格拼装对应的表格
  
   -- 时间维表一定需要 放在可能会取到时间的表之后 
  IF(CHARINDEX('Dim7',@SiftValue) <> 0)           
	SET @sqlJoin += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';            
  
  -- 临时存储拼接的SQL语句
  DECLARE @sql1 VARCHAR(max) = '';
  
  -- 将INNER JOIN 维度临时表段拼接起来
  SET @sql1 = ( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE DimName + '.ID = ' + DimYsql END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
		
   -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
  SET @sql1 = REPLACE(REPLACE(@sql1,'&lt;','<'),'&gt;','>') ;
  
  -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'
  SET @sqlJoin += @sql1 ;
  
  set @sqlJoin += '
  WHERE ' + @Ycolumn + ' IS NOT NULL 
  ) x
  GROUP BY ' + @Dims;

  -- 排序段
  IF(@DSName='无分组')
    SET @sqlJoin += ' Order By abs(Xorder)'
	else
  SET @sqlJoin += ' Order By abs(Xorder),abs(Gorder);
  '
  
  -- 注销临时表
	SET @sqlJoin += ( SELECT 'DROP TABLE #' +  DimName + ';'
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );
	
	
	PRINT @sql;
	print @sqlJoin;
  EXEC(@sql + @sqlJoin);
  SELECT @sql + @sqlJoin
    INSERT INTO Tbl_Log_AnaUseLog    
            ( EmpID ,  
			  EmpName,  
              freshTime ,    
              spName ,    
              AnaName ,    
              siftvalue ,    
              OherParemeter    
            )    
     VALUES ( @EmpID ,
	 (SELECT EmpName from Tbl_Com_Employee WHERE EmpID=@EmpID),    
              GETDATE() ,    
              'Sp_Analysister_List' ,    
              ''+@SpName+'列表显示' ,
              @condition ,
              '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='    
              + @OtherCond
            )       
 END
go

