

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AllQuery_List_Forward_BK]
  @ID varchar(50) = ''
 ,@ResultType VARCHAR(50) = '粒子数据' -- 结果类型
 ,@Action VARCHAR(50) = '上'     
AS
BEGIN


	DECLARE @CodeType  VARCHAR(50) = 'ID'   -- 编号类型      
	DECLARE @CodeValue VARCHAR(50) = @ID  -- 编号取值  
	DECLARE @ParaType VARCHAR(50) = ''   -- 参数类型:单层PH   Oil.Viscosity  
	DECLARE @ParaValueL VARCHAR(50) = '' -- 参数取值下限   
	DECLARE @paraValueH VARCHAR(50) = '' -- 参数取值上限  
	DECLARE @PageIndex varchar(5) = '1'  
	DECLARE @PageSize varchar(5) = '20'  
	DECLARE @OrderFields varchar(50) = ''  
	DECLARE @EmpID varchar(50) = '1'
    DECLARE @TalbeName  VARCHAR(MAX) = ''  
    DECLARE @WhereValue  VARCHAR(MAX) = ''
    DECLARE @SelectValue VARCHAR(MAX) = '' 
	 if (@id<> '')
	 begin
	 if(@Action='上')
	 begin
	       if (@ResultType='粒子数据')
			begin	       
			  set @ResultType='颜料数据'
			  set @CodeType  ='粒子编号ID'   
			end
			else if (@ResultType='油项数据')
			begin
			  set @ResultType='粒子数据'
			  set @CodeType  ='油项编号ID' 
			end 
			else if (@ResultType='单层胶囊数据')
			begin
			 set @ResultType='油项数据'
			 set @CodeType  ='单层胶囊编号ID' 
			end
			else if (@ResultType='双层胶囊数据')
			begin
			 set @ResultType='单层胶囊数据'
			 set @CodeType  ='双层胶囊编号ID' 
			end 
			else
			begin
			    set @ResultType='颜料数据'
			    set @CodeType  ='颜料编号'
			    set @CodeValue='0000'
			    --return;
			end
			  
	 end else
	 begin
	       if (@ResultType='颜料数据')
			begin	       
			  set @ResultType='粒子数据'
			  set @CodeType  ='颜料编号ID'   
			end
			else if (@ResultType='粒子数据')
			begin
			  set @ResultType='油项数据'
			  set @CodeType  ='粒子编号ID' 
			end 
			else if (@ResultType='油项数据')
			begin
			 set @ResultType='单层胶囊数据'
			 set @CodeType  ='油项编号ID' 
			end
			else if (@ResultType='单层胶囊数据')
			begin
			 set @ResultType='双层胶囊数据'
			 set @CodeType  ='单层胶囊编号ID' 
			end  
			else
			begin
			    set @ResultType='双层胶囊数据'
			    set @CodeType  ='双层胶囊编号'
			    set @CodeValue='0000'
			    --return;
			end
			 
	 end     
	    
	    exec [Sp_AllQuery_List] @CodeType,@CodeValue,@ParaType,@ParaValueL,@paraValueH,@ResultType ,@PageIndex,@PageSize,@OrderFields,@EmpID 
	 end
	
	 
END
go

