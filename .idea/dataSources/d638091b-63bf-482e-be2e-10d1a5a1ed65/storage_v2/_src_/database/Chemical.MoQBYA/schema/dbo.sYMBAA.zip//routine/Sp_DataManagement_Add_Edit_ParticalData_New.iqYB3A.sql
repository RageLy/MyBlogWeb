




-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_DataManagement_Add_Edit_ParticalData_New]
	@ID NVARCHAR(50) = ''
	,@Code NVARCHAR(50) = ''
	,@Series NVARCHAR(50) = ''
	,@OptDate NVARCHAR(50) = ''
	,@PType NVARCHAR(50) = ''
	,@Kettle NVARCHAR(50) = ''
	,@PigmentCode NVARCHAR(50) = ''
	,@GrindPress NVARCHAR(50) = ''
	,@GrindTimeB NVARCHAR(50) = ''
	,@GrindTimeE NVARCHAR(50) = ''
	,@GrindOutPut NVARCHAR(50) = ''
	,@CLTemp10MIN NVARCHAR(50) = ''
	,@CLTemp20MIN NVARCHAR(50) = ''
	,@CLTemp30MIN NVARCHAR(50) = ''
	,@CLTemp60MIN NVARCHAR(50) = ''
	,@CLTemp90MIN NVARCHAR(50) = ''
	,@CLTemp120MIN NVARCHAR(50) = ''
	,@LQTemp10MIN NVARCHAR(50) = ''
	,@LQTemp20MIN NVARCHAR(50) = ''
	,@LQTemp30MIN NVARCHAR(50) = ''
	,@LQTemp60MIN NVARCHAR(50) = ''
	,@LQTemp90MIN NVARCHAR(50) = ''
	,@LQTemp120MIN NVARCHAR(50) = ''
	,@GHL NVARCHAR(50) = ''
	,@Remark NVARCHAR(50) = ''
	,@EmpID NVARCHAR(5) = '1'
	,@Action NVARCHAR(50) = ''
AS
BEGIN
	
	DECLARE @Class NVARCHAR(50) = ''
	
	SET @Class = (select name from Bs_ParticalSeries where ID=@Series)+'新工艺'
	

	
	IF @Action  = 'Insert'
	BEGIN
		IF @ID IS NULL OR @ID=''
		BEGIN
			IF exists(select 1 from dbo.Bs_ParticalSp where Code=rtrim(ltrim(@Code)))                      
			BEGIN
				SELECT '粒子编号不能重复！'
				RETURN
			END
			IF @Code = '' 
			BEGIN
				SELECT '粒子编号不能为空' 
				RETURN  
			END
		
			INSERT dbo.Bs_ParticalSp
			        (Code, OptDate, PType, Series, Class, Kettle, pigmentCode, GrindPress, GrindTimeB, GrindTimeE, GrindOutPut, CLTemp10MIN, 
			        CLTemp20MIN, CLTemp30MIN, CLTemp60MIN, CLTemp90MIN, CLTemp120MIN, LQTemp10MIN, LQTemp20MIN, LQTemp30MIN, LQTemp60MIN, 
			        LQTemp90MIN, LQTemp120MIN, GHL, Remark
			        )
			VALUES  ( LTRIM(RTRIM(@Code)) , -- Code - nchar(20)
			        @OptDate , -- OptDate - datetime
			        @PType , -- PType - varchar(50)
			        @Series,
					@Class , -- Class - varchar(50)
					@Kettle , -- Kettle - varchar(50)
					@pigmentCode , -- Kettle - varchar(50)
					CASE WHEN @GrindPress = '' THEN NULL ELSE @GrindPress END, --  TOutput - decimal
					CASE WHEN @GrindTimeB = '' THEN NULL ELSE @GrindTimeB END, --  FOutput - decimal
					CASE WHEN @GrindTimeE = '' THEN NULL ELSE @GrindTimeE END , -- ReactBACode - varchar(50) 
					CASE WHEN @GrindOutPut = '' THEN NULL ELSE @GrindOutPut END, -- ReactBECode - varchar(50) 
					CASE WHEN @CLTemp10MIN ='' THEN NULL ELSE @CLTemp10MIN END, -- SolventG - varchar(50) 
					CASE WHEN @CLTemp20MIN ='' THEN NULL ELSE @CLTemp20MIN END, -- SolventG - varchar(50) 
					CASE WHEN @CLTemp30MIN ='' THEN NULL ELSE @CLTemp30MIN END, -- SolventG - varchar(50) 
					CASE WHEN @CLTemp60MIN ='' THEN NULL ELSE @CLTemp60MIN END, -- SolventG - varchar(50) 
					CASE WHEN @CLTemp90MIN ='' THEN NULL ELSE @CLTemp90MIN END, -- SolventG - varchar(50) 
					CASE WHEN @CLTemp120MIN ='' THEN NULL ELSE @CLTemp120MIN END, -- SolventG - varchar(50) 
					CASE WHEN @LQTemp10MIN ='' THEN NULL ELSE @LQTemp10MIN END, -- SolventG - varchar(50) 
					CASE WHEN @LQTemp20MIN ='' THEN NULL ELSE @LQTemp20MIN END, -- SolventG - varchar(50) 
					CASE WHEN @LQTemp30MIN ='' THEN NULL ELSE @LQTemp30MIN END, -- SolventG - varchar(50) 
					CASE WHEN @LQTemp60MIN ='' THEN NULL ELSE @LQTemp60MIN END, -- SolventG - varchar(50) 
					CASE WHEN @LQTemp90MIN ='' THEN NULL ELSE @LQTemp90MIN END, -- SolventG - varchar(50) 
					CASE WHEN @LQTemp120MIN ='' THEN NULL ELSE @LQTemp120MIN END, -- SolventG - varchar(50) 
					CASE WHEN @GHL = '' THEN NULL ELSE @GHL END, --  PCRSpeed - decimal 
					@RemarK -- RemarK - varchar(200) 
			        )
			-- Update PigmentID
			
			
			INSERT INTO dbo.Tbl_Log_AnaUseLog
			        ( EmpID ,
			          freshTime ,
			          spName ,
			          AnaName ,
			          siftvalue ,
			          OherParemeter
			        )
			VALUES (@EmpID,GETDATE(),'Sp_DataManagement_Add_Edit_ParticalData','新增粒子数据', 
			          'insert',Isnull(@ID,'')
	                +','+Isnull(@Code,'')
	                +','+Isnull(@OptDate,'')
	                +','+Isnull(@PType,'')
	                +','+Isnull(@Kettle,'')
	                +','+Isnull(@Series,'')
	                +','+Isnull(@Class,'')
	                +','+Isnull(@PigmentCode,'')
	                +','+Isnull(@GrindPress,'')
	                +','+Isnull(@GrindTimeB,'')
	                +','+Isnull(@GrindTimeE,'')
	                +','+Isnull(@GrindOutPut,'')
	                +','+Isnull(@CLTemp10MIN,'')
	                +','+Isnull(@Remark,'')
	                +','+Isnull(@Action,'')
	                +','+Isnull(@CLTemp20MIN,'')+','+
	                Isnull(@CLTemp30MIN,'')+','+
	                Isnull(@CLTemp60MIN,'')+','+
	                Isnull(@CLTemp90MIN,'') +','+
	                Isnull(@CLTemp120MIN,'') +','+
	                Isnull(@LQTemp10MIN,'') +','+ 
	                Isnull(@LQTemp20MIN,'') +','+ 
	                Isnull(@LQTemp30MIN,'') +','+
	                Isnull(@LQTemp60MIN,'') +','+
	                Isnull(@LQTemp90MIN,'') +','+ 
	                Isnull(@LQTemp120MIN,'') +','+ 
	                Isnull(@GHL,'') +','+
	                Isnull(@EmpID,''))
		END
		ELSE
		BEGIN
			UPDATE dbo.Bs_ParticalSp
			SET [Code] = LTRIM(RTRIM(@Code))
			,[Series] =LTRIM(RTRIM(@Series))
			    ,[OptDate] = CASE WHEN @OptDate = '' THEN NULL ELSE @OptDate END
                ,[PType] = CASE WHEN @PType = '' THEN NULL ELSE @PType END
                ,[Class] = CASE WHEN @Class = '' THEN NULL ELSE @Class END
                ,[Kettle] = CASE WHEN @Kettle = '' THEN NULL ELSE @Kettle END
                ,[PigmentCode] = CASE WHEN @PigmentCode = '' THEN NULL ELSE @PigmentCode END
                ,[GrindPress] = CASE WHEN @GrindPress = '' THEN NULL ELSE @GrindPress END
                ,[GrindTimeB] = CASE WHEN @GrindTimeB = '' THEN NULL ELSE @GrindTimeB END
                ,[GrindTimeE] = CASE WHEN @GrindTimeE = '' THEN NULL ELSE @GrindTimeE END
                ,[GrindOutPut] = CASE WHEN @GrindOutPut = '' THEN NULL ELSE @GrindOutPut END
                ,[CLTemp10MIN] = CASE WHEN @CLTemp10MIN = '' THEN NULL ELSE @CLTemp10MIN END
                ,[CLTemp20MIN] = CASE WHEN @CLTemp20MIN = '' THEN NULL ELSE @CLTemp20MIN END
                ,[CLTemp30MIN] = CASE WHEN @CLTemp30MIN = '' THEN NULL ELSE @CLTemp30MIN END
                ,[CLTemp60MIN] = CASE WHEN @CLTemp60MIN = '' THEN NULL ELSE @CLTemp60MIN END
                ,[CLTemp90MIN] = CASE WHEN @CLTemp90MIN = '' THEN NULL ELSE @CLTemp90MIN END
                ,[CLTemp120MIN] = CASE WHEN @CLTemp120MIN = '' THEN NULL ELSE @CLTemp120MIN END
                ,[LQTemp10MIN] = CASE WHEN @LQTemp10MIN = '' THEN NULL ELSE @LQTemp10MIN END
                ,[LQTemp20MIN] = CASE WHEN @LQTemp20MIN = '' THEN NULL ELSE @LQTemp20MIN END
                ,[LQTemp30MIN] = CASE WHEN @LQTemp30MIN = '' THEN NULL ELSE @LQTemp30MIN END
                ,[LQTemp60MIN] = CASE WHEN @LQTemp60MIN = '' THEN NULL ELSE @LQTemp60MIN END
                ,[LQTemp90MIN] = CASE WHEN @LQTemp90MIN = '' THEN NULL ELSE @LQTemp90MIN END
                ,[LQTemp120MIN] = CASE WHEN @LQTemp120MIN = '' THEN NULL ELSE @LQTemp120MIN END
                ,[GHL] = CASE WHEN @GHL = '' THEN NULL ELSE @GHL END
                ,[RemarK] = CASE WHEN @RemarK = '' THEN NULL ELSE @RemarK END
			WHERE [ID] = @ID
			
			INSERT INTO dbo.Tbl_Log_AnaUseLog
			        ( EmpID ,
			          freshTime ,
			          spName ,
			          AnaName ,
			          siftvalue ,
			          OherParemeter
			        )
			VALUES  ( @EmpID,GETDATE(),'Sp_DataManagement_Add_Edit_ParticalData', '编辑粒子数据' ,'ID=' + @ID ,Isnull(@ID,'')
                +','+Isnull(@Code,'')
	                +','+Isnull(@OptDate,'')
	                +','+Isnull(@PType,'')
	                +','+Isnull(@Kettle,'')
	                +','+Isnull(@Series,'')
	                +','+Isnull(@Class,'')
	                +','+Isnull(@PigmentCode,'')
	                +','+Isnull(@GrindPress,'')
	                +','+Isnull(@GrindTimeB,'')
	                +','+Isnull(@GrindTimeE,'')
	                +','+Isnull(@GrindOutPut,'')
	                +','+Isnull(@CLTemp10MIN,'')
	                +','+Isnull(@Remark,'')
	                +','+Isnull(@Action,'')
	                +','+Isnull(@CLTemp20MIN,'')+','+
	                Isnull(@CLTemp30MIN,'')+','+
	                Isnull(@CLTemp60MIN,'')+','+
	                Isnull(@CLTemp90MIN,'') +','+
	                Isnull(@CLTemp120MIN,'') +','+
	                Isnull(@LQTemp10MIN,'') +','+ 
	                Isnull(@LQTemp20MIN,'') +','+ 
	                Isnull(@LQTemp30MIN,'') +','+
	                Isnull(@LQTemp60MIN,'') +','+
	                Isnull(@LQTemp90MIN,'') +','+ 
	                Isnull(@LQTemp120MIN,'') +','+ 
	                Isnull(@GHL,'') +','+
	                Isnull(@EmpID,''))
			
		END
		
		SELECT 0
	END
	
	
	
	
END
go

