-- =============================================
-- Author:		<曹乐平>
-- Create date: <2012-9-7>
-- Description:	<员工状态>
-- =============================================
CREATE procedure [dbo].[Sp_Com_EmpType_Del] 
    @KeyValue  varchar(50)='',
    @TableName  varchar(50)='',
    @KeyName  varchar(50)=''
as 
Begin 
set nocount on    

if (select COUNT(*) from dbo.Tbl_Com_Employee where EmpTypeID=@KeyValue )>0
begin
	 select '该记录已被员工管理引用，不能被删除'
end
else	
begin
	delete dbo.Tbl_Com_EmployeeType where EmpTypeID=@KeyValue
	select '0'
end
 
End
go

