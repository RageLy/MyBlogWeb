-- =============================================    

-- Description: <User保存-暂时修改为一个员工对应一个权限>    
-- =============================================    
CREATE PROCEDURE [dbo].[Sp_Sys_User_Save]    
 @UserID varchar(500)='',    
 @EmpID varchar(500)='',    
 @AccountName varchar(500)='',    
 @RoleID varchar(50)=''    
AS    
BEGIN    
 SET NOCOUNT ON;    
     
 if( @AccountName='')    
 begin    
  select '请先输入帐号！'    
  return    
 end    
 if exists(select 1 from Tbl_Sys_User where UserAccount=@AccountName and UserID!=@UserID)    
 begin    
  select '账号不能重复！'    
  return     
 end  
     
 if( @RoleID = '0' )    
 begin    
   select '角色必须选择！'    
   return     
 end    
   
 if(@UserID ='')--新增用户    
 begin    
     
     
  INSERT Tbl_Sys_User(UserAccount,UserName)   
  SELECT @AccountName,EmpName   
  FROM dbo.Tbl_Com_Employee   
  WHERE EmpID = @EmpID  
    
  UPDATE Tbl_Com_Employee set UserID=@@IDENTITY where EmpID=@EmpID    
      
  insert into Tbl_Sys_UserRoleRelation (UserID,RoleID)values(@@IDENTITY,@RoleID)    
  select '0'    
      
 end     
 else     
 begin    
  update Tbl_Sys_User set UserAccount=@AccountName where UserID=@UserID    
  IF EXISTS(SELECT * FROM Tbl_Sys_UserRoleRelation WHERE UserID=@UserID)    
  BEGIN    
    UPDATE Tbl_Sys_UserRoleRelation  set RoleID=@RoleID where UserID=@UserID    
  END    
  ELSE    
  BEGIN    
    insert into Tbl_Sys_UserRoleRelation (UserID,RoleID)values(@UserID,@RoleID)    
  END    
  select '0'    
 end    
    
    
   end
go

