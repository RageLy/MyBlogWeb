-- =============================================
-- Author:		白冰
-- Create date: 2016-06-17
-- Description:	获取用户信息列表
-- =============================================
CREATE PROCEDURE Sp_Permission_User_List_2
	-- Add the parameters for the stored procedure here
    @UserName varchar(50) = ''
    , @UserAccount varchar(50) = '' 
    , @Role varchar(10) = '1'
    
    , @PageSize VARCHAR(5) = '20'
    , @PageIndex VARCHAR(5) = '1'
    , @OrderFields VARCHAR(50) = ''
    , @EmpID varchar(50) = '1'
AS
BEGIN
    DECLARE @sql NVARCHAR(max) = ''
	DECLARE @condition NVARCHAR(MAX) = ''
	
	SET @UserName = LTRIM(RTRIM(@UserName))
	SET @UserAccount = LTRIM(RTRIM(@UserAccount))
	
	IF (@UserName IS NOT NULL AND @UserName <> '')
        SET @condition += ' AND tUser.UserName like ''%' + @UserName + '%'''
   
    IF (@UserAccount IS NOT NULL AND @UserAccount <> '')
        SET @condition += ' AND tUser.UserAccount like ''%' + @UserAccount + '%'''
        
    IF (@Role IS NOT NULL AND @Role!='0' AND LEN(@Role) <> 0)
        SET @condition += ' AND tRole.RoleID = ''' + @Role + ''''
    
    IF LEN(@condition) >= 4
        SET @condition = RIGHT(@condition, LEN(@condition) - 4)
    
    PRINT @condition
    
    IF(@OrderFields='')  
	BEGIN
		SET @OrderFields ='UserID'
	END
	
	SET @sql = 'SELECT 
	tUser.UserID,
    tUser.UserName, 
    tUser.UserAccount, 
    tRole.RoleName, 
    (SELECT UserName FROM tbl_sys_user WHERE UserID=tUser.OperatorID)AS Operator
    INTO #Result
    FROM tbl_sys_user AS tUser
    LEFT JOIN dbo.Tbl_Sys_UserRoleRelation AS tRelation ON tuser.userid = tRelation.UserID
    LEFT JOIN dbo.Tbl_Sys_Role AS tRole ON tRole.RoleID = tRelation.RoleID '
    
    IF LEN(@condition) <> 0
        SET @sql += 'WHERE ' + @condition + ' '
    
    SET @sql +='
	DECLARE @totalRow int = @@ROWCOUNT;'
	 

	SET @sql +='
	EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
		,@fldName = ''' + @OrderFields + '''
		,@rowcount = @totalRow  
		,@PageIndex = ''' + @PageIndex + '''   
		,@PageSize = ''' + @PageSize + '''    
		,@SumType = 0  
		,@SumColumn = ''''  
		,@AvgColumn = '''''

	PRINT @sql
	EXEC(@sql)
  
END
go

