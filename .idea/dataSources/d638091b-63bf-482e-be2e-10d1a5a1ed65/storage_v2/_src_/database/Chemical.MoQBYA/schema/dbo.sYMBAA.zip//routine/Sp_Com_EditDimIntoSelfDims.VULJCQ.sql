

CREATE PROCEDURE [dbo].[Sp_Com_EditDimIntoSelfDims]
    @AnaName varchar(500) = '颜料W到白粒子分析器'
    ,@DimNum varchar(500) = 'DimParticalWSeries'
    ,@IsBan varchar(500) = '否'
    ,@ShowIndex varchar(500) = '0.5'--名称
AS
    BEGIN
	IF(@ShowIndex = '' or @ShowIndex is null)
		set @ShowIndex = 9999;
		
	DECLARE @selectdim varchar(Max);
	
	DECLARE @IsHaveDim7 int = 1; -- 用于标识是否含有Dim7 标准时间维度

	select @selectdim = selectdim from Tbl_AnsCom_SelfDims
	where Name = @AnaName;
	
	IF( CHARINDEX('Dim7',@selectdim) = 0 )
		set @IsHaveDim7 = 0;
    
    -- 用于存储按顺序排列的维度表
    CREATE Table #DimList
    (
		ShowIndex decimal(18,2),
		DimNum varchar(100)
    );
    
    INSERT INTO #DimList
    select StartIndex,string from Split(@selectdim,',')
    where string <> 'Dim7';
    
    -- 如果禁止该维度 从维度表中删除
    IF( @IsBan = '是')
		DELETE FROM #DimList where DimNum = @DimNum;
	-- 如果包含该维度，则检查原来是否存在,不存在则按顺序加入
	ELSE IF( @IsBan = '否' )
	BEGIN
		-- 如果存在，则设置该维度的显示顺序为设置的顺序
		IF exists (select 1 FROM #DimList where DimNum = @DimNum)
			update #DimList set ShowIndex = @ShowIndex where DimNum = @DimNum;
		-- 如果不存在则加入
		ELSE
			INSERT INTO #DimList select @ShowIndex,@DimNum;
	END
    
	set @selectdim = (select ',' + DimNum FROM #DimList ORDER BY ShowIndex FOR XML PATH(''));
	
	IF(@IsHaveDim7 = 1)
		set @selectdim = 'Dim7' + @selectdim;
	ELSE
		set @selectdim = SUBSTRING(@selectdim,1,LEN(@selectdim));
	
	DECLARE @tag NVARCHAR(50)=(SELECT  tag FROM Tbl_AnsCom_SelfDims WHERE Name=@AnaName)
	update Tbl_AnsCom_SelfDims set selectdim = @selectdim
	where tag LIKE '%'+@tag+'%';
	
	
	DROP TABLE #DimList;
	select 0;
	

	
    END;
go

