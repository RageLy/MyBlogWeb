CREATE  PROCEDURE [dbo].[QueryCompound] @Str NVARCHAR(100) = ''
AS
    BEGIN 
        IF ( @Str = '' )
            BEGIN
                SELECT  'prompt' AS 提示
                UNION ALL
                SELECT  'varchar(500)'; 
    
                SELECT  '请输入字符串' AS prompt;
                RETURN;
            END;
        CREATE  TABLE Result
            (
              id INT IDENTITY(1, 1) ,
              ActSmiles NVARCHAR(100) ,
              StorageSmiles NVARCHAR(100) ,
              NewStr NVARCHAR(100) ,
              Num INT ,
              CompType NVARCHAR(100) ,
              Layer INT
            );
     
            
        CREATE  TABLE #ResultOK
            (
              id INT IDENTITY(1, 1) ,
              StorageSmiles NVARCHAR(100) ,
              CompType NVARCHAR(100)
            );
        INSERT  INTO Result
                ( ActSmiles ,
                  StorageSmiles ,
                  NewStr ,
                  CompType ,
                  Layer
                )
                SELECT  ActSmiles ,
                        ActSmiles ,
                        REPLACE(REPLACE(@Str, ActSmiles, ''), '()', '') newStr ,
                        CompType ,
                        1
                FROM    Bs_Compound_Learn
                WHERE   CHARINDEX(ActSmiles, @Str, 1) > 0
                        AND LEN(ActSmiles) > 1;
                        
        SELECT  *
        FROM    Result;
        DECLARE @Count INT= 1;
        DECLARE @DataCount INT= 1;
        SET @DataCount = ( SELECT   COUNT(*)
                           FROM     dbo.Result
                         ) + 1;
        WHILE ( ( SELECT    COUNT(*)
                  FROM      Result
                  WHERE     NewStr = ''
                ) = 0
                AND ( SELECT    COUNT(*)
                      FROM      Result
                    ) <> @DataCount
              )
            BEGIN
                SET @DataCount = ( SELECT   COUNT(*)
                                   FROM     Result
                                 ); 
                INSERT  INTO Result
                        ( ActSmiles ,
                          StorageSmiles ,
                          NewStr ,
                          CompType ,
                          Layer
                        )
                        SELECT  Bs_Compound_Learn.ActSmiles ,
                                Result.StorageSmiles + ';'
                                + Bs_Compound_Learn.ActSmiles ,
                                REPLACE(REPLACE(REPLACE(REPLACE(NewStr,
                                                              Bs_Compound_Learn.ActSmiles,
                                                              ''), '()', ''),
                                                '()', ''), '()', '') newStr ,
                                Result.CompType + ';'
                                + CAST(Bs_Compound_Learn.CompType AS NVARCHAR(1)) ,
                                dbo.Result.Layer + 1
                        FROM    Result
                                CROSS JOIN Bs_Compound_Learn
                        WHERE   CHARINDEX(Bs_Compound_Learn.ActSmiles, newStr,
                                          0) > 0
                                AND LEN(Bs_Compound_Learn.ActSmiles) > 1
                                AND Result.Layer = @Count;
                                
                SET @Count = @Count + 1;
                SELECT  *
                FROM    Result; 
            END; 
           
        INSERT  INTO #ResultOK
                ( StorageSmiles ,
                  CompType
                )
                SELECT TOP 1
                        *
                FROM    ( SELECT    StorageSmiles ,
                                    CompType
                          FROM      Result
                          WHERE     NewStr = ''
                        ) a;
        
        SELECT  'StartIndex' AS '编号' ,
                'string' AS '化合物名称' ,
                'Name' AS '化合物类型'
        UNION ALL
        SELECT  'varchar(500)' ,
                'varchar(500)' ,
                'varchar(500)';
                
        SELECT  a.StartIndex ,
                a.string ,
                c.Name INTO #ResultNew
        FROM    ( SELECT    StartIndex + 1 StartIndex ,
                            string
                  FROM      dbo.Split(( SELECT  StorageSmiles
                                        FROM    #ResultOK
                                      ), ';')
                  WHERE     string IS NOT NULL
                ) a
                INNER JOIN ( SELECT StartIndex + 1 StartIndex ,
                                    string
                             FROM   dbo.Split(( SELECT  CompType
                                                FROM    #ResultOK
                                              ), ';')
                             WHERE  string IS NOT NULL
                           ) b ON b.StartIndex = a.StartIndex
                LEFT JOIN dbo.Bs_Base_CompType c ON b.string = c.Id;
                IF((SELECT COUNT(*) FROM #ResultOK)=0)
                SELECT 0 StartIndex,@str string,'未知化合物' Name
                ELSE
                SELECT * FROM #ResultNew
        
        DROP TABLE Result;
        DROP TABLE #ResultOK;
        DROP TABLE #ResultNew;
         
    END;

go

