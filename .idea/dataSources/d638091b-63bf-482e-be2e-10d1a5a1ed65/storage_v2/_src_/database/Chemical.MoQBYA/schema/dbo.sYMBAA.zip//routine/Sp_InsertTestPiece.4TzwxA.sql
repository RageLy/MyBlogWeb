
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2018年1月3日                                                
-- Descript: 从Excel插入测试片数据
-- =============================================                 
-- exec [Sp_InsertTestPiece]
CREATE PROCEDURE [dbo].[Sp_InsertTestPiece]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_TestPiece
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_TestPiece
                            GROUP BY 测试片编码
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_TestPiece
                           );

        UPDATE Bs_TestPiece
        SET    OptDate = 制作日期 ,
               DouCapsuleCode = 胶囊编码 ,
               DynamicCode = 动态编码 ,
               DynamicType = 类型 ,
               Weight = 胶囊总量g ,
               GHL = 固含量 ,
               WaterUse = 水加入量g ,
               BC0013Use = BG0013加入量g ,
               BC0009Use = BC0009加入量g ,
               BG0009Use = BG0009加入量g ,
               SF0011Use = SF0011加入量g ,
               BinderAUse = BinderA料加入量g ,
               MsND = 墨水粘度cp ,
               MsGDKD = 墨水刮刀刻度um ,
               MsTbJSpeed = 墨水涂布机速度 ,
               MsHgTemp = 墨水烘干温度 ,
               MsHgTime = 墨水烘干时间min ,
               MsWsDPHTemp = 墨水温湿度平衡温度 ,
               MsWsDPHWet = 墨水温湿度平衡湿度 ,
               MsCHD = 墨水层厚度 ,
               JSGdTemp = 胶水刮刀刻度 ,
               JsTbJSpeed = 胶水涂布机速度 ,
               JsHgTemp = 胶水烘干温度 ,
               JsHgTime = 胶水烘干时间 ,
               JsWsDPHTemp = 胶水温湿度平衡温度 ,
               JsWsDPHWet = 胶水温湿度平衡湿度 ,
               TbZHD = 涂布总厚度 ,
               min0LBKAvg = L黑均值0min ,
               min2LBKAvg = L黑均值2min ,
               min0LWAvg = L白均值0min ,
               min2LWAvg = L白均值2min ,
               DBD = 对比度 ,
               deltaBK = DL黑 ,
               deltaW = DL白 ,
               min2WB = 白B值2min
        FROM   dbo.TempTb_TestPiece
        WHERE  Code = 测试片编码;
        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_TestPiece
                                            INNER JOIN dbo.TempTb_TestPiece ON TempTb_TestPiece.测试片编码 = Bs_TestPiece.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;
        INSERT INTO dbo.Bs_TestPiece (   OptDate ,
                                         Code ,
                                         DouCapsuleCode ,
                                         DynamicCode ,
                                         DynamicType ,
                                         Weight ,
                                         GHL ,
                                         WaterUse ,
                                         BC0013Use ,
                                         BC0009Use ,
                                         BG0009Use ,
                                         SF0011Use ,
                                         BinderAUse ,
                                         MsND ,
                                         MsGDKD ,
                                         MsTbJSpeed ,
                                         MsHgTemp ,
                                         MsHgTime ,
                                         MsWsDPHTemp ,
                                         MsWsDPHWet ,
                                         MsCHD ,
                                         JSGdTemp ,
                                         JsTbJSpeed ,
                                         JsHgTemp ,
                                         JsHgTime ,
                                         JsWsDPHTemp ,
                                         JsWsDPHWet ,
                                         TbZHD ,
                                         min0LBKAvg ,
                                         min2LBKAvg ,
                                         min0LWAvg ,
                                         min2LWAvg ,
                                         DBD ,
                                         deltaBK ,
                                         deltaW ,
                                         min2WB
                                     )
                    SELECT 制作日期 ,
                           测试片编码 ,
                           胶囊编码 ,
                           动态编码 ,
                           类型 ,
                           胶囊总量g ,
                           固含量 ,
                           水加入量g ,
                           BG0013加入量g ,
                           BC0009加入量g ,
                           BG0009加入量g ,
                           SF0011加入量g ,
                           BinderA料加入量g ,
                           墨水粘度cp ,
                           墨水刮刀刻度um ,
                           墨水涂布机速度 ,
                           墨水烘干温度 ,
                           墨水烘干时间min ,
                           墨水温湿度平衡温度 ,
                           墨水温湿度平衡湿度 ,
                           墨水层厚度 ,
                           胶水刮刀刻度 ,
                           胶水涂布机速度 ,
                           胶水烘干温度 ,
                           胶水烘干时间 ,
                           胶水温湿度平衡温度 ,
                           胶水温湿度平衡湿度 ,
                           涂布总厚度 ,
                           L黑均值0min ,
                           L黑均值2min ,
                           L白均值0min ,
                           L白均值2min ,
                           对比度 ,
                           DL黑 ,
                           DL白 ,
                           白B值2min
                    FROM   dbo.TempTb_TestPiece
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_TestPiece
                                          WHERE  Code = 测试片编码
                                      );

        PRINT '表Bs_TestPiece数据插入完毕，继续下一步';
        PRINT '所有过程完成';


    END;


go

