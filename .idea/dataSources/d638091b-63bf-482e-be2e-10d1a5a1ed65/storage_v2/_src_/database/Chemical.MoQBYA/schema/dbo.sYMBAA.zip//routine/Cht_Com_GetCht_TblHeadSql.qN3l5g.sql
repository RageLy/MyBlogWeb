




/*
刘轶 2014-7-7  
*/
CREATE function [dbo].[Cht_Com_GetCht_TblHeadSql](  
@OtherCond varchar(max) ='使用默认%使用默认%保险渗透率%11%数量'  
,@OrderFields varchar(max)  
,@SiftValue varchar(max)  
)    
returns varchar(max)               
AS                       
BEGIN
	--拆分X,Y,图类型等参数              
	declare @OtherCondTbl TABLE(                
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY               
		,String Nvarchar(50)              
	)              
	declare @XName nvarchar(50)--自定义X轴              
	,@DSName nvarchar(50)--自定义数据分组              
	,@YName nvarchar(50) --Y轴              
	,@CharName nvarchar(50)  --图表              
	,@CompareType nvarchar(50) --比较类型            
               
	insert into @OtherCondTbl              
	select String from dbo.f_splitSTR(@OtherCond,'%')              
	set @XName = (select String from @OtherCondTbl where ID = 1)              
	set @DSName = (select String from @OtherCondTbl where ID = 2)              
	set @YName = (select String from @OtherCondTbl where ID = 3)              
	set @CharName = (select String from @OtherCondTbl where ID = 4)              
	set @CompareType = (select String from @OtherCondTbl where ID = 5) 

	declare @sql varchar(max)=''
	--更新排序字段#FinalResult 
	if(@XName='星期')
	begin
		set @sql += ' update #FinalResult
			set OrderX =case when XName =''星期日'' then 0 
			when XName =''星期一'' then 1
			when XName =''星期二'' then 2
			when XName =''星期三'' then 3
			when XName =''星期四'' then 4
			when XName =''星期五'' then 5
			when XName =''星期六'' then 6
			else 1 end '
	end
	else if(@DSName='星期')
	begin
		set @sql += ' update #FinalResult
			set OrderDS =case when DSName =''星期日'' then 0 
			when DSName =''星期一'' then 1
			when DSName =''星期二'' then 2
			when DSName =''星期三'' then 3
			when DSName =''星期四'' then 4
			when DSName =''星期五'' then 5
			when DSName =''星期六'' then 6
			else 1 end '
	end
	--如果横轴为时间 这个时候替换ID为字符串  
	 if charindex('Dim7',[dbo].GetDimHead(@SiftValue,2))>0   
	 begin  
	  set @sql += ' update a set a.XName= CONVERT(nvarchar,b.beginDate,23)+''至''+CONVERT(nvarchar,b.endDate,23)  
	   from #FinalResult a  
	   inner join #time b on a.XName = b.ID '  
	 end  
	 --如果数据分组为时间 这个时候替换ID为字符串  
	 if charindex('Dim7',[dbo].GetDimHead(@SiftValue,3))>0  
	 begin  
	  set @sql += ' update a set a.DSName= CONVERT(nvarchar,b.beginDate,23)+''至''+CONVERT(nvarchar,b.endDate,23)  
	   from #FinalResult a  
	   inner join #time b on a.DSName = b.ID '  
	 end  
	set @sql +=' declare @sql2 varchar(max),@sql3 varchar(max),@sql4 varchar(max)'   
	  
	
	--判断饼图               
	if(@CharName='Pie2D' or @CharName = 'Pie3D')              
	begin              
		set  @Sql +='               
			set @sql2 = ''select ''''OrderX'''' as OrderX,'''' '''' as [ ],''              
			set @sql2 +='' ''''result'''' as ['+@YName+' '+@CompareType+']''                  
			set @sql3 = '' select ''''vachar,4000'''',''''vachar,4000'''',''''vachar,4000'''' '' '              
		set @Sql+= 'set @sql4 = @sql2 +'' union all ''+@sql3              
		exec (@sql4) '              
		set @sql+=' select OrderX as OrderX,XName as [ ],result into #FinalResultPie from #FinalResult'              
		if(@OrderFields!='')            
		begin            
			set @Sql+=' order by '+@OrderFields            
		end        
		set @sql+=' select OrderX,[ ], result from #FinalResultPie'    
	end              
	else   --其他图           
	begin              
		--if(@DSName='星期')              
		--begin              
		--set  @Sql +='               
		--	set @sql2 = ''select ''''OrderX'''' as OrderX, '''' '''' as [ ],''              
		--	set @sql2 +='' ''''星期日'''' as 星期日,''''星期一'''' as 星期一,''''星期二'''' as 星期二,              
		--	''''星期三'''' as 星期三,''''星期四'''' as 星期四,''''星期五'''' as 星期五,''''星期六'''' as 星期六''              
		--	set @sql3 = '' select ''''vachar,4000'''',''''vachar,4000'''',''''vachar,4000'''',''''vachar,4000'''',''''vachar,4000''''              
		--	,''''vachar,4000'''',''''vachar,4000'''',''''vachar,4000'''',''''vachar,4000'''' ''               
		--	set @sql4 = @sql2 +'' union all ''+@sql3              
		--	'              
		----print '1:  ' + @Sql            
		--end              
		--else    --非星期          
		--begin              
	        --sql2:表头第一行前两列 从#FinalResult中查出DSName拼成表头第一行后面的列
	        --sql3:表头第二行
			set  @Sql +='     
				select distinct DSName,OrderDS into #FinalCol from #FinalResult order by OrderDS
   
				set @sql2 = ''select ''''OrderX'''' as OrderX,'''' '''' as [ ],''  
			           
				set @sql2 +=(select ''''''''+'+'DSName'              
				+'+'''''''','' as ['','+'DSName'+'+''],''              
				from  #FinalCol  FOR XML PATH('''') )              
				set @sql2 = SUBSTRING(@sql2,0,len(@sql2))                
	                  
				set @sql3 = ''select ''''vachar,4000'''' as OrderX,''''vachar,4000'''' as [ ],''              
				set @sql3 +=(select distinct ''''''vachar,4000'''''','' as ['','+'DSName'+'+''],''              
				from  #FinalResult  FOR XML PATH(''''))              
				set @sql3 = SUBSTRING(@sql3,0,len(@sql3))               
	                  
				set @sql4 = @sql2 +'' union all ''+@sql3               
				'                     
	                
		--end              
	              
	  --print @sql              
		set @Sql+= 'set @sql4 = @sql2 +'' union all ''+@sql3   
		
		exec (@sql4) 
		print @sql4 ' 
		if(@OrderFields='')            
		begin            
			set @OrderFields = 'OrderX'            
		end   
		--行转列输出         
		set @sql+= dbo.RowToColumn('#FinalResult','DSName','result','OrderX,XName',@OrderFields+',[ ]','OrderDS')              
	end     
    return @sql  
end
go

