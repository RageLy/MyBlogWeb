
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年5月27日                                                
-- Descript: 从Excel插入单层胶囊数据
-- =============================================                 
-- exec [Sp_InsertSinCapsule]
CREATE PROCEDURE [dbo].[Sp_InsertSinCapsule]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        DELETE FROM dbo.TempTb_SinCapsule
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_SinCapsule
                            GROUP BY 胶囊编号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_SinCapsule
                           );
        BEGIN
            /*釜位维护,查看是否已经补全档案*/
            PRINT '开始插入Tbl_Base_Fu数据，继续下一步';
            INSERT INTO dbo.Tbl_Base_Fu ( Name )
                        SELECT DISTINCT 釜位
                        FROM   [TempTb_SinCapsule]
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Tbl_Base_Fu
                                              WHERE  釜位 = Name
                                          )
                               AND 釜位 IS NOT NULL;
            PRINT '表Tbl_Base_Fu数据插入完毕，继续下一步';
            /*AF0001批次维护,查看是否已经补全档案*/
            PRINT '开始插入Tbl_Base_AF0001数据，继续下一步';
            INSERT INTO dbo.Tbl_Base_AF0001 ( AF0001,AF0001RKDate )
                        SELECT DISTINCT AF0001批次,AF0001入库日期
                        FROM   [TempTb_SinCapsule]
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Tbl_Base_AF0001
                                              WHERE  AF0001批次 = AF0001
                                          )
                               AND AF0001批次 IS NOT NULL;
            PRINT '表Tbl_Base_AF0001数据插入完毕，继续下一步';

            /*AF0003批次维护,查看是否已经补全档案*/
            PRINT '开始插入Tbl_Base_AF0003数据，继续下一步';
            INSERT INTO dbo.Tbl_Base_AF0003 ( AF0003,AF0003RKDate )
                        SELECT DISTINCT AF0003批次,AF0003入库日期
                        FROM   [TempTb_SinCapsule]
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Tbl_Base_AF0003
                                              WHERE  AF0003批次 = AF0003
                                          )
                               AND AF0003批次 IS NOT NULL;
            PRINT '表Tbl_Base_AF0003数据插入完毕，继续下一步';

            /*AF0003批次维护,查看是否已经补全档案*/
            PRINT '开始插入Tbl_Base_BG0002数据，继续下一步';
            INSERT INTO dbo.Tbl_Base_BG0002 ( BG0002 )
                        SELECT DISTINCT BG0002批次
                        FROM   [TempTb_SinCapsule]
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Tbl_Base_BG0002
                                              WHERE  BG0002批次 = BG0002
                                          )
                               AND BG0002批次 IS NOT NULL;
            PRINT '表Tbl_Base_BG0002数据插入完毕，继续下一步';
            /*AF0003批次维护,查看是否已经补全档案*/
            PRINT '开始插入Tbl_Base_BG0004数据，继续下一步';
            INSERT INTO dbo.Tbl_Base_BG0004 ( BG0004 )
                        SELECT DISTINCT BG0004批次
                        FROM   [TempTb_SinCapsule]
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Tbl_Base_BG0004
                                              WHERE  BG0004批次 = BG0004
                                          )
                               AND BG0004批次 IS NOT NULL;
            PRINT '表Tbl_Base_BG0004数据插入完毕，继续下一步';
            PRINT '开始插入Tbl_Base_BG0026数据，继续下一步';
            INSERT INTO dbo.Tbl_Base_BG0026 ( BG0026 )
                        SELECT DISTINCT BG0026测试日期
                        FROM   [TempTb_SinCapsule]
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Tbl_Base_BG0026
                                              WHERE  BG0026测试日期 = BG0026
                                          )
                               AND BG0026测试日期 IS NOT NULL;
            PRINT '表Tbl_Base_BG0026数据插入完毕，继续下一步';

            /*插入Bs_SinCapsule*/

			UPDATE Tbl_Base_AF0001 SET AF0001RKDate=AF0001入库日期 FROM  [TempTb_SinCapsule] WHERE AF0001=AF0001批次
			UPDATE Tbl_Base_AF0003 SET AF0003RKDate=AF0003入库日期 FROM  [TempTb_SinCapsule] WHERE AF0003=AF0003批次
            UPDATE dbo.Bs_SinCapsule
            SET    OptDate = [操作日期] ,
                   Lotcode = [胶囊批次] ,
				   OilCode=Bs_Oil.Code,
                   OilID = ( CASE WHEN Bs_Oil.ID IS NULL THEN 65533
                                  WHEN Bs_Oil.ID IS NOT NULL THEN Bs_Oil.ID
                             END
                           ) ,
                   Kettle = Tbl_Base_Fu.ID ,
                   Volume = [体积] ,
                   GAA = [冰醋酸] ,
                   AF0001 = Tbl_Base_AF0001.ID ,
                   AF0003 = Tbl_Base_AF0003.ID ,
                   BG0026testDate = Tbl_Base_BG0026.ID ,
                   BG0002Code = Tbl_Base_BG0002.ID ,
                   BG0004 = Tbl_Base_BG0004.ID ,
                   Temp41 = [温度41] ,
                   Time45 = [时间45] ,
                   Rspeed580 = [转速580] ,
                   Temp8 = [温度8] ,
                   Time120 = [时间120] ,
                   Temp25 = [温度25] ,
                   Time360 = [时间360] ,
                   Rspeed400 = [转速400] ,
                   OutPut = [产值] ,
                   Psize = [胶囊粒径] ,
                   UpSW = [上层筛网] ,
                   DownSw = [下层筛网] ,
                   PsizeSpan = [粒径Span] ,
                   SoildContent = [胶囊固含量] ,
                   CR = [CR值] ,
                   LBK = [L黑] ,
                   LW = [L白] ,
                   DeltaBK = [delta黑] ,
                   DeltaW = [delta白] ,
                   PH = [PH值] ,
                   PHTemp = [PH温度] ,
                   Remark = [备注] ,
                   Employer = 操作人员 ,
                   update_time = GETDATE()
            FROM   [dbo].[TempTb_SinCapsule]
                   LEFT JOIN dbo.Bs_Oil ON Bs_Oil.Code = [TempTb_SinCapsule].油相编号
                   LEFT JOIN dbo.Tbl_Base_Fu ON Tbl_Base_Fu.Name = [TempTb_SinCapsule].[釜位]
                   LEFT JOIN Tbl_Base_AF0001 ON Tbl_Base_AF0001.AF0001 = [TempTb_SinCapsule].AF0001批次
                   LEFT JOIN Tbl_Base_AF0003 ON Tbl_Base_AF0003.AF0003 = [TempTb_SinCapsule].AF0003批次
                   LEFT JOIN Tbl_Base_BG0002 ON Tbl_Base_BG0002.BG0002 = [TempTb_SinCapsule].[BG0002批次]
                   LEFT JOIN dbo.Tbl_Base_BG0004 ON Tbl_Base_BG0004.BG0004 = [TempTb_SinCapsule].BG0004批次
                   LEFT JOIN Tbl_Base_BG0026 ON Tbl_Base_BG0026.BG0026 = [TempTb_SinCapsule].BG0026测试日期
            WHERE  Bs_SinCapsule.Code = [胶囊编号];

            SET @ReturnupdateValue = (   SELECT COUNT(*)
                                         FROM   dbo.Bs_SinCapsule
                                                INNER JOIN dbo.TempTb_SinCapsule ON TempTb_SinCapsule.[胶囊编号] = Bs_SinCapsule.Code
                                     );
            SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;


            PRINT '开始插入Bs_SinCapsule数据，继续下一步';
            INSERT INTO dbo.Bs_SinCapsule (   OptDate ,
                                              Code ,
											  OilCode,
                                              Lotcode ,
                                              OilID ,
                                              Kettle ,
                                              Volume ,
                                              GAA ,
                                              AF0001 ,
                                              AF0003 ,
                                              BG0026testDate ,
                                              BG0002Code ,
                                              BG0004 ,
                                              Temp41 ,
                                              Time45 ,
                                              Rspeed580 ,
                                              Temp8 ,
                                              Time120 ,
                                              Temp25 ,
                                              Time360 ,
                                              Rspeed400 ,
                                              OutPut ,
                                              Psize ,
                                              UpSW ,
                                              DownSw ,
                                              PsizeSpan ,
                                              SoildContent ,
                                              CR ,
                                              LBK ,
                                              LW ,
                                              DeltaBK ,
                                              DeltaW ,
                                              PH ,
                                              PHTemp ,
                                              Remark ,
                                              Employer ,
                                              update_time
                                          )
                        SELECT [操作日期] ,
                               [胶囊编号] ,
							   Bs_Oil.Code,
                               [胶囊批次] ,
                               ( CASE WHEN Bs_Oil.ID IS NULL THEN 65533
                                      WHEN Bs_Oil.ID IS NOT NULL THEN
                                          Bs_Oil.ID
                                 END
                               ) 油相编号ID ,
                               Tbl_Base_Fu.ID 釜ID ,
                               [体积] ,
                               [冰醋酸] ,
                               Tbl_Base_AF0001.ID AF0001ID ,
                               Tbl_Base_AF0003.ID AF0003ID ,
                               Tbl_Base_BG0026.ID ,
                               Tbl_Base_BG0002.ID BG0002ID ,
                               Tbl_Base_BG0004.ID ,
                               [温度41] ,
                               [时间45] ,
                               [转速580] ,
                               [温度8] ,
                               [时间120] ,
                               [温度25] ,
                               [时间360] ,
                               [转速400] ,
                               [产值] ,
                               [胶囊粒径] ,
                               [上层筛网] ,
                               [下层筛网] ,
                               [粒径Span] ,
                               [胶囊固含量] ,
                               [CR值] ,
                               [L黑] ,
                               [L白] ,
                               [delta黑] ,
                               [delta白] ,
                               [PH值] ,
                               [PH温度] ,
                               [备注] ,
                               操作人员 ,
                               GETDATE() 更新日期
                        FROM   [dbo].[TempTb_SinCapsule]
                               LEFT JOIN dbo.Bs_Oil ON Bs_Oil.Code = [TempTb_SinCapsule].油相编号
                               LEFT JOIN dbo.Tbl_Base_Fu ON Tbl_Base_Fu.Name = [TempTb_SinCapsule].[釜位]
                               LEFT JOIN Tbl_Base_AF0001 ON Tbl_Base_AF0001.AF0001 = [TempTb_SinCapsule].AF0001批次
                               LEFT JOIN Tbl_Base_AF0003 ON Tbl_Base_AF0003.AF0003 = [TempTb_SinCapsule].AF0003批次
                               LEFT JOIN Tbl_Base_BG0002 ON Tbl_Base_BG0002.BG0002 = [TempTb_SinCapsule].[BG0002批次]
                               LEFT JOIN dbo.Tbl_Base_BG0004 ON Tbl_Base_BG0004.BG0004 = [TempTb_SinCapsule].BG0004批次
                               LEFT JOIN Tbl_Base_BG0026 ON Tbl_Base_BG0026.BG0026 = [TempTb_SinCapsule].BG0026测试日期
                        WHERE  NOT EXISTS (   SELECT 1
                                              FROM   Bs_SinCapsule
                                              WHERE  Code = [胶囊编号]
                                          )
                               AND [胶囊编号] IS NOT NULL;
            PRINT '表Bs_SinCapsule数据插入完毕，继续下一步';
            PRINT '所有过程完成';
        END;
    END;
go

