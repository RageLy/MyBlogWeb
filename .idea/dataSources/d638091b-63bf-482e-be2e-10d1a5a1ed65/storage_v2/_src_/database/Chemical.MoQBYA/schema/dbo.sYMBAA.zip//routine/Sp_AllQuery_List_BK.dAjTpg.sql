





  
  
  
  
-- =============================================        
  
-- Description: 全结构查询  
-- Auth:hjl  
-- Parameter: 1 @CodeType -- 编号类型      
--            2 @CodeValue -- 编号取值  
--            3 @ParaType -- 参数类型  
--            4 @ParaValueL -- 参数取值下限  
--            5 @paraValueH -- 参数取值上限    
--            6 @ResultType -- 结果类型  
-- Content:  拼装SQL查询  
  
-- =============================================     
     
CREATE proc[dbo].[Sp_AllQuery_List_BK]  
 @CodeType  VARCHAR(50) = '颜料编号'   -- 编号类型      
 ,@CodeValue VARCHAR(50) = '1506MW3005'  -- 编号取值  
 ,@ParaType VARCHAR(50) = ''   -- 参数类型:单层PH   Oil.Viscosity  
 ,@ParaValueL VARCHAR(50) = '' -- 参数取值下限   
 ,@paraValueH VARCHAR(50) = '' -- 参数取值上限   
 ,@ResultType VARCHAR(50) = '颜料数据' -- 结果类型   
 ,@PageIndex varchar(5) = '1'  
 ,@PageSize varchar(5) = '10'  
 ,@OrderFields varchar(50) = ''  
 ,@EmpID varchar(50) = '1'
AS  
BEGIN  
 --------------------- 变量声明  -------------------------  
   
 DECLARE @SelectValue VARCHAR(MAX) = ''   -- select 段的语句，根据 【结果类型】 决定输出哪些列  
 DECLARE @WhereCode  VARCHAR(MAX) = ''    -- where 段中需要按编号段查询时根据 【编号类型】【编号取值】  
 DECLARE @WhereValue  VARCHAR(MAX) = ''   -- Where 段的参数选择语句，【参数类型】【参数取值下限】【参数取值上限】决定怎么筛选数据  
 DECLARE @WhereValueName  VARCHAR(MAX) = ''   -- Where 段的参数中的取值列名  
 DECLARE @TalbeValue  VARCHAR(MAX) = ''   -- From Table 段语句，根据@CodeType 和 @ResultType  和 @ParaType 决定  
 DECLARE @columnNames  VARCHAR(MAX) = ''   -- 输出的表名段语句，根据select段决定  
 DECLARE @WhereNonull  VARCHAR(MAX) = ''  -- 用where控制输出结果不带空值  
  -- 行数量 用于分页sp  
 DECLARE @Pagesql VARCHAR(2000) = '' -- 用于分页的sql  
   
 -- 临时表，用于存放需要哪些表  先暂时不用 后续使用，第一版先不用  
 CREATE TABLE #TalbesNeed  
 (  
  tablename VARCHAR(50)  
 )  
   
 -------------------- 变量参数拼接  ---------------------  
   
 IF @ResultType = '颜料数据'  
 BEGIN  
  -- 设定需要的列  
  SET @SelectValue = 'distinct   
   pigm.[Code],pigm.ID,CONVERT(varchar(100), pigm.[OptDate], 23) as [OptDate],pigm.[PType],pigm.[Kettle],pigm.[Mass],pigm.[InnerCode],pigm.[OutCode]  
   ,pigm.[SolventE] + '' /'' + isnull(cast(pigm.[SolventEDosage] AS varchar(20)),'''') AS [SolventE]  
   ,pigm.[SolventW] + '' /'' + isnull(cast(pigm.[SolventWDosage] AS varchar(20)),'''') AS [SolventW]  
   ,pigm.[SolventC] + '' /'' + isnull(cast(pigm.[SolventCDosage] AS varchar(20)),'''') AS [SolventC]  
   ,pigm.[SolventD] + '' /'' + isnull(cast(pigm.[SolventDDosage] AS varchar(20)),'''') AS [SolventD]  
   ,pigm.[SolventF] + '' /'' + isnull(cast(pigm.[SolventFDosage] AS varchar(20)),'''') AS [SolventF]  
   ,pigm.[SolventI] + '' /'' + isnull(cast(pigm.[SolventIDosage] AS varchar(20)),'''') AS [SolventI]  
   ,CONVERT(varchar(5), pigm.[PreheatBTime], 108) + '' - '' + CONVERT(varchar(5), pigm.[PreheatETime] , 108) AS [PreheatTime]  
   ,pigm.[ReactTempSet],pigm.[ReactTempActually],CONVERT(varchar(5), pigm.[ReactBTime], 108) + '' - '' + CONVERT(varchar(5), pigm.[ReactETime] , 108) AS [ReactTime]  
   ,pigm.[CTRSpeedSet],pigm.[CTRSpeedActually],CONVERT(varchar(5), pigm.[DisBTime], 108) + '' - '' + CONVERT(varchar(5), pigm.[DisETime] , 108) AS [DisTime]  
   ,pigm.[FRSpeedSet],pigm.[FRSpeedActually],pigm.[ReactOutput],pigm.[GrindOutput],pigm.[PSize05Bef],pigm.[PSize09Bef],pigm.[PSize05Aft],pigm.[PSize09Aft],pigm.[PH],pigm.[RemarK]  
   '   
    
  SET @WhereNonull = ' And pigm.Code is not null'  
    
    
  -- 设定需要的列头  
    
  SET @columnNames = '  
   select  ''n'' AS 序号,''ID'' AS 编号,''Code'' AS 颜料编号,''OptDate'' AS 操作日期,''PType'' AS 颜料类型,''Kettle'' AS 颜料大釜,''Mass'' AS 质量,''InnerCode'' AS 内部编号,''OutCode'' AS 外部编号  
     ,''SolventE'' AS [溶剂E/投入量],''SolventW'' AS [溶剂W/投入量],''SolventC'' AS [溶剂C/投入量],''SolventD'' AS [溶剂D/投入量],''SolventF'' AS [溶剂F/投入量],''SolventI'' AS [溶剂I/投入量]  
     ,''PreheatTime'' AS 预热时间,''ReactTempSet'' AS 设定反应温度,''ReactTempActually'' AS 反应温度,''ReactTime'' AS 反应时间  
     ,''CTRSpeedSet'' AS 设定恒温转速,''CTRSpeedActually'' AS 恒温转速 ,''DisTime'' AS 分散时间,''FRSpeedSet'' AS 设定加料转速 ,''FRSpeedActually'' AS 加料转速   
     ,''ReactOutput'' AS 反应后产量 ,''GrindOutput'' AS 研磨后产量,''PSize05Bef'' AS 离心前粒径05,''PSize09Bef'' AS 离心前粒径09 ,''PSize05Aft'' AS 离心后粒径05   
     ,''PSize09Aft'' AS 离心后粒径09,''PH'' AS PH值 ,''RemarK'' AS 备注                    
     union all  
     select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
     ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
     ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
     ,''varchar 500''   
     '  -- 31列  
       
  -- 设定需要颜料表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Pigment');  
    
    
    
 END  
   
 IF @ResultType = '粒子数据'  
 begin  
  SET @SelectValue = 'distinct   
  part.[ID]  
  ,part.[Code]  
  ,CONVERT(varchar(100), part.[OptDate], 23) AS [OptDate]  
  ,part.[PType]  
  ,part.[name]
  ,part.[Class]  
  ,part.[Kettle]  
  ,part.[TOutput]  
  ,part.[FOutput]  
  ,part.[PigmentCode]  
  ,part.[ReactBACode]  
  ,part.[ReactBECode]  
  ,part.[SolventG]  
  ,part.[Viscosity]  
  ,part.[Zeta]  
  ,part.[Organic]  
  ,part.[PSize05]  
  ,part.[PSize09]  
  ,part.[PCRSpeed]  
  ,part.[PCTime]  
  ,part.[WBTempSet]  
  ,part.[WBTempActually]  
  ,part.[WBRSpeedSet]  
  ,part.[WBRSpeedActually]  
  ,part.[Ini1JoinTime]  
  ,part.[Ini1SpeedSet]  
  ,part.[Ini1Speed]  
  ,part.[Ini1TempSet]  
  ,part.[Ini1Temp]  
  ,part.[Ini2BTime]  
  ,part.[Ini2JoinTime]  
  ,part.[Ini2SpeedSet]  
  ,part.[Ini2Speed]  
  ,part.[OffC1SpeedSet]  
  ,part.[OffC1Speed]  
  ,part.[OffC1Time]  
  ,part.[OffC2SpeedSet]  
  ,part.[OffC2Speed]  
  ,part.[OffC2Time]  
  ,part.[OffC3SpeedSet]  
  ,part.[OffC3Speed]  
  ,part.[OffC3Time]  
  ,part.[OffC4SpeedSet]  
  ,part.[OffC4Speed]  
  ,part.[OffC4Time]  
  ,part.[OffC5SpeedSet]  
  ,part.[OffC5Speed]  
  ,part.[OffC5Time]  
  ,part.[Ppole]  
  ,part.[Npole]  
  ,part.[RemarK]'   
    
    
  SET @WhereNonull = ' And part.Code is not null'  
    
  -- 设定需要的列头  
    
    
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号  
  ,''Code'' AS 粒子批号  
  ,''name'' AS 粒子系列
  ,''OptDate'' AS 操作日期  
  ,''PType'' AS 颜料类别  
  ,''Class'' AS 粒子小类别  
  ,''Kettle'' AS 粒子反应釜编号  
  ,''TOutput'' AS 理论产量  
  ,''FOutput'' AS 实际产量  
  ,''PigmentCode'' AS 颜料批次  
  ,''ReactBACode'' AS 反应BA编号  
  ,''ReactBECode'' AS BE编号  
  ,''SolventG'' AS 溶剂G  
  ,''Viscosity'' AS 粘度  
  ,''Zeta'' AS Zeta电位值  
  ,''Organic'' AS 有机物含量  
  ,''PSize05'' AS 粒子粒径05  
  ,''PSize09'' AS 粒子粒径09  
  ,''PCRSpeed'' AS 颜料清洗转速  
  ,''PCTime'' AS 清洗时间  
  ,''WBTempSet'' AS 预设水浴温度  
  ,''WBTempActually'' AS 水浴温度  
  ,''WBRSpeedSet'' AS 预设水浴转速  
  ,''WBRSpeedActually'' AS 水浴转速  
  ,''Ini1JoinTime'' AS 引发剂1加入时间  
  ,''Ini1SpeedSet'' AS 预设引发剂1蠕动泵速度  
  ,''Ini1Speed'' AS 引发剂1蠕动泵速度  
  ,''Ini1TempSet'' AS 预设引发剂1加入温度  
  ,''Ini1Temp'' AS 引发剂1加入温度  
  ,''Ini2BTime'' AS 引发剂2开始时间  
  ,''Ini2JoinTime'' AS 引发剂2加入时间  
  ,''Ini2SpeedSet'' AS 预设引发剂2蠕动泵速度  
  ,''Ini2Speed'' AS 引发剂2蠕动泵速度  
  ,''OffC1SpeedSet'' AS 预设离心1转速  
  ,''OffC1Speed'' AS 离心1转速  
  ,''OffC1Time'' AS 离心1时间  
  ,''OffC2SpeedSet'' AS 预设离心2转速  
  ,''OffC2Speed'' AS 离心2转速  
  ,''OffC2Time'' AS 离心2时间  
  ,''OffC3SpeedSet'' AS 预设离心3转速  
  ,''OffC3Speed'' AS 离心3转速  
  ,''OffC3Time'' AS 离心3时间  
  ,''OffC4SpeedSet'' AS 预设离心4转速  
  ,''OffC4Speed'' AS 离心4转速  
  ,''OffC4Time'' AS 离心4时间  
  ,''OffC5SpeedSet'' AS 预设离心5转速  
  ,''OffC5Speed'' AS 离心5转速  
  ,''OffC5Time'' AS 离心5时间  
  ,''Ppole'' AS 分散液带电性正极  
  ,''Npole'' AS 分散液带电性负极  
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''
  '  -- 50列  
    
  -- 设定需要粒子表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Partical')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Partical');  
   
 END  
 
 
   
 IF @ResultType = '新工艺粒子数据'  
 begin  
  SET @SelectValue = 'distinct   
  part1.[ID]  
  ,part1.[Code]  
  ,CONVERT(varchar(100), part1.[OptDate], 23) AS [OptDate]  
  ,part1.[PType]  
  ,part1.[name]
  ,part1.[Class]  
  ,part1.[Kettle]  
  ,part1.[PigmentCode]  
  ,part1.GrindPress
  ,part1.GrindTimeB
  ,part1.GrindTimeE
  ,part1.GrindOutPut
  ,part1.CLTemp10MIN
  ,part1.CLTemp20MIN
  ,part1.CLTemp30MIN
  ,part1.CLTemp60MIN
  ,part1.CLTemp90MIN
  ,part1.CLTemp120MIN
  ,part1.LQTemp10MIN
  ,part1.LQTemp20MIN
  ,part1.LQTemp30MIN
  ,part1.LQTemp60MIN
  ,part1.LQTemp90MIN
  ,part1.LQTemp120MIN
  ,part1.GHL
  ,part1.[RemarK]'   

  SET @WhereNonull = ' And part1.Code is not null'  
    
  -- 设定需要的列头  
    
    
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号  
  ,''Code'' AS 粒子批号
  ,''name'' AS 粒子系列
  ,''OptDate'' AS 操作日期
  ,''PType'' AS 粒子类别
  ,''Class'' AS 粒子工艺
  ,''Kettle'' AS 粒子反应釜编号   
  ,''PigmentCode'' AS 颜料批次  
  ,''GrindPress'' AS 研磨压力
  ,''GrindTimeB'' AS 研磨开始  
  ,''GrindTimeE'' AS 研磨结束
  ,''GrindOutPut'' AS 研磨产量  
  ,''CLTemp10MIN'' AS 出料温度10
  ,''CLTemp20MIN'' AS 出料温度20
  ,''CLTemp30MIN'' AS 出料温度30
  ,''CLTemp60MIN'' AS 出料温度60
  ,''CLTemp90MIN'' AS 出料温度90
  ,''CLTemp120MIN'' AS 出料温度120
  ,''LQTemp10MIN'' AS 冷却水温度10
  ,''LQTemp20MIN'' AS 冷却水温度20
  ,''LQTemp30MIN'' AS 冷却水温度30
  ,''LQTemp60MIN'' AS 冷却水温度60
  ,''LQTemp90MIN'' AS 冷却水温度90
  ,''LQTemp120MIN'' AS 冷却水温度120
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  '  -- 26列  
    
  -- 设定需要粒子表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_ParticalSp')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_ParticalSp');  
   
 END  
 
   
 IF @ResultType = '油项数据'  
 begin  
  SET @SelectValue = 'distinct oil.[ID],oil.[Code], CONVERT(varchar(100), oil.[OptDate], 23) AS [OptDate], oil.[name], oil.[SolventG], oil.[PH], oil.[Conductivity]  
       , oil.[Viscosity], oil.[PSize05], oil.[PSize09],  
       oil.[ParticalCodes], oil.[RemarK]'   
    
    
  SET @WhereNonull = ' And oil.Code is not null'  
  -- 设定需要的列头  
    
  SET @columnNames = ' select   
  ''n'' AS 序号  
  ,''ID'' AS 编号
  ,''Code'' AS 油项批号  
  ,''name'' AS 油项系列  
  ,''OptDate'' AS 操作日期  
  ,''SolventG'' AS 溶液G编号  
  ,''PH'' AS PH值  
  ,''Conductivity'' AS 电导率  
  ,''Viscosity'' AS 粘度  
  ,''PSize05'' AS 粒子粒径05  
  ,''PSize09'' AS 粒子粒径09  
  ,''ParticalCodes'' AS 粒子编号  
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500''
  '  -- 11列  
    
  -- 设定需要油项表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Oil')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Oil');  
   
 END  
   
 IF @ResultType = '单层胶囊数据'  
 begin  
  SET @SelectValue = 'distinct Scap.[ID],CONVERT(varchar(100), Scap.[OptDate], 23) AS [OptDate]  
   ,Scap.[Code]  
   ,Scap.[Lotcode]  
   ,Scap.[SpeType]  
   ,Scap.[Kettle]  
   ,Scap.[Volume]  
   ,Scap.[GAA]  
   ,Scap.[AF0001]  
   ,Scap.[AF0003]  
   ,Scap.[BG0002Fa]  
   ,Scap.[BG0002Code]  
   ,Scap.[SetTemp41]  
   ,Scap.[Temp41]  
   ,Scap.[Time45]  
   ,Scap.[SetRspeed580]  
   ,Scap.[Rspeed580]  
   ,Scap.[SetTemp8]  
   ,Scap.[Temp8]  
   ,Scap.[Time120]  
   ,Scap.[SetTemp25]  
   ,Scap.[Temp25]  
   ,Scap.[Time360]  
   ,Scap.[SetRspeed400]  
   ,Scap.[Rspeed400]  
   ,Scap.[OutPut]  
   ,Scap.[Psize]  
   ,Scap.[PsizeSpan]  
   ,Scap.[SievingPsize]
   ,Scap.[SoildContent]  
   ,Scap.[CR]  
   ,Scap.[LBK]  
   ,Scap.[LW]  
   ,Scap.[DeltaBK]  
   ,Scap.[DeltaW]  
   ,Scap.[PH]  
   ,Scap.[PHTemp]  
   ,Scap.[Remark]'  
   
   
  SET @WhereNonull = ' And Scap.Code is not null'  
  -- 设定需要的列头  
    
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号 
  ,''OptDate'' AS 操作日期  
  ,''Code'' AS 胶囊批号  
  ,''Lotcode'' AS 胶囊编号  
  ,''SpeType'' AS 分离方式  
  ,''Kettle'' AS 釜位  
  ,''Volume'' AS 体积  
  ,''GAA'' AS 冰醋酸  
  ,''AF0001'' AS AF001批次  
  ,''AF0003'' AS AF003批次  
  ,''BG0002Fa'' AS BG0002厂家  
  ,''BG0002Code'' AS BG0002批次  
  ,''SetTemp41'' AS 温度41设定值  
  ,''Temp41'' AS 温度41  
  ,''Time45'' AS 时间45  
  ,''SetRspeed580'' AS 转速580设定值  
  ,''Rspeed580'' AS 转速580  
  ,''SetTemp8'' AS 温度8设定值  
  ,''Temp8'' AS 温度8  
  ,''Time120'' AS 时间120  
  ,''SetTemp25'' AS 温度25设定值  
  ,''Temp25'' AS 温度25  
  ,''Time360'' AS 时间360  
  ,''SetRspeed400'' AS 转速400设定值  
  ,''Rspeed400'' AS 转速400  
  ,''OutPut'' AS 产值  
  ,''Psize'' AS 胶囊粒径  
  ,''PsizeSpan'' AS  粒径Span
  ,''SievingPsize'' AS  筛分粒径  
  ,''SoildContent'' AS 胶囊固含量  
  ,''CR'' AS CR值  
  ,''LBK'' AS L黑  
  ,''LW'' AS L白  
  ,''DeltaBK'' AS delta黑  
  ,''DeltaW'' AS delta白  
  ,''PH'' AS PH  
  ,''PHTemp'' AS PH温度  
  ,''Remark'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'' '  
    -- 37列  
    
  -- 设定需要油项表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_SinCapsule')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_SinCapsule');  
   
  
 END  
   
 IF @ResultType = '双层胶囊数据'  
 BEGIN   
  SET @SelectValue = 'distinct CONVERT(varchar(100), Dcap.[OptDate], 23) AS [OptDate]  
   ,Dcap.[ID] 
   ,Dcap.[Code]  
   ,Dcap.[SpeType]  
   ,Dcap.[Kettle]  
   ,Dcap.[GAA]  
   ,Dcap.[AF0001]  
   ,Dcap.[AF0003]  
   ,Dcap.[BG0002Fa]  
   ,Dcap.[BG0002Code]  
   ,Dcap.[Temp41Set]  
   ,Dcap.[Temp41]  
   ,Dcap.[Time60]  
   ,Dcap.[Rspeed400Set]  
   ,Dcap.[Rspeed400]  
   ,Dcap.[Temp8Set]  
   ,Dcap.[Temp8]  
   ,Dcap.[Time120]  
   ,Dcap.[Temp25Set]  
   ,Dcap.[Temp25]  
   ,Dcap.[Time360]  
   ,Dcap.[SetRspeed500]  
   ,Dcap.[Rspeed500]  
   ,Dcap.[OutPut]  
   ,Dcap.[Psize]  
   ,Dcap.[PsizeSpan]  
   ,Dcap.[SoildContent]  
   ,Dcap.[CR]  
   ,Dcap.[LBK]  
   ,Dcap.[LW]  
   ,Dcap.[DeltaBK]  
   ,Dcap.[DeltaW]  
   ,Dcap.[PH]  
   ,Dcap.[PHTemp]  
   ,Dcap.[Remark]'  
     
  SET @WhereNonull = ' And Dcap.Code is not null'  
  -- 设定需要的列头  
    
  SET @columnNames = 'select   
  ''OptDate'' AS 操作日期  
  ,''ID'' AS 编号  
  ,''Code'' AS 胶囊批号  
  ,''SpeType'' AS 分离方式  
  ,''Kettle'' AS 釜位  
  ,''GAA'' AS 冰醋酸  
  ,''AF0001'' AS AF001批次  
  ,''AF0003'' AS AF003批次  
  ,''BG0002Fa'' AS BG0002厂家  
  ,''BG0002Code'' AS BG0002批次  
  ,''Temp41Set'' AS 温度41设定值  
  ,''Temp41'' AS 温度41  
  ,''Time60'' AS 时间60  
  ,''Rspeed400Set'' AS 转速400设定值  
  ,''Rspeed400'' AS 转速400 
  ,''Temp8Set'' AS 温度8设定值   
  ,''Temp8'' AS 温度8  
  ,''Time120'' AS 时间120  
  ,''Temp25Set'' AS 温度25设定值   
  ,''Temp25'' AS 温度25  
  ,''Time360'' AS 时间360  
  ,''SetRspeed500'' AS 转速500设定值  
  ,''Rspeed500'' AS 转速500  
  ,''OutPut'' AS 产值  
  ,''Psize'' AS 胶囊粒径  
  ,''PsizeSpan'' AS  筛分粒径  
  ,''SoildContent'' AS 胶囊固含量  
  ,''CR'' AS CR值  
  ,''LBK'' AS L黑  
  ,''LW'' AS L白  
  ,''DeltaBK'' AS delta黑  
  ,''DeltaW'' AS delta白  
  ,''PH'' AS PH  
  ,''PHTemp'' AS PH温度  
  ,''Remark'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'' '  -- 36列 ...  
    
  -- 设定需要油项表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_DouCapsule')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_DouCapsule');  
   
 end  
      
    -------- 设定参数编号查询项  
      
    IF( @CodeValue IS NOT NULL and @CodeValue <> '')  
    BEGIN   
  IF( @CodeType = '颜料编号' )  
  BEGIN  
     SET @WhereCode = 'And Pigm.Code like ''%' + @CodeValue + '%'' ';  
     IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
     INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Pigment');  
  END 
  
   IF( @CodeType = '颜料编号ID' )  
  begin
     SET @WhereCode = 'And Pigm.ID=' + @CodeValue;  
     IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
     INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Pigment'); 
  end
  
    
  IF( @CodeType = '粒子编号' )  
  BEGIN  
   SET @WhereCode = 'And Part.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Partical');  
  END  
  
  IF( @CodeType = '粒子编号ID' )  
  BEGIN  
   SET @WhereCode = 'And Part.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Partical');  
  END  
    
  IF( @CodeType = '新工艺粒子编号' )  
  BEGIN  
   SET @WhereCode = 'And Part1.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_ParticalSp');  
  END  
  
  IF( @CodeType = '新工艺粒子编号ID' )  
  BEGIN  
   SET @WhereCode = 'And Part1.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_ParticalSp');  
  END  
  
  
  IF( @CodeType = '油项编号' )  
  BEGIN  
   SET @WhereCode = 'And Oil.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Oil');  
  END  
  
  IF( @CodeType = '油项编号ID' )  
  BEGIN  
   SET @WhereCode = 'And Oil.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Oil');  
  END  
    
  IF( @CodeType = '单层胶囊编号' )  
  BEGIN  
   SET @WhereCode = 'And SCap.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_SinCapsule');  
  END 
  
  IF( @CodeType = '单层胶囊编号ID' )  
  BEGIN  
   SET @WhereCode = 'And SCap.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_SinCapsule');  
  END 
    
  IF( @CodeType = '双层胶囊编号' )  
  BEGIN  
   SET @WhereCode = 'And Dcap.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_DouCapsule');  
  END  
  
  
  IF( @CodeType = '双层胶囊编号ID' )  
  BEGIN  
   SET @WhereCode = 'And Dcap.id=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Pigment')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_DouCapsule');  
  END 
    
    END  
   
 IF( (@ParaValueL <> '' AND @ParaValueL IS NOT NULL) OR (@ParaValueL <> '' AND @ParaValueL IS NOT NULL))  
 BEGIN  
    --select @WhereValueName = ColName From Bconf_ColNameToChName    
    SET @WhereValueName =@ParaType    
    SET @WhereValue = CASE when @ParaValueL <> '' THEN ' AND ' + @WhereValueName + ' >= ' + @ParaValueL END + CASE when @ParaValueH <> ''          THEN ' AND ' + @WhereValueName + ' <= ' + @ParaValueH END  
    
 END  
    
   
   
 ------- From段 判断取表 --------  
   
 --SET @TalbeValue = 'INTO #Result FROM dbo.Bs_Pigment AS pigm   
 --   FULL join Bs_PigmentToPartical AS a on pigm.ID = a.PigmentID  
 --   FULL join Bs_Partical AS part on part.ID = a.ParticalID  
 --   FUll join Bs_ParticalToOil AS b on b.ParticalID = part.ID  
 --   FUll join BS_Oil AS Oil on Oil.ID = b.OilID  
 --   FUll Join BS_SinCapsule AS Scap on Scap.OilID = Oil.ID  
 --   FUll Join BS_DouCapsule AS Dcap on Dcap.OilID = Oil.ID '  
    
     SET @TalbeValue = 'INTO #Result FROM dbo.Bs_Pigment AS pigm   
    FULL join Bs_PigmentToPartical AS a on pigm.ID = a.PigmentID  
    FULL join (select Partical.*,ser.name from Bs_Partical Partical
    left join Bs_ParticalSeries ser on Partical.Series=ser.id
    ) AS part on part.ID = a.ParticalID 
    FULL join (select Partical.*,ser.name from Bs_ParticalSp Partical
    left join Bs_ParticalSeries ser on Partical.Series=ser.id
    ) AS part1 on part1.ID = a.ParticalID
    FUll join Bs_ParticalToOil AS b on b.ParticalID = part.ID  
    FUll join (select oil.*,ser.name from BS_Oil oil
    left join Bs_OilSeries ser on oil.Series=ser.id
    ) AS Oil on Oil.ID = b.OilID  
    FUll Join BS_SinCapsule AS Scap on Scap.OilID = Oil.ID  
    FUll Join BS_DouCapsule AS Dcap on Dcap.OilID = Oil.ID '  
   
 PRINT @columnNames  
 exec (@columnNames )  
   
   
    if(@OrderFields='')  
  set @OrderFields ='optdate desc'  
      
 -- 数据分页  
   
 set @Pagesql =  
 '  
  EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
  ,@fldName = '' ' + @OrderFields + ' ''                               
  ,@rowcount = @totalRow   
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0  
  ,@SumColumn = ''  
  ,@AvgColumn = ''  
 '  
   
   
 PRINT 'select ' + @SelectValue + @TalbeValue + 'WHERE 1=1 ' + @WhereCode + @WhereValue + @WhereNonull + '; DECLARE @totalRow int = @@ROWCOUNT ; ' + @Pagesql  
 exec ('select ' + @SelectValue + @TalbeValue + 'WHERE 1=1 ' + @WhereCode + @WhereValue + @WhereNonull + '; DECLARE @totalRow int = @@ROWCOUNT ; ' + @Pagesql)  
 --select   'select ' + @SelectValue + @TalbeValue + 'WHERE 1=1 ' + @WhereCode + @WhereValue + @WhereNonull + 'as 测试结果'  
 
  INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_AllQuery_List',
        '全数据查询', @ResultType,@WhereCode + @WhereValue )  
END   
--select * from tbl_sys_myMenu  
go

