-- =============================================
-- Author:		YangYi
-- Create date: 时间不记得了
-- Description:	执行远程数据获取的时候得到权限
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Sys_GetOpenDataSource]

AS
BEGIN

 -- 打开使用 OpenDataSource权限 --
 
EXEC sys.sp_configure @configname = 'show advanced options',@configvalue = 1
RECONFIGURE
EXEC sys.sp_configure @configname = 'Ad Hoc Distributed Queries',@configvalue = 1

RECONFIGURE

END
go

