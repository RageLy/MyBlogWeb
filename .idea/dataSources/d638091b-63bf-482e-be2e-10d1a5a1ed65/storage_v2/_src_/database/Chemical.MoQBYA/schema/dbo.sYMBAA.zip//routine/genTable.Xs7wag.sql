-- =============================================
-- Author:		<刘轶>
-- create date: <2014年7月7日>
-- Description:	<Description,分割字符串,>
-- =============================================
CREATE PROCEDURE [genTable]
@step INT =0
AS
    BEGIN
        DECLARE @num INT= 1;
        DECLARE @Str NVARCHAR(50)= '';
        --CREATE TABLE [Bs_Compound_ActPoint]
        --    (
        --      ID INT IDENTITY(1, 1) ,
        --      CmpID INT,
        --      Name NVARCHAR(500) ,
        --      ActLocation NVARCHAR(500),
        --      AfterLocation NVARCHAR(20),
        --      step int
        --    );
        CREATE TABLE [#result]
            (
              ID INT IDENTITY(1, 1) ,
              cmpID int,
              [TarSmCode1] NVARCHAR(500) ,
              [TarActPoint] NVARCHAR(500)
          
            );
        INSERT  INTO #result
                ( cmpID ,TarSmCode1 ,
                  TarActPoint
                )
                SELECT  TarSmCode1ID AS cmpID ,TarSmCode1 ,
                        TarActPoint
                FROM    Bs_Act_MNByOutCode
                WHERE   TarActPoint <> ''
                        AND step = @step;
        WHILE ( ( SELECT    COUNT(*)
                  FROM      Bs_Act_MNByOutCode
                  WHERE     TarActPoint <> ''
                            AND step = @step
                ) > = @num )
            BEGIN
                SET @Str = ( SELECT TarActPoint
                             FROM   #result
                             WHERE  ID = @num
                           );
                INSERT  INTO [Bs_Compound_ActPoint]
                        ( CmpID,Name ,
                          ActLocation,AfterLocation,step
                        )
                        SELECT  cmpID,TarSmCode1 ,
                                replace(string,' ',''),TarActPoint,@step
                        FROM    dbo.Split(@Str, ',')
                                LEFT JOIN #result ON ID = @num;
                SET @num = @num + 1;
            END;

    END;


--EXEC [genTable] 2

--DROP TABLE [Bs_Compound_ActPoint]
--SELECT * FROM Bs_Compound_ActPoint
--select cmpID, Name, ActLocation ,AfterLocation from Bs_Compound_ActPoint where  step = 1
go

