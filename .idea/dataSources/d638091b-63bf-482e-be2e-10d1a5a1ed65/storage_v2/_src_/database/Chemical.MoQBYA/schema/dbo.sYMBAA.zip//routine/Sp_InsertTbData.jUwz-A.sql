




-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2017年5月11日                                                
-- Descript: 从Excel插入涂布数据
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_InsertTbData ]
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
BEGIN
	------------------- 已有数据单独更新
	--UPDATE Bs_Coating_ZJ SET MpTbLv = MpTbLv * 100,
	--MpFdLv = MpFdLv * 100

	--UPDATE Bs_Coating_ZJ SET MpTbLv = MpTbLv * 100,
	--MpFdLv = MpFdLv * 100


	--UPDATE co 
	--SET SDJAvg = x.水滴角均值 , SDJsqt = x.水滴角标准偏差
	--FROM
	--Bs_Coating_ITO co LEFT JOIN
	--(
	--	SELECT * FROM 
	--	(
	--		SELECT ROW_NUMBER() OVER(PARTITION BY ITO卷号 ORDER BY ITO卷号) n,ITO卷号,水滴角均值,水滴角标准偏差
	--		FROM [涂布工艺$]
	--		WHERE ITO卷号 IS NOT NULL
	--	) x where n = 1
	--) x ON co.Code = x.ITO卷号

	-------------------
	----------------- 处理异常数据

	--UPDATE [涂布工艺$]
	--SET [配墨过程中pH-1] = NULL
	--WHERE [配墨过程中pH-1] = '\'

	-----------------------------------------------------------  维护基础表
	----------------- 膜片类型
	INSERT INTO Tbl_Base_MpSeries(MpSeries)
	SELECT a.F4 FROM 
	( SELECT DISTINCT F4 FROM [涂布工艺$] WHERE F4 IS NOT NULL AND F4 <> '') a
	Left JOIN Tbl_Base_MpSeries b ON a.F4 = b.MpSeries
	WHERE b.ID IS NULL

	----------------- 黏合剂类型
	INSERT INTO Tbl_Base_NhjType(NhjType)
	SELECT a.黏合剂类型 FROM 
	( SELECT DISTINCT 黏合剂类型 FROM [涂布工艺$] WHERE 黏合剂类型 IS NOT NULL  AND 黏合剂类型 <> '') a
	Left JOIN Tbl_Base_NhjType b ON 黏合剂类型 = b.NhjType
	WHERE b.ID IS NULL

	----------------- 流平剂类型
	INSERT INTO Tbl_Base_MsLpjCode(MsLpjCode)
	SELECT a.流平剂类型 FROM 
	( SELECT DISTINCT 流平剂类型 FROM [涂布工艺$] WHERE 流平剂类型 IS NOT NULL AND 流平剂类型 <> '') a
	Left JOIN Tbl_Base_MsLpjCode b ON 流平剂类型 = b.MsLpjCode
	WHERE b.ID IS NULL

	----------------- [黏合剂类型-1]
	INSERT INTO Tbl_Base_MsNhjType(MsNhjType)
	SELECT a.[黏合剂类型-1] FROM 
	( SELECT DISTINCT [黏合剂类型-1] FROM [涂布工艺$] WHERE [黏合剂类型-1] IS NOT NULL  AND [黏合剂类型-1] <> '' ) a
	Left JOIN Tbl_Base_MsNhjType b ON [黏合剂类型-1] = b.MsNhjType
	WHERE b.ID IS null

	----------------- 水的类型
	INSERT INTO Tbl_Base_MsWaterType(MsWaterType)
	SELECT a.水的类型 FROM 
	( SELECT DISTINCT 水的类型 FROM [涂布工艺$] WHERE 水的类型 IS NOT NULL AND 水的类型 <> '' ) a
	Left JOIN Tbl_Base_MsWaterType b ON 水的类型 = b.MsWaterType
	WHERE b.ID IS NULL

	----------------- 胶水型号
	INSERT INTO Tbl_Base_JsCode(JsCode,JsType)
	SELECT a.型号,a.胶水类型 FROM 
	( SELECT DISTINCT 型号,胶水类型 FROM [涂布工艺$] WHERE 型号 IS NOT NULL AND 型号 <> '' ) a
	Left JOIN Tbl_Base_JsCode b ON 型号 = b.JsCode
	WHERE b.ID IS NULL

	----------------- [风频Hz]
	INSERT INTO Tbl_Base_HxFpCode(HxFpCode)
	SELECT a.[风频Hz] FROM 
	( SELECT DISTINCT [风频Hz] FROM [涂布工艺$] WHERE [风频Hz] IS NOT NULL AND [风频Hz] <> '' ) a
	Left JOIN Tbl_Base_HxFpCode b ON [风频Hz] = b.HxFpCode
	WHERE b.ID IS NULL

	----------------- [风频]
	INSERT INTO Tbl_Base_HxFpCode(HxFpCode)
	SELECT a.风频 FROM 
	( SELECT DISTINCT 风频 FROM [涂布工艺$] WHERE 风频 IS NOT NULL AND 风频 <> '' ) a
	Left JOIN Tbl_Base_HxFpCode b ON 风频 = b.HxFpCode
	WHERE b.ID IS null

	--------------------------------------------------------------------------------------


	--------------------------------- 处理ITO ---------------------------------------------

	INSERT INTO Bs_Coating_ITO
	(Code,LWater,LEDJW,LBMN,MWater,MEDJW,MBMN,RWater,REDJW,RBMN,SDJAvg,SDJsqt)
	SELECT ITO卷号,左水接触角,左二碘甲烷接触角,左表面能,中水接触角,中二碘甲烷接触角,中表面能,右水接触角,右二碘甲烷接触角,右表面能,水滴角均值,水滴角标准偏差 
	FROM
	(
		SELECT * FROM 
		(
			SELECT ROW_NUMBER() OVER(PARTITION BY ITO卷号 ORDER BY ITO卷号) n,ITO卷号,左水接触角,左二碘甲烷接触角,左表面能,中水接触角,中二碘甲烷接触角,中表面能,右水接触角,右二碘甲烷接触角,右表面能,水滴角均值,水滴角标准偏差
			FROM [涂布工艺$]
			WHERE ITO卷号 IS NOT NULL
		) x where n = 1
	) a LEFT JOIN dbo.Bs_Coating_ITO b ON a.ITO卷号 = b.Code
	WHERE b.ID IS NULL


	--------------------- 处理工艺段

	--- 删除已经存在的 方便插入新的

	DELETE
	FROM Bs_Coating
	WHERE Code IN 
	(select DISTINCT 膜片批次号 FROM [涂布工艺$] )

	--- 


	INSERT INTO dbo.Bs_Coating
	( Code ,Lotcode ,OptDate ,MpSeries ,
	ITOCode ,
	NhjType ,NhjGHL ,NhjND ,NhjPH ,ZcjND ,ZcjGHL ,ZcjPH ,MsFsjUse ,
	MsLpjCode ,MsLpjUse ,MsNhjType ,MsNhjUse ,MsZcjUse ,MsXpjUse ,MsCapsulePH ,MsWaterType ,
	MsWaterPH ,MsWaterDDlps ,MsLPH ,MsPH1 ,MsPH2 ,MsOverPH ,MsOverND ,MsOverGHL ,MsOverZL ,MsNdBe ,MsGhlBe ,
	JsCode ,JsType ,JsNd ,JsGHL ,JsZl ,JsNdBe ,JsGhlBe ,MsTtTemp ,MsTtSd ,MsTtGTemp ,MsTtGSd ,
	MsTtITOhd ,MsTtSpeed ,MsTtKd ,MsTtJx ,
	MsHxFpCode ,MsHxFpTemp1 ,MsHxFpTemp2 ,MsHxFpTemp3 ,MsHxFpTemp4 ,MsHxFpTemp5 ,MsHxFpTemp6 ,MsHxFpTemp7 ,MsCjCd ,MsCjTemp ,MsCjSd ,
	MsCjITODown ,MsCjLXM ,
	MsCjSpeed ,MsCjZhd ,MsCjMshd ,JsTtTemp ,JsTtSd ,JsTtHd ,JsTtSpeed ,JsTtKd ,JsTtJx ,
	JsHxFpCode ,JsHxFpTemp1 ,JsHxFpTemp2 ,JsHxFpTemp3 ,JsHxFpTemp4 ,JsHxFpTemp5 ,JsHxFpTemp6 ,JsHxFpTemp7 ,JsCjCd ,JsCjTemp ,JsCjSd ,JsCjLXM ,
	JsCjSpeed ,JsCjZhd ,JsCjJshd ,info)

	SELECT 膜片批次,膜片批次号,CAST(CAST(涂布日期 AS VARCHAR(10)) AS DATETIME),mps.ID
	,ito.ID
	,Nhj.ID,CASE WHEN 黏合剂固含量 < 1 THEN 黏合剂固含量 * 100 ELSE 黏合剂固含量 END,黏合剂粘度,黏合剂pH值,增稠剂粘度,REPLACE(增稠剂固含量,'%',''),增稠剂pH值,分散剂加入量
	,lpj.ID,流平剂加入量,MsNhj.ID,黏合剂加入量,增稠剂加入量,消泡剂加入量,胶囊pH,msw.ID
	,水pH,水电导率,料pH,[配墨过程中pH-1],[配墨过程中pH-2],墨水收集时pH,墨水粘度,墨水固含量,墨水张力,涂布前粘度,涂布前固含量
	,jsc.ID,jsc.ID,胶水粘度,胶水固含量,胶水张力,涂布前胶水粘度,涂布前胶水固含量,墨水涂头温度,墨水涂头湿度,井下罐温度,[井下罐湿度%]
	,SUBSTRING(LTRIM([ITO厚度]),0,4),墨水泵速,涂幅宽度,墨水涂头间隙
	,fpc.ID,烘箱温度1,烘箱温度2,烘箱温度3,烘箱温度4,烘箱温度5,烘箱温度6,烘箱温度7,墨水涂布长度,REPLACE(墨水车间温度,'℃',''),墨水车间湿度
	,CASE WHEN 检查ITO导电面是否向下 = '√' THEN 1 ELSE 0 END,CASE WHEN 传送辊是否覆离型膜 = '否' THEN 2 ELSE 1 END
	,墨水车速,涂墨总厚度,墨水层厚度,REPLACE(胶水涂头温度,'℃',''),胶水涂头湿度,厚度,胶水泵速,涂幅宽度1,胶水涂头间隙
	,fpc2.ID,温度1,温度2,温度3,温度4,温度5,温度6,温度7,胶水涂布长度,胶水车间温度,胶水车间湿度,CASE WHEN 传送辊是否覆离型膜1 = '是' THEN 1 ELSE 2 END,
	胶水车速,涂胶总厚度,胶水层厚度,备注
	FROM [涂布工艺$]
	LEFT JOIN dbo.Bs_Coating_ITO ito ON ITO卷号 = ito.Code
	LEFT JOIN Tbl_Base_MpSeries mps ON F4 = mps.MpSeries
	LEFT JOIN Tbl_Base_NhjType Nhj ON 黏合剂类型 = Nhj.NhjType
	LEFT JOIN dbo.Tbl_Base_MsLpjCode lpj ON 流平剂类型 = lpj.MsLpjCode
	LEFT JOIN dbo.Tbl_Base_MsNhjType MsNhj ON [黏合剂类型-1] = MsNhj.MsNhjType
	LEFT JOIN dbo.Tbl_Base_MsWaterType msw ON 水的类型 = msw.MsWaterType
	LEFT JOIN dbo.Tbl_Base_JsCode jsc ON 型号 = jsc.JsCode
	LEFT JOIN dbo.Tbl_Base_HxFpCode fpc ON [风频Hz] = fpc.HxFpCode
	LEFT JOIN dbo.Tbl_Base_HxFpCode fpc2 ON 风频 = fpc2.HxFpCode
	WHERE 膜片批次 IS NOT NULL

	--------------------------------------- 处理质检

	------- 质检基础数据处理

	---  墨水段数
	INSERT INTO Tbl_Base_MSds([type])
	SELECT a.墨水段数 FROM 
	( SELECT DISTINCT 墨水段数 FROM [涂布检测$] WHERE 墨水段数 IS NOT NULL AND 墨水段数 <> '') a
	Left JOIN Tbl_Base_MSds b ON 墨水段数 = b.[type]
	WHERE b.ID IS null

	INSERT INTO Tbl_Base_JSds([type])
	SELECT a.胶水段数 FROM 
	( SELECT DISTINCT 胶水段数 FROM [涂布检测$] WHERE 胶水段数 IS NOT NULL AND 胶水段数 <> '') a
	Left JOIN Tbl_Base_JSds b ON 胶水段数 = b.[type]
	WHERE b.ID IS null

	INSERT INTO Tbl_Base_TbBad([type])
	SELECT a.[第一大_不良项] FROM 
	( SELECT DISTINCT [第一大_不良项] FROM [涂布检测$] WHERE [第一大_不良项] IS NOT NULL AND [第一大_不良项] <> '') a
	Left JOIN Tbl_Base_TbBad b ON [第一大_不良项] = b.[type]
	WHERE b.ID IS NULL

	INSERT INTO Tbl_Base_TbBad([type])
	SELECT a.[第二大_不良项] FROM 
	( SELECT DISTINCT [第二大_不良项] FROM [涂布检测$] WHERE [第二大_不良项] IS NOT NULL AND [第二大_不良项] <> '') a
	Left JOIN Tbl_Base_TbBad b ON [第二大_不良项] = b.[type]
	WHERE b.ID IS NULL

	INSERT INTO Tbl_Base_TbBad([type])
	SELECT a.[第三大_不良项] FROM 
	( SELECT DISTINCT [第三大_不良项] FROM [涂布检测$] WHERE [第三大_不良项] IS NOT NULL AND [第三大_不良项] <> '') a
	Left JOIN Tbl_Base_TbBad b ON [第三大_不良项] = b.[type]
	WHERE b.ID IS null

	------- 质检基础数据处理完毕

	---- 删除已有的


	DELETE
	FROM Bs_Coating_ZJ
	WHERE MpCode IN 
	(select DISTINCT 膜片批次 FROM [涂布检测$] where 膜片批次 is not null )

	insert into dbo.Bs_Coating_ZJ
	( TbDate ,MpCode , MpLotCode ,CoatingCode ,MSds ,JsDs 
	, CoatingID , MpTbLv ,MpFdLv ,
	PointBK,PointW ,PointM ,PointH ,LineSW ,LineHW ,LineGS ,JsGH ,JsQP ,ScJP ,ScSc ,ScKD ,ZcZK ,ZcTFBZ ,ZcQT ,ZcHDBZ
	,SYJudge,OEDJudge,Bad1Type ,Bad2Type ,Bad3Type 
	,TestDate ,min0LBK ,min2LBK ,min0LW ,min2LW ,min2detaLBK ,min2detaLW ,Dbd ,WBdata ,Qddl)

	SELECT CAST(CAST(涂布日期 AS VARCHAR(10)) AS DATETIME),膜片批次,膜片批次,NULL,md.ID,jd.ID
	,b.id,膜片涂布利用率 * 100 ,膜片分段利用率 * 100
	,[黑_点],[白_点],[麻_点],[灰阶点],[竖_纹],[横_纹],[刮_伤],[胶水刮痕],[胶_水_气_泡],[桔皮],[色差],[空_点],[针_孔],[涂_幅_不_足],[缺_涂],[厚_度_不_足]
	,sy.s,Oed.s,bad.id,bad2.id,bad3.id
	,CAST(测试日期 AS DATETIME),[0minL黑均值],[2minL黑均值],[0minL白均值],[2minL白均值],[2min△LBK],[2min△LW],[对比度],[白色B值（2min)-5~1],[单位面积驱动电流]
	FROM [涂布检测$] a
	left JOIN dbo.Tbl_Base_MSds md ON a.墨水段数 = md.[type]
	LEFT JOIN dbo.Tbl_Base_JSds jd ON a.胶水段数 = jd.[type]
	LEFT JOIN dbo.Bs_Coating b ON a.膜片批次 = b.LotCode
	LEFT JOIN dbo.Tbl_Base_TbBad bad ON [第一大_不良项] = bad.[Type]
	LEFT JOIN dbo.Tbl_Base_TbBad bad2 ON [第二大_不良项] = bad2.[Type]
	LEFT JOIN dbo.Tbl_Base_TbBad bad3 ON [第三大_不良项] = bad3.[Type]
	LEFT join tbl_Base_Judge sy ON 生益判定 = sy.judge
	LEFT join tbl_Base_Judge Oed ON Oed判定 = Oed.judge
	WHERE 膜片批次 is not null

	------------------- 更新工艺段引用的双层胶囊ID 
	-- 1
	UPDATE co 
	SET DouCapsule1 = x.ID
	FROM
	Bs_Coating co LEFT JOIN
	(
		select a.膜片批次号,b.ID from
		[涂布工艺$] a INNER join Bs_DouCapsule b on a.双层胶囊1编号 = b.Code
	) x ON co.Lotcode = x.膜片批次号
	WHERE co.DouCapsule1 is NULL

	-- 2
	UPDATE co 
	SET DouCapsule2 = x.ID
	FROM
	Bs_Coating co LEFT JOIN
	(
		select a.膜片批次号,b.ID from
		[涂布工艺$] a INNER join Bs_DouCapsule b on a.双层胶囊2编号 = b.Code
	) x ON co.Lotcode = x.膜片批次号
	WHERE co.DouCapsule1 is NULL

	-- 3
	UPDATE co 
	SET DouCapsule3 = x.ID
	FROM
	Bs_Coating co LEFT JOIN
	(
		select a.膜片批次号,b.ID from
		[涂布工艺$] a INNER join Bs_DouCapsule b on a.双层胶囊3编号 = b.Code
	) x ON co.Lotcode = x.膜片批次号
	WHERE co.DouCapsule1 is NULL

	-- 4
	UPDATE co 
	SET DouCapsule4 = x.ID
	FROM
	Bs_Coating co LEFT JOIN
	(
		select a.膜片批次号,b.ID from
		[涂布工艺$] a INNER join Bs_DouCapsule b on a.双层胶囊4编号 = b.Code
	) x ON co.Lotcode = x.膜片批次号
	WHERE co.DouCapsule1 is NULL

	-- 5
	UPDATE co 
	SET DouCapsule5 = x.ID
	FROM
	Bs_Coating co LEFT JOIN
	(
		select a.膜片批次号,b.ID from
		[涂布工艺$] a INNER join Bs_DouCapsule b on a.双层胶囊5编号 = b.Code
	) x ON co.Lotcode = x.膜片批次号
	WHERE co.DouCapsule1 is NULL

	-- 6
	UPDATE co 
	SET DouCapsule6 = x.ID
	FROM
	Bs_Coating co LEFT JOIN
	(
		select a.膜片批次号,b.ID from
		[涂布工艺$] a INNER join Bs_DouCapsule b on a.双层胶囊6编号 = b.Code
	) x ON co.Lotcode = x.膜片批次号
	WHERE co.DouCapsule1 is NULL


END
-------------------
go

