CREATE function [dbo].fn_GetPartAmount(  
@table varchar(50)
)
returns @Result TABLE
(
PartID INT ,
PartLocationID INT,
Quantity DECIMAL(18,2),
PartAmount DECIMAL(18,2)
) 
BEGIN 
DECLARE @Sql VARCHAR(max)=''
SET @Sql='
;WITH cte AS 
(
SELECT iod.PartID,iod.PartLocationID,e.EnumType,st.IOStoreTime,iod.Quantity,iod.PartAmount
FROM dbo.Tbl_AftIO_PartIODetail AS iod
LEFT JOIN dbo.Tbl_AftIO_PartInOutStore AS st ON st.IOStoreID = iod.IOStoreID
LEFT JOIN dbo.Tbl_Config_EnumType AS e ON e.EnumValue = st.StoreType
INNER JOIN '+@table+' AS t ON iod.PartID = t.PartID AND t.PartLocationID = iod.PartLocationID
)

SELECT c1.PartID,c1.PartLocationID,c1.Quantity,c1.EnumType,c1.IOStoreTime,c1.PartAmount
,SUM(CASE WHEN c2.EnumType =''入库'' THEN c2.Quantity ELSE -c2.Quantity END ) AS Yu
,SUM(CASE WHEN c2.EnumType =''入库'' THEN c2.Quantity END ) AS ru
,SUM(CASE WHEN c2.EnumType =''出库'' THEN c2.Quantity END ) AS chu
INTO #Store
FROM cte AS c1
LEFT JOIN cte AS c2 ON c2.PartID = c1.PartID AND c2.PartLocationID = c1.PartLocationID AND c2.IOStoreTime <= c1.IOStoreTime
GROUP BY c1.PartID,c1.PartLocationID,c1.Quantity,c1.EnumType,c1.IOStoreTime,c1.PartAmount
ORDER BY c1.IOStoreTime

SELECT PartID,PartLocationID, MAX(chu) AS maxOut INTO #max_Store FROM #Store GROUP BY PartID,PartLocationID

SELECT #Store.* 
INTO #Store_in
FROM #Store 
INNER JOIN #max_Store AS m ON m.PartID = #Store.PartID AND m.PartLocationID = #Store.PartLocationID
WHERE ru > maxOut


SELECT PartID,PartLocationID ,MIN(chu) AS minOut,SUM(CASE WHEN EnumType=''入库'' THEN Quantity end) sum_in 
INTO #Min_Store 
FROM #Store_in GROUP BY PartID,PartLocationID

UPDATE X SET Quantity = a.yu-sum_in+Quantity
FROM #Store_in AS X
LEFT JOIN 
(
SELECT PartID,PartLocationID,yu
FROM (
SELECT #Store_in.PartID,#Store_in.PartLocationID,yu,ROW_NUMBER() OVER (PARTITION BY #Store_in.PartID,#Store_in.PartLocationID ORDER BY IOStoreTime desc) AS n FROM #Store_in 
INNER JOIN #max_Store AS m ON m.PartID = #Store_in.PartID AND m.PartLocationID = #Store_in.PartLocationID
WHERE chu = maxOut 
) AS x WHERE n = 1
)AS a ON a.PartID = X.PartID AND a.PartLocationID = X.PartLocationID
INNER JOIN #Min_Store AS mi ON mi.PartID = X.PartID AND mi.PartLocationID = X.PartLocationID
WHERE EnumType=''入库'' AND chu  = minOut

;WITH cte AS 
(
SELECT PartID,PartLocationID,Quantity,''出库'' AS EnumType,0 AS PartAmount,''2000-01-01'' as thistime FROM '+@table+'
UNION ALL
SELECT PartID,PartLocationID,Quantity,EnumType,PartAmount,IOStoreTime as thistime FROM #Store_in WHERE EnumType = ''入库''
) 
SELECT c1.PartID,c1.PartLocationID,c1.Quantity,c1.EnumType,c1.PartAmount,c1.thistime
,SUM(CASE WHEN c2.EnumType =''入库'' THEN c2.Quantity ELSE -c2.Quantity END ) AS Yu
,SUM(CASE WHEN c2.EnumType =''入库'' THEN c2.Quantity END ) AS ru
,SUM(CASE WHEN c2.EnumType =''出库'' THEN c2.Quantity END ) AS chu
INTO #Store_Out
FROM cte AS c1
LEFT JOIN cte AS c2 ON c2.PartID = c1.PartID AND c2.PartLocationID = c1.PartLocationID AND c2.thistime < c1.thistime
GROUP BY c1.PartID,c1.PartLocationID,c1.Quantity,c1.EnumType,c1.PartAmount,c1.thistime
ORDER BY c1.thistime

INSERT INTO @Result
( PartLocationID,PartID,PartAmount,Quantity)
SELECT PartID,PartLocationID
,CASE WHEN -yu >Quantity THEN Quantity ELSE -Yu END AS Quantity,PartAmount 
FROM #Store_Out WHERE Yu<=0


'





RETURN
END
go

