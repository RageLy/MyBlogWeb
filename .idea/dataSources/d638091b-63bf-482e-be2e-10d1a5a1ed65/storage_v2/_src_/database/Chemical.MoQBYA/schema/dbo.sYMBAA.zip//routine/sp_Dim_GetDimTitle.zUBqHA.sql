CREATE PROC sp_Dim_GetDimTitle
@Dims VARCHAR(max)=''
AS 
BEGIN
SELECT DimNum,Name_ch FROM dbo.Tbl_AnsCom_DIimToTable AS a
INNER JOIN dbo.Split(@dims,',') AS b ON a.DimNum = b.string
END
go

