
CREATE PROC [dbo].[SP_SYS_EditDgvColumns]
@DeleteColumns VARCHAR(max)='',
@AddColumns VARCHAR(max)='',
@DgvGuid VARCHAR(max)=''
AS
BEGIN
SELECT string INTO #tmpDel FROM dbo.Split(@DeleteColumns,',')
SELECT * FROM #tmpDel

--UPDATE x SET SortColumns =
select
CASE WHEN LEFT(REPLACE(SortColumns,string,''),1)=',' THEN right( REPLACE(SortColumns,string,''),LEN(REPLACE(SortColumns,string,'')) -1)
WHEN RIGHT(REPLACE(SortColumns,string,''),1)=',' THEN LEFT( REPLACE(SortColumns,string,''),LEN(REPLACE(SortColumns,string,'')) -1)
ELSE REPLACE(REPLACE(SortColumns,string,''),',,',',') END
,--HideColumns = 
CASE WHEN LEFT( REPLACE(HideColumns,string,''),1)=',' THEN right( REPLACE(HideColumns,string,''),LEN(REPLACE(HideColumns,string,'')) -1)
WHEN RIGHT(REPLACE(HideColumns,string,''),1)=',' THEN LEFT( REPLACE(HideColumns,string,''),LEN(REPLACE(HideColumns,string,'')) -1)
ELSE REPLACE(REPLACE(HideColumns,string,''),',,',',') END
--,FroZenColumn = CASE when string=FroZenColumn THEN NULL ELSE FroZenColumn end
FROM Tbl_Sys_CsUserDgvConfiger AS x
FULL JOIN #tmpDel ON 1=1
WHERE DgvGuid=@DgvGuid

UPDATE x set SortColumns=SortColumns+','+@AddColumns
FROM Tbl_Sys_CsUserDgvConfiger AS x
WHERE DgvGuid=@DgvGuid

END
go

