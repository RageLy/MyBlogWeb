

                                           
CREATE PROCEDURE [dbo].[Sp_DataManagement_Pigment_TypeSearch]                                                                                    
@EmpID VARCHAR(500)=''   
,@SerchPara VARCHAR(500)=''  -- 此参数由框架自动传入，不在XML中配置
AS
BEGIN
  SELECT id, LTRIM(RTRIM(Code)) AS Code FROM Bs_Pigment
	WHERE  Code LIKE '%' + @SerchPara + '%' 
			AND Code IS NOT NULL AND LEN(Code) <> 0
    ORDER BY Code
END
go

