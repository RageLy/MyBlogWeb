--EXEC Sp_Act_Detail '4','','0','1','15'
CREATE PROCEDURE Sp_Act_Detail
    @Para NVARCHAR(100) = '' ,
    @BaseCompoundName NVARCHAR(100),
    @OrderFields VARCHAR(100) = '' ,
    @EmpID INT = 1 ,
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15'
AS
    BEGIN
    DECLARE @Code NVARCHAR(100)=''
    IF @Para<>''
    BEGIN

    SET @Code=@Para
     SELECT  'n' AS '序号' ,
                'orgSmCode1' AS '原材料1Smiles编码' ,
                'orgSmCode2' AS '原材料2Smiles编码' ,
                'ruleCode1' AS '原材料1可反应部分' ,
                'ruleCode2' AS '原材料2可反应部分' ,
                'tarSmCode1' AS '目标化合物1Smiles编码' ,
                'tarSmCode2' AS '目标化合物2Smiles编码' ,
                'ActTime' AS '时间/h' ,
                'orgNum1' AS '原料1投料量/g' ,
                'orgNum2' AS '原料2投料量/g' ,
                'TarNum1' AS '目标化合物1量/g' ,
                'TarNum2' AS '目标化合物2量/g' ,
                'Temp' AS '温度/℃' ,
                'Solvent' AS '使用溶剂' ,
                'Reagent' AS '试剂' ,
                'Gas' AS '气体' ,
                'Yield' AS '化合物ID'
        UNION ALL
        SELECT  'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500';
 

 
        SELECT  B1.Name orgSmCode1 ,
                B2.Name orgSmCode2 ,
                BR1.Name ruleCode1 ,
                BR2.Name ruleCode2 ,
                T1.Name tarSmCode1 ,
                T2.Name tarSmCode2 ,
                ActTime ,
                orgNum1 ,
                orgNum2 ,
                TarNum1 ,
                TarNum2 ,
                Temp ,
                Solvent ,
                Reagent ,
                Gas ,
                Yield
        INTO    Resultact
        FROM    dbo.Bs_Act_Mn
                LEFT JOIN dbo.Bs_BaseCompound B1 ON B1.ID = Bs_Act_Mn.orgSmID1
                LEFT JOIN dbo.Bs_BaseCompound B2 ON B2.ID = Bs_Act_Mn.orgSmID2
                LEFT JOIN dbo.Bs_BaseCompound T1 ON T1.ID = Bs_Act_Mn.tarSmID1
                LEFT JOIN dbo.Bs_BaseCompound T2 ON T2.ID = Bs_Act_Mn.tarSmID2
                LEFT JOIN dbo.Bs_ActRulers R1 ON R1.ID = Bs_Act_Mn.ruleID1
                LEFT JOIN dbo.Tbl_Base_ActRules BR1 ON R1.ActSmiles = BR1.ID
                LEFT JOIN dbo.Bs_ActRulers R2 ON R2.ID = Bs_Act_Mn.ruleID2
                LEFT JOIN dbo.Tbl_Base_ActRules BR2 ON R2.ActSmiles = BR2.ID
        WHERE   B1.Name LIKE '%' + @Code + '%'
                OR B2.Name LIKE '%' + @Code + '%'
                OR BR1.Name LIKE '%' + @Code + '%'
                OR BR2.Name LIKE '%' + @Code + '%'
                OR T1.Name LIKE '%' + @Code + '%'
                OR T2.Name LIKE '%' + @Code + '%'
                OR ActTime LIKE '%' + @Code + '%'
                OR orgNum1 LIKE '%' + @Code + '%'
                OR orgNum2 LIKE '%' + @Code + '%'
                OR Solvent LIKE '%' + @Code + '%'
                OR TarNum1 LIKE '%' + @Code + '%'
                OR TarNum2 LIKE '%' + @Code + '%'
                OR Temp LIKE '%' + @Code + '%'
                OR Reagent LIKE '%' + @Code + '%'
                OR Gas LIKE '%' + @Code + '%'
                OR Yield LIKE '%' + @Code + '%';
    end
    ELSE IF @BaseCompoundName <>''
    
    BEGIN
    
    SET @Code=@BaseCompoundName
        SELECT  'n' AS '序号' ,
                'orgSmCode1' AS '原材料1Smiles编码' ,
                'orgSmCode2' AS '原材料2Smiles编码' ,
                'ruleCode1' AS '原材料1可反应部分' ,
                'ruleCode2' AS '原材料2可反应部分' ,
                'tarSmCode1' AS '目标化合物1Smiles编码' ,
                'tarSmCode2' AS '目标化合物2Smiles编码' ,
                'ActTime' AS '时间/h' ,
                'orgNum1' AS '原料1投料量/g' ,
                'orgNum2' AS '原料2投料量/g' ,
                'TarNum1' AS '目标化合物1量/g' ,
                'TarNum2' AS '目标化合物2量/g' ,
                'Temp' AS '温度/℃' ,
                'Solvent' AS '使用溶剂' ,
                'Reagent' AS '试剂' ,
                'Gas' AS '气体' ,
                'Yield' AS '化合物ID'
        UNION ALL
        SELECT  'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500' ,
                'Varchar 500';
 

 
        SELECT  B1.Name orgSmCode1 ,
                B2.Name orgSmCode2 ,
                BR1.Name ruleCode1 ,
                BR2.Name ruleCode2 ,
                T1.Name tarSmCode1 ,
                T2.Name tarSmCode2 ,
                ActTime ,
                orgNum1 ,
                orgNum2 ,
                TarNum1 ,
                TarNum2 ,
                Temp ,
                Solvent ,
                Reagent ,
                Gas ,
                Yield
        INTO    Resultact
        FROM    dbo.Bs_Act_Mn
                LEFT JOIN dbo.Bs_BaseCompound B1 ON B1.ID = Bs_Act_Mn.orgSmID1
                LEFT JOIN dbo.Bs_BaseCompound B2 ON B2.ID = Bs_Act_Mn.orgSmID2
                LEFT JOIN dbo.Bs_BaseCompound T1 ON T1.ID = Bs_Act_Mn.tarSmID1
                LEFT JOIN dbo.Bs_BaseCompound T2 ON T2.ID = Bs_Act_Mn.tarSmID2
                LEFT JOIN dbo.Bs_ActRulers R1 ON R1.ID = Bs_Act_Mn.ruleID1
                LEFT JOIN dbo.Tbl_Base_ActRules BR1 ON R1.ActSmiles = BR1.ID
                LEFT JOIN dbo.Bs_ActRulers R2 ON R2.ID = Bs_Act_Mn.ruleID2
                LEFT JOIN dbo.Tbl_Base_ActRules BR2 ON R2.ActSmiles = BR2.ID
        WHERE   R1.ID=@Code OR R2.ID=@Code
        end
        IF ( @OrderFields IS NULL
             OR @OrderFields = ''
           )
            SET @OrderFields = 'orgSmCode1';
        DECLARE @totalRow INT = ( SELECT    COUNT(1)
                                  FROM      Resultact
                                );
        EXEC dbo.Sp_Sys_Page @tblName = 'Resultact', @fldName = @OrderFields,
            @rowcount = @totalRow, @PageIndex = @PageIndex,
            @PageSize = @PageSize, @SumType = 0, @SumColumn = '',
            @AvgColumn = '';  
        DROP TABLE Resultact;
    END;


go

