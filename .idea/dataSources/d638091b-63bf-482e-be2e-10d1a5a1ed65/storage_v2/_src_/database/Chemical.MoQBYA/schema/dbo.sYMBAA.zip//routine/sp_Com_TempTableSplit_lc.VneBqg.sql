

-- =============================================    
-- Author:   杨艺    
-- Create date: 2016-03-17    
-- Description: 对维度临时表中的Name字段进行再次解析     
-- 例：把列Name中的10-2000 解析到 BeginValue和EndValue列中 再进行分组    
-- =============================================    
CREATE PROCEDURE [dbo].[sp_Com_TempTableSplit_lc]    
@tempTable  VARCHAR(50) -- 需要拆分的临时维度表表名     
AS    
BEGIN    
     
 DECLARE @sql VARCHAR(MAX);    
     
 SET @sql = 'SELECT VWID,Name INTO #t FROM ' + @tempTable + '; ';    
 SET @sql += ' TRUNCATE TABLE ' + @tempTable + '; INSERT ' + @tempTable + '(VWID,Name) SELECT VWID,Name FROM #t GROUP BY VWID,Name; ';    
     
  
 SET @sql += ' UPDATE t SET t.Beginvalue = part.Beginvalue,t.Endvalue = part.EndValue '  
 SET @sql += ' FROM ' + @tempTable + ' AS t LEFT JOIN  ' + (SELECT 'vw_'+ DimNum + '_Part AS part' FROM dbo.lc_SinCapsuleTbl_AnsCom_DIimToTable WHERE TableName = @tempTable)  
 SET @sql += ' ON t.VWID = part.ID'  
   print @tempTable
 PRINT @sql;    
 EXEC (@sql);    
     
     
     
     
     
     
     
END
go

