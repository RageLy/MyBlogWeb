-- =============================================
-- Author:		<hmw>
-- Create date: <2017-8-3>
-- Description:	<ID类型距离度量明细>
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_Distance_DetailNew]
    @DimNum NVARCHAR(50),
    @EmpID INT = 1,
    @PageSize VARCHAR(5) = '10',
    @PageIndex VARCHAR(5) = '1',
    @OrderFields VARCHAR(50) = '',
    @OtherCond VARCHAR(50) = ''
AS
BEGIN
    DECLARE @XName NVARCHAR(50) = '';
    DECLARE @AnalysisCondTbl TABLE
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        String NVARCHAR(50)
    );

    INSERT INTO @AnalysisCondTbl
    SELECT string
    FROM dbo.f_splitSTR(@DimNum, ',');

    SET @XName =
    (
        SELECT String FROM @AnalysisCondTbl WHERE ID = 1
    );

    SELECT CoName,
           DimNum,
           (CASE
                WHEN GY = 1 THEN
                    '优等'
                ELSE
                    '差等'
            END
           ) GY,
           MinValue,
           FiveValue,
           DownFourValue,
           MiddleValue,
           UpFourValue,
           NineFiveValue,
           MaxValue,
           Num
    INTO #result
    FROM dbo.TempResult
    WHERE DimNum = @XName;

    SELECT 'n' 序号,
           'CoName' 字段名,
           'GY' 优差等分类,
           'MinValue' 最小值,
           'FiveValue' 五分位数,
           'DownFourValue' 上四分位数,
           'MiddleValue' 中位数,
           'UpFourValue' 下四分位数,
           'NineFiveValue' 九五分位数,
           'MaxValue' 最大值,
           'Num' 数量
    UNION ALL
    SELECT 'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500',
           'Varchar 500';
    SET @OrderFields = 'GY desc';
    DECLARE @totalRow INT = (
                                SELECT COUNT(1) FROM #result
                            );
    EXEC dbo.Sp_Sys_Page @tblName = '#result',
                         @fldName = @OrderFields,
                         @rowcount = @totalRow,
                         @PageIndex = @PageIndex,
                         @PageSize = @PageSize,
                         @SumType = 0,
                         @SumColumn = '',
                         @AvgColumn = '';

    DROP TABLE #result;

    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        EmpName,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter
    )
    VALUES
    (   @EmpID,
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
        GETDATE(),
        'Sp_Analysister_Distance_DetailNew',
        '' + @DimNum + '距离度量明细',
        NULL,
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=' + @OtherCond
    );
END;


go

