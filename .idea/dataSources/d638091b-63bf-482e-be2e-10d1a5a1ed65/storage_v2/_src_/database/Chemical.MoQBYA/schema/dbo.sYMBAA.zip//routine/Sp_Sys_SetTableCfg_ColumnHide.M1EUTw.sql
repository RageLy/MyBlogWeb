      

 -- =============================================        
-- Author:  刘轶      
-- Create date: 2014-06-30        
-- Description: 通过容器名字获取相关信息进行加载(隐藏列、查询器condition)        
-- =============================================        
CREATE proc [dbo].[Sp_Sys_SetTableCfg_ColumnHide]        
 -- Add the parameters for the stored procedure here        
 @FormID varchar(500)       
 ,@EmpID int=0       
 ,@GroupID varchar(500)      
 ,@ColumnHide varchar(max)   
 ,@ColumnSort VARCHAR(MAX)  
 ,@FrozenColumn varchar(50)    
AS        
BEGIN        
 if exists (select * from tbl_sys_TableCfg where FormID = @FormID and EmpID = @EmpID and GroupID = @GroupID)      
 begin      
  update tbl_sys_TableCfg set ColumnHide=@ColumnHide  ,ColumnSort =@ColumnSort ,FrozenColumn = @FrozenColumn     
   where FormID = @FormID and EmpID = @EmpID and GroupID = @GroupID      
 end      
 else      
 begin      
  INSERT INTO [Tbl_Sys_TableCfg]      
           ([FormID],[GroupID],[ColumnHide],[Condition],[EmpID],[HStr],[ColumnWidth],ColumnSort,FrozenColumn)      
     VALUES      
           (@FormID,@GroupID,@ColumnHide,'' ,@EmpID,'','',@ColumnSort,@FrozenColumn)      
 end      
END 

--select * from tbl_sys_TableCfg
 go

