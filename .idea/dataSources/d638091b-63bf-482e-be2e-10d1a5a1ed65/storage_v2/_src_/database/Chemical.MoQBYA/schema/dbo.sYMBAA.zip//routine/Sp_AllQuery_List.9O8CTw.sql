














-- =============================================        
  
-- Description: 全结构查询  
-- Auth:hjl  
-- Parameter: 1 @CodeType -- 编号类型      
--            2 @CodeValue -- 编号取值  
--            3 @ParaType -- 参数类型  
--            4 @ParaValueL -- 参数取值下限  
--            5 @paraValueH -- 参数取值上限    
--            6 @ResultType -- 结果类型  
-- Content:  拼装SQL查询  
  
-- =============================================     
     
CREATE proc[dbo].[Sp_AllQuery_List]  
 @CodeType  VARCHAR(50) = '颜料编号'   -- 编号类型      
 ,@CodeValue VARCHAR(50) = '1506MW3005'  -- 编号取值  
 ,@ParaType VARCHAR(50) = '单层PH'   -- 参数类型:单层PH   Oil.Viscosity  
 ,@ParaValueL VARCHAR(50) = '' -- 参数取值下限   
 ,@paraValueH VARCHAR(50) = '' -- 参数取值上限   
 ,@ResultType VARCHAR(50) = '颜料数据' -- 结果类型   
 ,@PageIndex varchar(5) = '1'  
 ,@PageSize varchar(5) = '10'  
 ,@OrderFields varchar(50) = ''  
 ,@EmpID varchar(50) = '1'
AS  
BEGIN  
 --------------------- 变量声明  -------------------------  
   
 DECLARE @SelectValue VARCHAR(MAX) = ''   -- select 段的语句，根据 【结果类型】 决定输出哪些列  
 DECLARE @WhereCode  VARCHAR(MAX) = ''    -- where 段中需要按编号段查询时根据 【编号类型】【编号取值】  
 DECLARE @WhereValue  VARCHAR(MAX) = ''   -- Where 段的参数选择语句，【参数类型】【参数取值下限】【参数取值上限】决定怎么筛选数据  
 DECLARE @WhereValueName  VARCHAR(MAX) = ''   -- Where 段的参数中的取值列名  
 DECLARE @TalbeValue  VARCHAR(MAX) = ''   -- From Table 段语句，根据@CodeType 和 @ResultType  和 @ParaType 决定  
 DECLARE @columnNames  VARCHAR(MAX) = ''   -- 输出的表名段语句，根据select段决定  
 DECLARE @WhereNonull  VARCHAR(MAX) = ''  -- 用where控制输出结果不带空值  
  -- 行数量 用于分页sp  
 DECLARE @Pagesql VARCHAR(2000) = '' -- 用于分页的sql  
   
 -- 临时表，用于存放需要哪些表  先暂时不用 后续使用，第一版先不用  
 CREATE TABLE #TalbesNeed  
 (  
  tablename VARCHAR(50)  
 )  
   
 -------------------- 变量参数拼接  ---------------------  
   
 IF @ResultType = '颜料BK数据'  
 BEGIN  
  -- 设定需要的列  
  SET @SelectValue = 'distinct   
   PigmentBK.[Code]
   ,PigmentBK.ID
   ,CONVERT(varchar(100), PigmentBK.[OptDate], 23) as [OptDate]
   ,PigmentBK.[FuName]
   ,PigmentBK.[Mass]
   ,PigmentBK.[innerCodeName]
   ,PigmentBK.[SolventEName]
   ,PigmentBK.[SolventCName]
   ,PigmentBK.[SolventDName]
   ,PigmentBK.[SolventFName]
   ,PigmentBK.[CTRSpeedActually]
   ,PigmentBK.[FRSpeedActually]
   ,PigmentBK.[ReactOutput]
   ,PigmentBK.[GrindOutput]
   ,PigmentBK.[PSize05Bef]
   ,PigmentBK.[PSize09Bef]
   ,PigmentBK.[RemarK]  
   '
  SET @WhereNonull = ' And PigmentBK.Code is not null'  

  -- 设定需要的列头
  SET @columnNames = 'select
    ''n'' AS 序号
    ,''ID'' AS 编号
    ,''Code'' AS 颜料BK编号
    ,''OptDate'' AS 操作日期
    ,''FuName'' AS 颜料大釜
    ,''Mass'' AS 质量
    ,''innerCodeName'' AS 内部编号
    ,''SolventEName'' AS [溶剂E]
    ,''SolventCName'' AS [溶剂C]
    ,''SolventDName'' AS [溶剂D]
    ,''SolventFName'' AS [溶剂F]
    ,''CTRSpeedActually'' AS 恒温转速
    ,''FRSpeedActually'' AS 加料转速   
    ,''ReactOutput'' AS 反应后产量
    ,''GrindOutput'' AS 研磨后产量
    ,''PSize05Bef'' AS 离心前粒径05
    ,''PSize09Bef'' AS 离心前粒径09
    ,''RemarK'' AS 备注                    
     union all  
     select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
     ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''   
     '  -- 18列
  -- 设定需要颜料表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentBK');  
 end
 
  IF @ResultType = '颜料Sp514数据'  
  BEGIN  
  -- 设定需要的列  
  SET @SelectValue = 'distinct   
  PigmentSp514.[ID]  
  ,PigmentSp514.[Code]  
  ,CONVERT(varchar(100), PigmentSp514.[OptDate], 23) AS [OptDate]  
  ,PigmentSp514.[RawCodeName]
  ,PigmentSp514.[OuterCodeName]
  ,PigmentSp514.GrindPress
  ,PigmentSp514.GrindTimeB
  ,PigmentSp514.GrindTimeE
  ,PigmentSp514.GrindOutPut
  ,PigmentSp514.GHL
  ,PigmentSp514.CLTemp15MIN
  ,PigmentSp514.CLTemp30MIN
  ,PigmentSp514.CLTemp45MIN
  ,PigmentSp514.CLTemp60MIN
  ,PigmentSp514.CLTemp90MIN
  ,PigmentSp514.CLTemp120MIN
  ,PigmentSp514.LQTemp10MIN
  ,PigmentSp514.LQTemp20MIN
  ,PigmentSp514.LQTemp30MIN
  ,PigmentSp514.LQTemp60MIN
  ,PigmentSp514.LQTemp90MIN
  ,PigmentSp514.LQTemp120MIN
  ,PigmentSp514.[RemarK]'
  SET @WhereNonull = ' And PigmentSp514.Code is not null'  

  -- 设定需要的列头
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号  
  ,''Code'' AS 颜料Sp514编号
  ,''OptDate'' AS 操作日期
  ,''RawCodeName'' AS 内部编号
  ,''OuterCodeName'' AS 外部编号  
  ,''GrindPress'' AS 研磨压力
  ,''GrindTimeB'' AS 研磨开始  
  ,''GrindTimeE'' AS 研磨结束
  ,''GrindOutPut'' AS 研磨产量  
  ,''GHL'' AS 固含量
  ,''CLTemp15MIN'' AS 出料温度15
  ,''CLTemp30MIN'' AS 出料温度30
  ,''CLTemp45MIN'' AS 出料温度45
  ,''CLTemp60MIN'' AS 出料温度60
  ,''CLTemp90MIN'' AS 出料温度90
  ,''CLTemp120MIN'' AS 出料温度120
  ,''LQTemp10MIN'' AS 冷却水温度10
  ,''LQTemp20MIN'' AS 冷却水温度20
  ,''LQTemp30MIN'' AS 冷却水温度30
  ,''LQTemp60MIN'' AS 冷却水温度60
  ,''LQTemp90MIN'' AS 冷却水温度90
  ,''LQTemp120MIN'' AS 冷却水温度120
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500''
  '  -- 24列  
  
  -- 设定需要颜料表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentlSp514')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentlSp514');  
 END
 
  IF @ResultType = '颜料W数据'  
  BEGIN  
  -- 设定需要的列  
  SET @SelectValue = 'distinct   
  PigmentW.[ID]  
  ,PigmentW.[Code]  
  ,CONVERT(varchar(100), PigmentW.[OptDate], 23) AS [OptDate]  
  ,PigmentW.[InnerCodeName]
  ,PigmentW.[FuName]  
  ,PigmentW.Mass
  ,PigmentW.SolventCName
  ,PigmentW.SolventEName
  ,PigmentW.CTRSpeedActually
  ,PigmentW.FRSpeedActually
  ,PigmentW.ReactOutput
  ,PigmentW.GrindOutput
  ,PigmentW.PSize05Bef
  ,PigmentW.PSize09Bef
  ,PigmentW.PH
  ,PigmentW.[RemarK]'
  SET @WhereNonull = ' And PigmentW.Code is not null'  
  
  -- 设定需要的列头
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号  
  ,''Code'' AS 颜料W编号
  ,''OptDate'' AS 操作日期
  ,''InnerCodeName'' AS 内部编号  
  ,''FuName'' AS 颜料釜
  ,''Mass'' AS 质量  
  ,''SolventCName'' AS 溶剂C
  ,''SolventEName'' AS 溶剂E  
  ,''CTRSpeedActually'' AS 恒温转速
  ,''FRSpeedActually'' AS 反应转速
  ,''ReactOutput'' AS 反应后产量
  ,''GrindOutput'' AS 研磨后产量
  ,''PSize05Bef'' AS 离心前粒径05
  ,''PSize09Bef'' AS 离心前粒径09
  ,''PH'' AS PH值
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''
  '  -- 17列  
  
  -- 设定需要颜料表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentW')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentW');  
 END
 
 IF @ResultType = '粒子数据'  
 begin  
  SET @SelectValue = 'distinct   
  Partical.[ID]  
  ,Partical.[Code]  
  ,CONVERT(varchar(100), Partical.[OptDate], 23) AS [OptDate]  
  ,Partical.[SeriesName]
  ,Partical.[NameFu]  
  ,Partical.[TOutput]  
  ,Partical.[FOutput]  
  ,Partical.[PigmentCode]
  ,Partical.[BA0001Name]  
  ,Partical.[BE0001Name]  
  ,Partical.[BC0012Name]  
  ,Partical.[BC0001Name]
  ,Partical.[Viscosity]
  ,Partical.[Zeta]
  ,Partical.[Organic]  
  ,Partical.[PSize05]
  ,Partical.[PSize09]
  ,Partical.[PpoleName]  
  ,Partical.[NpoleName]  
  ,Partical.[RemarK]'
  SET @WhereNonull = ' And Partical.Code is not null'  
    
  -- 设定需要的列头  
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号  
  ,''Code'' AS 粒子编号  
  ,''SeriesName'' AS 粒子系列
  ,''OptDate'' AS 操作日期  
  ,''NameFu'' AS 粒子反应釜
  ,''TOutput'' AS 理论产量  
  ,''FOutput'' AS 实际产量  
  ,''PigmentCode'' AS 颜料编号
  ,''BA0001Name'' AS BA0001批号
  ,''BE0001Name'' AS BE0001批号
  ,''BC0012Name'' AS BC0012批号
  ,''BC0001Name'' AS BC0001批号
  ,''Viscosity'' AS 粘度  
  ,''Zeta'' AS Zeta电位值  
  ,''Organic'' AS 有机物含量  
  ,''PSize05'' AS 粒子粒径05  
  ,''PSize09'' AS 粒子粒径09  
  ,''PpoleName'' AS 分散液带电性正极  
  ,''NpoleName'' AS 分散液带电性负极  
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''
  '  -- 21列  

  -- 设定需要粒子表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Partical')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Partical');  
   
 END  

 IF @ResultType = '油项数据'  
 begin  
  SET @SelectValue = 'distinct Oil.[ID]
  ,Oil.[Code]
  ,CONVERT(varchar(100),Oil.[OptDate], 23) AS [OptDate]
  ,Oil.[name]
  ,Oil.[SolventGName]
  ,Oil.[Density]
  ,Oil.[STension]
  ,Oil.[Conductivity]  
  ,Oil.[Viscosity]
  ,Oil.[PSize05]
  ,Oil.[PSize09]
  ,Oil.[ParticalIDW1Name]
  ,Oil.[ParticalIDW2Name]
  ,Oil.[ParticalIDW3Name]
  ,Oil.[ParticalIDBK1Name]
  ,Oil.[ParticalIDBK2Name]
  ,Oil.[ParticalIDBK3Name]
  ,Oil.[ParticalCodes]
  ,Oil.[RemarK]'   
  SET @WhereNonull = ' And Oil.Code is not null'  
  
  -- 设定需要的列头
  SET @columnNames = ' select   
  ''n'' AS 序号  
  ,''ID'' AS 编号
  ,''Code'' AS 油项编号
  ,''name'' AS 油项系列  
  ,''OptDate'' AS 操作日期
  ,''SolventGName'' AS 溶液G编号
  ,''Density'' AS 密度
  ,''STension'' AS 表面张力
  ,''Conductivity'' AS 电导率  
  ,''Viscosity'' AS 粘度
  ,''PSize05'' AS 粒子粒径05  
  ,''PSize09'' AS 粒子粒径09
  ,''ParticalIDW1Name'' AS 白粒子1编号
  ,''ParticalIDW2Name'' AS 白粒子2编号
  ,''ParticalIDW3Name'' AS 白粒子3编号
  ,''ParticalIDBK1Name'' AS 黑粒子1编号
  ,''ParticalIDBK2Name'' AS 黑粒子2编号
  ,''ParticalIDBK3Name'' AS 黑粒子3编号
  ,''ParticalCodes'' AS 粒子编号  
  ,''RemarK'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''
  '  -- 20列
  -- 设定需要油项表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_Oil')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Oil');  
 END  

 IF @ResultType = '单层胶囊数据'  
 begin  
  SET @SelectValue = 'distinct 
    SinCapsule.[ID]
   ,CONVERT(varchar(100), SinCapsule.[OptDate], 23) AS [OptDate]  
   ,SinCapsule.[Code]  
   ,SinCapsule.[Lotcode]  
   ,SinCapsule.[SpeType]  
   ,SinCapsule.[OILNAME]
   ,SinCapsule.[FuName]  
   ,SinCapsule.[Volume]  
   ,SinCapsule.[GAA]  
   ,SinCapsule.[AF0001Name]  
   ,SinCapsule.[AF0003Name]  
   ,SinCapsule.[BG0002Name]  
   ,SinCapsule.[Temp41]  
   ,SinCapsule.[Time45]  
   ,SinCapsule.[Rspeed580]  
   ,SinCapsule.[Temp8]  
   ,SinCapsule.[Time120]  
   ,SinCapsule.[Temp25]  
   ,SinCapsule.[Time360]  
   ,SinCapsule.[Rspeed400]  
   ,SinCapsule.[OutPut]  
   ,SinCapsule.[Psize]  
   ,SinCapsule.[PsizeSpan]  
   ,SinCapsule.[SoildContent]  
   ,SinCapsule.[CR]  
   ,SinCapsule.[LBK]  
   ,SinCapsule.[LW]  
   ,SinCapsule.[DeltaBK]  
   ,SinCapsule.[DeltaW]  
   ,SinCapsule.[PH]  
   ,SinCapsule.[PHTemp]  
   ,SinCapsule.[Remark]'  

  SET @WhereNonull = ' And SinCapsule.Code is not null'  
  
  -- 设定需要的列头  
  SET @columnNames = 'select   
  ''n'' AS 序号  
  ,''ID'' AS 编号 
  ,''OptDate'' AS 操作日期  
  ,''Code'' AS 胶囊编号
  ,''Lotcode'' AS 胶囊批次
  ,''OILNAME'' AS 油相编号
  ,''SpeType'' AS 分离方式  
  ,''FuName'' AS 釜位  
  ,''Volume'' AS 体积  
  ,''GAA'' AS 冰醋酸  
  ,''AF0001Name'' AS AF0001批次  
  ,''AF0003Name'' AS AF0003批次  
  ,''BG0002Name'' AS BG0002批次  
  ,''Temp41'' AS 温度41  
  ,''Time45'' AS 时间45  
  ,''Rspeed580'' AS 转速580  
  ,''Temp8'' AS 温度8  
  ,''Time120'' AS 时间120  
  ,''Temp25'' AS 温度25  
  ,''Time360'' AS 时间360  
  ,''Rspeed400'' AS 转速400  
  ,''OutPut'' AS 产值  
  ,''Psize'' AS 胶囊粒径  
  ,''PsizeSpan'' AS  粒径Span
  ,''SoildContent'' AS 胶囊固含量  
  ,''CR'' AS CR值  
  ,''LBK'' AS L黑  
  ,''LW'' AS L白  
  ,''DeltaBK'' AS delta黑  
  ,''DeltaW'' AS delta白  
  ,''PH'' AS PH  
  ,''PHTemp'' AS PH温度  
  ,''Remark'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500''
  '-- 33列  
  -- 设定需要表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_SinCapsule')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_SinCapsule');  
   
 END  
   
 IF @ResultType = '双层胶囊数据'  
 BEGIN   
  SET @SelectValue = 'distinct CONVERT(varchar(100), DouCapsule.[OptDate], 23) AS [OptDate]  
   ,DouCapsule.[ID] 
   ,DouCapsule.[Code]  
   ,DouCapsule.[SpeType]  
   ,DouCapsule.[OILNAME]
   ,DouCapsule.[FuName]  
   ,DouCapsule.Volume
   ,DouCapsule.[GAA]  
   ,DouCapsule.[AF0001Name]  
   ,DouCapsule.[AF0003Name]  
   ,DouCapsule.[BG0002Name]  
   ,DouCapsule.[Temp41]  
   ,DouCapsule.[Time60]  
   ,DouCapsule.[Rspeed400]  
   ,DouCapsule.[Temp8]  
   ,DouCapsule.[Time120]  
   ,DouCapsule.[Temp25]  
   ,DouCapsule.[Time360]  
   ,DouCapsule.[Rspeed500]  
   ,DouCapsule.[OutPut]  
   ,DouCapsule.[Psize]  
   ,DouCapsule.[PsizeSpan]  
   ,DouCapsule.[SoildContent]  
   ,DouCapsule.[CR]  
   ,DouCapsule.[LBK]  
   ,DouCapsule.[LW]  
   ,DouCapsule.[DeltaBK]  
   ,DouCapsule.[DeltaW]  
   ,DouCapsule.[PH]  
   ,DouCapsule.[PHTemp]  
   ,DouCapsule.[Remark]'  
     
  SET @WhereNonull = ' And DouCapsule.Code is not null'  
  
  -- 设定需要的列头  
  SET @columnNames = 'select   
  ''n'' AS 序号 
  ,''OptDate'' AS 操作日期  
  ,''ID'' AS 编号  
  ,''Code'' AS 胶囊编号
  ,''OILNAME'' AS 油相编号
  ,''SpeType'' AS 分离方式  
  ,''FuName'' AS 釜位  
  ,''Volume'' AS 体积
  ,''GAA'' AS 冰醋酸  
  ,''AF0001Name'' AS AF0001批次  
  ,''AF0003Name'' AS AF0003批次  
  ,''BG0002Name'' AS BG0002批次  
  ,''Temp41'' AS 温度41  
  ,''Time60'' AS 时间60  
  ,''Rspeed400'' AS 转速400 
  ,''Temp8'' AS 温度8  
  ,''Time120'' AS 时间120  
  ,''Temp25'' AS 温度25  
  ,''Time360'' AS 时间360  
  ,''Rspeed500'' AS 转速500  
  ,''OutPut'' AS 产值  
  ,''Psize'' AS 胶囊粒径  
  ,''PsizeSpan'' AS  粒径Span
  ,''SoildContent'' AS 胶囊固含量  
  ,''CR'' AS CR值  
  ,''LBK'' AS L黑  
  ,''LW'' AS L白  
  ,''DeltaBK'' AS delta黑  
  ,''DeltaW'' AS delta白  
  ,''PH'' AS PH  
  ,''PHTemp'' AS PH温度  
  ,''Remark'' AS 备注  
  union all  
  select ''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500'',''varchar 500''  
  ,''varchar 500''
  '  -- 32列 ...  
    
  -- 设定需要表  
  IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_DouCapsule')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_DouCapsule');  
 end  
    
  -------- 设定参数编号查询项  
  IF( @CodeValue IS NOT NULL and @CodeValue <> '')  
  BEGIN   
  IF( @CodeType = '颜料BK编号' )  
  BEGIN  
     SET @WhereCode = 'And PigmentBK.Code like ''%' + @CodeValue + '%'' ';  
     IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
     INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentBK');  
  END 
  
   IF( @CodeType = '颜料BK编号ID' )  
  begin
     SET @WhereCode = 'And PigmentBK.ID=' + @CodeValue;  
     IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
     INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentBK'); 
  end
  
  --IF( @CodeType = '颜料Sp514编号' )  
  --BEGIN  
  --   SET @WhereCode = 'And PigmentSp514.Code like ''%' + @CodeValue + '%'' ';  
  --   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
  --   INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentlSp514');  
  --END 
  
  -- IF( @CodeType = '颜料Sp514编号ID' )  
  --begin
  --   SET @WhereCode = 'And PigmentSp514.ID=' + @CodeValue;  
  --   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
  --   INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentlSp514'); 
  --end
  
  IF( @CodeType = '颜料W编号' )  
  BEGIN  
     SET @WhereCode = 'And PigmentW.Code like ''%' + @CodeValue + '%'' ';  
     IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
     INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentW');  
  END 
  
   IF( @CodeType = '颜料W编号ID' )  
  begin
     SET @WhereCode = 'And PigmentW.ID=' + @CodeValue;  
     IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
     INSERT INTO #TalbesNeed(tablename) VALUES('Bs_PigmentW'); 
  end
  
  IF( @CodeType = '粒子编号' )  
  BEGIN  
   SET @WhereCode = 'And Partical.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Partical');  
  END  
  
  IF( @CodeType = '粒子编号ID' )  
  BEGIN  
   SET @WhereCode = 'And Partical.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Partical');  
  END  
    
  IF( @CodeType = '油项编号' )  
  BEGIN  
   SET @WhereCode = 'And Oil.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Oil');  
  END  
  
  IF( @CodeType = '油项编号ID' )  
  BEGIN  
   SET @WhereCode = 'And Oil.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_Oil');  
  END  
    
  IF( @CodeType = '单层胶囊编号' )  
  BEGIN  
   SET @WhereCode = 'And SinCapsule.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_SinCapsule');  
  END 
  
  IF( @CodeType = '单层胶囊编号ID' )  
  BEGIN  
   SET @WhereCode = 'And SinCapsule.ID=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_SinCapsule');  
  END 
    
  IF( @CodeType = '双层胶囊编号' )  
  BEGIN  
   SET @WhereCode = 'And DouCapsule.Code like ''%' + @CodeValue + '%'' ';  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_DouCapsule');  
  END  
  
  IF( @CodeType = '双层胶囊编号ID' )  
  BEGIN  
   SET @WhereCode = 'And DouCapsule.id=' + @CodeValue;  
   IF NOT exists (SELECT tablename FROM #TalbesNeed WHERE tablename = 'Bs_PigmentBK')  
    INSERT INTO #TalbesNeed(tablename) VALUES('Bs_DouCapsule');  
  END 
    END  
   
 IF( (@ParaValueL <> '' AND @ParaValueL IS NOT NULL) OR (@ParaValueL <> '' AND @ParaValueL IS NOT NULL))  
 BEGIN
    SET @WhereValueName =@ParaType    
    SET @WhereValue = CASE when @ParaValueL <> '' THEN ' AND ' + @WhereValueName + ' >= ' + @ParaValueL END + CASE when @ParaValueH <> '' THEN ' AND ' + @WhereValueName + ' <= ' + @ParaValueH END  
 END
   
 ------- From段 判断取表 --------  
SET @TalbeValue = 'INTO #Result FROM
    (SELECT ParticalBK.*,ser.Series as SeriesName,fu.name as NameFu,ba.BA0001 as BA0001Name,bc.BC0001 as BC0001Name,bc2.BC0012 as BC0012Name,be.BE0001 as BE0001Name,BSP.Ppole AS PpoleName,BSPP.Npole AS NpoleName FROM Bs_ParticalBK ParticalBK
    LEFT JOIN Tbl_Base_ParticalSeries ser ON ParticalBK.Series=ser.id
    LEFT JOIN Tbl_Base_ParticalKettle fu
    ON ParticalBK.kettle=fu.id
    LEFT JOIN dbo.Tbl_Base_ParticalBA0001 ba
    ON ParticalBK.BA0001=ba.id
    LEFT JOIN dbo.Tbl_Base_ParticalBC0001 bc
    ON ParticalBK.ConfigBC0001=bc.id
    LEFT JOIN dbo.Tbl_Base_ParticalBC0012 bc2
    ON ParticalBK.ClenBC0012=bc2.id
    LEFT JOIN dbo.Tbl_Base_ParticalBE0001 be
    ON ParticalBK.BE0001=be.id
    LEFT JOIN Tbl_Base_ParticalPole BSP
    ON ParticalBK.ppole=BSP.ID
    LEFT JOIN Tbl_Base_ParticalPole BSPP
    ON ParticalBK.Npole=BSPP.ID
    ) AS ParticalBK
FULL JOIN
    (SELECT bk.*,pgf.name as FuName,soc.SolventC as SolventCName,sod.SolventD AS SolventDName,
     soe.SolventE as SolventEName,sof.SolventF as SolventFName,INN.innerCode AS innerCodeName FROM Bs_PigmentBK bk 
     LEFT JOIN dbo.Tbl_Base_PigmentBKKettle pgf
     ON bk.kettle=pgf.ID
     LEFT JOIN dbo.Tbl_Base_PigmentBKSolventC soc
     ON bk.SolventC=soc.id
     LEFT JOIN dbo.Tbl_Base_PigmentBKSolventD sod
     ON bk.SolventD=sod.id
     LEFT JOIN dbo.Tbl_Base_PigmentBKSolventE soe
     ON bk.SolventE=soe.id
     LEFT JOIN dbo.Tbl_Base_PigmentBKSolventF sof
     ON bk.SolventF=sof.id
     LEFT JOIN dbo.Tbl_Base_PigmentBKinnerCode INN
     ON bk.innerCode=INN.ID
     ) AS PigmentBK
     ON ParticalBK.PigmentID=PigmentBK.ID and Partical.SeriesName=''BK-SP0''
--FULL JOIN
--    (SELECT sp.*,rw.RawCode as RawCodeName,OuterCode.OuterCode AS OuterCodeName FROM Bs_PigmentlSp514 sp
--     LEFT JOIN dbo.Tbl_Base_PigmentSp514RawCode rw on sp.RawCode=rw.id
--     LEFT JOIN dbo.Tbl_Base_PigmentSp514OuterCode OuterCode ON sp.OuterCode=OuterCode.ID
--     ) as PigmentSp514
--     ON ParticalBK.PigmentID=PigmentSp514.ID  and CHARINDEX(''BK-SP514'',Partical.SeriesName)>0
--FULL JOIN
--    (SELECT bk.*,pgf.name as FuName,soc.SolventC as SolventCName,soe.SolventE AS SolventEName,INN.innerCode AS InnerCodeName FROM dbo.Bs_PigmentW bk
--     LEFT JOIN dbo.Tbl_Base_PigmentWKettle pgf
--     ON bk.kettle=pgf.ID
--     LEFT JOIN dbo.Tbl_Base_PigmentWSolventC soc
--     ON bk.SolventC=soc.id
--     LEFT JOIN dbo.Tbl_Base_PigmentWSolventE soe
--     ON bk.SolventE=soe.id
--     LEFT JOIN dbo.Tbl_Base_PigmentWinnerCode INN
--     ON BK.innerCode=INN.ID
--     ) as PigmentW
--     ON Partical.PigmentID=PigmentW.ID and CHARINDEX(''W'',Partical.SeriesName)>0
FUll JOIN Bs_ParticalToOil AS b ON b.ParticalID = Partical.ID
FUll JOIN
    (SELECT oil.*,ser.name,SG.SolventG AS SolventGName,BP1.CODE AS ParticalIDW1Name,
    BP2.CODE AS ParticalIDW2Name,BP3.CODE AS ParticalIDW3Name,BP4.CODE AS ParticalIDBK1Name,
    BP5.CODE AS ParticalIDBK2Name,BP6.CODE AS ParticalIDBK3Name FROM BS_Oil oil
    LEFT JOIN Tbl_Base_OilSeries ser ON oil.Series=ser.id
    LEFT JOIN dbo.Tbl_Base_OilSolventG SG ON OIL.SolventG=SG.ID
    LEFT JOIN Bs_Partical BP1
    ON oil.ParticalIDW1=BP1.ID
    LEFT JOIN Bs_Partical BP2
    ON oil.ParticalIDW2=BP2.ID
    LEFT JOIN Bs_Partical BP3
    ON oil.ParticalIDW3=BP3.ID
    LEFT JOIN Bs_Partical BP4
    ON oil.ParticalIDBK1=BP4.ID
    LEFT JOIN Bs_Partical BP5
    ON oil.ParticalIDBK2=BP5.ID
    LEFT JOIN Bs_Partical BP6
    ON oil.ParticalIDBK3=BP6.ID
    ) AS Oil 
    ON Oil.ID = b.OilID
FUll JOIN 
    (SELECT bs.*,fu.name as FuName,af1.AF0001 as AF0001Name,af3.AF0003 as AF0003Name,bg2.BG0002 as BG0002Name,OIL.CODE AS OILNAME FROM BS_SinCapsule bs
    LEFT JOIN BS_Oil oil ON BS.OilID=OIL.ID
    LEFT JOIN dbo.Tbl_Base_Fu fu ON bs.kettle=fu.id
    LEFT JOIN dbo.Tbl_Base_AF0001 af1 ON bs.AF0001=af1.id
    LEFT JOIN dbo.Tbl_Base_AF0003 af3 ON bs.AF0003=af3.id
    LEFT JOIN dbo.Tbl_Base_BG0002 bg2 ON bs.BG0002Code=bg2.id
    ) AS SinCapsule 
    ON SinCapsule.OilID = Oil.ID
FUll JOIN 
    (SELECT bs.*,fu.name as FuName,af1.AF0001 as AF0001Name,af3.AF0003 as AF0003Name,bg2.BG0002 as BG0002Name,OIL.CODE AS OILNAME FROM BS_DouCapsule bs
    LEFT JOIN BS_Oil oil ON BS.OilID=OIL.ID
    LEFT JOIN dbo.Tbl_Base_DouFu fu ON bs.kettle=fu.id
    LEFT JOIN dbo.Tbl_Base_AF0001 af1 ON bs.AF0001=af1.id
    LEFT JOIN dbo.Tbl_Base_AF0003 af3 ON bs.AF0003=af3.id
    LEFT JOIN dbo.Tbl_Base_BG0002 bg2 ON bs.BG0002Code=bg2.id
    ) AS DouCapsule
    ON DouCapsule.OilID = Oil.ID '  
   
 PRINT @columnNames  
 exec (@columnNames )  
   
   
    if(@OrderFields='')  
  set @OrderFields ='optdate desc'  
      
 -- 数据分页  
   
 set @Pagesql =  
 '  
  EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
  ,@fldName = '' ' + @OrderFields + ' ''                               
  ,@rowcount = @totalRow   
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0  
  ,@SumColumn = ''  
  ,@AvgColumn = ''  
 '  
   
   
 PRINT 'select ' + @SelectValue + @TalbeValue + 'WHERE 1=1 ' + @WhereCode + @WhereValue + @WhereNonull + '; DECLARE @totalRow int = @@ROWCOUNT ; ' + @Pagesql  
 exec ('select ' + @SelectValue + @TalbeValue + 'WHERE 1=1 ' + @WhereCode + @WhereValue + @WhereNonull + '; DECLARE @totalRow int = @@ROWCOUNT ; ' + @Pagesql)  
 --select   'select ' + @SelectValue + @TalbeValue + 'WHERE 1=1 ' + @WhereCode + @WhereValue + @WhereNonull + 'as 测试结果'  
 
  INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_AllQuery_List',
        '全数据查询', @ResultType,@WhereCode + @WhereValue )  
END
--select * from tbl_sys_myMenu  
go

