




        
-- =============================================                          
-- Author:  <刘轶>                          
-- Create date: <2014-08-18>                          
-- Description: <基础配置 优惠项目 列表>                     
-- =============================================                          
CREATE PROCEDURE [dbo].[Sp_Base_ModuleAssembly_GlassList]                          
 @PageIndex varchar(50)='1'
 ,@PageSize varchar(50)='10'
 ,@OrderFields varchar(50)=''
 ,@KeyValue varchar(50)='-1'
 ,@ID VARCHAR(50)=''
 --,@IsBanState varchar(50)=''
AS                          
BEGIN                          
SET NOCOUNT ON;
--设置默认排序
if(LEN(@OrderFields)=0)
begin
 set @OrderFields=' cast(ID as int) desc'                          
end
       
   
--如果该数据源存在数据  则显示           
               
 SELECT                           
 CAST(ID AS INT) ID                            
 ,CAST(Code AS VARCHAR(50)) Name      
 into #T                                    
 FROM Tbl_Base_Glass  a                          
                               
 declare @pageCount int =@@ROWCOUNT            
 
--处理查询结果为空时插入空行(列表为行内编辑时需要)                 
if(@pageCount = 0)                      
begin          
 insert into #T values(null,null)          
end


--调用通用分页          
          
exec Sp_Sys_Page '#T',@OrderFields,@pageCount,@PageIndex,@PageSize                                        
          
          
END
go

