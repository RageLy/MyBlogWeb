-- =============================================  
-- Description: <通用更新存储过程>  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_UpdateTBLTable]  
    @tableName          varchar(256),  
    @IDName             varchar(256),  
    @IDValue            varchar(256),  
    @colName            varchar(3000),  
    @colValue           varchar(8000)  
AS  
BEGIN try  
 --Sp_Sys_UpdateTBLTable 'Tbl_Com_Brand','BrandID','25','BrandName','null'   
 SET NOCOUNT ON;  
 declare @sql    varchar(8000);  
   
 if CHARINDEX('{&^}',@colValue,0)<1  
 begin  
    
  
  set @sql= '   
    update '+@tableName +' set '+@colName+'='''+replace(replace(@colValue,'''',''''''),'''null''','null') +  
    ''' where '+@IDName +'='''+@IDValue + ''''  
    --,'''null''','null'  
  print @sql  
  exec (@sql)  
  select '0'  
  return  
 end  
   
 -- 存放拆分后的列名和值  
 create table #tmp_name  
 (  
     id      int identity,  
     name    varchar(256),  
 );  
 create table #tmp_value  
 (  
     id      int identity,  
     value    varchar(4000),  
 );  
   
    insert into #tmp_name (name)  
    select string from dbo.Split(@colName,',')  
      
    insert into #tmp_value (value)  
    select string from dbo.Split(@colValue,'{&^}')  
      
    select name,value   
    into #t  
    from #tmp_name a      
    left join #tmp_value b on b.id=a.id  
      
    declare @sets varchar(4000)=''  
 declare @name varchar(256)  
 declare @value varchar(4000)  
 declare v_cursor cursor for  
 select name,value from #t  
   
 open v_cursor  
 FETCH NEXT FROM v_cursor  
 INTO @name,@value  
   
 WHILE @@FETCH_STATUS = 0  
 BEGIN  
  set @sets = @sets+@name +'='''+ replace(@value,'''','''''')+''''+ ','  
  FETCH NEXT FROM v_cursor  
  INTO @name,@value    
 end  
 CLOSE v_cursor  
 DEALLOCATE v_cursor   
   
 set @sets=SUBSTRING(@sets,0,LEN(@sets))   
 set @sql= '  
  update '+@tableName +' set '+replace(@sets,'''null''','null') +' where '+@IDName +'='+@IDValue + ''  
 print @sql  
 exec(@sql)  
 select '0'  
END try  
begin catch  
  
     declare @errMsg varchar(500)='',@columnName varchar(50)=''  
    declare @s int=0,@e int=1  
    select @errMsg=ERROR_MESSAGE()  
    set @s=CHARINDEX('''',@errMsg,0)  
    set @e=CHARINDEX('''',@errMsg,@s+1)  
    set @columnName=SUBSTRING(@errMsg,@s+1,@e-@s-1)  
    select @errMsg msg,@columnName [column],ERROR_NUMBER() errNum  
end catch
go

