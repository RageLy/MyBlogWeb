-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-22>
-- Description:	<删除角色>
-- =============================================
create PROCEDURE [dbo].[Sp_Permission_Role_Del]
    @RoleID varchar(50)
AS
BEGIN
	SET NOCOUNT ON;
    if exists(select * from Tbl_Com_Employee a left join Tbl_Sys_UserRoleRelation b on a.UserID=b.UserID where b.RoleID=@RoleID)
    begin
		select '删除失败：该角色已用于员工'
    end
    else
    begin
		delete from Tbl_Sys_Role where RoleID = @RoleID
		select '0'
    end
END
go

