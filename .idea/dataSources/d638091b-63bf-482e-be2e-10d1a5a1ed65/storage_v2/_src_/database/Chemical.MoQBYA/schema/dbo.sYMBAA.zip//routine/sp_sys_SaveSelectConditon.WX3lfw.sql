--陈建波    
--保存搜索条件    
--2015.11.6 

CREATE procedure dbo.sp_sys_SaveSelectConditon
   @EmpID int,    
   @groupID varchar(200),    
   @formID varchar(200),    
   @selectConditionData varchar(2000)   
as
declare @recordcount int
select @recordcount=(select count(*) from dbo.TBL_SaveSelectConditon where EmpID=@EmpID and formID=@formID and GroupID=@GroupID)
if(@recordcount=0)
    insert into dbo.TBL_SaveSelectConditon(EmpID,formID,GroupID,selectCondition) values(@EmpID,@formID,@groupID,@selectConditionData)
else
    Update dbo.TBL_SaveSelectConditon set selectCondition=@selectConditionData where EmpID=@EmpID and formID=@formID and GroupID=@GroupID
go

