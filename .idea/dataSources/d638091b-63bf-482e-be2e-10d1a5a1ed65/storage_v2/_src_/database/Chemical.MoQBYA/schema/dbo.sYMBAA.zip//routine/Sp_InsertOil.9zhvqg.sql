
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年5月27日                                                
-- Descript: 从Excel插入油相数据
-- =============================================                 
-- exec [Sp_InsertOil]
CREATE PROCEDURE [dbo].[Sp_InsertOil]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN
        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_Oil
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Oil
                            GROUP BY 油相编号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_Oil
                           );
        INSERT INTO dbo.Tbl_Base_OilSeries ( [NAME] )
                    SELECT DISTINCT 油相系列
                    FROM   dbo.TempTb_Oil
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_OilSeries
                                          WHERE  油相系列 = [NAME]
                                      )
                           AND 油相系列 IS NOT NULL;
        /*BC0001批次维护,查看是否已经补全档案*/
        PRINT '开始插入Tbl_Base_OilBC0001数据，继续下一步';
        DELETE FROM dbo.TempTb_Oil_BC0001
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Oil_BC0001
                            GROUP BY BC0001批号
                        );
        INSERT INTO dbo.Tbl_Base_BC0001 (   BC0001 ,
                                            Density ,
                                            Tension ,
                                            Refractivity
                                        )
                    SELECT DISTINCT BC0001批号 ,
                           BC0001密度 ,
                           BC0001表面张力 ,
                           BC0001折射率
                    FROM   dbo.TempTb_Oil_BC0001
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BC0001
                                          WHERE  BC0001批号 = BC0001
                                      )
                           AND BC0001批号 IS NOT NULL;
        PRINT '表Tbl_Base_OilBC0001数据插入完毕，继续下一步';

        /*助剂A批次维护,查看是否已经补全档案*/
        PRINT '开始插入Tbl_Base_OilAdditivesA数据，继续下一步';
        DELETE FROM dbo.TempTb_Oil_AdditivesA
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Oil_AdditivesA
                            GROUP BY 助剂A批次
                        );
        INSERT INTO dbo.Tbl_Base_OilAdditivesA (   AdditivesA ,
                                                   GHL ,
                                                   ZSL ,
                                                   ddl,
												   DHDate
                                               )
                    SELECT DISTINCT 助剂A批次 ,
                           固含量 ,
                           折射率 ,
                           电导率,A物料到货日期
                    FROM   dbo.TempTb_Oil_AdditivesA
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_OilAdditivesA
                                          WHERE  助剂A批次 = AdditivesA
                                      )
                           AND 助剂A批次 IS NOT NULL;
        PRINT '表Tbl_Base_OilAdditivesA数据插入完毕，继续下一步';
        /*助剂B批次维护,查看是否已经补全档案*/
        PRINT '开始插入Tbl_Base_OilAdditivesB数据，继续下一步';
        DELETE FROM dbo.TempTb_Oil_AdditivesB
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Oil_AdditivesB
                            GROUP BY 助剂B批次
                        );
        INSERT INTO dbo.Tbl_Base_OilAdditivesB (   AdditivesB ,
                                                   ND ,
                                                   Temp ,
                                                   GHL,DHDate
                                               )
                    SELECT DISTINCT 助剂B批次 ,
                           粘度 ,
                           温度 ,
                           固含量,B物料到货日期
                    FROM   dbo.TempTb_Oil_AdditivesB
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_OilAdditivesB
                                          WHERE  助剂B批次 = AdditivesB
                                      )
                           AND 助剂B批次 IS NOT NULL;
        PRINT '表Tbl_Base_OilAdditivesB数据插入完毕，继续下一步';

        /*[L9 批次]维护,查看是否已经补全档案*/
        PRINT '开始插入Tbl_Base_OilL9Batch数据，继续下一步';
        DELETE FROM dbo.TempTb_Oil_L9
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_Oil_L9
                            GROUP BY [L9批次]
                        );
        INSERT INTO dbo.Tbl_Base_OilL9Batch (   L9Batch ,
                                                ZetaPotential ,
                                                Organic ,
                                                Psize05 ,
                                                Psize09 ,
                                                GHL
                                            )
                    SELECT DISTINCT [L9批次] ,
                           [L9zeta电位] ,
                           [L9有机物含量] ,
                           [L9粒径05] ,
                           [L9粒径09] ,
                           [固含量]
                    FROM   dbo.TempTb_Oil_L9
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_OilL9Batch
                                          WHERE  [L9批次] = L9Batch
                                      )
                           AND [L9批次] IS NOT NULL;
        PRINT '表Tbl_Base_OilL9Batch数据插入完毕，继续下一步';
        INSERT INTO dbo.Tbl_Base_OilAdditivesAType ( AdditivesATYpe )
                    SELECT DISTINCT 助剂A批次类型
                    FROM   dbo.TempTb_Oil
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   dbo.Tbl_Base_OilAdditivesAType
                                          WHERE  助剂A批次类型 = AdditivesATYpe
                                      )
                           AND 助剂A批次类型 IS NOT NULL;
        INSERT INTO dbo.Tbl_Base_OilAdditivesBType ( AdditivesBType )
                    SELECT DISTINCT 助剂B批次类型
                    FROM   dbo.TempTb_Oil
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   dbo.Tbl_Base_OilAdditivesBType
                                          WHERE  助剂B批次类型 = AdditivesBType
                                      )
                           AND 助剂B批次类型 IS NOT NULL;
        INSERT INTO dbo.Tbl_Base_OilL9BatchType ( L9BatchType )
                    SELECT DISTINCT L9批次类型
                    FROM   dbo.TempTb_Oil
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   dbo.Tbl_Base_OilL9BatchType
                                          WHERE  L9批次类型 = L9BatchType
                                      )
                           AND L9批次类型 IS NOT NULL;

        UPDATE dbo.Tbl_Base_BC0001
        SET    Density = BC0001密度 ,
               Tension = BC0001表面张力 ,
               Refractivity = BC0001折射率
        FROM   dbo.TempTb_Oil_BC0001
        WHERE  BC0001 = BC0001批号;
        UPDATE dbo.Tbl_Base_OilAdditivesA
        SET    GHL = 固含量 ,
               ZSL = 折射率 ,
               ddl = 电导率,
			   DHDate=A物料到货日期
        FROM   dbo.TempTb_Oil_AdditivesA
        WHERE  AdditivesA = 助剂A批次;
        UPDATE dbo.Tbl_Base_OilAdditivesB
        SET    GHL = 固含量 ,
               ND = 粘度 ,
               Temp = 温度,
			   DHDate=B物料到货日期
        FROM   dbo.TempTb_Oil_AdditivesB
        WHERE  AdditivesB = 助剂B批次;
        UPDATE dbo.Tbl_Base_OilL9Batch
        SET    GHL = 固含量 ,
               ZetaPotential = L9zeta电位 ,
               Organic = L9有机物含量 ,
               Psize05 = L9粒径05 ,
               Psize09 = L9粒径09
        FROM   dbo.TempTb_Oil_L9
        WHERE  L9Batch = L9批次;

        UPDATE Bs_Oil
        SET    OptDate = [操作日期] ,
               Series = Tbl_Base_OilSeries.id ,
               OilSpeed = 油相转速 ,
               Density = [密度] ,
               STension = [表面张力] ,
               Conductivity = [电导率] ,
               Viscosity = [粘度] ,
               PSize05 = [油相粒径05] ,
               PSize09 = [油相粒径09] ,
               Oiltemp = 油相温度 ,
               ParticalIDW1 = r1.ID ,
               ParticalIDW2 = r2.ID ,
               ParticalIDW3 = r3.ID ,
               ParticalIDBK1 = r4.ID ,
               ParticalIDBK2 = r5.ID ,
               ParticalIDBK3 = r6.ID ,
			   ParticalWCode1 = r1.Code ,
               ParticalWCode2 = r2.Code ,
               ParticalWCode3 = r3.Code ,
               ParticalBKCode1 = r4.Code ,
               ParticalBKCode2 = r5.Code ,
               ParticalBKCode3 = r6.Code ,
               MixParticalW05 = [混合白粒子粒径05] ,
               MixParticalW09 = [混合白粒子粒径09] ,
               MixParticalBK05 = [混合黑粒子粒径05] ,
               MixParticalBK09 = [混合黑粒子粒径09] ,
			   GHL=固含量,
               BC0001 = Tbl_Base_BC0001.ID ,
               AdditivesA = Tbl_Base_OilAdditivesA.ID ,
               AdditivesAType = Tbl_Base_OilAdditivesAType.ID ,
               AdditivesB = Tbl_Base_OilAdditivesB.ID ,
               AdditivesBType = Tbl_Base_OilAdditivesBType.ID ,
               L9Batch = Tbl_Base_OilL9Batch.ID ,
               L9BatchType = Tbl_Base_OilL9BatchType.ID ,
               update_time = GETDATE() ,
               ParticalWViscosityCP = [白色粒子_粘度CP] ,
               ParticalBKViscosityCP = [黑色粒子_粘度CP] ,
               [ParticalWTestTemp] = [白色粒子_测试温度C] ,
               [ParticalBKTestTemp] = [黑色粒子_测试温度C] ,
               [PercentBK45] = [BK大于45] ,
               [PercentW45] = [W大于45] ,
               HJTemp = 环境温度 ,
               HJhumidity = 环境湿度
        FROM   dbo.TempTb_Oil
               LEFT JOIN Tbl_Base_OilSeries ON NAME = TempTb_Oil.[油相系列]
               LEFT JOIN Tbl_Base_BC0001 ON BC0001 = TempTb_Oil.BC0001批次
               LEFT JOIN dbo.Tbl_Base_OilAdditivesA ON Tbl_Base_OilAdditivesA.AdditivesA = TempTb_Oil.助剂A批次
               LEFT JOIN Tbl_Base_OilAdditivesB ON Tbl_Base_OilAdditivesB.AdditivesB = TempTb_Oil.助剂B批次
               LEFT JOIN dbo.Tbl_Base_OilL9Batch ON Tbl_Base_OilL9Batch.L9Batch = TempTb_Oil.[L9批次]
               LEFT JOIN dbo.Tbl_Base_OilAdditivesAType ON Tbl_Base_OilAdditivesAType.AdditivesATYpe = TempTb_Oil.助剂A批次类型
               LEFT JOIN Tbl_Base_OilAdditivesBType ON Tbl_Base_OilAdditivesBType.AdditivesBType = TempTb_Oil.助剂B批次类型
               LEFT JOIN dbo.Tbl_Base_OilL9BatchType ON Tbl_Base_OilL9BatchType.L9BatchType = TempTb_Oil.[L9批次类型]
               LEFT JOIN dbo.Bs_ParticalW r1 ON r1.Code = TempTb_Oil.白粒子1编号
               LEFT JOIN dbo.Bs_ParticalW r2 ON r2.Code = TempTb_Oil.白粒子2编号
               LEFT JOIN dbo.Bs_ParticalW r3 ON r3.Code = TempTb_Oil.白粒子3编号
               LEFT JOIN dbo.Bs_ParticalBK r4 ON r4.Code = TempTb_Oil.黑粒子1编号
               LEFT JOIN dbo.Bs_ParticalBK r5 ON r5.Code = TempTb_Oil.黑粒子2编号
               LEFT JOIN dbo.Bs_ParticalBK r6 ON r6.Code = TempTb_Oil.黑粒子3编号
        WHERE  Bs_Oil.Code = 油相编号;

        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_Oil
                                            INNER JOIN dbo.TempTb_Oil ON TempTb_Oil.油相编号 = Bs_Oil.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;

        /*插入Bs_Oil*/
        PRINT '开始插入Bs_Oil数据，继续下一步';
        INSERT INTO dbo.Bs_Oil (   OptDate ,
                                   Code ,
                                   Series ,
                                   OilSpeed ,
                                   Density ,
                                   STension ,
                                   Conductivity ,
                                   Viscosity ,
                                   PSize05 ,
                                   PSize09 ,
                                   Oiltemp ,
                                   ParticalIDW1 ,
                                   ParticalIDW2 ,
                                   ParticalIDW3 ,
                                   ParticalIDBK1 ,
                                   ParticalIDBK2 ,
                                   ParticalIDBK3 ,
								   ParticalWCode1 ,
                                   ParticalWCode2 ,
                                   ParticalWCode3 ,
                                   ParticalBKCode1 ,
                                   ParticalBKCode2 ,
                                   ParticalBKCode3 ,
                                   MixParticalW05 ,
                                   MixParticalW09 ,
                                   MixParticalBK05 ,
                                   MixParticalBK09 ,
                                   BC0001 ,
								   GHL,
                                   AdditivesA ,
                                   AdditivesAType ,
                                   AdditivesB ,
                                   AdditivesBType ,
                                   L9Batch ,
                                   L9BatchType ,
                                   update_time ,
                                   ParticalWViscosityCP ,
                                   ParticalBKViscosityCP ,
                                   [ParticalWTestTemp] ,
                                   [ParticalBKTestTemp] ,
                                   [PercentBK45] ,
                                   [PercentW45] ,
                                   HJTemp ,
                                   HJhumidity
                               )
                    SELECT [操作日期] ,
                           [油相编号] ,
                           Tbl_Base_OilSeries.id ,
                           油相转速 ,
                           [密度] ,
                           [表面张力] ,
                           [电导率] ,
                           [粘度] ,
                           [油相粒径05] ,
                           [油相粒径09] ,
                           油相温度 ,
                           r1.ID ,
                           r2.ID ,
                           r3.ID ,
                           r4.ID ,
                           r5.ID ,
                           r6.ID ,
						   r1.Code ,
                           r2.Code ,
                           r3.Code ,
                           r4.Code ,
                           r5.Code ,
                           r6.Code ,
                           [混合白粒子粒径05] ,
                           [混合白粒子粒径09] ,
                           [混合黑粒子粒径05] ,
                           [混合黑粒子粒径09] ,
                           Tbl_Base_BC0001.ID ,
						   固含量,
                           Tbl_Base_OilAdditivesA.ID ,
                           Tbl_Base_OilAdditivesAType.ID ,
                           Tbl_Base_OilAdditivesB.ID ,
                           Tbl_Base_OilAdditivesBType.ID ,
                           Tbl_Base_OilL9Batch.ID ,
                           Tbl_Base_OilL9BatchType.ID ,
                           GETDATE() ,
                           [白色粒子_粘度CP] ,
                           [黑色粒子_粘度CP] ,
                           [白色粒子_测试温度C] ,
                           [黑色粒子_测试温度C] ,
                           [BK大于45] ,
                           [W大于45] ,
                           环境温度 ,
                           环境湿度
                    FROM   [dbo].TempTb_Oil
                           LEFT JOIN Tbl_Base_OilSeries ON NAME = TempTb_Oil.[油相系列]
                           LEFT JOIN Tbl_Base_BC0001 ON BC0001 = TempTb_Oil.BC0001批次
                           LEFT JOIN dbo.Tbl_Base_OilAdditivesA ON Tbl_Base_OilAdditivesA.AdditivesA = TempTb_Oil.助剂A批次
                           LEFT JOIN Tbl_Base_OilAdditivesB ON Tbl_Base_OilAdditivesB.AdditivesB = TempTb_Oil.助剂B批次
                           LEFT JOIN dbo.Tbl_Base_OilL9Batch ON Tbl_Base_OilL9Batch.L9Batch = TempTb_Oil.[L9批次]
                           LEFT JOIN dbo.Tbl_Base_OilAdditivesAType ON Tbl_Base_OilAdditivesAType.AdditivesATYpe = TempTb_Oil.助剂A批次类型
                           LEFT JOIN Tbl_Base_OilAdditivesBType ON Tbl_Base_OilAdditivesBType.AdditivesBType = TempTb_Oil.助剂B批次类型
                           LEFT JOIN dbo.Tbl_Base_OilL9BatchType ON Tbl_Base_OilL9BatchType.L9BatchType = TempTb_Oil.[L9批次类型]
                           LEFT JOIN dbo.Bs_ParticalW r1 ON r1.Code = TempTb_Oil.白粒子1编号
                           LEFT JOIN dbo.Bs_ParticalW r2 ON r2.Code = TempTb_Oil.白粒子2编号
                           LEFT JOIN dbo.Bs_ParticalW r3 ON r3.Code = TempTb_Oil.白粒子3编号
                           LEFT JOIN dbo.Bs_ParticalBK r4 ON r4.Code = TempTb_Oil.黑粒子1编号
                           LEFT JOIN dbo.Bs_ParticalBK r5 ON r5.Code = TempTb_Oil.黑粒子2编号
                           LEFT JOIN dbo.Bs_ParticalBK r6 ON r6.Code = TempTb_Oil.黑粒子3编号
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_Oil
                                          WHERE  Code = 油相编号
                                      );



        PRINT '表Bs_Oil数据插入完毕，继续下一步';
        PRINT '所有过程完成';

    END;

go

