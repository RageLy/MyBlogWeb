-- =============================================
-- Author:		<柳燕杰>
-- Create date: <2012-02-07>
-- Description:	<获取登录人的权限>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Sys_GetUserPermission]
	 @UserAccount varchar(500)=''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
--[Sp_Sys_GetUserPemission] 'wuguofeng'
    -- Insert statements for procedure here
  select distinct MenuID,FormID,GroupID,ControlID,ControlType,MenuName,GroupName,ControlName,AllowVisible,AllowInsert,AllowEdit,AllowDelete
  from Tbl_Sys_Permission
  where PermissionID
  in (
  
  select PermissionID
  from Tbl_Sys_TrPemission
  where TacticsID in 
  (
  select TacticsID
  from Tbl_Sys_RoleTactics
  where RoleID
  in(
  select a.RoleID
  from Tbl_Sys_Role a
  inner join 
  Tbl_Sys_UserRoleRelation b
  on a.RoleID = b.RoleID
  inner join 
  Tbl_Sys_User c
  on b.UserID = c.UserID
  where c.UserAccount = @UserAccount
  )
  )
  )
  
END
go

