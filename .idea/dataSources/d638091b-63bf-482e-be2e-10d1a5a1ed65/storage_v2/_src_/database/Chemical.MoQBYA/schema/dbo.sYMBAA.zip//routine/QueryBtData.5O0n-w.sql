CREATE PROCEDURE QueryBtData
AS 
BEGIN 
SELECT Name ,COUNT(Name) ct INTO 
#Result 
from (select Name from Btr_24
union all 
select Name from Btr_203
) t 
GROUP BY Name;
DECLARE @b INT;
SET @b = ( SELECT MAX(ct) FROM #Result);
SELECT Tbl_Base_ActRules.ID,Tbl_Base_ActRules.Name BcName,Tbl_Base_ActRules.AtomCount
FROM #Result
INNER JOIN dbo.Tbl_Base_ActRules ON Tbl_Base_ActRules.ID = #Result.Name
INNER JOIN dbo.Bs_ActRulers ON Tbl_Base_ActRules.ID = Bs_ActRulers.ActSmiles
INNER JOIN dbo.Bs_BaseCompound ON Bs_BaseCompound.ID = Bs_ActRulers.CompoundID
WHERE ct = @b order by Tbl_Base_ActRules.AtomCount desc; 
END;
go

