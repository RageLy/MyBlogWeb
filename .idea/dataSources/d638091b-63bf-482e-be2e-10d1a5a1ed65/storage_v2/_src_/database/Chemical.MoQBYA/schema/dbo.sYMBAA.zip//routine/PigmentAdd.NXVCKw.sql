-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[PigmentAdd] 
--@OptDate datetime = '', 
@ID varchar(50) = '',
@OptDate varchar(50) = '',
@Code varchar(50) = ' ', 
@PType varchar(50) = '', 
@SolventC varchar(50) = '' ,
@SolventD varchar(50) = '', 
@SolventE varchar(50) = '' ,
@SolventF varchar(50) = '' ,
@SolventW varchar(50) = '',
@InnerCode varchar(50) = '',
@Action varchar(50) = 'Select',--Insert  Select
@OutCode varchar(50) = '',
@PSize05Bef varchar(50) = '', 
@PSize05Aft varchar(50) = '', 
@PSize09Bef varchar(50) = '', 
@PSize09Aft varchar(50) = '', 
@Kettle varchar(50) = '',
@Mass varchar(50) = '',
@ReactTempActually varchar(50) = '',
@CTRSpeedActually varchar(50) = '',
@FRSpeedActually varchar(50) = '',
@PH varchar(50) = '',
@ReactOutput  varchar(50) = '',
@GrindOutput varchar(50) = '',
@RemarK varchar(50) = '',
@PreheatETime varchar(50) = '',
@PreheatBTime varchar(50) = '',
@PageIndex varchar(5) = '1',  
@PageSize varchar(5) = '10',
@EmpID varchar(50) = '1',
@OrderFields varchar(50) = ''   
AS
BEGIN
	DECLARE @columnNames  VARCHAR(MAX) = ''   -- 输出的表名段语句，根据select段决定	
	 -- 行数量 用于分页sp
	DECLARE @Pagesql VARCHAR(2000) = '' -- 用于分页的sql
	DECLARE @SelectValue VARCHAR(MAX) = ''   -- select 段的语句，根据 【结果类型】 决定输出哪些列
	DECLARE @WhereValue  VARCHAR(MAX) = ''  -- Where 段的参数选择语句
	DECLARE @allsql  VARCHAR(MAX) = ''  -- sql 语句
	DECLARE @ROWCOUNT int = ''
	SET NOCOUNT ON;
	set @SelectValue='OptDate,Code,PType,SolventC ,SolventD,SolventE ,SolventF ,SolventW,PreheatTime';
	
	if @ReactOutput=''
	begin
	   set @ReactOutput=NULL
	end
	
	if @FRSpeedActually=''
	begin
	   set @FRSpeedActually=NULL
	end
	
	if @CTRSpeedActually=''
	begin
	   set @CTRSpeedActually=NULL
	end
	
	if @ReactTempActually=''
	begin
	   set @ReactTempActually=NULL
	end
	
	if @GrindOutput=''
	begin
	   set @GrindOutput=NULL
	end
	
	if @PH=''
	begin
	   set @PH=NULL
	end	

	if @PSize05Bef=''
	begin
	   set @PSize05Bef=NULL
	end
	
	if @PSize05Aft=''
	begin
	   set @PSize05Aft=NULL
	end
	
	if @PSize09Bef=''
	begin
	   set @PSize09Bef=NULL
	end
	
	if @PSize09Aft=''
	begin
	   set @PSize09Aft=NULL
	end
	
	if @Mass=''
	begin
	   set @Mass=NULL
	end
	
	IF @Action = 'Insert'  --插入数据
	BEGIN
	IF(@ID = '')        
    BEGIN
		   insert into Bs_Pigment(OptDate
		   ,Code
		   ,PType
		   ,SolventC
		   ,SolventD
		   ,SolventE
		   ,SolventF
		   ,SolventW
		   ,InnerCode
		   ,OutCode
		   ,PSize05Bef 
		   ,PSize05Aft
		   ,PSize09Bef 
		   ,PSize09Aft
		   ,Kettle
		   ,Mass
		   ,ReactTempActually
		   ,CTRSpeedActually
		   ,FRSpeedActually
		   ,PH
		   ,ReactOutput
		   ,GrindOutput
		   ,RemarK
		   ,PreheatBTime
           ,PreheatETime)
		   values(dbo.trim(@OptDate)
		   , dbo.trim(@Code)
		   , dbo.trim(@PType)
		   , dbo.trim(@SolventC)
		   , dbo.trim(@SolventD)
		   , dbo.trim(@SolventE)
		   , dbo.trim(@SolventF)
		   , dbo.trim(@SolventW)
		   , dbo.trim(@InnerCode)
		   , dbo.trim(@OutCode)
		   , dbo.trim(@PSize05Bef)
		   , dbo.trim(@PSize05Aft)
		   , dbo.trim(@PSize09Bef)
		   , dbo.trim(@PSize09Aft)
		   , dbo.trim(@Kettle)
		   , dbo.trim(@Mass)
		   , dbo.trim(@ReactTempActually)
		   , dbo.trim(@CTRSpeedActually)
		   , dbo.trim(@FRSpeedActually)
		   , dbo.trim(@PH)
		   , dbo.trim(@ReactOutput)
		   , dbo.trim(@GrindOutput)
		   , dbo.trim(@RemarK)
		   , dbo.trim(@PreheatBTime)
           , dbo.trim(@PreheatETime)) 
    
    set @allsql=@OptDate
		   +','+@Code
		   +','+@PType
		   +','+@SolventC
		   +','+@SolventD
		   +','+@SolventE
		   +','+@SolventF
		   +','+@SolventW
		   +','+@InnerCode
		   +','+@OutCode
		   +','+Isnull(@PSize05Bef,'')
		   +','+Isnull(@PSize05Aft,'')
		   +','+Isnull(@PSize09Bef,'')
		   +','+Isnull(@PSize09Aft,'')
		   +','+@Kettle
		   +','+Isnull(@Mass,'')
		   +','+Isnull(@ReactTempActually,'')
		   +','+Isnull(@CTRSpeedActually,'')
		   +','+Isnull(@FRSpeedActually,'')
		   +','+Isnull(@PH,'')
		   +','+Isnull(@ReactOutput,'')
		   +','+Isnull(@GrindOutput,'')
		   +','+@RemarK
		   +','+@PreheatBTime
           +','+@PreheatETime
   
      INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'PigmentAdd',
        '新增颜料数据','insert',@allsql)  
			
	    
    
    end
    else
		begin	     
			UPDATE  Bs_Pigment SET         
			OptDate = dbo.trim(@OptDate)     
			,Code = dbo.trim(@Code)        
			,PType = dbo.trim(@PType)        
			,SolventC = dbo.trim(@SolventC)       
			,SolventD = dbo.trim(@SolventD)        
			,SolventE = dbo.trim(@SolventE)              
			,SolventF = dbo.trim(@SolventF)
			,SolventW = dbo.trim(@SolventW)   
			,InnerCode = dbo.trim(@InnerCode)   
			,OutCode = dbo.trim(@OutCode)
			,PSize05Bef = dbo.trim(@PSize05Bef)
			,PSize05Aft = dbo.trim(@PSize05Aft)
			,PSize09Bef = dbo.trim(@PSize09Bef)
			,PSize09Aft = dbo.trim(@PSize09Aft)
			,Kettle=dbo.trim(@Kettle)
		    ,Mass=dbo.trim(@Mass)
		    ,ReactTempActually=dbo.trim(@ReactTempActually)
		    ,CTRSpeedActually=dbo.trim(@CTRSpeedActually)
		    ,FRSpeedActually=dbo.trim(@FRSpeedActually)
		    ,PH=dbo.trim(@PH)
		    ,ReactOutput=dbo.trim(@ReactOutput)
		    ,GrindOutput=dbo.trim(@GrindOutput)
		    ,RemarK=dbo.trim(@RemarK)
		    ,PreheatBTime=dbo.trim(@PreheatBTime)
		    ,PreheatETime=dbo.trim(@PreheatETime)
			WHERE ID = @ID   
			
			 --加入日志
    
  set @allsql=@OptDate
		   +','+@Code
		   +','+@PType
		   +','+@SolventC
		   +','+@SolventD
		   +','+@SolventE
		   +','+@SolventF
		   +','+@SolventW
		   +','+@InnerCode
		   +','+@OutCode
		   +','+Isnull(@PSize05Bef,'')
		   +','+Isnull(@PSize05Aft,'')
		   +','+Isnull(@PSize09Bef,'')
		   +','+Isnull(@PSize09Aft,'')
		   +','+@Kettle
		   +','+Isnull(@Mass,'')
		   +','+Isnull(@ReactTempActually,'')
		   +','+Isnull(@CTRSpeedActually,'')
		   +','+Isnull(@FRSpeedActually,'')
		   +','+Isnull(@PH,'')
		   +','+Isnull(@ReactOutput,'')
		   +','+Isnull(@GrindOutput,'')
		   +','+@RemarK
		   +','+@PreheatBTime
           +','+@PreheatETime+' WHERE ID = '+@ID
   
      INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'PigmentAdd',
        '编辑颜料数据','ID = '+@ID,@allsql)  
			
	    end;

    
    -- Insert statements for procedure here
	SELECT 0
	end;
	
	--查询数据
	
	IF @Action = 'Select' or @Action = 'Select1'  --查询数据  Select1表示只查询一条记录
	BEGIN
	--OptDate,Code,PType,SolventC ,SolventD,SolventE ,SolventF ,SolventW
    /*
	    SET @columnNames = 'select  ''n'' AS 序号,''OptDate'' AS 反应日期,''Code'' as 颜料编号                 
					union all
					select ''varchar 500'',''varchar 500'',''varchar 500'''    	
    	PRINT @columnNames
    	exec (@columnNames )    	
    	*/
  	
    	IF(@PType<>'')        
		BEGIN        
		  set @WhereValue=' and PType ='''+ @PType+''' '		           
		END 
	 
		IF(@OptDate<>'')        
		BEGIN        
		  set @WhereValue=@WhereValue+' and OptDate =CONVERT(varchar(100),'''+ @OptDate+''', 10) '	 
		  --  set @WhereValue=@WhereValue+' and OptDate ='+ @OptDate	  	          
		END 
		
		IF(@Code<>'')        
		BEGIN        
		  set @WhereValue=@WhereValue+' and Code ='''+ @Code+''' '		
		  --  set @WhereValue=@WhereValue+' and OptDate ='+ @OptDate	  	          
		END 
		
		IF(@ID<>'')        
		BEGIN        
		  set @WhereValue=@WhereValue+' and ID ='+ @ID		
		  --  set @WhereValue=@WhereValue+' and OptDate ='+ @OptDate	  	          
		END 
		
    	
    	if  @Action = 'Select1' and @ID = ''
    	begin
    	   return
    	end
    	
    	IF(@WhereValue<>'')        
		BEGIN		      
		  set @WhereValue= ' where 1=1 '+@WhereValue
		    INSERT INTO Tbl_Log_AnaUseLog(EmpID, freshTime, spName,
             AnaName, siftvalue, OherParemeter)
             VALUES (@EmpID, GETDATE(), 'PigmentAdd','查询颜料数据','select',@WhereValue)
		END		

       set @allsql='select  [ID]
      ,[Code]
      ,CONVERT(varchar(100),OptDate, 23) OptDate    
      ,[PType]
      ,[Kettle]
      ,[Mass]
      ,[InnerCode]
      ,[OutCode]
      ,[SolventE]
      ,[SolventEDosage]
      ,[SolventW]
      ,[SolventWDosage]
      ,[SolventC]
      ,[SolventCDosage]
      ,[SolventD]
      ,[SolventDDosage]
      ,[SolventF]
      ,[SolventFDosage]
      ,[SolventI]
      ,[SolventIDosage]
      ,[PreheatTimeSet]
       ,SUBSTRING(convert(varchar,PreheatBTime,108),0,6) as PreheatBTime     
      ,SUBSTRING(convert(varchar,PreheatETime,108),0,6) as PreheatETime
      ,[ReactTempSet]
      ,[ReactTempActually]
      ,[ReactTimeSet]
      ,[ReactBTime]
      ,[ReactETime]
      ,[CTRSpeedSet]
      ,[CTRSpeedActually]
      ,[DisTimeSet]
      ,[DisBTime]
      ,[DisETime]
      ,[FRSpeedSet]
      ,[FRSpeedActually]
      ,[ReactOutput]
      ,[GrindOutput]
      ,[PSize05Bef]
      ,[PSize09Bef]
      ,[PSize05Aft]
      ,[PSize09Aft]
      ,[PH]
      ,[RemarK]
      ,[info] INTO #B  from Bs_Pigment '+@WhereValue+';'   
     
       
			
  --   select @allsql
 	 
	--set @ROWCOUNT=@@rowcount 
 
      print '查询'
     if(@OrderFields='')  
        set @OrderFields ='ID desc'  
 
 	-- 数据分页
	
	set @Pagesql =
	'
	 EXEC dbo.Sp_Sys_Page @tblName = ''#B''                   
	 ,@fldName = '' ' + @OrderFields + ' ''                    
	 ,@rowcount =@@rowcount 
     ,@PageIndex = ' + @PageIndex + '    
     ,@PageSize = ' + @PageSize + '  
	 ,@SumType = 0
	 ,@SumColumn = ''
	 ,@AvgColumn = ''	'
	--PRINT(@allsql+@Pagesql)
    exec (@allsql+@Pagesql)
 
	--EXEC dbo.Sp_Sys_Page @tblName = '#B'                      
	-- ,@fldName = 'ID desc'                            
	-- ,@rowcount = @ROWCOUNT 
	-- ,@PageIndex = 1
	-- ,@PageSize = 1000
	-- ,@SumType = 0
	-- ,@SumColumn = ''
	-- ,@AvgColumn = ''
	 
	
	end;
	
END
go

