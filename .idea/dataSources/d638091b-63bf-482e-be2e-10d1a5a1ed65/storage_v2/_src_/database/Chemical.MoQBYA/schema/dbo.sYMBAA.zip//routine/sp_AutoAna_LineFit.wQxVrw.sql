

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_AutoAna_LineFit]
	@data SpearmanPara READONLY
	,@a DECIMAL(18,6) OUTPUT -- 斜率
	,@b DECIMAL(18,6) OUTPUT -- 常数
AS
BEGIN
		
	DECLARE @afenzi DECIMAL(24,12);
	DECLARE @bfenzi DECIMAL(24,12);
	DECLARE @fenmu DECIMAL(24,12);
	
	select @afenzi = t3 * n - t2 * t4 ,@bfenzi = (t1 * t4) - (t2 * t3),@fenmu = t1 * n  - t2 * t2 FROM 
		(
			SELECT cast(SUM(x * x) as DECIMAL(24,12)) AS t1
			, cast(SUM(x) as DECIMAL(24,12))  AS t2
			, cast(SUM(x * y) as DECIMAL(24,12)) AS t3
			, cast(SUM(y) as DECIMAL(24,12)) AS t4
			, cast(COUNT(*) as DECIMAL(24,12)) AS n
			FROM @data
		) x

	IF(@fenmu <> 0) 
		SELECT @a = @afenzi / @fenmu , @b = @bfenzi / @fenmu;
	ELSE   -- 分母为0的情况
		SELECT @a = 1,@b = 0;


	--SELECT @a,@b,@afenzi,@bfenzi,@fenmu;

END
go

