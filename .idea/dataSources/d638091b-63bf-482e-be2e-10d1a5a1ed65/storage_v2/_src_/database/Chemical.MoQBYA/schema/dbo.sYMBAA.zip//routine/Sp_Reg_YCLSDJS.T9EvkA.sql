
-- =============================================
-- Author:		hjl
-- Create date: 2016-04-1
-- Description:	一个油相、一组公益参数循环计算
-- =============================================
create PROCEDURE [dbo].[Sp_Reg_YCLSDJS]
 
@YXNum		VARCHAR(100) = 'RN1505FB001'		--回归计算的油相编号
,@CSMC1     VARCHAR(100) = 't41'       --实验计算的参数名称1
,@CSMC2     VARCHAR(100) = 's41'      --实验计算的参数名称2
,@Min1		DECIMAL(12,2) = 10		-- 计算2的小值
,@Max1		DECIMAL(12,2) = 500		--计算2的最大值
,@Interval1	DECIMAL(12,2) = 10		--计算2的间隔值
,@Min2		DECIMAL(12,2) = 1		-- 计算2的小值
,@Max2		DECIMAL(12,2) = 40		--计算2的最大值
,@Interval2	DECIMAL(12,2) = 1		--计算2的间隔值
,@t8        DECIMAL(12,2) = 150	
,@t25        DECIMAL(12,2) = 150	
,@t41        DECIMAL(12,2) = 150	
,@s8         DECIMAL(12,2) = 5	
,@s25        DECIMAL(12,2) = 5	
,@s41        DECIMAL(12,2) = 5	

AS
BEGIN

	--- 验证油相编号存在
	IF NOT EXISTS(SELECT * FROM dbo.Tbl_Data_eCapsule WHERE YXNum = @YXNum)
	BEGIN
		SELECT '油相编号不存在！';
		RETURN;
	END

	-- 验证实验参数正确
	IF (@CSMC1 NOT IN ('t8','t25','t41','s8','s25','s41'))
	BEGIN
		SELECT '实验参数名称不存在！';
		RETURN;
	END

	IF (@CSMC2 NOT IN ('t8','t25','t41','s8','s25','s41'))
	BEGIN
		SELECT '实验参数名称不存在！';
		RETURN;
	END
-------------------------------------- 开始一次明细计算 --------------------------------------------------
			exec	[dbo].[Sp_Reg_YCGHJS]
			@JSBH      = 'hjl41第一次计算'
			,@RegNum	= '第一对温度41转速41'
			,@YXNum		= 'RN1505FB001'	
			,@CSMC1     = 't41'  
			,@CSMC2     = 's41'  
			,@Min1		 = 10	
			,@Max1		 = 500	
			,@Interval1	 = 10	
			,@Min2		 = 1	
			,@Max2		 = 40	
			,@Interval2	 = 1	
			,@t8         = 150	
			,@t25        = 150	
			,@t41        = 150	
			,@s8         = 5	
			,@s25        = 5	
			,@s41        = 5	;
			
			exec	[dbo].[Sp_Reg_YCGHJS]
			@JSBH      = 'hjl41第一次计算'
			,@RegNum	= '第二对温度8'
			,@YXNum		= 'RN1505FB001'	
			,@CSMC1     = 's8'  
			,@CSMC2     = 't8'  
			,@Min1		 = 1	
			,@Max1		 = 1	
			,@Interval1	 = 1	
			,@Min2		 = 10	
			,@Max2		 = 500	
			,@Interval2	 = 10	
			,@t8         = 150	
			,@t25        = 150	
			,@t41        = 20	
			,@s8         = 5	
			,@s25        = 5	
			,@s41        = 1	
-------------------------------------- 开始明细的合计计算 ------------------------------------------------

	INSERT  dbo.Reg_eCapsule ( JSBH,YXNum ,LValue,LSD ,RegNum,whileNum ,c_temp8 ,c_temp25 ,c_temp41 ,c_speed25 ,c_speed41)
		
		SELECT 'hjl41第一次计算','RN1505FB001'
		,avgPoint
		,ISNULL(SUM(DiscreteValue),0)
		,'第二对温度8'
		,whileNum
		,t8
		,t25
		,t41
		,s25
		,s41
		FROM dbo.Reg_eCapsule_Detail
		WHERE JSBH = 'hjl41第一次计算'
		and	RegNum = '第二对温度8'
		 AND YXNum = 'RN1505FB001'
		 GROUP BY avgPoint,whileNum,t8,t25,t41,s25,s41

END

go

