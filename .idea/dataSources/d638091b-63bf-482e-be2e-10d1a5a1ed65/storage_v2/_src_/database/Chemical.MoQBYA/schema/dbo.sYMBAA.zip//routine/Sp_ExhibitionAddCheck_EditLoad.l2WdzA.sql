  
        
        
/*
刘轶 2014-8-5  展厅新增检查 编辑
*/            
CREATE proc [dbo].[Sp_ExhibitionAddCheck_EditLoad]            
@EmpID varchar(50)='556'            
as            
BEGIN                        
select cast(EmpID as varchar(50))  as EmpID
	   ,cast(isnull(CPlan,0) as varchar(50)) as CPlan               
from Tbl_Com_Employee as e             
where EmpID = @EmpID            
END
go

