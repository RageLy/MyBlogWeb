
CREATE PROC [dbo].[Sp_Com_ReadOpenMessage]
@MesID varchar(50)
AS
BEGIN
UPDATE   Tbl_Com_OpenMessage SET IsRead = 1 ,ReadTime = GETDATE() WHERE MesID = @MesID
END
go

