

-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 柱图、折线图两个图形的标准分析器sp

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_ActMn_List]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimSinYX:-1%DimOilSeries:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimDDLps:-1%DimOilViscosity:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimSinJNPH:-1%DimSinBG0002:-1%DimOilDensity:-1%DimOilSTension:-1'
 --,@OtherCond VARCHAR(MAX) ='%温度8%釜%胶囊产值%line%平均值%温度8%数量'
 --,@Type VARCHAR(10) = '列表' -- '业务列表'  业务列表表示用于展示业务的列表
    ,
    @OrderFields VARCHAR(100) = '' ,
    @SpName VARCHAR(50) = 'SinCapsule' ,
    @EmpID INT = 1

 -- 以下参数只在出明细时使用
    ,
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15' ,
    @XValue VARCHAR(50) = '' ,
    @DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
    BEGIN

---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

        SET NOCOUNT ON;

        DECLARE @SiftValue VARCHAR(MAX);
        SET @SiftValue = REPLACE(@condition, '|', ',');
            
-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            
    
----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       
    

	-- 时间表 时间临时表必然需要
        CREATE TABLE #time
            (
              id VARCHAR(200) ,
              beginDate DATETIME ,
              endDate DATETIME ,
              beginDate_Lp DATETIME ,
              endDate_Lp DATETIME ,
              beginDate_Ly DATETIME ,
              endDate_Ly DATETIME
            );
	
	-- 如果有其它需要用 #时间表的必须在这里添加
	
        DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
        DECLARE @XOrder VARCHAR(500);      -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
        DECLARE @DsOrder VARCHAR(500);     -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
        DECLARE @CountType VARCHAR(100);   -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
        DECLARE @NumSql VARCHAR(500);      -- 用于拼接@Sql中 指标计算方式的Sql语句            
        DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	

	-- 处理维度临时表
        CREATE TABLE #Dims
            (
              DimName VARCHAR(50) ,
              DimValues VARCHAR(MAX) ,
              ChName VARCHAR(50) ,
              Isneed VARCHAR(50) ,
              DimOrdersql VARCHAR(50) ,
              DimYsql VARCHAR(50) ,
              isrange VARCHAR(50)
            );
     
        EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue, @XName = '',
            @DsName = '';
     
     --SELECT * FROM #Dims
        UPDATE  #Dims
        SET     Isneed = 'ND'
        WHERE   ChName = '顺序维度选择';
        UPDATE  #Dims
        SET     Isneed = 'ND'
        WHERE   ChName = '分组维度';
     -- 拼接创建维度临时表的语句

     
        SET @sql += ( SELECT    'CREATE TABLE #' + DimName
                                + -- 非范围维度类型3列
					CASE WHEN isrange = 0
                         THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
                         WHEN isrange = 1
                         THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'
                    END
                      FROM      #Dims
                      WHERE     Isneed <> 'ND'
                    FOR
                      XML PATH('')
                    );

        IF @sql IS NULL
            SET @sql = '';
    
        DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
     -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析
     
     -- 用 Dims 临时表拼接需要解析的 维度字符串
        SET @NeedSiftvalue = ( SELECT   '%' + DimName + ':' + DimValues
                               FROM     #Dims
                               WHERE    Isneed <> 'ND'
                             FOR
                               XML PATH('')
                             );
     
        IF @NeedSiftvalue IS NULL
            SET @NeedSiftvalue = '';
     
     -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
        SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7', @SiftValue) <> 0
                                  THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,
                                                              'Dim7')
                                       + @NeedSiftvalue
                                  ELSE SUBSTRING(@NeedSiftvalue, 2,
                                                 LEN(@NeedSiftvalue))
                             END;

     -- 解析维度
        SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''
            + @NeedSiftvalue + ''', @EmpID = ' + CAST(@EmpID AS VARCHAR(50))
            + ';';
    
	
-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              


	-- 处理select语句
	
        SET @InnerSelect = ( SELECT ',' + TableName + '.[' + CoName + '] AS '
                                    + TableName + CoName
                             FROM   Tbl_AnsCom_DIimToTable
                             WHERE  CHARINDEX(',' + @SpName + ',', SpType) > 0
                                    AND IsDimBan = 'False'
                             ORDER BY ShowIndex
                           FOR
                             XML PATH('')
                           );
	
        SET @InnerSelect = SUBSTRING(@InnerSelect, 2, LEN(@InnerSelect));


   -- 构造列名
   
        DECLARE @CoChNames VARCHAR(MAX);
   
        SET @CoChNames = ( SELECT   ',''' + TableName + CoName + ''' AS ['
                                    + Name_ch + ']'
                           FROM     Tbl_AnsCom_DIimToTable
                           WHERE    CHARINDEX(',' + @SpName + ',', SpType) > 0
                                    AND IsDimBan = 'False'
                           ORDER BY ShowIndex
                         FOR
                           XML PATH('')
                         );
	
        DECLARE @Varchar500s VARCHAR(MAX);
   
        SET @Varchar500s = ( SELECT ',''Varchar 500'''
                             FROM   Tbl_AnsCom_DIimToTable
                             WHERE  CHARINDEX(',' + @SpName + ',', SpType) > 0
                                    AND IsDimBan = 'False'
                             ORDER BY ShowIndex
                           FOR
                             XML PATH('')
                           );
    

        SET @sql += '
    select ActMn.* INTO #Result from (SELECT ' + ( SELECT ISNULL(SqlKey, '') + ' '
                 FROM   dbo.Tbl_AnsCom_AnaSpConfig
                 WHERE  SpName = @SpName
               );
 
        DECLARE @FromSql VARCHAR(MAX) = ( SELECT    JoinTables + ' '
                                                    + ISNULL(BaseTable,'')
                                          FROM      Tbl_AnsCom_AnaSpConfig
                                          WHERE     SpName = @SpName
                                        );
	 
	
	 --SELECT @InnerSelect
        SET @sql += ISNULL(@InnerSelect, '') + '  FROM '
            + @FromSql;

 --PRINT @sql

  -- 临时存储拼接的SQL语句
        DECLARE @sql1 VARCHAR(MAX) = '';
  
  -- 将INNER JOIN 维度临时表段拼接起来
  --DECLARE @JoinSql NVARCHAR(1000)=
        SET @sql1 = ( SELECT    ' INNER JOIN #' + DimName + ' AS ' + DimName
                                + ' on '
                                + -- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1
             THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName
                  + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
             WHEN CHARINDEX(';',DimYsql) > 0
             THEN '(' + DimName + '.ID = ' + SUBSTRING(DimYsql, 0,
                                                       CHARINDEX(';', DimYsql,
                                                              0)) + ' OR '
                  + DimName + '.ID = ' + SUBSTRING(DimYsql,
                                                   CHARINDEX(';', DimYsql, 0)
                                                   + 1,
                                                   LEN(DimYsql)
                                                   - CHARINDEX(';', DimYsql, 0))
                  + ')'
             ELSE DimName + '.ID = ' + DimYsql
        END
                      FROM      #Dims
                      WHERE     Isneed <> 'ND'
                    FOR
                      XML PATH('')
                    );
                
                   
   -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
        SET @sql1 = REPLACE(REPLACE(@sql1, '&lt;', '<'), '&gt;', '>');
  
  -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'
        SET @sql += ISNULL(@sql1, '')+' ) ActMn';
 -- SELECT @sql1;
    DECLARE @sql2 NVARCHAR(MAX)=''
                    SET @sql2+= '
    inner join (SELECT ' + ( SELECT ISNULL(SqlKey, '') + ' '
                 FROM   dbo.Tbl_AnsCom_AnaSpConfig
                 WHERE  SpName = @SpName
               );
		SET @sql2 += ISNULL(@InnerSelect, '') + '  FROM '
            + @FromSql;
      
            IF((SELECT COUNT(Isneed) FROM #Dims  WHERE (DimName='DimActOrgSmCodeType' OR DimName='DimActOrgSmCodeType' OR DimName='DimActStep') AND Isneed='F')>0 )
            SET @sql2+=') ActMn1 ON ActMn1.ActMnCode = ActMn.ActMnCode AND ActMn1.StepStep<=ActMn.StepStep '
            ELSE
            SET @sql2+=') ActMn1 ON ActMn1.ActMnCode = ActMn.ActMnCode AND ActMn1.StepStep=ActMn.StepStep '
 
 --PRINT @sql2
  --SET @sql+=@sql2
			-- 默认使用时间排序
        IF ( @OrderFields IS NULL
             OR @OrderFields = ''
           )
            SET @OrderFields = 'StepStep,ActMnOrgID1,ActMnOrg1ActPoint,ActMnOrgID2';

  
        DECLARE @Pagesql VARCHAR(MAX) = 'DECLARE @totalRow int = (Select count(1) FROM #Result) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow   
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''  
  ,@AvgColumn = ''  
 ';  
   
   --插入错误提示的判断语句
	
  --print  @Pagesql;
  -- 注销临时表
        SET @sql += ISNULL(( SELECT ' DROP TABLE #' + DimName + ';'
                             FROM   #Dims
                             WHERE  Isneed <> 'ND'
                           FOR
                             XML PATH('')
                           ), '');
	
  
  --PRINT @SqlName;
  -- 运行处表头
  --PRINT @Varchar500s;
        PRINT ' SELECT ''n'' AS 序号' + @CoChNames
            + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s;
        EXEC(' SELECT ''n'' AS 序号' + @CoChNames + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s);
  
        PRINT ' CREATE TABLE #time            
    (            
      id VARCHAR(200) ,            
      beginDate DATETIME ,            
      endDate DATETIME ,            
      beginDate_Lp DATETIME ,            
      endDate_Lp DATETIME ,            
      beginDate_Ly DATETIME ,            
      endDate_Ly DATETIME            
    )' + @sql;
  --  SELECT @sql;
   --SELECT @sql + @Pagesql  
        EXEC(@sql + @Pagesql);
  --PRINT @sql
  --SELECT @sql + @Pagesql 
 
	-- 注销临时表
        DROP TABLE #time;
        DROP TABLE #Dims;
	
	
    END;
go

