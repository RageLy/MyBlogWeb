



-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 降维sp
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_JW]
    @condition VARCHAR(MAX) = 'DimDouKzWd:-1165|-2380|237%DimDouYX:-1%DimDouLW:-1%DimDouFu:-1%DimDouTemp41:-1%DimDouSpeed500:-1%DimDouSpeed400:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDDLps:-1%DimOilViscosity:-1%DimYXLJ05:-1%DimYXLJ09:-1' ,
    @OtherCond VARCHAR(MAX) = '%无选项%无选项%L白%列表%相关性%undefined%undefined' ,
    @Type VARCHAR(10) = '图' , -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
    @OrderFields VARCHAR(50) = '' ,
    @SpName VARCHAR(50) = 'DouCapsule' ,
    @TB INT = 2 ,
    @EmpID INT = 1 ,
                              --@SpTable NVARCHAR(50) = '',
                              -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '10' ,
    @XValue VARCHAR(50) = '' ,
    @DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
    BEGIN

        ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

        SET NOCOUNT ON;

        DECLARE @SiftValue VARCHAR(MAX);
        SET @SiftValue = REPLACE(@condition, '|', ',');

        DECLARE @Usertitle VARCHAR(50) = ''; -- 标题            
        DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
        DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
        DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                
        DECLARE @ChatType VARCHAR(50) = ''; -- 图形名称                
        DECLARE @CTOC VARCHAR(50) = ''; -- @OtherCond 传入的比较方式                

        DECLARE @CompareType VARCHAR(50) = ''; -- 比较方式                  

        -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

        DECLARE @OtherCondTbl TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                String NVARCHAR(50)
            );

        INSERT INTO @OtherCondTbl
                    SELECT string
                    FROM   dbo.f_splitSTR(@OtherCond, '%');

        SET @Usertitle = (   SELECT String
                             FROM   @OtherCondTbl
                             WHERE  ID = 1
                         );
        SET @XName = '无选项'; --( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
        SET @DSName = (   SELECT String
                          FROM   @OtherCondTbl
                          WHERE  ID = 3
                      );
        SET @YName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 4
                     );
        SET @ChatType = (   SELECT String
                            FROM   @OtherCondTbl
                            WHERE  ID = 5
                        );
        SET @CTOC = (   SELECT String
                        FROM   @OtherCondTbl
                        WHERE  ID = 6
                    );

        --select * from @OtherCondTbl
        -- OtherCond解析完毕            
        -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

        ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


        -- 时间表 时间临时表必然需要
        CREATE TABLE #time
            (
                id VARCHAR(200) ,
                beginDate DATETIME ,
                endDate DATETIME ,
                beginDate_Lp DATETIME ,
                endDate_Lp DATETIME ,
                beginDate_Ly DATETIME ,
                endDate_Ly DATETIME
            );

        -- 如果有其它需要用 #时间表的必须在这里添加

        DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
        DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
        DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
        DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
        DECLARE @NumSql VARCHAR(500); -- 用于拼接@Sql中 指标计算方式的Sql语句            
        DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句
        DECLARE @ErrorRecord NVARCHAR(MAX) = '';
        SET @XOrder = ',1 as X排序';
        SET @DsOrder = ',1 as G排序';

        -- 处理维度临时表
        CREATE TABLE #Dims
            (
                DimName VARCHAR(50) ,
                DimValues VARCHAR(MAX) ,
                ChName VARCHAR(50) ,
                Isneed VARCHAR(50) ,
                DimOrdersql VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                isrange VARCHAR(50)
            );

        EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue ,
                                        @XName = @XName ,
                                        @DsName = @DSName;


        IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @YName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'ND' ,
                                   '' ,
                                   AtYSql ,
                                   IsRange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @YName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
            END;

        --AND CHARINDEX(',SinCapsule,',SpType) > 0

        --from 源表
        DECLARE @FromSql VARCHAR(MAX) = (   SELECT JoinTables+CHAR(10)+BaseTable
                                            FROM   Tbl_AnsCom_AnaSpConfig
                                            WHERE  SpName = @SpName
                                        );
        IF (   @FromSql IS NULL
               OR @FromSql = ''
           )
            BEGIN
                SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables+BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = ''' + @SpName
                                    + '''结果为空 ,可能导致报错,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JW' , -- SpName - nvarchar(50)
                           @ErrorRecord ,        -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JW @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@SpName''' + @SpName
                           + ''',@TB=''' + CAST(@TB AS NVARCHAR(2)) + ''',@EmpID=''' + CAST(@EmpID AS NVARCHAR(2))
                           + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()             -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;

        -- 拼接创建维度临时表的语句
        SET @sql += ISNULL(
                        (   SELECT 'CREATE TABLE #' + DimName
                                   + -- 非范围维度类型3列
                                CASE WHEN isrange = 0 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                                     -- 范围维度类型5列
                                     WHEN isrange = 1 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'
                                END
                            FROM   #Dims
                            WHERE  Isneed <> 'ND'
                            FOR XML PATH('')
                        ) ,
                        ''
                          );


        --   SELECT @sql;

        DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
        SET @NeedSiftvalue = (   SELECT '%' + DimName + ':' + DimValues
                                 FROM   #Dims
                                 WHERE  Isneed <> 'ND'
                                 FOR XML PATH('')
                             );
        SET @NeedSiftvalue = ISNULL(@NeedSiftvalue, '');

        --SELECT * FROM #Dims

        -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
        SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                      'Dim7:'
                                      + dbo.GetDimValue(@SiftValue, 'Dim7')
                                      + @NeedSiftvalue
                                  ELSE
                                      SUBSTRING(
                                                   @NeedSiftvalue ,
                                                   2 ,
                                                   LEN(@NeedSiftvalue)
                                               )
                             END;



        -- 解析维度
        SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''
                    + @NeedSiftvalue + ''', @EmpID = '
                    + CAST(@EmpID AS VARCHAR(50)) + ';';


        --PRINT 'sql: ' + @sql;

        -- 创建 where维度
        DECLARE @whereWD VARCHAR(MAX) = ''; ---提取控制维度名

        DECLARE @TimeName VARCHAR(50);
        SET @TimeName = (   SELECT TimeName
                            FROM   Tbl_AnsCom_AnaSpConfig
                            WHERE  SpName = @SpName
                        );
        IF (   @TimeName = NULL
               OR @TimeName IS NULL
           )
            BEGIN
                SET @ErrorRecord += '查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '''
                                    + @SpName + '''为空,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JW' , -- SpName - nvarchar(50)
                           @ErrorRecord ,        -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JW @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@SpName''' + @SpName
                           + ''',@TB=''' + CAST(@TB AS NVARCHAR(2)) + ''',@EmpID=''' + CAST(@EmpID AS NVARCHAR(2))
                           + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()             -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;
        IF ( CHARINDEX('Dim7', @SiftValue) <> 0 )
            SET @whereWD += ' INNER JOIN #time t on ' + @TimeName
                            + ' >= t.beginDate and ' + @TimeName
                            + ' <= t.endDate';



        SET @whereWD += ISNULL(
                            (   SELECT ' inner JOIN #' + DimName + ' AS '
                                       + DimName + ' on '
                                       + CASE WHEN isrange = 1 THEN
                                                  DimName + '.BeginValue <= '
                                                  + DimYsql + ' AND '
                                                  + DimName + '.EndValue > '
                                                  + DimYsql
                                              ELSE
                                                  DimName + '.ID = '
                                                  + DimYsql
                                         END
                                FROM   #Dims
                                WHERE  Isneed <> 'ND'
                                       AND DimYsql <> ''
                                FOR XML PATH('')
                            ) ,
                            ''
                              );
        --SELECT * FROM #Dims
        DECLARE @DimNum NVARCHAR(50) = ISNULL((   SELECT DimName
                                                  FROM   #Dims
                                                  WHERE  ChName = @YName
                                              ) ,
                                              ''
                                             );

        SET @whereWD = REPLACE(REPLACE(@whereWD, '&lt;', '<'), '&gt;', '>');
        --SET @whereWD +=' '+ISNULL(( SELECT  DimYsql
        --                                        FROM    #Dims
        --                                        WHERE   ChName = @YName
        --                                      ), '')+'is not null'
        --PRINT '条件：' + @whereWD;

        -- 创建 控制维度筛选项维度
        DECLARE @KZWD VARCHAR(MAX) = '';
        DECLARE @KZWDName VARCHAR(MAX) = '';
        DECLARE @KZWDViewName VARCHAR(MAX) = '';
        SET @KZWDName = (   SELECT DimName
                            FROM   #Dims
                            WHERE  DimYsql = ''
                        );

        SET @KZWD = (   SELECT DimValues
                        FROM   #Dims
                        WHERE  DimYsql = ''
                               AND DimName = @KZWDName
                    );
        SET @KZWDViewName = (   SELECT ISNULL(ViewName, '')
                                FROM   dbo.Tbl_AnsCom_DIimToTable
                                WHERE  DimNum = @KZWDName
                            );
        --PRINT @DimNum
        --拼select 列名（主表ID+控制维度列）
        CREATE TABLE #DimsTb
            (
                DimID NVARCHAR(10) ,
                DimName VARCHAR(50) ,
                viewName VARCHAR(50) ,
                ChName VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                Stp VARCHAR(50),
				IsRange int
            );

        INSERT INTO #DimsTb (   DimID ,
                                DimName ,
                                viewName ,
                                ChName ,
                                DimYsql ,
                                Stp,
								IsRange
                            )
                    SELECT b.ID ,
                           a.DimName ,
                           b.ViewName ,
                           a.ChName ,
                           a.DimYsql ,
                           '1',
						   b.IsRange
                    FROM   #Dims a
                           LEFT JOIN dbo.Tbl_AnsCom_DIimToTable b ON a.DimName = b.DimNum
                    WHERE  Isneed <> 'ND'
                           AND DimYsql <> '';





        DECLARE @KZWDDimsTb VARCHAR(MAX) = '';

        SET @KZWDDimsTb = ( SELECT '
	 insert into #DimsTb (DimID,DimName,viewName,ChName,DimYsql,Stp,IsRange)
	 select  kz.ID,dimname,tad.ViewName,Name,AtYSql,istrue,IsRange 
	 from VW_' + @KZWDViewName + '_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in (' + @KZWD + ')
	  '                   );

        --PRINT '@KZWDDimsTb' + @KZWDDimsTb;
        EXEC ( @KZWDDimsTb );
        --SELECT * FROM #DimsTb 
        --PRINT @KZWDDimsTb
        --拼控制维度inner join

        --SELECT @KZWDDimsTb;

        --SELECT * FROM #DimsTb;


        DECLARE @KZWDinner VARCHAR(MAX) = '';
		 DECLARE @VWWhereSql VARCHAR(MAX) = '';
		SET @VWWhereSql +=CHAR(10)+(SELECT CASE WHEN IsRange=1 THEN 'CREATE Table #'+DimName+ '([ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2))' ELSE 'CREATE Table #'+DimName+ '([ID] INT , Name NVARCHAR(500) DEFAULT '''')' END +CHAR(10) FROM #DimsTb WHERE Stp<>1  FOR XML PATH('') )
		SET @VWWhereSql +=(SELECT CASE WHEN IsRange=1 THEN 'insert into #'+DimName+ ' select ID,Name,BeginValue,EndValue from vw_'+viewName+'_part where Istrue='+Stp else 'insert into #'+DimName+ ' select ID,Name from vw_'+viewName+'_part where Istrue='+Stp end +CHAR(10)FROM #DimsTb WHERE Stp<>1 FOR XML PATH(''))
        SET @KZWDinner = (   SELECT  CASE WHEN IsRange=1 THEN ' INNER join #' + viewName
                                    + ' as ' + DimName + ' on '
                                     + DimYsql + '>=' + DimName
                                    + '' + '.beginvalue and ' + DimYsql
                                    + '<' + DimName + '' + '.endvalue ' ELSE ' INNER join #' + viewName
                                    + ' as ' + DimName + ' on ' + DimYsql + '=' + DimName+'.ID' end+CHAR(10)
                             FROM   #DimsTb
                             WHERE  Stp <> 1
                             FOR XML PATH('')
                         );
        --PRINT '@KZWDinner: ' + @KZWDinner;

        SET @KZWDinner = REPLACE(
                                    REPLACE(@KZWDinner, '&lt;', '<') ,
                                    '&gt;' ,
                                    '>'
                                );
        SET @KZWDinner = ISNULL(@KZWDinner, '');

        --SELECT @KZWDinner;
        --拼接控制维度与where维度列
        DECLARE @KZNamewh VARCHAR(MAX) = '';
        SET @KZNamewh = (   SELECT CASE WHEN Stp <> 1 THEN
                                            ',' + DimName + '.name'
                                            + ' as ' + DimName
                                   END
                            FROM   #DimsTb
                            FOR XML PATH('')
                        );
        PRINT '@KZNamewh:' + @KZNamewh;
        DECLARE @KZIDwh VARCHAR(MAX) = '';
        SET @KZIDwh = (   SELECT CASE WHEN Stp <> 1 THEN
                                          ',' + CAST(DimID AS NVARCHAR(10))
                                 END
                          FROM   #DimsTb
                          FOR XML PATH('')
                      );
        DECLARE @KZNameCom VARCHAR(MAX) = '';
        SET @KZNameCom = (   SELECT CASE WHEN Stp <> 1 THEN
                                             'CAST(' + DimName
                                             + '.ID AS NVARCHAR(5))+'
                                    END
                             FROM   #DimsTb
                             FOR XML PATH('')
                         );
        PRINT '@KZNameCom:' + @KZNameCom;
        IF ( @KZNameCom <> '' )
            SET @KZNameCom = ',' + LEFT(@KZNameCom, LEN(@KZNameCom) - 1);
        ELSE
            SET @KZNameCom = ',NULL';
        --Y 列
        DECLARE @YSQL VARCHAR(100);
        DECLARE @Ycolumn VARCHAR(50) = ISNULL(
                                           (   SELECT CASE WHEN SUBSTRING(
                                                                             DimName ,
                                                                             4 ,
                                                                             9
                                                                         ) = 'FromSelfY' THEN
                                                               DimName
                                                           ELSE DimYsql
                                                      END
                                               FROM   #Dims
                                               WHERE  ChName = @YName
                                           ) ,
                                           ''
                                             ); -- Y轴在本表上面的列名
        SET @YSQL = ',' + ISNULL((   SELECT DimYsql
                                     FROM   #Dims
                                     WHERE  ChName = @YName
                                 ) ,
                                 ''
                                ) + ' AS ' + REPLACE(@Ycolumn, '.', '');

        DECLARE @DistanceTypeStr VARCHAR(MAX);
        SET @DistanceTypeStr = (   SELECT DistanceTypeStr
                                   FROM   dbo.Tbl_BaseSetDistance
                                   WHERE  DimNum = @DimNum
                               );

        IF ( @DistanceTypeStr IS NULL )
            BEGIN
                SELECT 'prompt' AS 提示
                UNION ALL
                SELECT 'varchar 500';
                SELECT '请配置目标的优等、差等设置！' AS prompt;
                RETURN;

            END;

        SET @InnerSelect = ( SELECT 'select ' + @SpName + '.ID,NULL'
                                    + @KZNameCom + ISNULL(@KZNamewh, '')
                                    + ',' + (   SELECT DistanceTypeStr
                                                FROM   dbo.Tbl_BaseSetDistance
                                                WHERE  DimNum = @DimNum
                                            ) + @YSQL + ' from '
                           );
        IF (   (   SELECT DistanceTypeStr
                   FROM   dbo.Tbl_BaseSetDistance
                   WHERE  DimNum = @DimNum
               ) = ''
               OR  (   SELECT DistanceTypeStr
                       FROM   dbo.Tbl_BaseSetDistance
                       WHERE  DimNum = @DimNum
                   ) IS NULL
           )
            BEGIN
                SET @ErrorRecord += '查询 SELECT DistanceTypeStr FROM dbo.Tbl_BaseSetDistance WHERE DimNum = '''
                                    + @DimNum + '''为空,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JW' , -- SpName - nvarchar(50)
                           @ErrorRecord ,        -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JW @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@SpName''' + @SpName
                           + ''',@TB=''' + CAST(@TB AS NVARCHAR(2)) + ''',@EmpID=''' + CAST(@EmpID AS NVARCHAR(2))
                           + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()             -- ExecSql - nvarchar(1000)
                       );
            END;

        --PRINT '@InnerSelect:' + @InnerSelect;
        -----------------------------------------------降维计算---------------------------------------------------
        DECLARE @Resultdata VARCHAR(MAX);
        DECLARE @ResultName VARCHAR(MAX) = '';
        SET @ResultName = (   SELECT ',' + DimName + ' varchar(100)'
                              FROM   #DimsTb
                              WHERE  Stp <> 1
                              FOR XML PATH('')
                          );
        --PRINT '结果数据：' + @ResultName;

        SET @Resultdata = ( SELECT 'CREATE TABLE #Resultdata
	   (ID int,RowID INT,WDComb NVARCHAR(1000)
		' + ISNULL(@ResultName, '') + ',GY INT ,'
                                   + REPLACE(@Ycolumn, '.', '')
                                   + ' decimal(18, 6)
		)'
                          );

        --PRINT '结果数据：' + @ResultName;
        --PRINT '@sql:' + @sql;
        --数据插入临时表#Resultdata
        DECLARE @Resultzj VARCHAR(MAX);

        SET @Resultzj = ( @sql +@VWWhereSql+ @Resultdata + ' insert into  #Resultdata '
                          + @InnerSelect + @FromSql  +@whereWD + @KZWDinner
                          + ' where '
                          + ISNULL((   SELECT DimYsql
                                       FROM   #Dims
                                       WHERE  ChName = @YName
                                   ) ,
                                   ''
                                  )
                        ) + ' Is not NULL';


        --SELECT @sql,@Resultdata,@InnerSelect,@FromSql,@whereWD,@KZWDinner;


        --提取验证数据
        DECLARE @Resultyz VARCHAR(MAX);
        DECLARE @InnerSelectyz VARCHAR(MAX);
        DECLARE @KZNamewhyz VARCHAR(MAX) = '';
        SET @KZNamewhyz = (   SELECT CASE WHEN Stp <> 1 THEN
                                              ',' + DimYsql + ' as '
                                              + REPLACE(DimYsql, '.', '')
                                     END
                              FROM   #DimsTb
                              FOR XML PATH('')
                          );



        DECLARE @ResultNameyz VARCHAR(MAX);
        SET @ResultNameyz = (   SELECT ',' + DimName + 'yz decimal(18, 6)'
                                FROM   #DimsTb
                                WHERE  Stp <> 1
                                FOR XML PATH('')
                            );

        DECLARE @Resultdatayz VARCHAR(MAX);
        SET @Resultdatayz = ( SELECT 'CREATE TABLE #Resultdatayz
	   (ID int
		' + @ResultNameyz + ',' + REPLACE(@Ycolumn, '.', '')
                                     + ' decimal(18, 6)
		)'
                            );

        SET @InnerSelectyz = ( SELECT 'select ' + @SpName + '.ID'
                                      + @KZNamewhyz + @YSQL + ' from '
                             );
        SET @Resultyz = ( @sql + @Resultdatayz
                          + ' insert into  #Resultdatayz ' + @InnerSelectyz
                          + @FromSql + @whereWD
                        );

        --print @Resultyz
        ------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             
        -- 建立结果表
        DECLARE @CreateTable VARCHAR(MAX);

        SET @CreateTable = ( SELECT ' CREATE TABLE #Result1
	   (
	   ID INT IDENTITY(1,1) NOT NULL,
	    floatValue decimal(18,4),
		BadfloatValue decimal(18,4),
		GoodValue int,
		BadValue int,
	    PercentON NVARCHAR(10),
		PercentONBad NVARCHAR(10),
	    spName varchar(50),
		DataCount int,
		MaxY Decimal(18,6),
		MinY Decimal(18,6),
		AVGY Decimal(18,6),
		SQtY Decimal(18,6),
		Siftvalue varchar(Max),
		PearSenR DECIMAL(18,6),
		Slope DECIMAL(18,6),
		LineCons DECIMAL(18,6),
		ChangePoint int ,
		Trend Varchar(Max)
		' + ISNULL(@ResultName, '') + ',WDComb NVARCHAR(50))' + CHAR(10));

        --PRINT @CreateTable;

        --取Y轴列
        DECLARE @Ycolumnjs VARCHAR(50) = ISNULL(
                                             (   SELECT CASE WHEN SUBSTRING(
                                                                               DimName ,
                                                                               4 ,
                                                                               9
                                                                           ) = 'FromSelfY' THEN
                                                                 DimName
                                                             ELSE
                                                                 REPLACE(
                                                                            DimYsql ,
                                                                            '.' ,
                                                                            ''
                                                                        )
                                                        END
                                                 FROM   #Dims
                                                 WHERE  ChName = @YName
                                             ) ,
                                             ''
                                               );

        DECLARE @ResultDataSql VARCHAR(500);
        SET @ResultDataSql = '''' + @SpName + ''' spname,SUM(CASE WHEN '
                             + @Ycolumnjs
                             + ' is not null THEN 1 ELSE 0 END ) DataCount,MAX('
                             + @Ycolumnjs + ') MaxY,MIN(' + @Ycolumnjs
                             + ') MinY,AVG(' + @Ycolumnjs + ') AVGY,stdev('
                             + @Ycolumnjs + ') SQtY,';
        --PRINT '@ResultDataSql' + @ResultDataSql;
        DECLARE @GroupBy VARCHAR(500);
        --SELECT * FROM #DimsTb
        SET @GroupBy = (   SELECT CASE WHEN Stp <> 1 THEN ',' + DimName
                                  END
                           FROM   #DimsTb
                           FOR XML PATH('')
                       );
        DECLARE @GroupBy1 VARCHAR(500);
        --SELECT * FROM #DimsTb
        SET @GroupBy1 = (   SELECT CASE WHEN Stp <> 1 THEN DimName + ','
                                   END
                            FROM   #DimsTb
                            FOR XML PATH('')
                        );


        --SET @GroupBy = ( SELECT SUBSTRING(@GroupBy, 2, LEN(@GroupBy) - 1)
        --               );

        DECLARE @ONRelation NVARCHAR(MAX) = '';

        SET @ONRelation += (   SELECT ' and a.' + DimName + '=b.' + DimName
                               FROM   #DimsTb
                               WHERE  Stp <> 1
                               FOR XML PATH('')
                           );
		DECLARE @ONRelation2 NVARCHAR(MAX) = '';

        SET @ONRelation2 += (   SELECT ' and c.' + DimName + '=b.' + DimName
                               FROM   #DimsTb
                               WHERE  Stp <> 1
                               FOR XML PATH('')
                           );
        --SET @ONRelation = RIGHT(@ONRelation, LEN(@ONRelation) - 3); 

        --PRINT '@ONRelation: ' + @ONRelation;

        DECLARE @Result1 VARCHAR(MAX);

        SET @GroupBy = ISNULL(@GroupBy, '');
        SET @ONRelation = ISNULL(@ONRelation, '');
		 SET @ONRelation2 = ISNULL(@ONRelation2, '');
        SET @GroupBy1 = ISNULL(@GroupBy1, '');
        IF ( @GroupBy1 <> '' )
            DECLARE @groupBy2 NVARCHAR(200) = LEFT(@GroupBy1, LEN(@GroupBy1)
                                                              - 1) + ',';
        ELSE
            SET @groupBy2 = '';
        --PRINT '@Resultzj: ' + @Resultzj; 
        --PRINT '@CreateTable: ' + @CreateTable; 
        --PRINT '@ResultDataSql: ' + @ResultDataSql; 
        --PRINT '@GroupBy: ' + @GroupBy; 
        --PRINT '@GroupBy1: ' + @GroupBy1;
        --PRINT '@ONRelation: ' + @ONRelation;
        SET @Result1 = ( @Resultzj + @CreateTable + 'INSERT INTO #Result1 '
                         + 'SELECT  ISNULL(ROUND(CAST(a.DataCount AS FLOAT)/(case when b.DataCount=0 then 1 else b.DataCount end)*100 ,4),0),ISNULL(ROUND(CAST(c.DataCount AS FLOAT)/(case when b.DataCount=0 then 1 else b.DataCount end)*100 ,4),0),ISNULL(ROUND(CAST(a.DataCount AS FLOAT),4),0),ISNULL(ROUND(CAST(c.DataCount AS FLOAT),4),0),
                ISNULL(CAST(ROUND(CAST(a.DataCount AS FLOAT)/(case when b.DataCount=0 then 1 else b.DataCount end)*100 ,4) AS NVARCHAR(8)),0)+''%'' PercentON,ISNULL(CAST(ROUND(CAST(c.DataCount AS FLOAT)/(case when b.DataCount=0 then 1 else b.DataCount end)*100 ,4) AS NVARCHAR(8)),0)+''%'' PercentONBad,
                b.* 
        FROM    ( SELECT ' + @ResultDataSql
                         + 'NULL Siftvalue,NULL PearSenR,NULL Slope,NULL LineCons,NULL ChangePoint,NULL Trend'
                         + @GroupBy
                         + ',WDComb FROM #Resultdata WHERE GY=1 Group by '
                         + @GroupBy1
                         + 'GY,WDComb)   a
                  RIGHT JOIN ( SELECT ' + @ResultDataSql
                         + 'NULL Siftvalue,NULL PearSenR,NULL Slope,NULL LineCons,NULL ChangePoint,NULL Trend'
                         + @GroupBy + ',WDComb FROM #Resultdata Group by '
                         + @groupBy2 + 'WDComb) b on 1=1 ' + @ONRelation
                         + ' AND ISNULL(b.WDComb,0) = ISNULL(a.WDComb,0)
						 LEFT JOIN (   SELECT   '+@ResultDataSql+'
                                          NULL Siftvalue ,
                                          NULL PearSenR ,
                                          NULL Slope ,
                                          NULL LineCons ,
                                          NULL ChangePoint ,
                                          NULL Trend 
                                          '+ @GroupBy+',
                                          WDComb
                                 FROM     #Resultdata
                                 WHERE    GY = 0
                                 GROUP BY  '+@GroupBy1+'
                                          GY ,
                                          WDComb
                             ) c ON 1=1 '+@ONRelation2+'
                                    AND ISNULL(b.WDComb, 0) = ISNULL(c.WDComb , 0);'
                       );


        SET @Result1 += ' if((select count(*) from #Resultdata)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_JW'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister_JW @condition='''''
                        + @condition + ''''',@OtherCond=''''' + @OtherCond
                        + ''''',@Type=''''' + @Type
                        + ''''',@OrderFields=''''' + @OrderFields
                        + ''''',@SpName''''' + @SpName + ''''',@TB='''''
                        + CAST(@TB AS NVARCHAR(2)) + ''''',@EmpID=''''' + CAST(@EmpID AS NVARCHAR(2))
                        + ''''',@PageIndex=''''' + @PageIndex
                        + ''''',@PageSize=''''' + @PageSize
                        + ''''',@XValue,=''''' + @XValue
                        + ''''',@DSValue=''''' + @DSValue + ''''''','''
                        + CONVERT(NVARCHAR(20), GETDATE(), 120) + ''') END ';

        --select @Resultzj,@CreateTable,@ResultDataSql,@GroupBy,@GroupBy1,@ResultDataSql,@GroupBy,@groupBy2;

        SET @InnerSelect = (   SELECT   ',' + TableName + '.' + CoName + ' AS '
                                        + TableName + CoName
                               FROM     Tbl_AnsCom_DIimToTable
                               WHERE    CHARINDEX(',' + @SpName + ',', SpType) > 0
                                        AND SUBSTRING(CoName, 1, 9) != 'FromSelfY'
                               ORDER BY ShowIndex
                               FOR XML PATH('')
                           );
        --PRINT @InnerSelect;
        SET @InnerSelect = SUBSTRING(@InnerSelect, 2, LEN(@InnerSelect));

        DECLARE @UpdateSql NVARCHAR(MAX) = '';
        --SELECT * FROM #Dims
        --IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        --    SET @whereWD = ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';
        --IF(@KZNameCom='')
        --SET @KZNameCom='NULL';

        SET @UpdateSql += (   SELECT CHAR(10) + 'DROP TABLE DetailResult'
                                     + CHAR(10) + ' select ' + @SpName
                                     + '.ID,NULL RowID' + @KZNameCom
                                     + ' AS WDComb,' + @InnerSelect
                                     + ' into DetailResult from '
                                     + JoinTables + CHAR(10) + BaseTable
                                     + CHAR(10)
                              FROM   dbo.Tbl_AnsCom_AnaSpConfig
                              WHERE  SpName = @SpName
                          ) + @whereWD + @KZWDinner + ' where '
                          + ISNULL((   SELECT DimYsql
                                       FROM   #Dims
                                       WHERE  ChName = @YName
                                   ) ,
                                   ''
                                  ) + ' Is not NULL';
        SET @UpdateSql += ' UPDATE DetailResult SET RowID=#Result1.ID FROM #Result1 WHERE isnull(#Result1.WDComb,0)=isnull(DetailResult.WDComb,0)'
                          + CHAR(10);
        --PRINT @UpdateSql;

        --select @UpdateSql
        --SELECT  @Result1;
        --设置Y轴比较分档
        --极差分档
        DECLARE @jd DECIMAL(18, 4);
        DECLARE @jcmin DECIMAL(18, 4);
        DECLARE @jcmax DECIMAL(18, 4);
        DECLARE @jcn DECIMAL(18, 4);
        DECLARE @bzcmin DECIMAL(18, 4);
        DECLARE @bzcmax DECIMAL(18, 4);
        DECLARE @bzcn DECIMAL(18, 4);

        SET @jd = (   SELECT NumDecimal
                      FROM   #Dims dp
                             INNER JOIN Tbl_AnsCom_DIimToTable tnd ON dp.DimName = tnd.DimNum
                                                                      AND dp.ChName = @YName
                  );

        SET @jcmin = 0;
        SET @jcmax = ( 5 * 10 * @jd );
        SET @jcn = 11.0000;
        SET @bzcmin = 0;
        SET @bzcmax = @jcmax;
        SET @bzcn = 11.0000;

        --置信度计算
        DECLARE @zxd VARCHAR(MAX);
        SET @zxd = ' SELECT COUNT(*) AS zcount,COUNT(CASE WHEN datacount > 1 THEN 1 END) AS yxzcount,CAST(CAST(COUNT(CASE WHEN datacount > 1 THEN 1 END) AS DECIMAL(18,4)) / (CASE WHEN COUNT(*) = 0 THEN 1 ELSE COUNT(*) END ) * 100 as DECIMAL(18,2)) AS zlv
                ,SUM(datacount) AS sccount,SUM(CASE WHEN datacount > 1 THEN datacount END) AS yxsccount,cast(CAST(SUM(CASE WHEN datacount > 1 THEN datacount END) AS DECIMAL(18,4)) / (CASE WHEN SUM(datacount) = 0 THEN 1 ELSE SUM(datacount) END ) * 100 as DECIMAL(18,2)) AS sclv
                FROM #Result1
                WHERE datacount IS NOT null ';

        --极差计算
        DECLARE @jc VARCHAR(MAX);
        SET @jc = ' 
    
				DECLARE @Maxjc decimal(18,6) = (select Max(MaxY - MinY) FROM #Result1 );
				;WITH CTE AS (
	                select ID,Name ,ncount AS zcount
	                ,cast(CAST(ncount AS DECIMAL(18,4)) / (SUM(ncount) OVER() ) * 100 as DECIMAL(18,2)) AS zlv
	                ,Sumn AS sccount
	                ,cast(CAST(Sumn AS DECIMAL(18,4)) / (SUM(Sumn) OVER() ) * 100 as DECIMAL(18,2)) AS sclv
	                FROM
	                    (
		                SELECT isnull(b.ID,100) id,isnull(b.Name,''其他'') Name,COUNT(*) AS ncount,SUM(datacount) AS Sumn
		                FROM #Result1 a
		                LEFT JOIN dbo.fn_getAreaTable(0 - ( [dbo].[GetMaxRange](@Maxjc) / 10 ) , [dbo].[GetMaxRange](@Maxjc) , 11 ) b ON a.MaxY - a.MInY > b.beginvalue  AND a.MaxY - a.MInY <= b.endvalue 
		                WHERE datacount > 1 GROUP BY b.ID,b.NAME,b.beginvalue
	                        ) x
                            )
                    SELECT b.id,b.name,b.zcount,b.zlv,b.sccount,b.sclv
                    ,(SELECT SUM(zlv) FROM CTE a WHERE a.ID <= b.ID ) AS ljzlv
                    ,(SELECT SUM(sclv) FROM CTE a WHERE a.ID <= b.ID ) AS ljsclv
                    FROM CTE b order by b.id';
        --标准差计算
        DECLARE @bzc VARCHAR(MAX);
        SET @bzc = ' 
				DECLARE @Maxbzc decimal(18,6) = (select Max(SQtY) FROM #Result1 );
				;WITH CTE AS (
	            select ID,Name ,ncount AS zcount
	            ,cast(CAST(ncount AS DECIMAL(18,4)) / (SUM(ncount) OVER() ) * 100 as DECIMAL(18,2)) AS zlv
	            ,Sumn AS sccount
	            ,cast(CAST(Sumn AS DECIMAL(18,4)) / (SUM(Sumn) OVER() ) * 100 as DECIMAL(18,2)) AS sclv
	            FROM
	            (
		            SELECT isnull(b.ID,100) id,isnull(b.Name,''其他'') Name,COUNT(*) AS ncount,SUM(datacount) AS Sumn
		            FROM #Result1 a
		            LEFT JOIN dbo.fn_getAreaTable(0 - ( [dbo].[GetMaxRange](@Maxbzc) / 10 ) , [dbo].[GetMaxRange](@Maxbzc) , 11 ) b ON a.SqtY > b.beginvalue AND a.SqtY <= b.endvalue
		            WHERE datacount > 1 GROUP BY b.ID,b.NAME,b.beginvalue
	            ) x
                )
                SELECT b.id,b.name,b.zcount,b.zlv,b.sccount,b.sclv
                ,(SELECT SUM(zlv) FROM CTE a WHERE a.ID <= b.ID ) AS ljzlv
                ,(SELECT SUM(sclv) FROM CTE a WHERE a.ID <= b.ID ) AS ljsclv
                FROM CTE b order by b.id';

        --主副因素验证
        --维度控制区间
        DECLARE @CKON VARCHAR(MAX);
        SET @CKON = (   SELECT ' AND ABS(a.' + Dims + ' - ' + 'b.' + Dims
                               + ')<=' + CAST(bs AS VARCHAR(50))
                        FROM   (   SELECT DimName + 'yz' Dims ,
                                          CASE WHEN Stp = 0 THEN tnd.NumDecimal
                                               WHEN Stp = 2 THEN
                                                   2 * tnd.NumDecimal
                                               WHEN Stp = 3 THEN
                                                   5 * tnd.NumDecimal
                                               WHEN Stp = 4 THEN
                                                   10 * tnd.NumDecimal
                                          END AS bs
                                   FROM   #DimsTb dp
                                          INNER JOIN Tbl_AnsCom_DIimToTable tnd ON dp.DimName = tnd.DimNum
                                   WHERE  Stp <> 1
                               ) aa
                        FOR XML PATH('')
                    );
        SET @CKON = REPLACE(@CKON, '&lt;', '<');

        DECLARE @CK VARCHAR(MAX);
        DECLARE @CKYsql VARCHAR(MAX);
        SET @CKYsql = ISNULL((   SELECT REPLACE(DimYsql, '.', '')
                                 FROM   #Dims
                                 WHERE  ChName = @YName
                             ) ,
                             ''
                            );

        --数据源不能为null
        DECLARE @notnull VARCHAR(MAX);
        SET @notnull = (   SELECT ' and ' + DimName + 'yz is not null'
                           FROM   #DimsTb
                           WHERE  Stp <> 1
                           FOR XML PATH('')
                       );

        SET @CK = '
			 ;WITH CTEs AS
	            (
		        SELECT * FROM  #Resultdatayz WHERE ' + @CKYsql
                  + ' IS NOT null' + @notnull
                  + ' 
	            ),
	             CTEs1 AS
	             (
				        SELECT ABS(a.' + @CKYsql + ' - ' + 'b.' + @CKYsql
                  + ') AS cha FROM CTEs a
				        INNER JOIN CTEs B
				        ON a.ID > b.ID ' + @CKON
                  + '  
	            ),
				CTEs2 AS
	            (
		        select ID,Name ,n ,SUM(n) OVER() AS dbcount
		        ,cast(CAST(n AS DECIMAL(18,4)) / (SUM(n) OVER() ) * 100 as DECIMAL(18,2)) AS lv
		        FROM ( 
		        SELECT isnull(b.ID,100) id,isnull(b.Name,''其他'') Name,COUNT(*) AS n FROM 
						CTEs1 x LEFT JOIN dbo.fn_getAreaTable(0 - ( [dbo].[GetMaxRange]((select Max(cha) FROM CTEs1)) / 10 ) , [dbo].[GetMaxRange]((select Max(cha) FROM CTEs1)) , 11 ) b 
						ON x.cha > b.beginvalue AND x.cha <= b.endvalue
			        GROUP BY b.ID,b.Name
			        ) xx
	            )
	        SELECT b.id,b.name,b.n,b.dbcount,b.lv
	        ,(SELECT SUM(lv) FROM CTEs2 a WHERE a.ID <= b.ID ) AS ljlv
	        FROM CTEs2 b
	        ORDER BY b.ID';

        --return;

        IF ( @TB = 1 )
            BEGIN
                PRINT ( @Result1 + @zxd );
                EXEC ( @Result1 + @zxd );
            END;

        IF ( @TB = 2 )
            BEGIN
                PRINT ( @Result1 + @jc );
                EXEC ( @Result1 + @jc );
            END;

        IF ( @TB = 3 )
            BEGIN
                PRINT ( @Result1 + @bzc );
                EXEC ( @Result1 + @bzc );
            END;

        IF ( @TB = 4 )
            BEGIN
                PRINT ( @Resultyz + @CK );
                EXEC ( @Resultyz + @CK );
            END;


        DECLARE @DimNamesAndChs VARCHAR(MAX);
        SET @DimNamesAndChs = (   SELECT CASE WHEN Stp <> 1 THEN
                                                  ',''' + DimName + ''' AS ['
                                                  + ChName + ']'
                                         END
                                  FROM   #DimsTb
                                  FOR XML PATH('')
                              );
        --set @DimNamesAndChs=(select substring(@GroupBy,2,LEN(@GroupBy)-1))

        DECLARE @Var500s VARCHAR(MAX);
        SET @Var500s = (   SELECT ',''Varchar 500'''
                           FROM   #DimsTb
                           WHERE  Stp <> 1
                           FOR XML PATH('')
                       );
        --set @DimNamesAndChs=(select substring(@GroupBy,2,LEN(@GroupBy)-1))

        --清理临时表
        DECLARE @ClearTempTable NVARCHAR(MAX) = '';
        SET @ClearTempTable += (   SELECT ' if((select count(*) from #'
                                          + DimName
                                          + ')=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_JW'',''数据源数据为空,可能造成报错，请检查'',''Exec Sp_Analysister_JW @condition='''''
                                          + @condition
                                          + ''''',@OtherCond='''''
                                          + @OtherCond + ''''',@Type='''''
                                          + @Type + ''''',@OrderFields='''''
                                          + @OrderFields + ''''',@SpName'''''
                                          + @SpName + ''''',@TB=''''' + CAST(@TB AS NVARCHAR(2))
                                          + ''''',@EmpID=''''' + CAST(@EmpID AS NVARCHAR(2))
                                          + ''''',@PageIndex='''''
                                          + @PageIndex
                                          + ''''',@PageSize=''''' + @PageSize
                                          + ''''',@XValue,=''''' + @XValue
                                          + ''''',@DSValue=''''' + @DSValue
                                          + ''''''','''
                                          + CONVERT(
                                                       NVARCHAR(20) ,
                                                       GETDATE(),
                                                       120
                                                   ) + ''') END  '
                                   FROM   #Dims
                                   WHERE  Isneed <> 'ND'
                                   FOR XML PATH('')
                               );

        SET @ClearTempTable += ISNULL(
                                   (   SELECT 'DROP TABLE #' + DimName + ';'
                                       FROM   #Dims
                                       WHERE  Isneed <> 'ND'
                                       FOR XML PATH('')
                                   ) ,
                                   ''
                                     );

        DECLARE @Varchars VARCHAR(MAX) = 'select ''n'' 序号,''GoodValue'' 优等数据量,''BadValue'' 差等数据量,''DataCount'' 组内数据数,''floatValue'' [优等占比(%)],''BadfloatValue'' [差等占比(%)],''MaxY'' 最大目标值,''MinY'' 最小目标值,''AVGY'' 平均目标值,''JC'' 极差,''SQtY'' 标准差'
                                         + ISNULL(@DimNamesAndChs, '')
                                         + ' UNION ALL 
    SELECT ''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'''
                                         + ISNULL(@Var500s, '');
        ;

        DECLARE @Detail VARCHAR(MAX) = '
    select ID,GoodValue,BadValue,DataCount ,floatValue,BadfloatValue,MaxY ,MinY ,AVGY ,MaxY - MinY AS JC,SQtY'
                                       + @GroupBy
                                       + ' INTO #RDetail From #Result1;
     '  ;
        IF (   @OrderFields = ''
               OR @OrderFields IS NULL
           )
            SET @OrderFields = 'floatValue desc';

        DECLARE @Pagesql VARCHAR(MAX) = '  DECLARE @totalRow int = (Select count(1) FROM #RDetail) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#RDetail''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''''
  ,@AvgColumn = ''''
 '      ;

 --SELECT @Detail
        IF ( @TB = 5 )
            BEGIN
                -- Print @Varchars
                --SELECT 1;
                --EXEC (@Varchars);

                --PRINT @Varchars + @Result1 + @UpdateSql + @Detail
                --      + @ClearTempTable + @Pagesql;
                EXEC ( @Varchars + @Result1 + @UpdateSql + @Detail + @ClearTempTable + @Pagesql );

            --SELECT @Varchars + @Result1 + @UpdateSql + @Detail + @ClearTempTable + @Pagesql ;
            END;
        INSERT INTO Tbl_Log_AnaUseLog (   EmpID ,
                                          EmpName ,
                                          freshTime ,
                                          spName ,
                                          AnaName ,
                                          siftvalue ,
                                          OherParemeter
                                      )
        VALUES ( @EmpID ,
                 (   SELECT EmpName
                     FROM   Tbl_Com_Employee
                     WHERE  EmpID = @EmpID
                 ) ,
                 GETDATE(),
                 'Sp_Analysister_JW,TB=' + CAST(@TB AS NVARCHAR(5)),
                 '' + @SpName + '分区统计',
                 @condition ,
                 '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='
                 + @OtherCond
               );
    END;
go

