
-- =============================================      
-- Author:  hjl      
-- Create date: <2017-6-6>      
-- Description: <选出数值的分区上限>      
-- =============================================      
 
CREATE function [dbo].[GetMaxRange](  
@num decimal(18,6)
)
returns decimal(18,6)
AS
BEGIN

	DECLARE @result decimal(18,6);
	DECLARE @numv varchar(20) = cast (@num as varchar(20));
	
	IF @num = 0
		set @result = 0
	
	-- 如果本身就是整齐的值就是自己
	ELSE IF ( LEN( replace( replace(@numv,'0',''),'.','') ) = 1 )
		set @result = @num;

	ELSE
	BEGIN
		
		
		--set @numv = cast ('0.045' as varchar(20));
		
		DECLARE @Log int = cast( log(@num)/log(10) as INT ) ;
		
		---- 小数
		IF( log(@num)/log(10) < 0 )
		BEGIN
		
			set @result = '0.'+ isnull( (select '0' FROM tbl_Base_Num where ID <= abs(@Log) For XML PATH('') ),'') + cast( substring(@numv,3 + abs(@Log),1) + 1 AS varchar(20) )
			
			-- 如果开头是9 则*10 进位
			IF( substring(@numv,3 + abs(@Log),1) = '9')
				set @result = @result * 10;
		
		END
		---- 整数
		ELSE
		BEGIN
		
		set @result = cast( substring(@numv,1,1) + 1 AS varchar(20) ) + isnull( (select '0' FROM tbl_Base_Num where ID <= @Log For XML PATH('') ),'')
		
		END
		
	END
	
	return @result
end
go

