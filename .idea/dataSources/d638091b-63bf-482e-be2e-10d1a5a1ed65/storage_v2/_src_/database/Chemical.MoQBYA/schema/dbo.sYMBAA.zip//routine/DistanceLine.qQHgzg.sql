-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
--exec DistanceLine @DimNum=N'DimMsOverND,Dim0minLW'
CREATE PROCEDURE [dbo].[DistanceLine]
    @DimNum NVARCHAR(50) ,
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimMpCode:-1%DimMpLotCode:-1%DimMpSeries:-1%DimSDJAvg:-1%DimSDJSqt:-1%DimNhjPH:-1%DimZcjND:-1%DimMsFsjUse:-1%DimMsLpjCode:-1%DimMsLpjUse:-1%DimMsNhjType:-1%DimMsNhjUse:-1%DimMsZcjUse:-1%DimMsCapsulePH:-1%DimMsWaterType:-1%DimMsWaterPH:-1%DimMsWaterDDlps:-1%DimMsLPH:-1%DimMsOverPH:-1%DimMsOverND:-1%DimMsOverGHL:-1%DimMsOverZL:-1%DimMsNdBe:-1%DimMsGhlBe:-1%DimJsCode:-1%DimJsType:-1%DimJsNdBe:-1%DimJsGhlBe:-1%DimMsTtTemp:-1%DimMsTtSd:-1%DimMsTtGTemp:-1%DimMsTtGSd:-1%DimMsTtITOhd:-1%DimMsTtSpeed:-1%DimMsHxFpTemp1:-1%DimMsHxFpTemp2:-1%DimMsHxFpTemp3:-1%DimMsHxFpTemp4:-1%DimMsHxFpTemp5:-1%DimMsHxFpTemp6:-1%DimMsHxFpTemp7:-1%DimMsCjTemp:-1%DimMsCjSd:-1%DimMsCjSpeed:-1%DimMsCjMshd:-1%DimJsTtTemp:-1%DimJsTtSd:-1%DimJsTtSpeed:-1%DimJsTtJx:-1%DimJsCjTemp:-1%DimJsCjSpeed:-1%DimJsCjJshd:-1%DimJsDs:-1%DimMsDs:-1%DimMpTbLv:-1%DimMpFdLv:-1%DimLineSW:-1%DimScJP:-1%DimZcZK:-1%DimSYJudge:-1%DimOEDJudge:-1%Dim0minLBK:-1%Dim2minLBK:-1%Dim0minLW:-1%Dim2minLW:-1%Dim2mindetaLBK:-1%Dim2mindetaLW:-1%DimDbd:-1%DimWBdata:-1%DimQddl:-1' ,
    @OtherCond VARCHAR(MAX) = '质检膜片批次%时间%水滴角均值%line%平均值%水滴角均值%数量'
AS
    BEGIN
        DECLARE @XName VARCHAR(50) = '';             
        DECLARE @YName VARCHAR(50) = '';     
        DECLARE @AnalysisCondTbl TABLE
            (
              ID INT IDENTITY(1, 1)
                     NOT NULL
                     PRIMARY KEY ,
              String NVARCHAR(50)
            );
  
        INSERT  INTO @AnalysisCondTbl
                SELECT  string
                FROM    dbo.f_splitSTR(@DimNum, ',');
      
        SET @XName = ( SELECT   String
                       FROM     @AnalysisCondTbl
                       WHERE    ID = 1
                     );
        SET @YName = ( SELECT   String
                       FROM     @AnalysisCondTbl
                       WHERE    ID = 2
                     );
    
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '最小值' DimX ,
                            MinValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '最小值' DimX ,
                                    MinValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX
        UNION ALL
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '五分位数' DimX ,
                            FiveValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '五分位数' DimX ,
                                    FiveValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX
        UNION ALL
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '下四分位数' DimX ,
                            DownFourValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '下四分位数' DimX ,
                                    DownFourValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX
        UNION ALL
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '中位数' DimX ,
                            MiddleValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '中位数' DimX ,
                                    MiddleValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX
        UNION ALL
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '上四分位数' DimX ,
                            UpFourValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '上四分位数' DimX ,
                                    UpFourValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX
        UNION ALL
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '九五分位数' DimX ,
                            NineFiveValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '九五分位数' DimX ,
                                    NineFiveValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX
        UNION ALL
        SELECT  a.DimX ,
                a.优等 ,
                b.差等
        FROM    ( SELECT    DimNum ,
                            '最大值' DimX ,
                            MaxValue 优等
                  FROM      dbo.TempResult
                  WHERE     GY = 1
                            AND DimNum = @XName
                ) a
                INNER JOIN ( SELECT DimNum ,
                                    '最大值' DimX ,
                                    MaxValue 差等
                             FROM   dbo.TempResult
                             WHERE  GY = 0
                                    AND DimNum = @XName
                           ) b ON b.DimNum = a.DimNum
                                  AND b.DimX = a.DimX;
                                  
        DECLARE @XColumn NVARCHAR(20)= ( SELECT Name_ch
                                         FROM   dbo.Tbl_AnsCom_DIimToTable
                                         WHERE  DimNum = @XName
                                       );
        DECLARE @YColumn NVARCHAR(20)= ( SELECT Name_ch
                                         FROM   dbo.Tbl_AnsCom_DIimToTable
                                         WHERE  DimNum = @YName
                                       );
        
        SELECT  '' + @XColumn + '的数据分布线型图' AS Title ,
                '' + @XColumn + '' AS yName ,
                '数据类型' AS xName; 
        
    END;
go

