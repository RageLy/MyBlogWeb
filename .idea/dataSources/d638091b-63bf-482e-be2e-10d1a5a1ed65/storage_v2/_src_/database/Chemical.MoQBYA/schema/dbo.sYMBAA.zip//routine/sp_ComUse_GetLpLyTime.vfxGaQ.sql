  
  
-- ====================================      
-- Author:  <贺俊龙>        
-- Create date: <2014年3月27日>        
-- Description: 获取一个时间段的环比或者同比时间段   
-- ====================================      
  
CREATE proc [dbo].[sp_ComUse_GetLpLyTime]   
   @beginDate Datetime = '2000-02-01' -- 开始时间  
   ,@endDate Datetime = '2000-02-29'  -- 结束时间  
   ,@ReslutBegin_Ly Datetime  = '2000-02-01' output -- 同比开始时间  
   ,@ReslutEnd_ly datetime= '2000-02-29' output -- 同比结束时间  
   ,@ReslutBegin_Lp datetime = '2000-02-29' output -- 环比开始时间  
   ,@ReslutEnd_lp datetime = '2000-02-29' output -- 环比结束时间  
as  
    
 declare @Diff int = datediff(day,@begindate,@enddate);  -- 日期相距天数 用于计算日期的类型     
    
 if(@Diff > -1 And @Diff < 2) -- 日期为一天时  
 Begin  
 set @ReslutBegin_Lp = DATEADD(DAY,-1,@begindate);   
 set @ReslutEnd_lp = DATEADD(DAY,-1,@enddate);    
 set @ReslutBegin_Ly = DATEADD(YEAR,-1,@begindate);    
 set @ReslutEnd_ly = DATEADD(YEAR,-1,@enddate);  
 End  
   
 Else if(@Diff > 5 And @Diff < 9) -- 日期为一周时  
  Begin  
 set @ReslutBegin_Lp = DATEADD(WEEK,-1,@begindate);   
 set @ReslutEnd_lp = DATEADD(WEEK,-1,@enddate);  
 set @ReslutBegin_Ly = DATEADD(YEAR,-1,@begindate);  
 set @ReslutEnd_ly = DATEADD(YEAR,-1,@enddate);  
 End  
   
 Else if(@Diff > 26 And @Diff < 33) -- 日期为一个月时  
  Begin  
 set @ReslutBegin_Lp = DATEADD(MONTH,-1,@begindate);   
 set @ReslutEnd_lp = DATEADD(ss,-1,@begindate);    
 set @ReslutBegin_Ly = DATEADD(YEAR,-1,@begindate);    
 set @ReslutEnd_ly = DATEADD(YEAR,-1,@enddate);  
 End  
   
 Else if(@Diff > 82 And @Diff < 95) -- 日期为一个季度时  
 Begin  
 set @ReslutBegin_Lp = DATEADD(MONTH,-3,@begindate);   
 set @ReslutEnd_lp = DATEADD(ss,-1,@begindate);    
 set @ReslutBegin_Ly = DATEADD(YEAR,-1,@begindate);    
 set @ReslutEnd_ly = DATEADD(YEAR,-1,@enddate);  
 End   
    
 Else if(@Diff > 363 And @Diff < 367) -- 日期为一个年时  
 Begin  
 set @ReslutBegin_Lp = DATEADD(YEAR,-1,@begindate);   
 set @ReslutEnd_lp = DATEADD(YEAR,-1,@endDate);    
 set @ReslutBegin_Ly = DATEADD(YEAR,-1,@begindate);    
 set @ReslutEnd_ly = DATEADD(YEAR,-1,@enddate);  
 End   
    
 ELSE   -- 其余情况全部返回原值  
 Begin  
 set @ReslutBegin_Lp = @begindate;   
 set @ReslutEnd_lp = @endDate;    
 set @ReslutBegin_Ly = @begindate;    
 set @ReslutEnd_ly = @enddate;  
 End
go

