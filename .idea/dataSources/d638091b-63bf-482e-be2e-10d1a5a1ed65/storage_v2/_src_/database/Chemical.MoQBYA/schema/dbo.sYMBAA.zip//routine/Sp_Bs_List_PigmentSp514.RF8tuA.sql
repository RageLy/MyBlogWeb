












-- =============================================
-- Author:		白冰
-- Create date: 2016-06-03
-- Description:	获取粒子数据信息列表
-- Parameter：	@ParticalCode -- 粒子编号
--				@PType：-- 黑色粒子、白色粒子
--				@PigmentCode：-- 颜料编号
--              @OptDate：-- 粒子制作时间
--				@Kettle： -- 粒子反应釜
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Bs_List_PigmentSp514]
 @OptDateB VARCHAR(50) = ''      
 ,@OptDateE VARCHAR(50) = ''   
 ,@Code VARCHAR(50) = ''  
 ,@PageIndex varchar(5) = '1'
 ,@PageSize varchar(5) = '10'
 ,@OrderFields varchar(50) = ''
 ,@Type varchar(50) = ''  -- "查询" "编辑" 类型，是查询的List，还是编辑用的加载    
 ,@ID varchar(50) = ''   
 ,@EmpID varchar(50) = '1' 
AS
BEGIN

SET @Code = LTRIM(RTRIM(@Code))
select tPartical.ID, tPartical.Code,
		CONVERT(varchar(50), tPartical.OptDate, 23) AS OptDate ,
        rawc.RawCode,PigmentSp514OuterCode.OuterCode,tPartical.GrindPress,tPartical.GrindOutPut,tPartical.GrindTimeB,tPartical.GrindTimeE, tPartical.GHL, 
		tPartical.CLTemp15MIN,tPartical.CLTemp30MIN,tPartical.CLTemp45MIN,tPartical.CLTemp60MIN,tPartical.CLTemp90MIN,
		tPartical.CLTemp120MIN,tPartical.LQTemp10MIN,tPartical.LQTemp20MIN,tPartical.LQTemp30MIN,tPartical.LQTemp60MIN,tPartical.LQTemp90MIN,
		tPartical.LQTemp120MIN,tPartical.Remark
   INTO #Result
   FROM dbo.Bs_PigmentlSp514 AS tPartical
   left join Tbl_Base_PigmentSp514RawCode rawc
   on tPartical.RawCode=rawc.ID
   left join Tbl_Base_PigmentSp514OuterCode PigmentSp514OuterCode
   on tPartical.OuterCode=PigmentSp514OuterCode.id
   where ( @Code = '' or tPartical.Code like ('%' + @Code + '%') )
      AND ( @OptDateB = '' or tPartical.[OptDate] >= @OptDateB )       
   AND ( @OptDateE = '' or tPartical.[OptDate] < DATEAdd(DD,1,@OptDateE ) )    
   AND ( @Type = '查询' OR tPartical.ID = @ID )
   
     -- 数据分页    
 DECLARE @totalRow int = @@ROWCOUNT ;    
  
    if(@OrderFields='')    
  set @OrderFields ='optdate desc'    

  -- 编辑的加载 
		 INSERT INTO Tbl_Log_AnaUseLog
			(EmpID, freshTime, spName,
				AnaName, siftvalue, OherParemeter)
			VALUES (@EmpID, GETDATE(), 'SP_Bs_List_PigmentSp514',
				'查询颜料Sp514', 'select',@Code)    
     
 IF(@Type = '查询')
 begin
 
  EXEC dbo.Sp_Sys_Page @tblName = '#Result'                      
  ,@fldName = @OrderFields                              
  ,@rowcount = @totalRow     
  ,@PageIndex = @PageIndex     
  ,@PageSize = @PageSize      
  ,@SumType = 0    
  ,@SumColumn = ''    
  ,@AvgColumn = ''    
     
     end
 ELSE     
    SELECT * FROM #Result
    end
go

