-- =============================================  
-- Description: <通用插入存储过程>  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Sys_InsertTBLTable]  
    @tableName          varchar(256),  
    @colName            varchar(3000),  
    @colValue           varchar(8000)  
AS  
BEGIN try  
 --Sp_Sys_InsertTBLTable @tableName=N'users',@colName=N'name',@colValue=N'111'  
 SET NOCOUNT ON  
  
 declare @sql varchar(4000)  
 declare @Values varchar(4000)=''  
 declare @identity varchar(50);  
   
   
 if CHARINDEX('{&^}',@colValue,0)>0  
 begin  
  declare @value varchar(4000)  
  declare v_cursor cursor for  
  select [string] from  dbo.split(@colValue,'{&^}')  
    
  open v_cursor  
  FETCH NEXT FROM v_cursor  
  INTO @value  
    
  WHILE @@FETCH_STATUS = 0  
  BEGIN  
   set @Values = @Values +''''+ replace(@value,'''','''''')+''''+ ','  
   set @Values=replace(@Values,'''null''','null')  
   FETCH NEXT FROM v_cursor  
   INTO @value  
     
  end  
  CLOSE v_cursor  
  DEALLOCATE v_cursor   
  set @values=SUBSTRING(@values,0,LEN(@values))  
 end  
 else  
 begin  
  set @Values=''''+replace(@colValue,'''','''''') +''''  
  set @Values=replace(@Values,'''null''','null')  
 end  
   
    
  
 set @sql = 'insert into '+@tableName+'('+@colName+') values('+@Values+')'  
 print @sql  
 exec(@sql)  
   
 select '0';  
    select @@IDENTITY;  
END try  
begin catch  
  
    declare @errMsg varchar(500)='',@columnName varchar(50)=''  
    declare @s int=0,@e int=1  
    select @errMsg=ERROR_MESSAGE()  
    set @s=CHARINDEX('''',@errMsg,0)  
    set @e=CHARINDEX('''',@errMsg,@s+1)  
    set @columnName=SUBSTRING(@errMsg,@s+1,@e-@s-1)  
    select @errMsg msg,@columnName [column],ERROR_NUMBER() errNum  
end catch
go

