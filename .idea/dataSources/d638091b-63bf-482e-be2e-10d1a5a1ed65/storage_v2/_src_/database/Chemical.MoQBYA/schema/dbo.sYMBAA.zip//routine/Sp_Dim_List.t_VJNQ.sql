



-- =============================================        
--分析器维度调整
-- =============================================     
     
CREATE proc [dbo].[Sp_Dim_List]  
 @CodeType  VARCHAR(50) = '颜料编号'   -- 编号类型
 ,@PageIndex varchar(5) = '1'  
 ,@PageSize varchar(5) = '10'  
 ,@OrderFields varchar(50) = ''
 ,@ID varchar(50) = ''
 ,@Type varchar(50) = '' 
 ,@EmpID varchar(50) = '1'
AS  
BEGIN  
 --------------------- 变量声明  -------------------------  
 DECLARE @CodeTypeUS VARCHAR(2000) = '' --
 

 SET @CodeTypeUS=(SELECT CodeType 
                    FROM (
                            SELECT ROW_NUMBER() OVER (ORDER BY CodeType) AS id
                            ,CodeType 
                            FROM (
                                    SELECT DISTINCT Used AS CodeType 
                                    FROM Tbl_AnsCom_DIimToTable
                                    WHERE Used IS NOT NULL) AA
                          ) BB 
                     WHERE id=@CodeType)

 SELECT ID,Used,Name_ch,CutInt,NumDecimal,BaseCount,CutInt+NumDecimal*BaseCount UL 
 INTO #RE FROM dbo.Tbl_AnsCom_DIimToTable
 WHERE Remark is not null
 AND ID>1
 AND IsRange=1
 AND Used IS NOT NULL
 AND Used like '%'+@CodeTypeUS+'%'
 AND ( @Type = '查询' OR ID = @ID)
 ORDER BY Name_ch

 DECLARE @totalRow int = @@ROWCOUNT ;    
  
    if(@OrderFields='')    
  set @OrderFields ='Name_ch'    
        
   --INSERT INTO Tbl_Log_AnaUseLog
   -- (EmpID, freshTime, spName,
   --     AnaName, siftvalue, OherParemeter)
   -- VALUES (@EmpID, GETDATE(), 'Sp_Bs_List_SinCapsule',
   --     '查询单层胶囊', 'select',@Code)    
        
     
 IF(@Type = '查询')
  begin
  EXEC dbo.Sp_Sys_Page @tblName = '#RE'                      
  ,@fldName = @OrderFields                              
  ,@rowcount = @totalRow     
  ,@PageIndex = @PageIndex     
  ,@PageSize = @PageSize      
  ,@SumType = 0    
  ,@SumColumn = ''    
  ,@AvgColumn = ''
end
     
 -- 编辑的加载    
 ELSE     
 SELECT * FROM #RE    
 
END
go

