


-- =============================================
-- Author:  <hjl>
-- Create date:<2017-11-14>
-- Description:<读取维度编辑器的条件 Othercond>
-- =============================================


CREATE PROCEDURE [dbo].[sp_Dim_GetOtherCondXG]
      @tag varchar(50)='WeldTime' -- 标识符
      ,@Condtype varchar(50) = 'Y' -- 'X' , 'G' , 'Y' 类型是X还是G还是Y轴
 as
 Begin

set nocount on;
	
	-- condition  和 humcondition 都拼接得到
	declare @Dims varchar(MAX) ;
	select @Dims =GdDim+ SELECTdim FROM Tbl_AnsCom_SelfDims where tag = @tag;
	
	declare @defaultAdd varchar(100) = CASE WHEN @Condtype = 'X' THEN '无横轴'
										    WHEN @Condtype = 'G' THEN '无分组' END;
	--select @Dims
	IF(@Condtype in ('X','G'))
	BEGIN
		select 0 as Yindex,@defaultAdd AS Value ,@defaultAdd AS [Text]
		UNION ALL
		select a.StartIndex,Name_ch,Name_ch
		from dbo.Split(@Dims,',') a 
		inner join Tbl_AnsCom_DIimToTable b on a.string = b.DimNum
		WHERE b.DimNum<>'' AND b.DimNum IS NOT NULL
		order by Yindex
	END
	
	ELSE IF(@Condtype = 'Y')
	BEGIN
		select 0 as Yindex,YName AS Value ,YName AS [Text]
		FROM Tbl_AnsCom_SelfY where SpName = @tag
		UNION ALL
		select a.StartIndex,Name_ch,Name_ch
		from dbo.Split(@Dims,',') a 
		inner join Tbl_AnsCom_DIimToTable b on a.string = b.DimNum
		where IsRange = 1 and b.DimNum<>'' AND b.DimNum IS NOT NULL
		order by Yindex
		;
	END

 End
go

