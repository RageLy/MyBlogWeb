  /**                  
 --  刘轶  2014-9-2 财务业务 加载SignEmpID                 
 **/                                                                        
CREATE PROCEDURE [dbo].Sp_Common_LoadSignEmpID                                                                          
@EmpID varchar(500)='565'                                                                      
AS                                                                          
BEGIN           
          
select  @EmpID as  SignEmpID
         
End
  go

