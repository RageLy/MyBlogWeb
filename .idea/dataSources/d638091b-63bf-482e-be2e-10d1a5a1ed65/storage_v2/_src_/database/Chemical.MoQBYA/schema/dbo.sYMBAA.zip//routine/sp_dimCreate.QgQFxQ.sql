-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[sp_dimCreate]

	@dimName VARCHAR(500)

AS
BEGIN

DECLARE @a INT = 1
DECLARE @total INT 



--SELECT 'CREATE TABLE ' + TableName + ' (ID BIGINT,Name VARCHAR(100));' AS t INTO #temp
--FROM dbo.Tbl_AnsCom_DIimToTable AS dt INNER JOIN dbo.f_splitSTR(@dimName,';') AS d ON dt.DimNum = d.string

--SELECT @total = COUNT(1) FROM #temp

--DECLARE @s VARCHAR(500);
--DECLARE loopExec CURSOR FOR (SELECT t FROM #temp);

--OPEN loopExec;

--FETCH NEXT FROM loopExec INTO @s;

--WHILE @@FETCH_STATUS = 0
--BEGIN
	
--	PRINT @s;
--	EXEC (@s);
	
--	FETCH NEXT FROM loopExec INTO @s;
--END

--CLOSE loopExec;
--DEALLOCATE loopExec;


SELECT 'CREATE TABLE #Temp41 (ID BIGINT,Name VARCHAR(100));
CREATE TABLE #Speed (ID BIGINT,Name VARCHAR(100));'


END
go

