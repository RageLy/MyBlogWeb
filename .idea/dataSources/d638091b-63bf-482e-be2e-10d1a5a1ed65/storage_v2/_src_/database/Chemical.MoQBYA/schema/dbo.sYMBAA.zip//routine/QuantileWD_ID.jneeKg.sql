CREATE PROCEDURE QuantileWD_ID
    @beginDate NVARCHAR(10) = '' ,
    @endDate NVARCHAR(10) = '' ,
    @CoNameID NVARCHAR(20) = '' ,
    @date NVARCHAR(10) = ''
AS
    BEGIN
    
        DECLARE @sql NVARCHAR(MAX) = '';
        DECLARE @sql1 NVARCHAR(MAX) = '';
        DECLARE @CoName NVARCHAR(50)= '';
        DECLARE @Name_ch NVARCHAR(20)= '';
        SET @CoName = ( SELECT  TableName + '.' + CoName
                        FROM    dbo.Tbl_AnsCom_DIimToTable
                        WHERE   ID = @CoNameID
                      );
        SET @Name_ch = ( SELECT Name_ch
                         FROM   dbo.Tbl_AnsCom_DIimToTable
                         WHERE  ID = @CoNameID
                       );
                       --CREATE  TABLE QuantileWDTb
                       --(ID INT IDENTITY(1,1) NOT NULL,
                       --Name_ch NVARCHAR(20),
                       --Co_Name NVARCHAR(50),
                       --MinValue DECIMAL(18,4),
                       --DownFourValue DECIMAL(18,4),
                       --MiddleValue DECIMAL(18,4),
                       --UpFourValue DECIMAL(18,4),
                       --MaxValue DECIMAL(18,4),
                       --TimeWD int
                       --)
                       
        SET @sql = 'insert into QuantileIDWDTb SELECT  distinct ' + @CoName
            + ',''' + @Name_ch + ''',
                CASE WHEN CoatingZJ.OptDate >= ''' + @date + ''' THEN 1
                     WHEN CoatingZJ.OptDate < ''' + @date
            + ''' THEN 0
                END 时间维度
FROM    dbo.Bs_Coating_ZJ CoatingZJ
LEFT JOIN dbo.Bs_Coating Coating ON CoatingZJ.CoatingCode = Coating.Code
LEFT JOIN Bs_Coating_ITO CoatingITO ON Coating.CoatingITOCode = CoatingITO.Code
LEFT JOIN Bs_Coating_MS CoatingMS ON CoatingMS.Code = Coating.CoatingMsCode
LEFT JOIN dbo.Bs_CapsuleDynamic CapsuleDynamic ON CapsuleDynamic.Code = CoatingMS.CapsuleDynamicCode
LEFT JOIN dbo.Bs_DouCapsule DouCapsule1 ON DouCapsule1.Code = CapsuleDynamic.DouCapsuleCode1
LEFT JOIN dbo.Bs_DouCapsule DouCapsule2 ON DouCapsule2.Code = CapsuleDynamic.DouCapsuleCode2
LEFT JOIN dbo.Bs_DouCapsule DouCapsule3 ON DouCapsule3.Code = CapsuleDynamic.DouCapsuleCode3
LEFT JOIN dbo.Bs_DouCapsule DouCapsule4 ON DouCapsule4.Code = CapsuleDynamic.DouCapsuleCode4
LEFT JOIN dbo.Bs_DouCapsule DouCapsule5 ON DouCapsule5.Code = CapsuleDynamic.DouCapsuleCode5
LEFT JOIN dbo.Bs_DouCapsule DouCapsule6 ON DouCapsule6.Code = CapsuleDynamic.DouCapsuleCode6
LEFT JOIN dbo.Bs_DouCapsule DouCapsule7 ON DouCapsule7.Code = CapsuleDynamic.DouCapsuleCode7
LEFT JOIN dbo.Bs_DouCapsule DouCapsule8 ON DouCapsule8.Code = CapsuleDynamic.DouCapsuleCode8
LEFT JOIN dbo.Bs_DouCapsule DouCapsule9 ON DouCapsule9.Code = CapsuleDynamic.DouCapsuleCode9
LEFT JOIN dbo.Bs_DouCapsule DouCapsule10 ON DouCapsule10.Code = CapsuleDynamic.DouCapsuleCode10
LEFT JOIN dbo.Bs_DouCapsule DouCapsule11 ON DouCapsule11.Code = CapsuleDynamic.DouCapsuleCode11
LEFT JOIN dbo.Bs_DouCapsule DouCapsule12 ON DouCapsule12.Code = CapsuleDynamic.DouCapsuleCode12
LEFT JOIN dbo.Bs_DouCapsule DouCapsule13 ON DouCapsule13.Code = CapsuleDynamic.DouCapsuleCode13
LEFT JOIN dbo.Bs_DouCapsule DouCapsule14 ON DouCapsule14.Code = CapsuleDynamic.DouCapsuleCode14
LEFT JOIN dbo.Bs_DouCapsule DouCapsule15 ON DouCapsule15.Code = CapsuleDynamic.DouCapsuleCode15
LEFT JOIN dbo.Bs_DouCapsule DouCapsule16 ON DouCapsule16.Code = CapsuleDynamic.DouCapsuleCode16
LEFT JOIN dbo.Tbl_Base_BC0009 BC0009 ON BC0009.ID = CapsuleDynamic.BC0009
LEFT JOIN dbo.Tbl_Base_MpSeries MpSeries ON MpSeries.ID = CoatingMS.MpSeries
LEFT JOIN Tbl_Base_NhjType NhjType ON NhjType.ID = CoatingMS.NhjType
LEFT JOIN tbl_Base_ZCJType ZCjType ON ZCjType.ID = CoatingMS.ZCJType
LEFT JOIN Tbl_Base_MSds MSds ON MSds.ID = Coating.Msds
LEFT JOIN Tbl_Base_JSds JSds ON JSds.ID = Coating.Jsds
LEFT JOIN Tbl_Base_MsLpjCode MsLpjCode ON MsLpjCode.ID = CoatingMS.MsLpjCode
LEFT JOIN Tbl_Base_MsWaterType MsWaterType ON MsWaterType.ID = CoatingMS.MsWaterType
LEFT JOIN Tbl_Base_TbBad TbBad1 ON TbBad1.ID = CoatingZJ.Bad1Type
LEFT JOIN Tbl_Base_TbBad TbBad2 ON TbBad2.ID = CoatingZJ.Bad2Type
LEFT JOIN Tbl_Base_TbBad TbBad3 ON TbBad3.ID = CoatingZJ.Bad3Type
LEFT JOIN Tbl_Base_JsCode JsCode ON JsCode.ID = Coating.JsCode
LEFT JOIN Tbl_Base_HxFpCode MsHxFpCode ON MsHxFpCode.ID = Coating.MsHxFpCode
LEFT JOIN Tbl_Base_HxFpCode JSHxFpCode ON JSHxFpCode.ID = Coating.JsHxFpCode
LEFT JOIN Tbl_Base_TJXLCode TJXLCode ON TJXLCode.ID = Coating.TJXLCode
LEFT JOIN dbo.Tbl_Base_BG0026 BG0026Dy ON BG0026Dy.ID = CapsuleDynamic.BG0026TestTime
LEFT JOIN Tbl_Base_MsZCJLLCode MsZCJLLCode ON MsZCJLLCode.ID = CoatingMS.MsZCJLLCode
LEFT JOIN Tbl_Base_MsFSJLLCode MsFSJLLCode ON MsFSJLLCode.ID = CoatingMS.MsFSJLLCode
LEFT JOIN Tbl_Base_MsLpjLLCode MsLpjLLCode ON MsLpjLLCode.ID = CoatingMS.MsLpjLLCode
LEFT JOIN Tbl_Base_401G Ms401G ON Ms401G.ID = CoatingMS.Ms401G
LEFT JOIN Tbl_Base_D207E D207E ON D207E.ID = CoatingMS.D207E
LEFT JOIN Tbl_Base_P100T P100T ON P100T.ID = CoatingMS.P100T
LEFT JOIN Tbl_Base_MsNHJPZDate MsNHJPZDate ON MsNHJPZDate.ID = CoatingMS.MsNHJPZDate
WHERE   min0LBK IS NOT NULL and CoatingZJ.optdate between  ''' + @beginDate
            + ''' and ''' + @endDate + '''
AND ( Coating.Code LIKE ''R5%'' OR Coating.Code LIKE ''R6%'')'
        -- SET @sql1='insert into WDFX select '''+@Name_ch+''' 维度名称,'''+@CoName+''' 英文字段,stdev('+@CoName+') 标准差,CASE WHEN Bs_Coating_ZJ.OptDate >= '''+@date+''' THEN 1
        --              WHEN Bs_Coating_ZJ.OptDate < '''+@date+'''THEN 0
        --         END 时间维度 from    dbo.Bs_Coating_ZJ
        --        LEFT JOIN dbo.Bs_Coating ON Bs_Coating.Code = Bs_Coating_ZJ.CoatingCode
        --        LEFT JOIN dbo.Bs_Coating_MS ON Bs_Coating_MS.Code = Bs_Coating.CoatingMsCode
        --WHERE   min0LBK IS NOT NULL
        --        AND ( dbo.Bs_Coating.Code LIKE ''R5%''
        --              OR dbo.Bs_Coating.Code LIKE ''R6%''
        --            )
        --GROUP BY CASE WHEN Bs_Coating_ZJ.OptDate >= '''+@date+''' THEN 1
        --              WHEN Bs_Coating_ZJ.OptDate < '''+@date+'''THEN 0
        --         END;'    
        
        PRINT LEN(@sql)

        PRINT @sql    
        EXEC (@sql)
    END;

go

