



-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年7月13日                                                
-- Descript: 主分析器sp，分配调用哪个sp
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_GoodnessOfFit]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-78,-80,-82%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1',
    @OtherCond VARCHAR(MAX) = '温度与产值%温度8%时间%胶囊产值%line%平均值%胶囊产值%数量',
    @EmpID INT = 1,
    @PageSize VARCHAR(5) = '10',
    @PageIndex VARCHAR(5) = '1',
    @OrderFields VARCHAR(50) = '',
    @SpName VARCHAR(50) = 'SinCapsule'
AS
BEGIN
    ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    SET NOCOUNT ON;

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue = REPLACE(@condition, '|', ',');
    DECLARE @Usertitle VARCHAR(50) = ''; -- 标题            
    DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                              

    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        String NVARCHAR(50)
    );

    INSERT INTO @OtherCondTbl
    SELECT string
    FROM dbo.f_splitSTR(@OtherCond, '%');

    SET @XName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 2
    );
    SET @DSName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 3
    );
    SET @YName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 4
    );


    --SELECT  *
    --FROM    @OtherCondTbl;
    -- OtherCond解析完毕            
    -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

    ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


    -- 时间表 时间临时表必然需要
    CREATE TABLE #time
    (
        id VARCHAR(200),
        beginDate DATETIME,
        endDate DATETIME,
        beginDate_Lp DATETIME,
        endDate_Lp DATETIME,
        beginDate_Ly DATETIME,
        endDate_Ly DATETIME
    );

    -- 如果有其它需要用 #时间表的必须在这里添加

    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(500); -- 用于拼接@Sql中 指标计算方式的Sql语句            
    DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句
	DECLARE @ErrorRecord NVARCHAR(MAX) = '';
    SET @XOrder = ',1 as X排序';
    SET @DsOrder = ',1 as G排序';

    -- 处理维度临时表
    CREATE TABLE #Dims
    (
        DimName VARCHAR(50),
        DimValues VARCHAR(MAX),
        ChName VARCHAR(50),
        Isneed VARCHAR(50),
        DimOrdersql VARCHAR(50),
        DimYsql VARCHAR(50),
        isrange VARCHAR(50)
    );

    EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue,
                                    @XName = @XName,
                                    @DsName = @DSName;
    --SELECT  *
    --FROM    #Dims;
    IF NOT EXISTS (SELECT 1 FROM #Dims WHERE ChName = @YName)
    BEGIN
        --PRINT '为啥不执行'
        INSERT INTO #Dims
        (
            DimName,
            DimValues,
            ChName,
            Isneed,
            DimOrdersql,
            DimYsql,
            isrange
        )
        SELECT DimNum,
               '',
               Name_ch,
               'ND',
               '',
               AtYSql,
               IsRange
        FROM dbo.Tbl_AnsCom_DIimToTable
        WHERE Name_ch = @YName
              AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
    END;
    PRINT 'XName' + @XName + @YName;
    IF NOT EXISTS (SELECT 1 FROM #Dims WHERE ChName = @XName)
    BEGIN
        INSERT INTO #Dims
        (
            DimName,
            DimValues,
            ChName,
            Isneed,
            DimOrdersql,
            DimYsql,
            isrange
        )
        SELECT DimNum,
               '',
               Name_ch,
               'X',
               '',
               AtYSql,
               IsRange
        FROM dbo.Tbl_AnsCom_DIimToTable
        WHERE Name_ch = @XName
              AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
    END;
    --SELECT  *
    --FROM    #Dims;

    --from 源表
    DECLARE @FromSql VARCHAR(MAX) = (
                                        SELECT JoinTables + CHAR(10) + BaseTable + ' '
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = @SpName
                                    );
    IF (@FromSql IS NULL OR @FromSql = '')
    BEGIN
       SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables,BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = ''' + @SpName
                                    + '''结果为空 ,可能导致报错,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_GoodnessOfFit' , -- SpName - nvarchar(50)
                           @ErrorRecord ,               -- ErrorInto - nvarchar(1000)
                           'Exec Sp_GoodnessOfFit @PageIndex = '''
                           + @PageIndex
                           + ''' ,
                                @PageSize = ''' + @PageSize
                           + ''' ,
                                @OrderFields = ''' + @OrderFields
                          
                           + ''' ,@condition=''' + @condition
                           + ''',@OtherCond=''' + @OtherCond + ''',@SpName'''
                           + @SpName + ''',@EmpID='''
                           + CAST(@EmpID AS NVARCHAR(2)) + '''',
                           GETDATE()                    -- ExecSql - nvarchar(1000)
                       );

                RETURN;
        RETURN;
    END;
    PRINT @FromSql;
    -- 拼接创建维度临时表的语句
    SET @sql +=
    (
        SELECT 'CREATE TABLE #' + DimName
               + -- 非范围维度类型3列
            CASE
                WHEN isrange = 0 THEN
                    '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                -- 范围维度类型5列
                WHEN isrange = 1 THEN
                    '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'
            END
        FROM #Dims
        WHERE Isneed <> 'ND'
        FOR XML PATH('')
    );
    DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
    SET @NeedSiftvalue =
    (
        SELECT '%' + DimName + ':' + DimValues
        FROM #Dims
        WHERE Isneed <> 'ND'
        FOR XML PATH('')
    );

    -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %-----------------------------------
    SET @NeedSiftvalue = CASE
                             WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                 'Dim7:' + dbo.GetDimValue(@SiftValue,
                                                           'Dim7'
                                                          ) + @NeedSiftvalue
                             ELSE
                                 SUBSTRING(@NeedSiftvalue,
                                           2,
                                           LEN(@NeedSiftvalue)
                                          )
                         END;
    -- 解析维度
    SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = '
                + CAST(@EmpID AS VARCHAR(50)) + ';';


    PRINT @sql;
    -------------------------- 维度解析段------------------------------------------------------------



    -------------------------- 创建 where INNERJOIN 筛选出数据维度主题---------------------------------
    DECLARE @whereWD VARCHAR(MAX) = ''; ---提取控制维度名

    DECLARE @TimeName VARCHAR(50);
    SET @TimeName =
    (
        SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName
    );

	IF(@TimeName = '' OR @TimeName IS NULL)
	BEGIN
		set @ErrorRecord+='查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '''+@SpName+'''为空,请检查;';
		  INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_GoodnessOfFit' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           'Exec Sp_GoodnessOfFit @PageIndex = '''+@PageIndex+''' ,
                                @PageSize = '''+@PageSize+''' ,
                                @OrderFields = '''+@OrderFields+''' ,
                              @condition='''+@condition+''',@OtherCond='''+@OtherCond+''',@SpName'''+@SpName+''',@EmpID='''+CAST(@EmpID AS NVARCHAR(2))+'''' ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
		RETURN;
	END

    IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        SET @whereWD += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';
    DECLARE @ChoiceWD TABLE
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        String NVARCHAR(50)
    );
    INSERT INTO @ChoiceWD
    SELECT string
    FROM dbo.f_splitSTR(
         (
             SELECT DimValues FROM #Dims WHERE ChName = '控制维度选项'
         ),
         ','
                       );
    CREATE TABLE #TempWD
    (
        Id INT,
        Istrue NVARCHAR(2),
        DimName NVARCHAR(50)
    );

    DECLARE @sqltemp NVARCHAR(MAX) = '';

    SET @sqltemp +=
    (
        SELECT 'INSERT INTO #TempWD SELECT  ID,Istrue,DimName   from vw_' + DimName + '_part  '
        FROM #Dims
        WHERE ChName = '控制维度选项'
    );
    PRINT @sqltemp;
    --SELECT  DimName
    --FROM    #Dims
    --WHERE   ChName = '控制维度选项';
    EXEC (@sqltemp);
    PRINT @sqltemp;
    --SELECT  *
    --FROM    #TempWD;
    CREATE TABLE #ViewNameTb
    (
        DimNum NVARCHAR(50),
        ViewName NVARCHAR(50),
        ChName NVARCHAR(50),
        istrue NVARCHAR(1),
        Isrange INT,
        DimYsql NVARCHAR(50),
    );
    INSERT INTO #ViewNameTb
    SELECT Tbl_AnsCom_DIimToTable.DimNum,
           Tbl_AnsCom_DIimToTable.ViewName,
           Tbl_AnsCom_DIimToTable.Name_ch,
           WD.Istrue,
           IsRange,
           Tbl_AnsCom_DIimToTable.AtYSql
    FROM #TempWD WD
        INNER JOIN @ChoiceWD
            ON [@ChoiceWD].String = WD.Id
        INNER JOIN Tbl_AnsCom_DIimToTable
            ON Tbl_AnsCom_DIimToTable.DimNum = WD.DimName;
    --                SELECT  *
    --FROM    #ViewNameTb; 
    INSERT INTO #ViewNameTb
    SELECT Tbl_AnsCom_DIimToTable.DimNum,
           Tbl_AnsCom_DIimToTable.ViewName,
           Tbl_AnsCom_DIimToTable.Name_ch,
           '0',
           Tbl_AnsCom_DIimToTable.IsRange,
           Tbl_AnsCom_DIimToTable.AtYSql
    FROM #Dims
        INNER JOIN Tbl_AnsCom_DIimToTable
            ON Tbl_AnsCom_DIimToTable.DimNum = #Dims.DimName
    WHERE NOT EXISTS
    (
        SELECT 1 FROM #ViewNameTb WD WHERE WD.DimNum = #Dims.DimName
    )
          AND Isneed = 'X';

    --SELECT  *
    --FROM    #ViewNameTb;        

    -- 选择了维度但是没有筛选条件的维度也需要关联   --控制维度视图里5倍的istrue全是3
    --而维度视图里面有些5倍值的istrue=3,有些等于5,于是这里我做了一个判断,控制维度的istrue=3的,
    --在关联维度视图时,使用OR关键字,保证能将istrue=5的数据也取上。这样就不用去修改视图了，不然会很麻烦的。                  
    SET @whereWD += ISNULL(
                    (
                        SELECT ' inner JOIN vw_' + ViewName + '_Part AS ' + DimNum + ' on '
                               + CASE
                                     WHEN Isrange
        =                   1
                                          AND istrue = 3 THEN
                                         DimNum + '.BeginValue <= ' + #ViewNameTb.DimYsql + ' AND ' + DimNum
                                         + '.EndValue > ' + #ViewNameTb.DimYsql + ' and (' + DimNum + '.Istrue =3 OR '
                                         + DimNum + '.Istrue =5)'
                                     WHEN Isrange = 1
                                          AND istrue = 4 THEN
                                         DimNum + '.BeginValue <= ' + #ViewNameTb.DimYsql + ' AND ' + DimNum
                                         + '.EndValue > ' + #ViewNameTb.DimYsql + ' and (' + DimNum + '.Istrue =4 OR '
                                         + DimNum + '.Istrue =10)'
                                     WHEN Isrange = 1
                                          AND istrue = 0 THEN
                                         DimNum + '.BeginValue <= ' + #ViewNameTb.DimYsql + ' AND ' + DimNum
                                         + '.EndValue > ' + #ViewNameTb.DimYsql + ' and (' + DimNum + '.Istrue =0 )'
                                     WHEN Isrange = 1
                                          AND istrue = 2 THEN
                                         DimNum + '.BeginValue <= ' + #ViewNameTb.DimYsql + ' AND ' + DimNum
                                         + '.EndValue > ' + #ViewNameTb.DimYsql + ' and (' + DimNum + '.Istrue =2 )'
                                     ELSE
                                         DimNum + '.ID = ' + DimYsql
                                 END
                        FROM #ViewNameTb
                        FOR XML PATH('')
                    ),
                    ''
                          );
    SET @whereWD += ISNULL(
                    (
                        SELECT ' inner JOIN #' + DimName + ' AS ' + DimName + ' on '
                               + CASE
                                     WHEN isrange
        =                   1 THEN
                                         DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > '
                                         + DimYsql
                                     ELSE
                                         DimName + '.ID = ' + DimYsql
                                 END
                        FROM #Dims
                        WHERE NOT EXISTS
                        (
                            SELECT 1 FROM #ViewNameTb WHERE #Dims.DimName = #ViewNameTb.DimNum
                        )
                              AND Isneed <> 'ND'
                              AND DimYsql <> ''
                        FOR XML PATH('')
                    ),
                    ''
                          );

    SET @whereWD = REPLACE(REPLACE(@whereWD, '&lt;', '<'), '&gt;', '>');
    PRINT '@whereWD: ' + @whereWD;
    --SELECT * FROM #Dims
    --Y 列
    PRINT @YName + @XName;
    DECLARE @Ycolumn VARCHAR(50) = ISNULL(
                                   (
                                       SELECT DimYsql FROM #Dims WHERE ChName = @YName
                                   ),
                                   ''
                                         ); -- Y轴在本表上面的列名
    DECLARE @Xcolumn VARCHAR(50) = ISNULL(
                                   (
                                       SELECT DimYsql FROM #Dims WHERE ChName = @XName
                                   ),
                                   ''
                                         ); -- Y轴在本表上面的列名


    PRINT 'Y列：' + @Ycolumn + 'X列：' + @Xcolumn;
    ------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             

    ------------------------------------------------查询列----------------------------------------------
    DECLARE @QuaryColumn NVARCHAR(MAX) = '';
    SET @QuaryColumn +=
    (
        SELECT 'A.' + DimName + 'Name,' FROM #Dims WHERE DimYsql = '' + @Xcolumn + ''
    ) + (ISNULL(
         (
             SELECT 'A.' + ViewName + 'Name,'
             FROM #ViewNameTb
             WHERE NOT EXISTS
             (
                 SELECT 1
                 FROM #Dims
                 WHERE #Dims.DimName = #ViewNameTb.DimNum
                       AND DimYsql = '' + @Xcolumn + ''
             )
             FOR XML PATH('')
         ),
         ''
               )
        ) + '';

    SET @QuaryColumn = SUBSTRING(@QuaryColumn, 1, LEN(@QuaryColumn) - 1);
    PRINT '查询列: ' + @QuaryColumn + '';
    --------------------------------------------分组语句----------------------------------------------------  
    DECLARE @sqlGroup NVARCHAR(MAX) = '';
    SET @sqlGroup += 'GROUP BY ' +
                     (
                         SELECT DimName + '.Name,' FROM #Dims WHERE DimYsql = '' + @Xcolumn + ''
                     ) + (ISNULL(
                          (
                              SELECT ViewName + '.Name,'
                              FROM #ViewNameTb
                              WHERE NOT EXISTS
                              (
                                  SELECT 1
                                  FROM #Dims
                                  WHERE #Dims.DimName = #ViewNameTb.DimNum
                                        AND DimYsql = '' + @Xcolumn + ''
                              )
                              FOR XML PATH('')
                          ),
                          ''
                                )
                         ) + '';
    SET @sqlGroup = SUBSTRING(@sqlGroup, 1, LEN(@sqlGroup) - 1);
    PRINT '分组' + @sqlGroup + '';
    --------------------------------------------分组语句2----------------------------------------------------  
    DECLARE @sqlGroup2 NVARCHAR(MAX) = '';
    SET @sqlGroup2 += 'GROUP BY A.num,A.AVGX,A.AVGY,' +
                      (
                          SELECT 'A.' + DimName + 'Name,' FROM #Dims WHERE DimYsql
        =                     '' + @Xcolumn + ''
                      ) + (ISNULL(
                           (
                               SELECT 'A.' + ViewName + 'Name,'
                               FROM #ViewNameTb
                               WHERE NOT EXISTS
                               (
                                   SELECT 1
                                   FROM #Dims
                                   WHERE #Dims.DimName = #ViewNameTb.DimNum
                                         AND DimYsql = '' + @Xcolumn + ''
                               )
                               FOR XML PATH('')
                           ),
                           ''
                                 )
                          ) + '';
    SET @sqlGroup2 = SUBSTRING(@sqlGroup2, 1, LEN(@sqlGroup2) - 1);
    PRINT '分组2' + @sqlGroup2 + '';
    ---------------------------------------------字段列------------------------------------------------------      
    DECLARE @sqlColumn NVARCHAR(MAX) = '';
    SET @sqlColumn +=
    (
        SELECT DimName + '.Name as ' + DimName + 'Name,'
        FROM #Dims
        WHERE DimYsql = '' + @Xcolumn + ''
    ) + (ISNULL(
         (
             SELECT ViewName + '.Name as ' + ViewName + 'Name,'
             FROM #ViewNameTb
             WHERE NOT EXISTS
             (
                 SELECT 1
                 FROM #Dims
                 WHERE #Dims.DimName = #ViewNameTb.DimNum
                       AND DimYsql = '' + @Xcolumn + ''
             )
             FOR XML PATH('')
         ),
         ''
               )
        ) + '';
    SET @sqlColumn = SUBSTRING(@sqlColumn, 1, LEN(@sqlColumn) - 1);
    PRINT '列' + @sqlColumn + '';



    ------------------------------------------------ON 条件关联----------------------------------------------
    DECLARE @ONRelation NVARCHAR(MAX) = '';
    SET @ONRelation +=
    (
        SELECT 'A.' + DimName + 'Name=B.' + DimName + 'Name and '
        FROM #Dims
        WHERE DimYsql = '' + @Xcolumn + ''
    ) + (ISNULL(
         (
             SELECT 'A.' + ViewName + 'Name=B.' + ViewName + 'Name and '
             FROM #ViewNameTb
             WHERE NOT EXISTS
             (
                 SELECT 1
                 FROM #Dims
                 WHERE #Dims.DimName = #ViewNameTb.DimNum
                       AND DimYsql = '' + @Xcolumn + ''
             )
             FOR XML PATH('')
         ),
         ''
               )
        ) + '';

    SET @ONRelation = LEFT(@ONRelation, LEN(@ONRelation) - 3);
    PRINT 'ON条件关联: ' + @ONRelation + '';
    ------------------------------------------------变动列----------------------------------------------------------------------
    DECLARE @ColumnOther VARCHAR(MAX) = '';
    SET @ColumnOther +=
    (
        SELECT '''' + DimName + 'Name'' ' + ChName + ','
        FROM #Dims
        WHERE DimYsql = '' + @Xcolumn + ''
    ) + (ISNULL(
         (
             SELECT '''' + ViewName + 'Name'' ' + #ViewNameTb.ChName + ','
             FROM #ViewNameTb
             WHERE NOT EXISTS
             (
                 SELECT 1
                 FROM #Dims
                 WHERE #Dims.DimName = #ViewNameTb.DimNum
                       AND DimYsql = '' + @Xcolumn + ''
             )
             FOR XML PATH('')
         ),
         ''
               )
        ) + '';
    SET @ColumnOther = LEFT(@ColumnOther, LEN(@ColumnOther) - 1);
    PRINT '@ColumnOther:' + @ColumnOther;
    -----------------------------------------变动列的字符类型-----------------------------------------------------------------
    DECLARE @VarcharsOther VARCHAR(MAX) = '';
    SET @VarcharsOther +=
    (
        SELECT '''Varchar 500'',' FROM #Dims WHERE DimYsql = '' + @Xcolumn + ''
    ) + (ISNULL(
         (
             SELECT '''Varchar 500'','
             FROM #ViewNameTb
             WHERE NOT EXISTS
             (
                 SELECT 1
                 FROM #Dims
                 WHERE #Dims.DimName = #ViewNameTb.DimNum
                       AND DimYsql = '' + @Xcolumn + ''
             )
             FOR XML PATH('')
         ),
         ''
               )
        ) + '';
    SET @VarcharsOther = LEFT(@VarcharsOther, LEN(@VarcharsOther) - 1);
    PRINT '@VarcharsOther:' + @VarcharsOther;
    ------------------------------------执行sql语句---------------------------------------------
    DECLARE @sqlnew NVARCHAR(MAX) = '';
    SET @sqlnew += 'SELECT COUNT(*) num, MIN(B.X) XMINValue ,
        MAX(B.X) XMAXValue,
        MIN(B.Y) YMINValue ,
        MAX(B.Y) YMAXValue,
        POWER(SUM(( B.X - A.AVGX ) * ( B.Y - A.AVGY )), 2)
        / ( CASE WHEN ( SUM(POWER(( B.X - A.AVGX ), 2))
                        * SUM(POWER(( B.Y - A.AVGY ), 2)) ) = 0 THEN 1
                 ELSE SUM(POWER(( B.X - A.AVGX ), 2))
                      * SUM(POWER(( B.Y - A.AVGY ), 2))
            END ) R2 ,
            ( SUM(B.X * B.Y)*num - SUM(B.X)*SUM(B.Y) )
        / ( CASE WHEN ( SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) ) = 0
                 THEN 1
                 ELSE  SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) 
            END ) K ,
        AVGY - ( ( SUM(B.X * B.Y)*num - SUM(B.X)*SUM(B.Y) )
        / ( CASE WHEN ( SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) ) = 0
                 THEN 1
                 ELSE  SUM(POWER(B.X, 2))*num - POWER(SUM(B.X),2) 
            END ) ) * AVGX Const ,

 SUM(( B.X - AVGX ) * ( B.Y - AVGY ))
        / ( CASE WHEN ( POWER(SUM(POWER(( B.X - AVGX ), 2)), 0.5)
                        * POWER(SUM(POWER(( B.Y - AVGY ), 2)), 0.5) ) = 0
                 THEN 1
                 ELSE POWER(SUM(POWER(( B.X - AVGX ), 2)), 0.5)
                      * POWER(SUM(POWER(( B.Y - AVGY ), 2)), 0.5)
            END ) Relation ,
        ' + @QuaryColumn + ' into #Result
        
FROM    ( SELECT    AVG(' + @Ycolumn + ') AVGY ,
                    AVG(' + @Xcolumn + ' ) AVGX ,
                    ' + @sqlColumn + ' ,
                    COUNT(*) num from
          ' + CHAR(10) + @FromSql + CHAR(10) + @whereWD + CHAR(10) + @sqlGroup
                   + '
        ) A
        INNER JOIN ( SELECT ' + @Ycolumn + ' Y ,
                            ' + @Xcolumn + ' X ,
                            ' + @sqlColumn + '
                    from ' + CHAR(10) + @FromSql + CHAR(10) + @whereWD + '
                   ) B ON ' + @ONRelation + '
' + @sqlGroup2 + '';
    SET @sqlnew += ' select *,(case when Relation>0 and Relation<1 then ''正相关'' 
when Relation<0 and Relation>-1 then ''负相关''
when Relation=1 then ''完全正相关'' 
when Relation=-1 then ''完全负相关''
when Relation=0 then ''不相关'' end) RelaRemark into #ResultNew from #Result where num>1';
    PRINT 'sql:' + @sql;
    PRINT '@sqlnew:' + @sqlnew;

	SET @sqlnew +=' if((select count(*) from #result)=0) begin INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_GoodnessOfFit'',''表#Result数据为空,可能造成报错请检查'',''Exec Sp_GoodnessOfFit @PageIndex = '''''+@PageIndex+''''',@PageSize = '''''+@PageSize+''''',@OrderFields = '''''+@OrderFields+''''',@condition='''''+@condition+''''',@OtherCond='''''+@OtherCond+''''',@SpName'''''+@SpName+''''',@EmpID='''''+CAST(@EmpID AS NVARCHAR(2))+''''''','''+CONVERT(nvarchar(20),GETDATE(),120)+''')  end'

    DECLARE @Varchars VARCHAR(MAX)
        = 'select ''n'' 序号,''num'' 数量,''XMINValue'' X轴最小值,''XMAXValue'' X轴最大值,''YMINValue'' Y轴最小值,''YMAXValue'' Y轴最大值,''R2'' 拟合优度,''K'' 斜率,''Const'' 截距,''Relation'' 相关系数,'
          + @ColumnOther + ''
          + ' UNION ALL 
    SELECT ''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'',''Varchar 500'','
          + @VarcharsOther + '';

    PRINT '字段列' + @Varchars;

    IF (@OrderFields = '' OR @OrderFields IS NULL)
        SET @OrderFields =
    (
        SELECT DimName + 'Name desc' FROM #Dims WHERE DimYsql = '' + @Xcolumn + ''
    )   ;

    DECLARE @Pagesql VARCHAR(MAX)
        = '  DECLARE @totalRow int = (Select count(1) FROM #ResultNew) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#ResultNew''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''''
  ,@AvgColumn = ''''
 '  ;
    -- 注销临时表
    --SET @sql += isnull ( ( SELECT ' DROP TABLE #' +  DimName + ';'
    --	FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') ) , '');

    --SELECT  @sql + @sqlnew
    --FOR     XML PATH('');
    EXEC (@Varchars);
    EXEC (@sql + @sqlnew + @Pagesql);
    --SELECT @sql+@sqlnew+@Pagesql 

    -- 注销临时表
    DROP TABLE #time;
    DROP TABLE #Dims;
    DROP TABLE #TempWD;
    DROP TABLE #ViewNameTb;
    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        EmpName,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter
    )
    VALUES
    (   @EmpID,
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
        GETDATE(),
        'Sp_GoodnessOfFit',
        '' + @SpName + '拟合分析',
        @condition,
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=' + @OtherCond
    );
END;
go

