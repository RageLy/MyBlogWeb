






-- =============================================                                                          
-- Description: <根据维度名称在字符串中获取相应的维度>   获取纬度解析后的表                                                 
-- =============================================                             
CREATE PROC [dbo].[Sp_Com_Getdimensions_Xname]              
    @SiftValue VARCHAR(MAX) = 'Dim7:Y:this10%Dim110:-1%DimLZBJ1:-1%DimLZBJ2:-1%DimLZBJ3:-1%DimLZHJ1:-1%DimLZHJ2:-1%DimLZHJ3:-1%DimNDBJ1:-1%DimNDBJ2:-1%DimNDBJ3:-1%DimNDHJ1:-1%DimNDHJ2:-1%DimNDHJ3:-1%DimZateBJ1:-1%DimZateBJ2:-1%DimZateBJ3:-1%DimZateHJ1:-1%DimZateHJ2:-1%DimZateHJ3:-1%DimYJWHLBJ1:-1%DimYJWHLBJ2:-1%DimYJWHLBJ3:-1%DimYJWHLHJ1:-1%DimYJWHLHJ2:-1%DimYJWHLHJ3:-1%DimLZLJD5BJ1:-1%DimLZLJD5BJ2:-1%DimLZLJD5BJ3:-1%DimLZLJD5HJ1:-1%DimLZLJD5HJ2:-1%DimLZLJD5HJ3:-1%DimLZLJD9BJ1:-1%DimLZLJD9BJ2:-1%DimLZLJD9BJ3:-1%DimLZLJD9HJ1:-1%DimLZLJD9HJ2:-1%DimLZLJD9HJ3:-1%DimLJ:-1%DimJNGHL:-1%DimCR:1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70|71|72|73|74|75|76|77|78|79%DimLBK:-1%DimLW:-1%DimDeltaBK:-1%DimDeltaW:-1%DimPH:-1%DimDDLps:-1%DimNDcp:-1' ,   --条件字符串  获取由逗号分隔的表名                          
    @EmpID VARCHAR(400) = '1',
    @XName   VARCHAR(50)='CR值'
AS                             
    BEGIN                                                
    SET @SiftValue = REPLACE(@SiftValue, '|', ',')
    SET @XName=@XName
--------------------------------------------------解析字符串------------------------------------------------------------------                     
                     
CREATE TABLE #AnalyzeTb              
(              
id VARCHAR(max) ,              
name VARCHAR(max)              
)                    
CREATE TABLE #AnalyzeTbTime              
(              
id VARCHAR(max) ,              
name VARCHAR(max) ,              
begindate VARCHAR(max),              
enddate VARCHAR(max)              
)                    
                               
DECLARE @char VARCHAR(MAX)                    
DECLARE @reverse VARCHAR(MAX)                    
DECLARE @start INT ,@end INT                    
                    
        
                    
WHILE ( 1 = 1 )              
BEGIN      
        
    IF ( CHARINDEX('filter', @SiftValue) = 0  OR @SiftValue IS NULL )      
        BREAK                    
      
    SET @start = CHARINDEX('filter', @SiftValue)                    
    SELECT  @end = CHARINDEX('endfilter', @SiftValue)                    
    SET @char = SUBSTRING(@SiftValue, @start + 7, @end - @start - 8)                    
 -- select @SiftValue,@char,@start+7,@end-@start-8                    
            
            
    SET @reverse = REVERSE(LEFT(@SiftValue, @start))                    
    SET @reverse = REVERSE(LEFT(@reverse,              
                                CHARINDEX('miD', @reverse) + 2))                    
    SET @reverse = LEFT(@reverse, CHARINDEX(':', @reverse) - 1)                    
 --select @char,@reverse          
        
      
      
    IF CHARINDEX('Dim7', @reverse) > 0              
    BEGIN                    
        TRUNCATE TABLE #AnalyzeTbTime                    
        INSERT  INTO #AnalyzeTbTime EXEC dbo.sp_Dim_7_Level_3_web @char             
        select * from  #AnalyzeTbTime     
  --      PRINT 'aaaaaaaaaaaaaa下面是@char'        
  --PRINT @char        
                          
        SET @char = ( SELECT    id + ','              
                      FROM      #AnalyzeTbTime              
                      WHERE     id NOT IN ( 'id', 'int' )              
       FOR XML PATH('')              
                    )           
                                     
        SET @char = LEFT(@char, LEN(@char) - 1)                    
  --select SUBSTRING(@SiftValue,@start,@end-@start+9)                  
----------------替换字符串----------------                    
        SET @SiftValue = STUFF(@SiftValue, @start,@end - @start + 9, @char)                    
  --print @SiftValue                    
    END                    
    ELSE              
    BEGIN                    
        TRUNCATE TABLE #AnalyzeTb                    
  --select @char ,@reverse                    
        INSERT  INTO #AnalyzeTb EXEC dbo.sp_Dim_Common_Level_3_web @char,@reverse                    
              
  --select * from #AnalyzeTb            
          
        SET @char = ( SELECT    id + ','              
                      FROM      #AnalyzeTb              
                      WHERE     id NOT IN ( 'id', 'int' )              
            FOR XML PATH('')              
                    )                    
        SET @char = LEFT(@char, LEN(@char) - 1)                    
  --select SUBSTRING(@SiftValue,@start,@end-@start+9)                    
----------------替换字符串----------------                    
        SET @SiftValue = STUFF(@SiftValue, @start,@end - @start + 9, @char)                    
  --print @SiftValue                    
    END                    
      
END                    
                     
                     
---------------------------------------------------------------解析字符串完成------------------------------------------------------------------                     
              
                       
        DECLARE @tableCount INT = 0 ,              
            @sql VARCHAR(MAX)= ''                          
   --,@TNames varchar(200) = '' -- 临时表名字符串组                          
            ,              
            @Name VARCHAR(max) = ''  -- 具体单个的表名                          
            ,              
            @DimIndex INT = 0           -- 维度索引，在循环中指明第几个维度                          
            ,              
            @DimName VARCHAR(max) = '' --维度名称，指明循环中当前操作的维度                          
            ,              
            @ViewName VARCHAR(max) = '' -- 维度视图名称                          
            ,              
            @ColumnName VARCHAR(max) = '' -- 维度视图第三列列名                          
                             
        SET @tableCount = ( LEN(@SiftValue) - LEN(REPLACE(@SiftValue, 'Dim',              
                                                          '')) ) / 3 -- 计算表的个数                          
        SET @DimIndex = 1                          
                           
        WHILE ( @tableCount > 0 )              
            BEGIN                          
                SET @DimName = dbo.[GetDimHead](@SiftValue, @DimIndex)                          
                            
  -- 从维度表获取维度对于表名                          
                SET @Name = ''                          
                SELECT  @Name = TableName              
                FROM    Tbl_AnsCom_DIimToTable              
                WHERE   DimNum = @DimName                          
  -- 获取单个表名                          
                IF ( @Name <> '' )              
                    BEGIN                          
                        IF CHARINDEX('Dim7', @DimName) > 0              
                            BEGIN          
                                IF ( LEN(@Name) <> 0 )              
                                    BEGIN                            
                                        CREATE TABLE #timeTemp              
                                            (              
                                              id INT ,              
                                              beginDate DATETIME ,              
                                              endDate DATETIME ,              
                                              beginDate_Ly DATETIME ,              
                                              endDate_Ly DATETIME ,            
                                              beginDate_Lp DATETIME ,              
                                              endDate_Lp DATETIME              
                                            )                                         
                                        DECLARE @TimeSql VARCHAR(MAX)                          
                                        SET @TimeSql = STUFF(( SELECT              
                                           ','              
                                                              + CAST(string AS VARCHAR(500))              
                                                              FROM dbo.GetDim(@SiftValue, @DimName) FOR XML PATH('')), 1, 1, '')          
                                   --时间参数 例：'Dim:7:Y:2013,Y:2012'                          
                                
                                        EXEC [Sp_Com_GetUp_link_time] @TimeSql,              
                                            '#timeTemp'                          
                                        SET @sql += ' insert into ' + @Name              
                                            + ' select * from #timeTemp'                          
                        
                                    END                             
                              
                            END                          
                             
                        ELSE              
                            IF ( @DimName = 'Dim19' ) --员工表有特殊进多加一段数据过滤                          
                                BEGIN          
                                    SET @sql += '                            
     insert into ' + @Name              
                                        + '(VWID,ID,Name) select distinct b.VWID,b.ID,b.Name FROM GetDim('''              
                                        + @SiftValue              
                                        + ''',''Dim19'') as a                            
     inner join vw_Dim19_PartAll as b on a.string = b.VWID                            
     inner join GetEmpQueryRange(' + @EmpID + ') as c on b.ID = c.string  '                            
                             
                                END                          
                             
                         --,'Dim101','Dim102','Dim103'    
      ELSE IF ( @DimName IN ('Dim511','Dim512','Dim513','Dim514','Dim89','Dim94') ) --   范围划分类 维度   想要解析需在此注册                       
                                BEGIN            
                     
                                    SET @ViewName = 'vw_' + @DimName              
                                        + '_PartAll'            
                              
                                    SELECT  @ColumnName = name            
                                    FROM    sys.columns            
                                    WHERE   object_id IN ( SELECT object_id FROM sys.objects WHERE name = @ViewName )              
                                            AND column_id = 3                          
                            
                                    SET @sql += '                          
     insert into ' + @Name + ' select distinct b.VWID,b.ID,b.' + @ColumnName  + ',b.Beginvalue,b.Endvalue'            
                                        + ' FROM GetDim(''' + @SiftValue              
                                        + ''',''' + @DimName              
                                        + ''') as a                            
     inner join ' + @ViewName + ' as b on a.string = b.VWID  '                          
                 
                                END            
                                            
                            ELSE -- 其它通用                          
                                BEGIN                          
    --获取维度第三列列名           

                                    SET @ViewName = 'vw_' + @DimName              
                                        + '_PartAll'                          
                              
                                    SELECT  @ColumnName = name              
                                    FROM    sys.columns              
                                    WHERE   object_id IN ( SELECT              
                                                              object_id     
                                                           FROM              
                                                              sys.objects              
                                                           WHERE              
                                                              name = @ViewName )              
                                            AND column_id = 3      

-------当X轴,维度展开时.将@XDimNum:1,2,3..替换为：@XDimNum:-1
      DECLARE @XDimNum VARCHAR(50)=''
      --DECLARE @XdimLen INT=''
      SET @XDimNum=(SELECT Name_ch FROM Tbl_AnsCom_DIimToTable WHERE Name_ch=@XName AND DimNum=@DimName)
      --SET @XdimLen=(SELECT SUBSTRING(@SiftValue,CHARINDEX(@XDimNum+':',@SiftValue)+LEN(@XDimNum+':'),1) AS cd)
      
                       IF (@XName IN ('DimLZBJ1','DimLZBJ2','DimLZBJ3','DimLZHJ1','DimLZHJ2','DimLZHJ3','DimLZHJ3'))
                            BEGIN
                            SET @SiftValue=REPLACE(@SiftValue,SUBSTRING(@SiftValue,CHARINDEX(@XDimNum+':',@SiftValue),CHARINDEX('%',SUBSTRING(@SiftValue,CHARINDEX(@XDimNum+':',@SiftValue),LEN(@SiftValue)-CHARINDEX(@XDimNum+':',@SiftValue)))-1),@XDimNum+':'+'-1')
                             PRINT @SiftValue
                             SET @sql += '
     insert into ' + @Name + ' (VWID,ID,Name) select distinct b.VWID,b.ID,b.' + @ColumnName              
                                        + ' FROM GetDim(''' + @SiftValue              
                                        + ''',''' + @DimName              
                                        + ''') as a                            
     inner join ' + @ViewName + ' as b on  a.string = b.VWID'  
                            END
-------修改结束          

                            ELSE 
                            BEGIN
                                    SET @sql += '                          
     insert into ' + @Name + ' (VWID,ID,Name) select distinct b.VWID,b.ID,b.' + @ColumnName              
                                        + ' FROM GetDim(''' + @SiftValue              
                                        + ''',''' + @DimName              
                                        + ''') as a                            
     inner join ' + @ViewName + ' as b on a.string = b.VWID  '                          
               PRINT '这次的 @ColumnName-' + @ColumnName            
                                END                          
                    END                          
                            
  --循环用参数                          
                SET @DimIndex = @DimIndex + 1                          
                SET @tableCount = @tableCount - 1                          
            END                          
                      
   PRINT @sql                   
                      
        EXEC(@sql)                          
                      
    END
END
go

