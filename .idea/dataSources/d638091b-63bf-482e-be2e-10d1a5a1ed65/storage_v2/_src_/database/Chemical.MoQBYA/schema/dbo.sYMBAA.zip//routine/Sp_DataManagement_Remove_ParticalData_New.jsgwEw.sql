
-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_DataManagement_Remove_ParticalData_New]
	-- Add the parameters for the stored procedure here
	@ID NVARCHAR(50) = ''
	,@EmpID varchar(50) = '1'
AS
BEGIN
	IF @ID IS NULL OR LEN(@ID) = 0
	BEGIN
		SELECT '请选择一条记录进行删除'
		RETURN 
	END
	ELSE
	BEGIN
	    DELETE FROM dbo.Bs_ParticalSp WHERE [ID] = @ID 
	    
	     INSERT INTO Tbl_Log_AnaUseLog
    (EmpID, freshTime, spName,
        AnaName, siftvalue, OherParemeter)
    VALUES (@EmpID, GETDATE(), 'Sp_AllQuery_List',
        '删除粒子数据', 'DELETE','[ID] ='+ @ID)  
	    
	    
	    
	    SELECT '0'
	    RETURN 		
	END
	
END
go

