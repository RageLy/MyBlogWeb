



-- =============================================        
--分析器维度调整
-- =============================================     
     
CREATE PROCEDURE [dbo].[Sp_Distance_List]
    @DimNum VARCHAR(50) = '' ,  -- 编号类型
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '10' ,
    @OrderFields VARCHAR(50) = '' ,
    @EmpID VARCHAR(2) = '1'
AS
    BEGIN  
 --------------------- 变量声明  -------------------------  

        IF ( @DimNum <> '' )
            BEGIN
                SELECT  Tbl_AnsCom_DIimToTable.DimNum ID ,
                        Tbl_AnsCom_DIimToTable.Name_ch CoName ,
                        Tbl_AnsCom_DIimToTable.TableName_ch TableName ,
                        GoodUpValue ,
                        GoodDownValue ,
                        BadUpValue ,
                        BadDownValue
                INTO    #re
                FROM    dbo.Tbl_AnsCom_DIimToTable
                        LEFT JOIN dbo.Tbl_BaseSetDistance ON Tbl_BaseSetDistance.DimNum = Tbl_AnsCom_DIimToTable.DimNum
                WHERE   Name_ch LIKE '%' + @DimNum + '%'
                        AND IsRange = 1;
                                
                IF ( @OrderFields = ''
                     OR @OrderFields IS NULL
                   )
                    SET @OrderFields = 'CoName desc';
    
                DECLARE @totalRow INT = ( SELECT    COUNT(1)
                                          FROM      #re
                                        );
                EXEC dbo.Sp_Sys_Page @tblName = #re, @fldName = @OrderFields,
                    @rowcount = @totalRow, @PageIndex = @PageIndex,
                    @PageSize = @PageSize, @SumType = 0, @SumColumn = '',
                    @AvgColumn = '';
            END;
        ELSE
            BEGIN
                SELECT  Tbl_AnsCom_DIimToTable.DimNum ID ,
                        Tbl_AnsCom_DIimToTable.Name_ch CoName ,
                        Tbl_AnsCom_DIimToTable.TableName_ch TableName ,
                        GoodUpValue ,
                        GoodDownValue ,
                        BadUpValue ,
                        BadDownValue
                INTO    #re1
                FROM    dbo.Tbl_AnsCom_DIimToTable
                        LEFT JOIN dbo.Tbl_BaseSetDistance ON Tbl_BaseSetDistance.DimNum = Tbl_AnsCom_DIimToTable.DimNum
                WHERE   IsRange = 1;
                        
                IF ( @OrderFields = ''
                     OR @OrderFields IS NULL
                   )
                    SET @OrderFields = 'CoName desc';
    
                DECLARE @totalRow1 INT = ( SELECT    COUNT(1)
                                          FROM      #re1
                                        );
                EXEC dbo.Sp_Sys_Page @tblName = #re1, @fldName = @OrderFields,
                    @rowcount = @totalRow1, @PageIndex = @PageIndex,
                    @PageSize = @PageSize, @SumType = 0, @SumColumn = '',
                    @AvgColumn = '';
            END;
       

    END;
go

