CREATE PROCEDURE [dbo].[GetDimValuetest](
@SiftValue   varchar(Max),   --待分拆的字符串
@DimName varchar(100)     -- Dim名称 Dim4
)
as
BEGIN

   declare @result varchar(max)
   if(@SiftValue='')
      set @result='' 
    
   declare @temp table
   (
     String varchar(max)
   )  
      
   if(charindex('%',@SiftValue)<0)
      set @result = replace(@SiftValue,@DimName+':','')
   ELSE
   
   BEGIN
   
       insert into @temp
       select String from dbo.f_splitSTR(@SiftValue,'%')
       
       select * FROM @temp;
       
       select @result = String from @temp
       where CHARINDEX(@DimName,String) <> 0
       
       set @result = replace(@result,@DimName+':','')
   End
   
   SELECT @result ;

end
go

