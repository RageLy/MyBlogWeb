



-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>
-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[SinCapsule_Edit]
 @ID  varchar(50) = ''
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON
	/**CREATE TABLE #Result            
     (            
      OptDate varchar(500)
      ,Code varchar(500)
      ,Lotcode varchar(500)
      ,OilID varchar(500)
      ,SpeType varchar(500)
      ,Kettle varchar(500)
      ,Volume varchar(500)
      ,GAA varchar(500)
      ,AF0001 varchar(500)
      ,AF0003 varchar(500)
      ,BG0002Fa varchar(500)
      ,BG0002Code varchar(500)
      ,SetTemp41 varchar(500)
      ,Temp41 varchar(500)
      ,Time45 varchar(500)
      ,SetRspeed580 varchar(500)
      ,Rspeed580 varchar(500)
      ,SetTemp8 varchar(500)
      ,Temp8 varchar(500)
      ,Time120 varchar(500)
      ,SetTemp25 varchar(500)
      ,Temp25 varchar(500)
      ,Time360 varchar(500)
      ,SetRspeed400 varchar(500)
      ,Rspeed400 varchar(500)
      ,OutPut varchar(500)
      ,Psize varchar(500)
      ,PsizeSpan varchar(500)
      ,SoildContent varchar(500)
      ,CR varchar(500)
      ,LBK varchar(500)
      ,LW varchar(500)
      ,DeltaBK varchar(500)
      ,DeltaW varchar(500)
      ,PH varchar(500)
      ,PHTemp varchar(500)
      ,Remark varchar(500)
     )**/
     
	IF @ID IS NOT NULL AND LEN(@ID) <> 0
	select
    CONVERT(varchar(100),a.OptDate, 23) OptDate
   ,cast(a.Code as varchar(500)) Code
   ,cast(a.Lotcode as varchar(500)) Lotcode
   ,cast(yx.Code as varchar(500)) OilID
   ,cast(a.SpeType as varchar(500)) SpeType
   ,cast(a.Kettle as varchar(500)) Kettle
   ,cast(a.Volume as varchar(500)) Volume
   ,cast(a.GAA as varchar(500)) GAA
   ,cast(a.AF0001 as varchar(500)) AF0001
   ,cast(a.AF0003 as varchar(500)) AF0003
   ,cast(a.BG0002Fa as varchar(500)) BG0002Fa
   ,cast(a.BG0002Code as varchar(500)) BG0002Code
   ,cast(a.SetTemp41 as varchar(500)) SetTemp41
   ,cast(a.Temp41 as varchar(500)) Temp41
   ,cast(a.Time45 as varchar(500)) Time45
   ,cast(a.SetRspeed580 as varchar(500)) SetRspeed580
   ,cast(a.Rspeed580 as varchar(500)) Rspeed580
   ,cast(a.SetTemp8 as varchar(500)) SetTemp8
   ,cast(a.Temp8 as varchar(500)) Temp8
   ,cast(a.Time120 as varchar(500)) Time120
   ,cast(a.SetTemp25 as varchar(500)) SetTemp25
   ,cast(a.Temp25 as varchar(500)) Temp25
   ,cast(a.Time360 as varchar(500)) Time360
   ,cast(a.SetRspeed400 as varchar(500)) SetRspeed400
   ,cast(a.Rspeed400 as varchar(500)) Rspeed400
   ,cast(a.OutPut as varchar(500)) OutPut
   ,cast(a.Psize as varchar(500)) Psize
   ,cast(a.PsizeSpan as varchar(500)) PsizeSpan
   ,cast(a.SoildContent as varchar(500)) SoildContent
   ,cast(a.CR as varchar(500)) CR
   ,cast(a.LBK as varchar(500)) LBK
   ,cast(a.LW as varchar(500)) LW
   ,cast(a.DeltaBK as varchar(500)) DeltaBK
   ,cast(a.DeltaW as varchar(500)) DeltaW
   ,cast(a.PH as varchar(500)) PH
   ,cast(a.PHTemp as varchar(500)) PHTemp
   ,cast(a.Remark as varchar(500)) Remark
    into #Result
    from Bs_SinCapsule a
    left join Bs_Oil yx
    on a.OilID=yx.ID
    where a.ID = @ID

    SELECT * FROM #Result
   
END
go

