

-- exec [Sp_Analysister_Stad] 'Dim7:Y:this10%DimMpCode:-1%DimMpLotCode:-1%DimMpSeries:-1%DimSDJAvg:-1%DimSDJSqt:-1%DimNhjPH:-1%DimZcjND:-1%DimMsFsjUse:-1%DimMsLpjCode:-1%DimMsLpjUse:-1%DimMsNhjType:-1%DimMsNhjUse:-1%DimMsZcjUse:-1%DimMsCapsulePH:-1%DimMsWaterType:-1%DimMsWaterPH:-1%DimMsWaterDDlps:-1%DimMsLPH:-1%DimMsOverPH:-1%DimMsOverND:-1%DimMsOverGHL:-1%DimMsOverZL:-1%DimMsNdBe:-1%DimMsGhlBe:-1%DimJsCode:-1%DimJsType:-1%DimJsNdBe:-1%DimJsGhlBe:-1%DimMsTtTemp:-1%DimMsTtSd:-1%DimMsTtGTemp:-1%DimMsTtGSd:-1%DimMsTtITOhd:-1%DimMsTtSpeed:-1%DimMsHxFpTemp1:-1%DimMsHxFpTemp2:-1%DimMsHxFpTemp3:-1%DimMsHxFpTemp4:-1%DimMsHxFpTemp5:-1%DimMsHxFpTemp6:-1%DimMsHxFpTemp7:-1%DimMsCjTemp:-1%DimMsCjSd:-1%DimMsCjSpeed:-1%DimMsCjMshd:-1%DimJsTtTemp:-1%DimJsTtSd:-1%DimJsTtSpeed:-1%DimJsTtJx:-1%DimJsCjTemp:-1%DimJsCjSpeed:-1%DimJsCjJshd:-1%DimJsDs:-1%DimMsDs:-1%DimMpTbLv:-1%DimMpFdLv:-1%DimLineSW:-1%DimScJP:-1%DimZcZK:-1%DimSYJudge:-1%DimOEDJudge:-1%Dim0minLBK:-1%Dim2minLBK:-1%Dim0minLW:-1%Dim2minLW:-1%Dim2mindetaLBK:-1%Dim2mindetaLW:-1%DimDbd:-1%DimWBdata:-1%DimQddl:-1','质检膜片批次%时间%水滴角均值%line%平均值%水滴角均值%数量','图','id','Coating',1

-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 柱图、折线图两个图形的标准分析器sp

-- =============================================

CREATE PROCEDURE [dbo].[Sp_Analysister_Stad_Test]
    @condition VARCHAR(MAX) = 'Dim7:Y:this10%DimWelderID:-1%DimResultType:-1',
    @OtherCond VARCHAR(MAX) = '%出错类型%无分组%平均工作率%line%总和%总时长%数量',
    @Type VARCHAR(10) = '图', -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
    @OrderFields VARCHAR(50) = 'id',
    @SpName VARCHAR(50) = 'WeldTime',
    @EmpID INT = 1,
                             -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1',
    @PageSize VARCHAR(5) = '10',
    @XValue VARCHAR(50) = '',
    @DSValue VARCHAR(50) = ''
AS
BEGIN

    ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    SET NOCOUNT ON;

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue = REPLACE(@condition, '|', ',');

    DECLARE @Usertitle VARCHAR(200) = ''; -- 标题            
    DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                
    DECLARE @ChatType VARCHAR(50) = ''; -- 图形名称                
    DECLARE @CTOC VARCHAR(50) = ''; -- @OtherCond 传入的比较方式                
	DECLARE @ErrorRecord NVARCHAR(MAX)='';
    DECLARE @CompareType VARCHAR(50) = ''; -- 比较方式                  

    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

    DECLARE @OtherCondTbl TABLE
    (
        ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY,
        String NVARCHAR(50)
    );

    INSERT INTO @OtherCondTbl
    SELECT string
    FROM dbo.f_splitSTR(@OtherCond, '%');
    IF ((SELECT String FROM @OtherCondTbl WHERE ID = 1) <> '')
    BEGIN
        SET @Usertitle =
        (
            SELECT String FROM @OtherCondTbl WHERE ID = 1
        );
    END;
    SET @XName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 2
    );
    SET @DSName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 3
    );
    SET @YName =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 4
    );
    SET @ChatType =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 5
    );
    SET @CTOC =
    (
        SELECT String FROM @OtherCondTbl WHERE ID = 6
    );

    -- OtherCond解析完毕            
    -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

    ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


    -- 时间表 时间临时表必然需要
    CREATE TABLE #time
    (
        id VARCHAR(200),
        beginDate DATETIME,
        endDate DATETIME,
        beginDate_Lp DATETIME,
        endDate_Lp DATETIME,
        beginDate_Ly DATETIME,
        endDate_Ly DATETIME
    );

    -- 打印出来用于调试
    PRINT '
    CREATE TABLE #time
    (
      id VARCHAR(200) ,
      beginDate DATETIME ,
      endDate DATETIME ,
      beginDate_Lp DATETIME ,
      endDate_Lp DATETIME ,
      beginDate_Ly DATETIME ,
      endDate_Ly DATETIME
    )
	 CREATE TABLE #Result_B
	 (
	  DimX varchar(50)
	  ,OrderX int
	  ,DimG varchar(50)
	  ,OrderG int
	  ,num decimal(18,4)
	 );
    ';

    -- 如果有其它需要用 #时间表的必须在这里添加

    DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
    DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
    DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
    DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
    DECLARE @NumSql VARCHAR(1000); -- 用于拼接@Sql中 指标计算方式的Sql语句            
    DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句

    SET @XOrder = ',1 as X排序';
    SET @DsOrder = ',1 as G排序';

    -- 默认使用 sum 遇到需要 count 或 avg 的Y轴再进行修改
    IF (@CTOC = '平均值')
        SET @CountType = 'AVG';
    ELSE IF (@CTOC = '数量')
        SET @CountType = 'Count';
    ELSE IF (@CTOC = '最大值')
        SET @CountType = 'MAX';
    ELSE IF (@CTOC = '最小值')
        SET @CountType = 'MIN';
    ELSE IF (@CTOC = '标准差')
        SET @CountType = 'STDEV';
    ELSE IF (@CTOC = '总和')
        SET @CountType = 'SUM';
    ELSE IF (@CTOC = '方差')
        SET @CountType = 'VAR';

    -- 读取转化 Y轴步骤 主要设置 @InnerSelect 内部 select 提取字段部分 还有 外部 select 的算法 @CountType          
    IF (@CTOC IN ( '平均值', '数量', '最大值', '最小值', '标准差', '方差', '总和' ))
    BEGIN
        SET @NumSql = ',' + @CountType + '([' + @YName + '])';
    END;

    ELSE IF (@CTOC = '极差')
    BEGIN
        SET @NumSql = ',' + 'MAX([' + @YName + ']) - MIN([' + @YName + '])';
    END;

    ELSE IF (@CTOC = '中位数')
    BEGIN
        SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.5 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
    END;

    ELSE IF (@CTOC = '上四分位')
    BEGIN
        SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.75 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
    END;

    ELSE IF (@CTOC = '下四分位')
    BEGIN
        SET @NumSql = ',' + 'SUM(CASE WHEN nIndex = cast( 0.25 * nCount AS INT) THEN [' + @YName + '] ELSE 0 END )';
    END;

    ELSE IF (@CTOC = '四分位差')
    BEGIN
        SET @NumSql
            = ',' + 'ABS( SUM(CASE WHEN nIndex = cast( 0.25 * nCount AS INT) THEN [' + @YName
              + '] ELSE 0 END ) - SUM(CASE WHEN nIndex = cast( 0.75 * nCount AS INT) THEN [' + @YName
              + '] ELSE 0 END ) )';
    END;


    -- 处理维度临时表
    CREATE TABLE #Dims
    (
        DimName VARCHAR(50),
        DimValues VARCHAR(MAX),
        ChName VARCHAR(50),
        Isneed VARCHAR(50),
        DimOrdersql VARCHAR(50),
        DimYsql VARCHAR(50),
        isrange VARCHAR(50)
    );

    EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue,
                                    @XName = @XName,
                                    @DsName = @DSName;



    -- 拼接创建维度临时表的语句

    --SELECT * FROM #Dims;


    SET @sql += ISNULL(
                (
                    SELECT 'CREATE TABLE #' + DimName
                           +
                        -- 非范围维度类型3列
                        CASE
                            WHEN isrange
        =               0 THEN
                                '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                            -- 范围维度类型5列
                            WHEN isrange = 1 THEN
                                '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,4), EndValue DECIMAL(18,4));'
                        END
                    FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')
                ),
                ''
                      );

    DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
    -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析

    -- 用 Dims 临时表拼接需要解析的 维度字符串
    SET @NeedSiftvalue = ISNULL(
                         (
                             SELECT '%' + DimName + ':' + DimValues
                             FROM #Dims
                             WHERE Isneed <> 'ND'
                             FOR XML PATH('')
                         ),
                         ''
                               );



    -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
    SET @NeedSiftvalue = CASE
                             WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                 'Dim7:' + dbo.GetDimValue(@SiftValue, 'Dim7') + @NeedSiftvalue
                             ELSE
                                 SUBSTRING(@NeedSiftvalue, 2, LEN(@NeedSiftvalue))
                         END;

    -- 解析维度
    SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = '
                + CAST(@EmpID AS VARCHAR(50)) + ';';

    ---------------------------------------------------------------- 维度解析完毕 ------------------------------------------------------------------------------------      

    -----------	-------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             

    -- 结果集表
    CREATE TABLE #Result_B
    (
        DimX VARCHAR(50),
        OrderX INT,
        DimG VARCHAR(50),
        OrderG INT,
        num DECIMAL(18, 4)
    );

    -- 打印出来用于调试



    DECLARE @Dims VARCHAR(50);

    DECLARE @TimeName VARCHAR(50); -- 用于判断时间的标志


    IF (CHARINDEX('时间', @XName) <> 0)
        SET @XOrder = 'CAST(t.beginDate as INT) AS X排序';
    ELSE IF (@XName = '无横轴')
        SET @XOrder = '1 AS X排序';
    ELSE
        SELECT @XOrder = (CASE
                              WHEN DimOrdersql = '' THEN
                                  DimName + '.VWID'
                              -- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS X排序'
                              WHEN DimOrdersql <> '' THEN
                                  DimOrdersql
                              -- 有特殊排序字符则使用特殊的
                              ELSE
                                  '1'
                          END + ' AS X排序'
                         ) -- 都没有则用默认
        FROM #Dims
        WHERE Isneed = 'X';



    IF (CHARINDEX('时间', @DSName) <> 0)
        SET @DsOrder = 'CAST(t.beginDate as INT) AS G排序';
    ELSE IF (@DSName = '无分组')
        SET @DsOrder = '1 AS G排序';
    ELSE
        SELECT @DsOrder = (CASE
                               WHEN DimOrdersql = '' THEN
                                   DimName + '.VWID'
                               -- 非特殊的排序则使用VWID 实例: 'NDcp.VWID AS G排序'
                               WHEN DimOrdersql <> '' THEN
                                   DimOrdersql
                               -- 有特殊排序字符则使用特殊的
                               ELSE
                                   '1'
                           END + ' AS G排序'
                          ) -- 都没有则用默认
        FROM #Dims
        WHERE Isneed = 'G';


    SET @InnerSelect += ',' + @XOrder + ',' + @DsOrder;
    --SELECT * FROM #Dims
    --set @TimeName = (SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig   WHERE SpName = @SpName)
	IF (   (   SELECT ISNULL(MainTable, '')
           FROM   dbo.Tbl_AnsCom_DIimToTable
           WHERE  DimNum = (   SELECT DimName
                               FROM   #Dims
                               WHERE  ChName = @YName
                           )
       ) = ''
   )
    BEGIN
        SET @ErrorRecord += '表Tbl_AnsCom_DIimToTable的MainTable字段为NULL或者为空,请检查;';
		RETURN;
    END;
	

    IF (@XName = '时间' OR @XName = '无横轴')
    BEGIN
        SET @TimeName =
        (
            SELECT MainTable + '.OptDate'
            FROM dbo.Tbl_AnsCom_DIimToTable
            WHERE DimNum =
            (
                SELECT DimName FROM #Dims WHERE ChName = @YName
            )
        );
        IF (@TimeName = '' OR @TimeName IS NULL)
            SET @TimeName =
        (
            SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName
        )   ;
    END;
    ELSE
        SET @TimeName =
    (
        SELECT MainTable + '.OptDate'
        FROM dbo.Tbl_AnsCom_DIimToTable
        WHERE DimNum =
        (
            SELECT DimName FROM #Dims WHERE ChName = @XName
        )
    )   ;

    --PRINT '时间配置字段: '+@TimeName
    IF (@TimeName = '' OR @TimeName IS NULL)
    BEGIN
        SET @TimeName =
        (
            SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName
        );
    END;


    IF (@TimeName = '' OR @TimeName IS NULL)
    BEGIN
        set @ErrorRecord+='找不到时间配置字段,表Tbl_AnsCom_AnaSpConfig的字段TimeName为空;';
        RETURN;
    END;

    -- Group by段的
    SET @Dims = '[' + @XName + '],X排序 ' + ',[' + @DSName + '],G排序'; -- 横轴排序字段            

    DECLARE @PieColumn VARCHAR(100);
    SET @PieColumn = '';

    -------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              

    -- 基础版本的 select段Sql语句

    DECLARE @Xcolumn VARCHAR(50)
        = ISNULL(
          (
              SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'X'
          ),
          'dbo.GetTimeName(t.begindate,t.enddate)'
                ); -- 横轴在本表上面的列名,如果没有说明是时间维度
    -- 如果是无横轴则赋值一个常量字符串
    IF (@XName = '无横轴')
        SET @Xcolumn = '''无横轴''';

    DECLARE @Gcolumn VARCHAR(50)
        = ISNULL(
          (
              SELECT DimName + '.Name ' FROM #Dims WHERE Isneed = 'G'
          ),
          'dbo.GetTimeName(t.begindate,t.enddate)'
                ); -- 分组在本表上面的列名，如果没有说明是时间维度
    IF (@DSName = '无分组')
        SET @Gcolumn = '''无分组''';

    DECLARE @Ycolumn VARCHAR(200) = ISNULL(
                                    (
                                        SELECT DimYsql FROM #Dims WHERE ChName = @YName
                                    ),
                                    ''
                                          ); -- Y轴在本表上面的列名



    ----------------- Y轴配置
    -- Y 轴上面的取值要拿出来

    DECLARE @YSQL VARCHAR(200);

    -- 从维度表中取出Y轴上面的维度
    SET @YSQL = ',' + @Ycolumn + ' AS [' + @YName + ']';
    -- 实例： ',data.Temp8 AS 温度8';

    -- 如果Y轴上面的选取数据是非维度化的内容，则需要在自定义Y轴配置表中寻找
    IF (@Ycolumn IS NULL OR @Ycolumn = '')
    BEGIN

        SELECT @Ycolumn = Ycolumn,
               @YSQL = CASE
                           WHEN YSQL = '自动拼接' THEN
                               ',' + Ycolumn + ' AS [' + @YName + '] '
                           ELSE
                               YSQL
                       END,
               @NumSql = CASE
                             WHEN NumSql = '自动拼接' THEN
                                 ',' + @CountType + '([' + @YName + ']) '
                             ELSE
                                 NumSql
                         END
        FROM Tbl_AnsCom_SelfY
        WHERE SpName = @SpName
              AND YName = @YName;
IF (   @Ycolumn = ''
       OR @Ycolumn IS NULL
   )
    BEGIN
        SET @ErrorRecord += '表Tbl_AnsCom_SelfY的字段Ycolumn为空,可能导致报错,请检查!';
        RETURN;
    END;
IF (   @YSQL = ''
       OR @YSQL IS NULL
   )
    BEGIN
        SET @ErrorRecord += '表Tbl_AnsCom_SelfY的字段@YSQL为空,可能导致报错,请检查!';
        RETURN;
    END;
IF (   @NumSql = ''
       OR @NumSql IS NULL
   )
    BEGIN
        SET @ErrorRecord += '表Tbl_AnsCom_SelfY的字段NumSql为空,可能导致报错,请检查!';
        RETURN;
    END;
    END;



    SET @sql += '
  INSERT INTO #Result_B(DimX,OrderX,DimG,OrderG,num)
   SELECT ' + @Dims + @NumSql + ' AS num
   FROM
   (
   SELECT ';

    -- 如果非分位数算法则不需要排序和算总数量 加快效率
    IF (@CTOC IN ( '平均值', '数量', '最大值', '最小值', '标准差', '方差', '总和' ))
        SET @sql += ' 1 AS [1],';

    ELSE -- 否则分位数算法则加入 排序和总量
        SET @sql += ' Row_Number() OVER(Partition by ' + @Xcolumn + ',' + @Gcolumn + ' Order BY ' + @Ycolumn
                    + ') AS nIndex ,
   COUNT(*) OVER(Partition by ' + @Xcolumn + ',' + @Gcolumn + ') AS nCount ,';

    -- 按照 是否需要维度 拼装选择的维度字段

    -- 如果有时间则取出时间  这里可能有特殊的时间维度需要特殊提出
    IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        SET @sql += 'dbo.GetTimeName(t.begindate,t.enddate) AS 时间';
    ELSE
        SET @sql += 'GetDate() AS 时间';

    -- 横轴上面的取值要拿出来,时间维度则不取出
    IF (@Xcolumn <> 'dbo.GetTimeName(t.begindate,t.enddate)')
        SET @sql += ',' + @Xcolumn + ' AS [' + @XName + ']';
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名

    -- 分组上面的取值也要拿出来,时间维度则不取出
    IF (@Gcolumn <> 'dbo.GetTimeName(t.begindate,t.enddate)')
        SET @sql += ',' + @Gcolumn + ' AS [' + @DSName + ']';
    -- 实例： ',temp8.Name AS 温度8';   其中 DimName 代表在From段中临时表的别名


    SET @sql += @YSQL;

    DECLARE @FromSql VARCHAR(MAX) = (
                                        SELECT JoinTables + ' ' + BaseTable
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = @SpName
                                    );

    IF (@FromSql IS NULL OR @FromSql = '')
    BEGIN
         SET @ErrorRecord += '数据源配置出错,表Tbl_AnsCom_AnaSpConfig的字段JoinTables或者BaseTable为空,可能导致报错,请检查;';
        RETURN;
    END;

    SET @sql += ISNULL(@InnerSelect, '') + ' FROM ' + @FromSql;


    -----------------------------------------------------
    -- 按照是否需要的表格拼装对应的表格

    -- 时间维表一定需要 放在可能会取到时间的表之后 
    IF (CHARINDEX('Dim7', @SiftValue) <> 0)
        SET @sql += ' INNER JOIN #time t on ' + @TimeName + ' >= t.beginDate and ' + @TimeName + ' <= t.endDate';

    -- 临时存储拼接的SQL语句
    DECLARE @sql1 VARCHAR(MAX) = '';

    -- 将INNER JOIN 维度临时表段拼接起来
    SET @sql1 =
    (
        SELECT ' INNER JOIN #' + DimName + ' AS ' + DimName + ' on '
               +
            -- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
            CASE
                WHEN isrange = 1 THEN
                    DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
                -- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
                ELSE
                    DimName + '.ID = ' + DimYsql
            END
        FROM #Dims
        WHERE Isneed <> 'ND'
        FOR XML PATH('')
    );

    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @sql1 = REPLACE(REPLACE(@sql1, '&lt;', '<'), '&gt;', '>');

    -- 拼接出来的实例：' INNER JOIN #Temp8N AS temp8 on temp8.BeginValue <= data.Temp8 AND temp8.EndValue > data.Temp8'

    SET @sql += ISNULL(@sql1, '');

    SET @sql += '
  WHERE ' + @Ycolumn + ' IS NOT NULL 
  ) x
  GROUP BY ' + @Dims;

    -- 排序段
    SET @sql += ' Order By X排序,G排序;
  ' ;
   SET @sql +=(SELECT ' if((select count(*) from #'+DimName+')=0) BEGIN INSERT INTO dbo.ErrorRecord (SpName,ErrorInfo,ExecSql,Createdate) VALUES (''Sp_Analysister_Stad'',''表#'+DimName+'数据为空,可能造成报错请检查'',''EXEC Sp_Analysister_Stad' +@condition+''','''+CONVERT(nvarchar(20),GETDATE(),120)+''') END ' FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH(''))
    -- 注销临时表
    SET @sql += ISNULL(
                (
                    SELECT 'DROP TABLE #' + DimName + ';'
                    FROM #Dims
                    WHERE Isneed <> 'ND'
                    FOR XML PATH('')
                ),
                ''
                      );

    --
    --select 1;

    --return;
    select @sql;

    PRINT 'Drop Table #time';

    EXEC (@sql);

    ------ 11.21 增加 连接到自动计算记录参数
    DECLARE @TrendSql VARCHAR(MAX) = '';
    DECLARE @XView VARCHAR(MAX) = '';
    DECLARE @GView VARCHAR(MAX) = '';

    SELECT @XView = 'VW_' + DimName + '_Part'
    FROM #Dims
    WHERE Isneed = 'X';
    SELECT @GView = 'VW_' + DimName + '_Part'
    FROM #Dims
    WHERE Isneed = 'G';

    SET @TrendSql += ' DECLARE @Data T_TrandAna_DataSource;';

    SET @TrendSql += '
  Insert into @Data select OrderX,OrderG,num FROM #Result_B
  ORDER BY OrderX,OrderG ;';

    SET @TrendSql += '
	EXEC [Sp_Analysister_TrendAna] 
	 @condition = ''' + @condition + '''
	,@OtherCond = ''' + @OtherCond + '''
	,@dataSource = @Data
	,@AnaName = ''' + @SpName + '''
   ';




    IF (@Type = '仅计算')
    BEGIN
        EXEC (@TrendSql);
        RETURN;
    END;
    ---- 增加END


    ------------------------------------------------------------ 各比较类型数据计算 ----------------------------------------------------------------------                  

    -- 结果临时表，写在外面方便后面调用            

    CREATE TABLE #Result_Final
    (
        OrderX INT,
        DimX VARCHAR(MAX),
        DimG VARCHAR(MAX),
        OrderG INT,
        num DECIMAL(18, 4)
    );

    CREATE TABLE #Result_All
    (
        DimX VARCHAR(MAX),
        OrderX INT,
        DimG VARCHAR(MAX),
        OrderG INT,
        num DECIMAL(18, 4)
    );

    INSERT INTO #Result_Final
    (
        DimX,
        OrderX,
        DimG,
        OrderG,
        num
    )
    SELECT *
    FROM #Result_B;



    DECLARE @YMax DECIMAL(18, 2),
            @YMin DECIMAL(18, 2);

    SELECT @YMax = MAX(num),
           @YMin = MIN(num)
    FROM #Result_B;

    IF (@YMax = @YMin)
        SELECT @YMin = @YMin - 2,
               @YMax = @YMax + 3;

    ------------------------------------------------------------------------------------- 图形输出格式计算 -------------------------------------------------------------------                

    DECLARE @Rsql VARCHAR(MAX);
    DECLARE @FinalColumn NVARCHAR(MAX);

    CREATE TABLE #Result_C
    (
        OrderX INT,
        DimX VARCHAR(50),
        DimG VARCHAR(50),
        num VARCHAR(50)
    );
    CREATE TABLE #Result_D
    (
        OrderX INT,
        DimX VARCHAR(50),
        DimG VARCHAR(50),
        num VARCHAR(50)
    );
    CREATE TABLE #Result_F
    (
        OrderX INT,
        DimX VARCHAR(50),
        DimG VARCHAR(50),
        num VARCHAR(50)
    );

    -- 为输出时不带OrderG这一列，要不前端不识别这一列 现在去掉是因为分组在输出时也需要排序，所以先排序然后再去掉这一列输出            
    -- IF (@ChatType IN ('pie','Pie2D','Pie3D'))            
    -- BEGIN            
    --ALTER TABLE #Result_Final DROP COLUMN OrderG            

    -- END

    -- 表 拼接标题用变量            
    DECLARE @title TABLE (cName NVARCHAR(100));
    DECLARE @titleSql VARCHAR(MAX);

    -- 行转列输出数据               

    IF
    (
        SELECT COUNT(1) FROM #Result_Final
    ) > 0
    BEGIN
        IF (@ChatType IN ( 'pie', 'Pie2D', 'Pie3D' ))
        BEGIN
            -- 如果是饼图不需要行转列直接输出            
            SET @Rsql = 'SELECT * into #RRR FROM #Result_Final';

        END;
        ELSE
        BEGIN
            -- 把结果集里的分组数据重新排序            
            SET @Rsql =
            (
                SELECT ',[' + y.DimG + ']'
                FROM
                (SELECT DISTINCT DimG, MIN(OrderG) OrderG FROM #Result_Final GROUP BY DimG) AS y
                ORDER BY y.OrderG
                FOR XML PATH('')
            );
            SET @Rsql = RIGHT(@Rsql, LEN(@Rsql) - 1);


            ALTER TABLE #Result_Final DROP COLUMN OrderG;
            SET @FinalColumn = @Rsql;
            SET @Rsql = 'SELECT * into #RRR FROM #Result_Final PIVOT ( max(num) FOR DimG IN ( ' + @Rsql + ' ))a ;';

        END;

        EXEC (@Rsql);

        IF (@Type = '图')
        BEGIN

            IF (@ChatType IN ( 'pie', 'Pie2D', 'Pie3D' ))
            BEGIN
                SET @Rsql = ' SELECT DimX,Num FROM #Result_Final';
            END;
            ELSE
            BEGIN

                SET @Rsql += ' SELECT DimX,' + @FinalColumn + ' FROM #RRR ORDER BY abs(OrderX)';

            END;

            PRINT @Rsql;
            EXEC (@Rsql);

        END;

        ELSE IF (@Type = '表')
        BEGIN

            IF (@ChatType IN ( 'pie', 'Pie2D', 'Pie3D' ))
            BEGIN

                INSERT @title
                SELECT DISTINCT
                    DimX
                FROM #Result_Final;

                SET @titleSql = 'Select ''OrderX'' AS OrderX,''DimX'' AS '' '' ,''num'' AS [' + @YName + '] ';
                SET @titleSql += ' UNION ALL SELECT ''varchar,500'',''varchar,500'',''varchar,500'' ';

            END;

            ELSE
            BEGIN

                INSERT @title
                SELECT DISTINCT
                    DimG
                FROM #Result_Final;

                SET @titleSql = 'Select ''OrderX'' AS ''OrderX'',''DimX'' AS '' ''' +
                                (
                                    SELECT ',''' + cName + ''' AS [' + cName + ']' FROM @title c FOR XML PATH('')
                                );
                SET @titleSql += ' UNION ALL SELECT ''varchar,500'',''varchar,500''' +
                                 (
                                     SELECT ',''varchar,500''' FROM @title c FOR XML PATH('')
                                 );

            END;

            PRINT @titleSql;
            EXEC (@titleSql);

            IF (@OrderFields IS NULL OR @OrderFields = '')
            BEGIN
                SET @OrderFields = 'OrderX';
            END;

            IF (CHARINDEX('asc', @OrderFields) > 0)
            BEGIN
                SET @OrderFields = '[' + LEFT(@OrderFields, LEN(@OrderFields) - 3) + '] asc';
            END;

            IF (CHARINDEX('desc', @OrderFields) > 0)
            BEGIN
                SET @OrderFields = '[' + LEFT(@OrderFields, LEN(@OrderFields) - 4) + '] desc';
            END;

            SET @Rsql += ' select * from #RRR ORDER BY ' + @OrderFields;
            PRINT 'Rsql: ' + @Rsql;
            EXEC (@Rsql);

        END;

    END;
    -- 没有数据的情况            
    ELSE
    BEGIN

        IF (@ChatType IN ( 'pie', 'Pie2D', 'Pie3D' ))
        BEGIN
            SELECT '' DimX,
                   '0';
        END;
        ELSE
        BEGIN
            SELECT '' AS DimX;
        END;

    END;

    --  图形标题拼接            

    IF (@Type = '图')
    BEGIN
        DECLARE @t VARCHAR(100);

        -- 按是否需要来拼接要出标题的 维度            
        SET @t = '#time';

        -- 如果用户没有定义标题 则拼接   
        DECLARE @Yma VARCHAR(MAX);
        DECLARE @Ymi VARCHAR(MAX);

        DECLARE @YTbl TABLE
        (
            Yma VARCHAR(MAX),
            Ymi VARCHAR(MAX)
        );

        INSERT INTO @YTbl
        EXEC [dbo].[Sp_Y_min_max] @maxY = @YMax, @minY = @YMin;
        SET @Yma =
        (
            SELECT Yma FROM @YTbl
        );
        SET @Ymi =
        (
            SELECT Ymi FROM @YTbl
        );
        ---------------------------------------------自建标题---------------------------------------------------
        IF (@Usertitle = '' OR @Usertitle IS NULL)
        BEGIN
            DECLARE @TimeStr NVARCHAR(100) = (
                                                 SELECT dbo.GetTimeName(beginDate, endDate) + ','
                                                 FROM #time
                                                 FOR XML PATH('')
                                             );
            SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1);
            IF ((SELECT COUNT(*) FROM #time) > 5)
            BEGIN
                SET @TimeStr =
                (
                    SELECT TOP 5
                        dbo.GetTimeName(beginDate, endDate) + ','
                    FROM #time
                    FOR XML PATH('')
                );
                SET @TimeStr = LEFT(@TimeStr, LEN(@TimeStr) - 1) + '...';
            END;
            SET @Usertitle = @TimeStr + ' [' + @XName + ']在[' + @DSName + ']上的[' + @YName + '-' + @CTOC + ']';
            IF ((SELECT COUNT(*) FROM #Dims WHERE Isneed = 'F') <> 0)
            BEGIN
                DECLARE @WDFilter NVARCHAR(500)
                    =   (
                            SELECT '[' + ChName + '],' FROM #Dims WHERE Isneed = 'F' FOR XML PATH('')
                        );
                SET @WDFilter = ',另筛选' + LEFT(@WDFilter, LEN(@WDFilter) - 1);
                SET @Usertitle += @WDFilter;
            END;
        END;
        -----------------------------------------------------------------------------------------------------------
        --EXEC Sp_Com_Get_ChtTitle_lc @TitleNames = @t,@EndStrTitle = @Usertitle, @YName = @YName,@XName = @XName,@DSName = @DsName,@Unit = '111',@OTOC=@CTOC ,@YMax = @Yma ,@YMin = @Ymi  

        EXEC Sp_Com_Get_ChtTitle_2Y @TitleNames = @t,
                                    @EndStrTitle = @Usertitle,
                                    @YName = @YName,
                                    @Unit = '',
                                    @XName = @XName,
                                    @YMax = @Yma,
                                    @YMin = @Ymi;
    END;

    -- 注销临时表
    DROP TABLE #Result_B;
    DROP TABLE #Result_Final;
    DROP TABLE #Result_All;
    DROP TABLE #Result_C;
    DROP TABLE #Result_D;
    DROP TABLE #Result_F;
    DROP TABLE #time;
    DROP TABLE #Dims;
    -- 插入日志记录
    INSERT INTO Tbl_Log_AnaUseLog
    (
        EmpID,
        EmpName,
        freshTime,
        spName,
        AnaName,
        siftvalue,
        OherParemeter
    )
    VALUES
    (   @EmpID,
        (
            SELECT EmpName FROM Tbl_Com_Employee WHERE EmpID = @EmpID
        ),
        GETDATE(),
        'Sp_Analysister_Stad',
        '' + @SpName + '多维分析器标准Sp',
        @condition,
        '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond=' + @OtherCond
    );

	IF(@ErrorRecord<>'')
	INSERT INTO dbo.ErrorRecord (   SpName ,
	                                ErrorInfo ,
	                                ExecSql,Createdate
	                            )
	VALUES (   'Sp_Analysister_Stad' , -- SpName - nvarchar(50)
	           @ErrorRecord , -- ErrorInto - nvarchar(1000)
	           @condition ,GETDATE()  -- ExecSql - nvarchar(1000)
	       )
END;
go

