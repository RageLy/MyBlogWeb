
-- =============================================
-- Author:		<clp>
-- alter date: <2013-07-23>
-- Description:	<根据维度名称在字符串中获取相应的维度头>
-- =============================================
CREATE function [dbo].[GetDimHead](
@SiftValue   varchar(Max),   --待分拆的字符串
@DimIndex int     --第几个dim
)returns varchar(max)
as
begin
   declare @result varchar(max)
   if(@SiftValue='')
      set @result='' 
    
   declare @temp table
   (
     ID int identity(1,1)
    ,String varchar(max)
   )  
 
     
   if(charindex('%',@SiftValue)<0)
      set @result = @SiftValue
   else
   Begin
       insert into @temp
       select String from dbo.Split(@SiftValue,'%')
       
       select @result=String from @temp
       where ID=@DimIndex

   End
   set @result = SUBSTRING(@result,1,CHARINDEX(':',@result)-1)
   return @result

end
go

