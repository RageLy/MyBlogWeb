-- =============================================  
-- Author:  <邓峰>  
-- Create date: <2012-07-13>  
-- Description: <个人密码修改>  
  
-- Author:  <张青青>  
-- Create date: <2013-03-25>  
-- Description: <存储过程调整>  
-- =============================================  
CREATE procedure [dbo].[sp_grp_GetUserLoad_web]  
 @UserID varchar(500)=''   
 as   
 Begin   
set nocount on  
  
   
  select   
     'UserName' [用户名],  
     'UserAccount' [用户账号]  
     union all  
     select  
     'varchar,200'[用户名],  
     'varchar,50'[用户账号]  
   union all  
   select  
   cast(Tbl_Sys_User.UserName as varchar(50))[用户名],  
   cast(Tbl_Sys_User.UserAccount as varchar(50))[用户账号]     
   from dbo.Tbl_Sys_User where UserID=@UserID    
  
   end  
  
  
  
  
--select * from Tbl_Sys_User  
go

