      
-- =============================================        
-- Author:  <曹乐平>        
-- alter date: <2013-10-22>        
-- Description: <根据员工ID返回能查询的员工范围>        
-- =============================================        
CREATE function [dbo].[GetEmpQueryRange](        
 @EmpID int    --数据分隔符        
)returns @Result table(string varchar(max))        
as        
begin        
 declare  @QueryRange nvarchar(10)        
 IF(@EmpID = NULL)  
 BEGIN  
 SET @QueryRange = 99  
 END  
   
 set @QueryRange =         
 (SELECT top 1 CASE WHEN a.EmpName='admin'  THEN 99 else c.QueryRange END      
  FROM Tbl_Com_Employee as a        
  left join Tbl_Sys_UserRoleRelation as b on a.UserID = b.UserID        
  left join Tbl_Sys_Role as c on b.RoleID = c.RoleID where  a.EmpID = @EmpID      
 )        
 if(@QueryRange is null or @QueryRange = 0)        
 begin        
  insert into @Result values (@EmpID)        
 end        
 else        
 begin        
  insert into @Result        
  select EmpID from Tbl_Com_Employee        
  union all      
  select 0       
 end        
 return        
end
go

