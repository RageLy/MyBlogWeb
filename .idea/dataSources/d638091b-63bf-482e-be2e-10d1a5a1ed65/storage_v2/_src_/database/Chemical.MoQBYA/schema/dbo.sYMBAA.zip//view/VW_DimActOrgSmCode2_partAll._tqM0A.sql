
CREATE View VW_DimActOrgSmCode2_partAll
AS
SELECT  Id AS VWID ,Id ,Name
FROM    VW_DimActOrgSmCode2_part
WHERE   istrue = 0
UNION ALL
SELECT -1,notall.Id,(SELECT Name FROM VW_DimActOrgSmCode2_part WHERE istrue = 1 )  FROM
(SELECT  Id AS VWID ,Id ,Name
FROM    VW_DimActOrgSmCode2_part
WHERE   istrue = 0) notall
go

