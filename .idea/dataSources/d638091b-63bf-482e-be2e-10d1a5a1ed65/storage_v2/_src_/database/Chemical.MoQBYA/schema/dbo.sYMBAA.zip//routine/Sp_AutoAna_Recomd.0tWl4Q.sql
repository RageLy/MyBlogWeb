




-- =============================================
-- Author:		 hjl
-- Create date:  2017.3.7
-- Description:	 算法推荐表
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AutoAna_Recomd]
	@SpName VARCHAR(50) = 'SinCapsule'
	,@Dims VARCHAR(max) = 'DimSinOutValue:,DimOilSeries:,DimSinTemp8:倍数2,DimSinTemp25:倍数2,DimSinTemp41:,DimOilViscosity:倍数5,DimDDLps:倍数5'
	,@XDim VARCHAR(50) = 'DimSinTemp41'
	,@YDim VARCHAR(50) = 'DimSinOutValue'
	,@NameTag VARCHAR(50) = 'hjl'
	,@TopN DECIMAL(18,2) = 2 -- 小于1 则是前百分之多少  大于等于1则是前多少个
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

	-- 所有的维度表
    CREATE TABLE #DimsPearSen
    (
		Dim varchar(50)
		,DType varchar(20)
		,isrange INT
		,ViewName varchar(200)
		,DimYsql varchar(200)
		,DimValue varchar(200)
		,DataCount INT  -- 该维度存在数据的条数
    );
    
    -- 分解维度插入零时表
    INSERT INTO #DimsPearSen
    SELECT SUBSTRING(string,1,CHARINDEX(':',string) - 1)
    ,CASE WHEN  CHARINDEX( SUBSTRING(string,1,CHARINDEX(':',string) - 1),@XDim) <> 0 THEN 'X'  -- 变量dim
	      WHEN  SUBSTRING(string,1,CHARINDEX(':',string) - 1) = @YDim THEN 'Y'  -- 目标dim
		  ELSE 'F' END   -- 条件Dim
    ,ta.IsRange
    ,ta.ViewName
    ,ta.AtYSql
    ,SUBSTRING(string,CHARINDEX(':',string) + 1,Len(string))
    ,NUll
    FROM dbo.Split(@Dims,',') s
    INNER JOIN dbo.Tbl_AnsCom_DIimToTable ta ON SUBSTRING(string,1,CHARINDEX(':',string) - 1) = ta.DimNum
    
    --SELECT * FROM #DimsPearSen;

    
    -- 目标维度在数据源的
    DECLARE @Ysql VARCHAR(500);
    SELECT @Ysql = DimYsql FROM #DimsPearSen WHERE Dim = @YDim;
    
    -- 数据源sql段
    DECLARE @TName VARCHAR(500);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
	
	--select @TName
	
    -- 计算所有条件 Dim 的数据量
    DECLARE @CreateT VARCHAR(max) = '';
    
    SET @CreateT += ( SELECT 'CREATE TABLE #' +  Dim + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #DimsPearSen WHERE DType = 'F' or DType = 'X' FOR XML PATH('') );
    
    -- 根据维度值取维度刻度
	DECLARE @InsertT VARCHAR(max) = '';

	SET @InsertT +=
	   ( SELECT 'insert into #' + Dim + 
		CASE WHEN isrange = 0 THEN '(VWID,ID,Name) select distinct ID,ID,Name FROM vw_'
		     WHEN isrange = 1 THEN '(VWID,ID,Name,beginvalue,endvalue) select distinct ID,ID,Name,beginvalue,endvalue FROM vw_'
		     END
		 + ViewName + '_Part where ' + 
				CASE WHEN ISNULL(DimValue,'') = '' THEN 'istrue = 0;'
						  ELSE '[选项集合类型] = ''' + DimValue + ''';' END
		FROM #DimsPearSen WHERE DType = 'F' or DType = 'X' FOR XML PATH('') )

    --select @InsertT;
    -- 拼接计算列

    -- join段
    DECLARE @SqlJoin VARCHAR(max);
    SET @SqlJoin = ( SELECT ' LEFT JOIN #' +  Dim + ' AS ' + Dim + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN Dim + '.BeginValue <= ' + DimYsql + ' AND ' + Dim + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE Dim + '.ID = ' + DimYsql END
		FROM #DimsPearSen WHERE DType = 'F' or DType = 'X' FOR XML PATH(''));
	
    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @SqlJoin = REPLACE(REPLACE(@SqlJoin,'&lt;','<'),'&gt;','>') ;
	
	--SELECT @SqlJoin
	---------------------------------- 拼接SiftValue段 ----------------------------------------------------
    DECLARE @SiftValue VARCHAR(max);
    SET @SiftValue = ( SELECT '''%' +  Dim + ':'' + CAST( isnull(' + Dim + ',0) AS Varchar(10)) + '
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	-- 去掉第一个 % 和最后一个 +
	SET @SiftValue = '''' + SUBSTRING(@SiftValue,3,LEN(@SiftValue) - 3);
	
	--SELECT @SiftValue;
	
	---------------------------------- 拼接 维度的各种拼接 段 ---------------------------------------------------
    DECLARE @GroupBy VARCHAR(max);
    SET @GroupBy = ( SELECT ',' + Dim + '.ID'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	-- 去掉第一个,
	SET @GroupBy = SUBSTRING(@GroupBy,2,LEN(@GroupBy));
	
	--SELECT @GroupBy;
	
	DECLARE @DimNamesSelect VARCHAR(max);
    SET @DimNamesSelect = ( SELECT ',' + Dim + '.ID AS ' + Dim
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	-- 去掉第一个,
	SET @DimNamesSelect = SUBSTRING(@DimNamesSelect,2,LEN(@DimNamesSelect));
	
	--SELECT @DimNamesSelect;
	
	DECLARE @DimNames VARCHAR(max);
    SET @DimNames = ( SELECT ',' + Dim
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	-- 去掉第一个,
	SET @DimNames = SUBSTRING(@DimNames,2,LEN(@DimNames));
	--SELECT @DimNames;
	
	---------------------------------- 设置目标表格 -----------------------------------------------------------
	DECLARE @ResultTable VARCHAR(max);
	SET @ResultTable = 'T_AutoAnaRecomd_' + REPLACE(ISNULL(@XDim,''),',','') + '_' +  ISNULL(@YDim,'') + '_' +ISNULL(@NameTag,'');
	--SELECT @ResultTable
	
	IF exists( SELECT 1 FROM sys.objects where name = @ResultTable )
		EXEC ( 'DROP TABLE ' + @ResultTable );
	
	-- 拼接 维度条件列名段
    DECLARE @CName VARCHAR(max);
    SET @CName = ( SELECT ',' + Dim + ' INT'
		FROM #DimsPearSen WHERE DType = 'F' FOR XML PATH(''));
	
	--SELECT @CName;
	
	DECLARE @XCollom VARCHAR(MAX) = REPLACE(@XDim,',',' INT,') + ' INT';
	
	EXEC ( 'CREATE TABLE ' + @ResultTable + '
	(	spName varchar(50),
		DataCount int,
		MaxY Decimal(18,6),
		MinY Decimal(18,6),
		AVGY Decimal(18,6),
		Siftvalue varchar(Max),
		PearSenR DECIMAL(18,6)
		'
		+ @CName + ',' + @XCollom + '
	)'
	 )
	
	-------------------------------------- 设置固定结果列 -----------------------------------------------------------
	-- 最外层结果
	DECLARE @ResultDataSql3 VARCHAR(max);
	SET @ResultDataSql3 = '''' + @SpName + ''',MAX(YN),MAX(Y),MIN(Y),AVG(TopYAvg),'
	
	--SELECT @ResultDataSql3;
	
	-- 中间层结果 主要取分区最大
	DECLARE @ResultDataSql2 VARCHAR(max);
	
	-- TopN 的判断条件
	DECLARE @TopNSql VARCHAR(MAX);
	IF( @TopN < 1 )
		-- 前百分之多少
		SET @TopNSql = 'CASE WHEN YN <= CASE WHEN Ycount * ' + CAST(@TopN AS VARCHAR(50)) + ' < 1 THEN 1 ELSE Ycount * ' + CAST(@TopN AS VARCHAR(50)) + ' END THEN Y END';
	ELSE -- 前几个
		SET @TopNSql = 'CASE WHEN YN <= ' + CAST(@TopN AS VARCHAR(50)) + ' THEN Y END';
	
	--SELECT @TopNSql;
	
	SET @ResultDataSql2 = 'YN
		,AVG(' + @TopNSql + ') OVER(PARTITION BY ' + @XDim + ',' + @DimNames + ') AS TopYAvg
		,Y
		,' + @XDim + ','+ @DimNames
	
	--SELECT @ResultDataSql2;
	
	DECLARE @ResultDataSql1 VARCHAR(max);
	DECLARE @XIDs VARCHAR(max);  -- X值的内容
	
	SET @XIDs = (SELECT ',' + string + '.ID AS ' + string FROM dbo.Split(@XDim,',') FOR XML PATH(''));
	
	--  1 YN 产值排序数   Ycount  产值总数据
	SET @ResultDataSql1 = @Ysql + ' AS Y
	,ROW_NUMBER() OVER(PARTITION BY ' + REPLACE(@XDim,',','.ID,') + '.ID,' + @GroupBy + ' ORDER BY ' + @Ysql + ' DESC) AS YN,
	COUNT(1) OVER(PARTITION BY ' + REPLACE(@XDim,',','.ID,') + '.ID,' + @GroupBy + ') AS Ycount
	' + @XIDs + ',' + @DimNamesSelect ;
	
	--SELECT @ResultDataSql1;
	--------------------------------------  执行语句 ------------------------------------------------------------------------

	 EXEC (@CreateT + @InsertT + 'INSERT INTO ' + @ResultTable + '
	 SELECT ' + @ResultDataSql3 + @SiftValue + ',NULL,' + @DimNames + ','+ @XDim + '
		FROM 
		( SELECT ' + @ResultDataSql2 + ' 
			FROM 
			( SELECT ' + @ResultDataSql1 + ' 
				FROM ' + @TName + @SqlJoin + '
			) x
		) xx
	  Group by ' + @XDim + ',' + @DimNames);
	
	PRINT @InsertT;
	PRINT 'Create Table: ' + @ResultTable
	
	
	-------------------------------------- 更新R ------------------------------
	
	DECLARE @RTable VARCHAR(max);
	SET @RTable = 'T_AutoAnaCountSift_' + ISNULL(@XDim,'') + '_' +  ISNULL(@YDim,'') + '_' +ISNULL(@NameTag,'');
	
	IF exists( SELECT 1 FROM sys.objects where name = @RTable )
	BEGIN
		EXEC ( ' UPDATE a set PearSenR = b.PearSenR 
		 FROM ' + @ResultTable + ' AS a INNER JOIN ' + @RTable + ' AS B on a.Siftvalue = b.Siftvalue' );
	END

END
go

