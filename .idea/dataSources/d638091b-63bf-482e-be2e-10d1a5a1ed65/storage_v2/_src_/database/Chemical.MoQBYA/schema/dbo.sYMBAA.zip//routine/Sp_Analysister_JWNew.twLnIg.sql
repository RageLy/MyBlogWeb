





-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 降维sp
-- =============================================                 


CREATE PROCEDURE [dbo].[Sp_Analysister_JWNew]
    @condition VARCHAR(MAX) = 'DimDouKzWd:-1165|-2380|237%DimDouYX:-1%DimDouLW:-1%DimDouFu:-1%DimDouTemp41:-1%DimDouSpeed500:-1%DimDouSpeed400:-1%DimDouTemp8:-1%DimDouTemp25:-1%DimDDLps:-1%DimOilViscosity:-1%DimYXLJ05:-1%DimYXLJ09:-1' ,
    @OtherCond VARCHAR(MAX) = '%无选项%无选项%L白%列表%相关性%undefined%undefined' ,
    @Type VARCHAR(10) = '图' , -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
    @OrderFields VARCHAR(50) = '' ,
    @SpName VARCHAR(50) = 'DouCapsule' ,
    @TB INT = 2 ,
    @EmpID INT = 1 ,
                              -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '10' ,
    @XValue VARCHAR(50) = '' ,
    @DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
    BEGIN

        ---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

        SET NOCOUNT ON;

        DECLARE @SiftValue VARCHAR(MAX);
        SET @SiftValue = REPLACE(@condition, '|', ',');

        DECLARE @Usertitle VARCHAR(50) = ''; -- 标题            
        DECLARE @XName VARCHAR(50) = ''; -- 横轴维度名称                
        DECLARE @DSName VARCHAR(50) = ''; -- 分组维度名称                
        DECLARE @YName VARCHAR(50) = ''; -- @OtherCond  传入的Y轴名称                
        DECLARE @ChatType VARCHAR(50) = ''; -- 图形名称                
        DECLARE @CTOC VARCHAR(50) = ''; -- @OtherCond 传入的比较方式                

        DECLARE @CompareType VARCHAR(50) = ''; -- 比较方式                  

        -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                

        DECLARE @OtherCondTbl TABLE
            (
                ID INT IDENTITY(1, 1) NOT NULL PRIMARY KEY ,
                String NVARCHAR(50)
            );

        INSERT INTO @OtherCondTbl
                    SELECT String
                    FROM   dbo.f_splitSTR(@OtherCond, '%');

        SET @Usertitle = (   SELECT String
                             FROM   @OtherCondTbl
                             WHERE  ID = 1
                         );
        SET @XName = '无选项'; --( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
        SET @DSName = (   SELECT String
                          FROM   @OtherCondTbl
                          WHERE  ID = 3
                      );
        SET @YName = (   SELECT String
                         FROM   @OtherCondTbl
                         WHERE  ID = 4
                     );
        SET @ChatType = (   SELECT String
                            FROM   @OtherCondTbl
                            WHERE  ID = 5
                        );
        SET @CTOC = (   SELECT String
                        FROM   @OtherCondTbl
                        WHERE  ID = 6
                    );

        --select * from @OtherCondTbl
        -- OtherCond解析完毕            
        -------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            

        ----------------------------------------------------------------- 步骤一 维度解析 --------------------------------------------------------------------------------                       


        -- 时间表 时间临时表必然需要
        CREATE TABLE #time
            (
                id VARCHAR(200) ,
                beginDate DATETIME ,
                endDate DATETIME ,
                beginDate_Lp DATETIME ,
                endDate_Lp DATETIME ,
                beginDate_Ly DATETIME ,
                endDate_Ly DATETIME
            );

        -- 如果有其它需要用 #时间表的必须在这里添加

        DECLARE @InnerSelect VARCHAR(500) = ''; -- 用于拼接@Sql中 Y轴的取表字段            
        DECLARE @XOrder VARCHAR(500); -- 用于拼接@Sql中 横轴的排序用字段 默认用 数字 1 作为排序            
        DECLARE @DsOrder VARCHAR(500); -- 用于拼接@Sql中 分组的排序用字段 默认用 数字 1 作为排序            
        DECLARE @CountType VARCHAR(100); -- 用于拼接@Sql中 的指标计算方式  count、sum、或者avg              
        DECLARE @NumSql VARCHAR(500); -- 用于拼接@Sql中 指标计算方式的Sql语句            
        DECLARE @sql VARCHAR(MAX) = ''; -- 最终执行提取与计算数据的 sql语句
        DECLARE @ErrorRecord NVARCHAR(MAX) = '';
        SET @XOrder = ',1 as X排序';
        SET @DsOrder = ',1 as G排序';

        -- 处理维度临时表
        CREATE TABLE #Dims
            (
                DimName VARCHAR(50) ,
                DimValues VARCHAR(MAX) ,
                ChName VARCHAR(50) ,
                Isneed VARCHAR(50) ,
                DimOrdersql VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                isrange VARCHAR(50)
            );

        EXEC [Sp_Com_GetdimensionTable] @SiftValue = @SiftValue ,
                                        @XName = @XName ,
                                        @DsName = @DSName;

        IF NOT EXISTS (   SELECT 1
                          FROM   #Dims
                          WHERE  ChName = @YName
                      )
            BEGIN
                INSERT INTO #Dims (   DimName ,
                                      DimValues ,
                                      ChName ,
                                      Isneed ,
                                      DimOrdersql ,
                                      DimYsql ,
                                      isrange
                                  )
                            SELECT DimNum ,
                                   '' ,
                                   Name_ch ,
                                   'ND' ,
                                   '' ,
                                   AtYSql ,
                                   isrange
                            FROM   dbo.Tbl_AnsCom_DIimToTable
                            WHERE  Name_ch = @YName
                                   AND CHARINDEX(',' + @SpName + ',', SpType) > 0;
            END;

        --AND CHARINDEX(',SinCapsule,',SpType) > 0

        --from 源表
        DECLARE @FromSql VARCHAR(MAX) = (   SELECT JoinTables
                                            FROM   Tbl_AnsCom_AnaSpConfig
                                            WHERE  SpName = @SpName
                                        );
        IF (   @FromSql IS NULL
               OR @FromSql = ''
           )
            BEGIN
                SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables
                                        FROM Tbl_AnsCom_AnaSpConfig
                                        WHERE SpName = ''' + @SpName
                                    + '''结果为空 ,可能导致报错,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JWNew' , -- SpName - nvarchar(50)
                           @ErrorRecord ,           -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JWNew @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@SpName''' + @SpName
                           + ''',@TB=''' + @TB + ''',@EmpID=''' + @EmpID
                           + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()                -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;

        -- 拼接创建维度临时表的语句
        SET @sql += ISNULL(
                        (   SELECT 'CREATE TABLE #' + DimName
                                   +
                                -- 非范围维度类型3列
                                CASE WHEN isrange = 0 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
                                     -- 范围维度类型5列
                                     WHEN isrange = 1 THEN
                                         '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'
                                END
                            FROM   #Dims
                            WHERE  Isneed <> 'ND'
                            FOR XML PATH('')
                        ) ,
                        ''
                          );
        DECLARE @NeedSiftvalue VARCHAR(MAX) = '';
        SET @NeedSiftvalue = ISNULL(
                                 (   SELECT '%' + DimName + ':' + DimValues
                                     FROM   #Dims
                                     WHERE  Isneed <> 'ND'
                                     FOR XML PATH('')
                                 ) ,
                                 ''
                                   );

        -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
        SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7', @SiftValue) <> 0 THEN
                                      'Dim7:'
                                      + dbo.GetDimValue(@SiftValue, 'Dim7')
                                      + @NeedSiftvalue
                                  ELSE
                                      SUBSTRING(
                                                   @NeedSiftvalue ,
                                                   2 ,
                                                   LEN(@NeedSiftvalue)
                                               )
                             END;


        -- 解析维度
        SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = '''
                    + @NeedSiftvalue + ''', @EmpID = '
                    + CAST(@EmpID AS VARCHAR(50)) + ';';
        PRINT @sql;
        -------------------------- 维度解析段



        -------------------------- 创建 where INNERJOIN 筛选出数据维度主题
        DECLARE @whereWD VARCHAR(MAX) = ''; ---提取控制维度名

        DECLARE @TimeName VARCHAR(50);
        SET @TimeName = (   SELECT TimeName
                            FROM   Tbl_AnsCom_AnaSpConfig
                            WHERE  SpName = @SpName
                        );
        IF (   @TimeName = NULL
               OR @TimeName IS NULL
           )
            BEGIN
                SET @ErrorRecord += '查询 SELECT TimeName FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = '''
                                    + @SpName + '''为空,请检查;';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JWNew' , -- SpName - nvarchar(50)
                           @ErrorRecord ,           -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JWNew @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@SpName''' + @SpName
                           + ''',@TB=''' + @TB + ''',@EmpID=''' + @EmpID
                           + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()                -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;
        IF ( CHARINDEX('Dim7', @SiftValue) <> 0 )
            SET @whereWD += ' INNER JOIN #time t on ' + @TimeName
                            + ' >= t.beginDate and ' + @TimeName
                            + ' <= t.endDate';



        SET @whereWD += ISNULL(
                            (   SELECT ' inner JOIN #' + DimName + ' AS '
                                       + DimName + ' on '
                                       + CASE WHEN isrange = 1 THEN
                                                  DimName + '.BeginValue <= '
                                                  + DimYsql + ' AND '
                                                  + DimName + '.EndValue > '
                                                  + DimYsql
                                              ELSE
                                                  DimName + '.ID = '
                                                  + DimYsql
                                         END
                                FROM   #Dims
                                WHERE  Isneed <> 'ND'
                                       AND DimYsql <> ''
                                FOR XML PATH('')
                            ) ,
                            ''
                              );

        SET @whereWD = REPLACE(REPLACE(@whereWD, '&lt;', '<'), '&gt;', '>');


        ------------------------- 创建 控制维度筛选项维度
        DECLARE @KZWD VARCHAR(MAX) = '';
        DECLARE @KZWDName VARCHAR(MAX) = '';
        DECLARE @KZWDViewName VARCHAR(MAX) = '';
        SET @KZWDName = (   SELECT DimName
                            FROM   #Dims
                            WHERE  DimYsql = ''
                        );
        SET @KZWD = (   SELECT DimValues
                        FROM   #Dims
                        WHERE  DimYsql = ''
                               AND DimName = @KZWDName
                    );
        SET @KZWDViewName = (   SELECT ISNULL(ViewName, '')
                                FROM   dbo.Tbl_AnsCom_DIimToTable
                                WHERE  DimNum = @KZWDName
                            );
        IF (   @KZWDViewName IS NULL
               OR @KZWDViewName = ''
           )
            BEGIN
                SET @ErrorRecord += '查询 SELECT    ISNULL(ViewName, '')
                              FROM      dbo.Tbl_AnsCom_DIimToTable
                              WHERE     DimNum = ''' + @KZWDName
                                    + '''没结果，请检查！';
                INSERT INTO dbo.ErrorRecord (   SpName ,
                                                ErrorInfo ,
                                                ExecSql ,
                                                Createdate
                                            )
                VALUES (   'Sp_Analysister_JWNew' , -- SpName - nvarchar(50)
                           @ErrorRecord ,           -- ErrorInto - nvarchar(1000)
                           'Exec Sp_Analysister_JWNew @condition='''
                           + @condition + ''',@OtherCond=''' + @OtherCond
                           + ''',@Type=''' + @Type + ''',@OrderFields='''
                           + @OrderFields + ''',@SpName''' + @SpName
                           + ''',@TB=''' + @TB + ''',@EmpID=''' + @EmpID
                           + ''',@PageIndex=''' + @PageIndex
                           + ''',@PageSize=''' + @PageSize + ''',@XValue,='''
                           + @XValue + ''',@DSValue=''' + @DSValue + '''',
                           GETDATE()                -- ExecSql - nvarchar(1000)
                       );
                RETURN;
            END;

        --拼select 列名（主表ID+控制维度列）
        CREATE TABLE #DimsTb
            (
                DimName VARCHAR(50) ,
                viewName VARCHAR(50) ,
                ChName VARCHAR(50) ,
                DimYsql VARCHAR(50) ,
                Stp VARCHAR(50) ,
                NumDecimal DECIMAL(18, 6)
            );



        --insert into #DimsTb (DimName,viewName,ChName,DimYsql,Stp)
        --select a.DimName,b.viewName,a.ChName,a.DimYsql,'1' from #Dims a
        --INNER JOIN dbo.Tbl_AnsCom_DIimToTable b ON a.DimName = b.DimNum
        --where Isneed <> 'ND' and DimYsql <> '';


        DECLARE @KZWDDimsTb VARCHAR(MAX) = '';

        SET @KZWDDimsTb = ( SELECT '
	 insert into #DimsTb (DimName,viewName,ChName,DimYsql,Stp,NumDecimal)
	 select  dimname,tad.ViewName,Name,AtYSql,istrue,NumDecimal
	 from VW_' + @KZWDViewName + '_Part AS kz 
	 inner join Tbl_AnsCom_DIimToTable tad
	 on kz.dimname=tad.dimnum
	  where kz.id in (' + @KZWD + ')
	  '                   );

        EXEC ( @KZWDDimsTb );
        --SELECT * FROM #DimsTb;
        --拼接控制维度与where维度列


        --DECLARE @KZNamewh VARCHAR(MAX) = '';
        --set @KZNamewh=(select case when Stp<>1 then ','+DimName+'part.name' +' as '+DimName end
        --from #DimsTb FOR XML PATH(''))

        --SELECT @KZNamewh;


        -- DECLARE @InnerSelect VARCHAR(MAX) = '';
        SET @InnerSelect = (   SELECT CASE WHEN Stp <> 1 THEN
                                               ',' + DimYsql + ' as '
                                               + REPLACE(DimYsql, '.', '')
                                      END
                               FROM   #DimsTb
                               FOR XML PATH('')
                           );
        --SET @InnerSelect = SUBSTRING(@InnerSelect,2,LEN(@InnerSelect) )
        PRINT '@InnerSelect: ' + @InnerSelect;
        SET @InnerSelect = ISNULL(@InnerSelect, '');

        --Y 列
        DECLARE @YSQL VARCHAR(100);
        DECLARE @Ycolumn VARCHAR(50) = ISNULL((   SELECT DimYsql
                                                  FROM   #Dims
                                                  WHERE  ChName = @YName
                                              ) ,
                                              ''
                                             ); -- Y轴在本表上面的列名
        SET @YSQL = ',' + @Ycolumn + ' AS ' + REPLACE(@Ycolumn, '.', '');



        --RETURN;
        --set @InnerSelect=(select 'select '+@SpName+'.ID'+@KZNamewh+@YSQL+' from ' )

        ------------------------------------------------------------- 维度及取表 sql 语句拼接 --------------------------------------------------------------------------------             

        --取Y轴列
        DECLARE @Ycolumnjs VARCHAR(50) = ISNULL(
                                             (   SELECT REPLACE(
                                                                   DimYsql ,
                                                                   '.' ,
                                                                   ''
                                                               )
                                                 FROM   #Dims
                                                 WHERE  ChName = @YName
                                             ) ,
                                             ''
                                               );

        --设置Y轴比较分档
        --极差分档
        DECLARE @jd DECIMAL(18, 4);
        DECLARE @jcmin DECIMAL(18, 4);
        DECLARE @jcmax DECIMAL(18, 4);
        DECLARE @jcn DECIMAL(18, 4);
        DECLARE @bzcmin DECIMAL(18, 4);
        DECLARE @bzcmax DECIMAL(18, 4);
        DECLARE @bzcn DECIMAL(18, 4);

        SET @jd = (   SELECT NumDecimal
                      FROM   #Dims dp
                             INNER JOIN Tbl_AnsCom_DIimToTable tnd ON dp.DimName = tnd.DimNum
                                                                      AND dp.ChName = @YName
                  );

        SET @jcmin = 0;
        SET @jcmax = ( 5 * 10 * @jd );
        SET @jcn = 11.0000;
        SET @bzcmin = 0;
        SET @bzcmax = @jcmax;
        SET @bzcn = 11.0000;

        --主副因素验证
        --维度控制区间
        DECLARE @CKON VARCHAR(MAX);
        SET @CKON = (   SELECT ' AND ABS(a.' + Dims + ' - ' + 'b.' + Dims
                               + ') <= ' + CAST(bs AS VARCHAR(50))
                        FROM   (   SELECT REPLACE(DimYsql, '.', '') Dims ,
                                          CASE WHEN Stp = 0 THEN NumDecimal
                                               WHEN Stp = 2 THEN 2 * NumDecimal
                                               WHEN Stp = 3 THEN 5 * NumDecimal
                                               WHEN Stp = 4 THEN
                                                   10 * NumDecimal
                                          END AS bs
                                   FROM   #DimsTb dp
                                   --inner join Tbl_AnsCom_DIimToTable tnd on dp.DimName=tnd.DimNum
                                   WHERE  Stp <> 1
                               ) aa
                        FOR XML PATH('')
                    );

        SET @CKON = ISNULL(REPLACE(@CKON, '&lt;', '<'), '');

        DECLARE @CK VARCHAR(MAX);
        DECLARE @CKYsql VARCHAR(MAX);
        SET @CKYsql = ISNULL((   SELECT DimYsql
                                 FROM   #Dims
                                 WHERE  ChName = @YName
                             ) ,
                             ''
                            );



        --数据源不能为null
        DECLARE @notnull VARCHAR(MAX);
        SET @notnull = ISNULL((   SELECT ' and ' + DimYsql + ' is not null'
                                  FROM   #DimsTb
                                  WHERE  Stp <> 1
                                  FOR XML PATH('')
                              ) ,
                              ''
                             );



        DECLARE @YNumDecimal VARCHAR(20) = (   SELECT CAST(NumDecimal AS VARCHAR(10))
                                               FROM   #Dims a
                                                      INNER JOIN dbo.Tbl_AnsCom_DIimToTable b ON a.ChName = @YName
                                                                                                 AND a.DimName = b.DimNum
                                           );


        CREATE TABLE #T
            (
                id INT ,
                name VARCHAR(50) ,
                n INT ,
                dbcount INT ,
                lv DECIMAL(18, 2)
            );


        SET @CK = '
			 ;WITH CTEs AS
	            (
		        SELECT '
                  + SUBSTRING(@TimeName, 1, CHARINDEX('.', @TimeName) - 1)
                  + '.ID AS ID ' + @InnerSelect + @YSQL + '  FROM  '
                  + @FromSql + @whereWD + ' WHERE ' + @CKYsql
                  + ' IS NOT null ' + @notnull
                  + ' 
	            )
	             INSERT INTO #T
					SELECT Row_NumBer() OVER(Order by be),Name,n,Sum(n) OVER(),CAST ( n / cast( SUM(n) OVER() AS DECIMAL(18,2) ) * 100 AS DECIMAL(18,2)) FROM
					(
						SELECT be,CASE WHEN be < 0 THEN ''0'' ELSE ''('' + CAST(be AS VARCHAR(10)) + '','' + CAST(ed AS VARCHAR(10)) + '']'' END AS Name,COUNT(*) AS n FROM 
						(
							SELECT ABS(a.' + REPLACE(@CKYsql, '.', '')
                  + ' - ' + 'b.' + REPLACE(@CKYsql, '.', '')
                  + ') AS cha,be,ed FROM CTEs a
							INNER JOIN CTEs b
							ON a.ID > b.ID ' + @CKON
                  + '
							INNER JOIN ( SELECT ( id - 2 ) * ' + @YNumDecimal
                  + ' AS Be,(id - 1) * ' + @YNumDecimal
                  + ' AS Ed FROM dbo.Tbl_Base_Num WHERE id <= 20 ) x 
							ON ABS(a.' + REPLACE(@CKYsql, '.', '') + ' - '
                  + 'b.' + REPLACE(@CKYsql, '.', '')
                  + ') > x.Be 
							AND ABS(a.' + REPLACE(@CKYsql, '.', '') + ' - '
                  + 'b.' + REPLACE(@CKYsql, '.', '')
                  + ') <= x.Ed
						) xx GROUP BY be,ed
					) xxx
	            ';

        PRINT ( @sql + @CK );

        --PRINT(@CK );
        EXEC ( @sql + @CK );

        SELECT * ,
               (   SELECT SUM(c2.lv)
                   FROM   #T c2
                   WHERE  c2.id <= c1.id
               ) AS ljlv
        FROM   #T c1;
        INSERT INTO Tbl_Log_AnaUseLog (   EmpID ,
                                          EmpName ,
                                          freshTime ,
                                          spName ,
                                          AnaName ,
                                          siftvalue ,
                                          OherParemeter
                                      )
        VALUES ( @EmpID ,
                 (   SELECT EmpName
                     FROM   Tbl_Com_Employee
                     WHERE  EmpID = @EmpID
                 ) ,
                 GETDATE(),
                 'Sp_Analysister_JWNew' ,
                 '' + @SpName + '维度控制性',
                 @condition ,
                 '@EmpID=' + CAST(@EmpID AS VARCHAR(10)) + ',@OtherCond='
                 + @OtherCond
               );
    END;
go

