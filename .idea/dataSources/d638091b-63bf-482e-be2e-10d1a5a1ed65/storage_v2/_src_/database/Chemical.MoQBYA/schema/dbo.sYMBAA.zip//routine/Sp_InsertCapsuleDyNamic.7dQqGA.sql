
-- =============================================                          
-- Author: hmw                                          
-- Create Date: 2017年6月13日                                                
-- Descript: 从Excel插入动态胶囊数据
-- =============================================                 
-- exec [Sp_InsertCapsuleDyNamic]
CREATE PROCEDURE [dbo].[Sp_InsertCapsuleDyNamic]
    @ReturnInsertValue INT = 0 OUTPUT ,
    @ReturnupdateValue INT = 0 OUTPUT
AS
    BEGIN

        DECLARE @ReturnValue INT = 0;
        --先处理数据重复问题--
        DELETE FROM dbo.TempTb_CapsuleDynamic
        WHERE ID NOT IN (   SELECT   MAX(ID) ID
                            FROM     TempTb_CapsuleDynamic
                            GROUP BY 涂布编号
                        );
        SET @ReturnValue = (   SELECT COUNT(*)
                               FROM   TempTb_CapsuleDynamic
                           );

        PRINT '开始插入Tbl_Base_BG0026数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_BG0026 ( BG0026 )
                    SELECT DISTINCT BG0026检测时间
                    FROM   dbo.TempTb_CapsuleDynamic
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BG0026
                                          WHERE  BG0026检测时间 = BG0026
                                      )
                           AND BG0026检测时间 IS NOT NULL;
        PRINT '表Tbl_Base_BG0026数据插入完毕，继续下一步';

        PRINT '开始插入Tbl_Base_BG0009数据，继续下一步';
        INSERT INTO dbo.Tbl_Base_BC0009 ( BC0009 )
                    SELECT DISTINCT BC0009批号
                    FROM   dbo.TempTb_CapsuleDynamic
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Tbl_Base_BC0009
                                          WHERE  BC0009批号 = BC0009
                                      )
                           AND BC0009批号 IS NOT NULL;
        PRINT '表Tbl_Base_BG0009数据插入完毕，继续下一步';


        UPDATE dbo.Bs_CapsuleDynamic
        SET    Optdate = [动态日期] ,
               MachineNum = [机台] ,
               CapsuleWeight = 胶囊重量kg ,
               BG0026Use = 加入BG0026重量kg ,
               BC0009Use = BC0009量g10per ,
               BC0009 = BC0009.ID ,
               BG0026TestTime = BG0026.ID ,
               SetZHSpeed = [设置转速] ,
               DyNamicTime = [动态时间48h] ,
               SievingDate = 筛分日期 ,
               OutDate = [出库日期] ,
               CKDouCapPh = 出库胶囊PH值 ,
               CrossWeight = [毛重kg] ,
               NetWeight = [胶囊净重kg] ,
               AddWaterUse = [加入纯水量kg] ,
               BucketWeight = [桶重kg] ,
               DouCapsule1 = DouCapsule1.ID ,
               DouCapsule2 = DouCapsule2.ID ,
               DouCapsule3 = DouCapsule3.ID ,
               DouCapsule4 = DouCapsule4.ID ,
               DouCapsule5 = DouCapsule5.ID ,
               DouCapsule6 = DouCapsule6.ID ,
               DouCapsule7 = DouCapsule7.ID ,
               DouCapsule8 = DouCapsule8.ID ,
               DouCapsule9 = DouCapsule9.ID ,
               DouCapsule10 = DouCapsule10.ID ,
               DouCapsule11 = DouCapsule11.ID ,
               DouCapsule12 = DouCapsule12.ID ,
               DouCapsule13 = DouCapsule13.ID ,
               DouCapsule14 = DouCapsule14.ID ,
               DouCapsule15 = DouCapsule15.ID ,
               DouCapsule16 = DouCapsule16.ID ,
               DouCapsuleCode1 = DouCapsule1.Code ,
               DouCapsuleCode2 = DouCapsule2.Code ,
               DouCapsuleCode3 = DouCapsule3.Code ,
               DouCapsuleCode4 = DouCapsule4.Code ,
               DouCapsuleCode5 = DouCapsule5.Code ,
               DouCapsuleCode6 = DouCapsule6.Code ,
               DouCapsuleCode7 = DouCapsule7.Code ,
               DouCapsuleCode8 = DouCapsule8.Code ,
               DouCapsuleCode9 = DouCapsule9.Code ,
               DouCapsuleCode10 = DouCapsule10.Code ,
               DouCapsuleCode11 = DouCapsule11.Code ,
               DouCapsuleCode12 = DouCapsule12.Code ,
               DouCapsuleCode13 = DouCapsule13.Code ,
               DouCapsuleCode14 = DouCapsule14.Code ,
               DouCapsuleCode15 = DouCapsule15.Code ,
               DouCapsuleCode16 = DouCapsule16.Code ,
               BKAvg0minBe = [前0minL黑均值L] ,
               BKAvg2minBe = [前2minL黑均值] ,
               WAvg0minBe = [前0minL白均值L] ,
               WAvg2minBe = [前2minL白均值] ,
               DBDBe = [前对比度] ,
               LBKBe = [前黑deltaL] ,
               LWBe = [前白deltaL] ,
               WB2minBe = [前2min白B值] ,
               BKAvg0minAf = [后0minL黑均值L] ,
               BKAvg2minAf = [后2minL黑均值] ,
               WAvg0minAf = [后0minL白均值L] ,
               WAvg2minAf = [后2minL白均值] ,
               DBDAf = [后对比度] ,
               LBKAf = [后黑deltaL] ,
               LWAf = [后白deltaL] ,
               WB2minAf = [后2min白B值] ,
               PMYSPH = 配墨用水PH值 ,
               PMYSDDLS = 配墨用水电导率 ,
               updatetime = GETDATE()
        FROM   [dbo].TempTb_CapsuleDynamic
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule1 ON DouCapsule1.Code = TempTb_CapsuleDynamic.胶囊编号1
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule2 ON DouCapsule2.Code = TempTb_CapsuleDynamic.胶囊编号2
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule3 ON DouCapsule3.Code = TempTb_CapsuleDynamic.胶囊编号3
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule4 ON DouCapsule4.Code = TempTb_CapsuleDynamic.胶囊编号4
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule5 ON DouCapsule5.Code = TempTb_CapsuleDynamic.胶囊编号5
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule6 ON DouCapsule6.Code = TempTb_CapsuleDynamic.胶囊编号6
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule7 ON DouCapsule7.Code = TempTb_CapsuleDynamic.胶囊编号7
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule8 ON DouCapsule8.Code = TempTb_CapsuleDynamic.胶囊编号8
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule9 ON DouCapsule9.Code = TempTb_CapsuleDynamic.胶囊编号9
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule10 ON DouCapsule10.Code = TempTb_CapsuleDynamic.胶囊编号10
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule11 ON DouCapsule11.Code = TempTb_CapsuleDynamic.胶囊编号11
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule12 ON DouCapsule12.Code = TempTb_CapsuleDynamic.胶囊编号12
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule13 ON DouCapsule13.Code = TempTb_CapsuleDynamic.胶囊编号13
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule14 ON DouCapsule14.Code = TempTb_CapsuleDynamic.胶囊编号14
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule15 ON DouCapsule15.Code = TempTb_CapsuleDynamic.胶囊编号15
               LEFT JOIN dbo.Bs_DouCapsule DouCapsule16 ON DouCapsule16.Code = TempTb_CapsuleDynamic.胶囊编号16
               LEFT JOIN dbo.Tbl_Base_BG0026 BG0026 ON BG0026.BG0026 = TempTb_CapsuleDynamic.BG0026检测时间
               LEFT JOIN Tbl_Base_BC0009 BC0009 ON BC0009.BC0009 = TempTb_CapsuleDynamic.BC0009批号
        WHERE  Bs_CapsuleDynamic.Code = 涂布编号;
        SET @ReturnupdateValue = (   SELECT COUNT(*)
                                     FROM   dbo.Bs_CapsuleDynamic
                                            INNER JOIN dbo.TempTb_CapsuleDynamic ON TempTb_CapsuleDynamic.涂布编号 = Bs_CapsuleDynamic.Code
                                 );
        SET @ReturnInsertValue = @ReturnValue - @ReturnupdateValue;

        /*插入Bs_CapsuleDynamic*/
        PRINT '开始插入Bs_CapsuleDynamic数据，继续下一步';
        INSERT INTO dbo.Bs_CapsuleDynamic (   Optdate ,
                                              Code ,
                                              MachineNum ,
                                              CapsuleWeight ,
                                              BG0026Use ,
                                              BC0009Use ,
                                              BC0009 ,
                                              BG0026TestTime ,
                                              SievingDate ,
                                              SetZHSpeed ,
                                              DyNamicTime ,
                                              OutDate ,
                                              CKDouCapPh ,
                                              CrossWeight ,
                                              NetWeight ,
                                              AddWaterUse ,
                                              BucketWeight ,
                                              DouCapsule1 ,
                                              DouCapsule2 ,
                                              DouCapsule3 ,
                                              DouCapsule4 ,
                                              DouCapsule5 ,
                                              DouCapsule6 ,
                                              DouCapsule7 ,
                                              DouCapsule8 ,
                                              DouCapsule9 ,
                                              DouCapsule10 ,
                                              DouCapsule11 ,
                                              DouCapsule12 ,
                                              DouCapsule13 ,
                                              DouCapsule14 ,
                                              DouCapsule15 ,
                                              DouCapsule16 ,
                                              DouCapsuleCode1 ,
                                              DouCapsuleCode2 ,
                                              DouCapsuleCode3 ,
                                              DouCapsuleCode4 ,
                                              DouCapsuleCode5 ,
                                              DouCapsuleCode6 ,
                                              DouCapsuleCode7 ,
                                              DouCapsuleCode8 ,
                                              DouCapsuleCode9 ,
                                              DouCapsuleCode10 ,
                                              DouCapsuleCode11 ,
                                              DouCapsuleCode12 ,
                                              DouCapsuleCode13 ,
                                              DouCapsuleCode14 ,
                                              DouCapsuleCode15 ,
                                              DouCapsuleCode16 ,
                                              BKAvg0minBe ,
                                              BKAvg2minBe ,
                                              WAvg0minBe ,
                                              WAvg2minBe ,
                                              DBDBe ,
                                              LBKBe ,
                                              LWBe ,
                                              WB2minBe ,
                                              BKAvg0minAf ,
                                              BKAvg2minAf ,
                                              WAvg0minAf ,
                                              WAvg2minAf ,
                                              DBDAf ,
                                              LBKAf ,
                                              LWAf ,
                                              WB2minAf ,
                                              PMYSPH ,
                                              PMYSDDLS ,
                                              updatetime
                                          )
                    SELECT [动态日期] ,
                           涂布编号 ,
                           [机台] ,
                           胶囊重量kg ,
                           加入BG0026重量kg ,
                           BC0009量g10per ,
                           BC0009.ID ,
                           BG0026.ID ,
                           筛分日期 ,
                           [设置转速] ,
                           [动态时间48h] ,
                           [出库日期] ,
                           出库胶囊PH值 ,
                           [毛重kg] ,
                           [胶囊净重kg] ,
                           [加入纯水量kg] ,
                           [桶重kg] ,
                           DouCapsule1.ID ,
                           DouCapsule2.ID ,
                           DouCapsule3.ID ,
                           DouCapsule4.ID ,
                           DouCapsule5.ID ,
                           DouCapsule6.ID ,
                           DouCapsule7.ID ,
                           DouCapsule8.ID ,
                           DouCapsule9.ID ,
                           DouCapsule10.ID ,
                           DouCapsule11.ID ,
                           DouCapsule12.ID ,
                           DouCapsule13.ID ,
                           DouCapsule14.ID ,
                           DouCapsule15.ID ,
                           DouCapsule16.ID ,
                           DouCapsule1.Code ,
                           DouCapsule2.Code ,
                           DouCapsule3.Code ,
                           DouCapsule4.Code ,
                           DouCapsule5.Code ,
                           DouCapsule6.Code ,
                           DouCapsule7.Code ,
                           DouCapsule8.Code ,
                           DouCapsule9.Code ,
                           DouCapsule10.Code ,
                           DouCapsule11.Code ,
                           DouCapsule12.Code ,
                           DouCapsule13.Code ,
                           DouCapsule14.Code ,
                           DouCapsule15.Code ,
                           DouCapsule16.Code ,
                           [前0minL黑均值L] ,
                           [前2minL黑均值] ,
                           [前0minL白均值L] ,
                           [前2minL白均值] ,
                           [前对比度] ,
                           [前黑deltaL] ,
                           [前白deltaL] ,
                           [前2min白B值] ,
                           [后0minL黑均值L] ,
                           [后2minL黑均值] ,
                           [后0minL白均值L] ,
                           [后2minL白均值] ,
                           [后对比度] ,
                           [后黑deltaL] ,
                           [后白deltaL] ,
                           [后2min白B值] ,
                           配墨用水PH值 ,
                           配墨用水电导率 ,
                           GETDATE()
                    FROM   [dbo].TempTb_CapsuleDynamic
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule1 ON DouCapsule1.Code = TempTb_CapsuleDynamic.胶囊编号1
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule2 ON DouCapsule2.Code = TempTb_CapsuleDynamic.胶囊编号2
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule3 ON DouCapsule3.Code = TempTb_CapsuleDynamic.胶囊编号3
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule4 ON DouCapsule4.Code = TempTb_CapsuleDynamic.胶囊编号4
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule5 ON DouCapsule5.Code = TempTb_CapsuleDynamic.胶囊编号5
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule6 ON DouCapsule6.Code = TempTb_CapsuleDynamic.胶囊编号6
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule7 ON DouCapsule7.Code = TempTb_CapsuleDynamic.胶囊编号7
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule8 ON DouCapsule8.Code = TempTb_CapsuleDynamic.胶囊编号8
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule9 ON DouCapsule9.Code = TempTb_CapsuleDynamic.胶囊编号9
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule10 ON DouCapsule10.Code = TempTb_CapsuleDynamic.胶囊编号10
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule11 ON DouCapsule11.Code = TempTb_CapsuleDynamic.胶囊编号11
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule12 ON DouCapsule12.Code = TempTb_CapsuleDynamic.胶囊编号12
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule13 ON DouCapsule13.Code = TempTb_CapsuleDynamic.胶囊编号13
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule14 ON DouCapsule14.Code = TempTb_CapsuleDynamic.胶囊编号14
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule15 ON DouCapsule15.Code = TempTb_CapsuleDynamic.胶囊编号15
                           LEFT JOIN dbo.Bs_DouCapsule DouCapsule16 ON DouCapsule16.Code = TempTb_CapsuleDynamic.胶囊编号16
                           LEFT JOIN dbo.Tbl_Base_BG0026 BG0026 ON BG0026.BG0026 = TempTb_CapsuleDynamic.BG0026检测时间
                           LEFT JOIN Tbl_Base_BC0009 BC0009 ON BC0009.BC0009 = TempTb_CapsuleDynamic.BC0009批号
                    WHERE  NOT EXISTS (   SELECT 1
                                          FROM   Bs_CapsuleDynamic
                                          WHERE  Code = 涂布编号
                                      )
                           AND 涂布编号 IS NOT NULL;

        PRINT '表Bs_CapsuleDynamic数据插入完毕，继续下一步';
        PRINT '所有过程完成';
    END;
go

