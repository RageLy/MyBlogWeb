

-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date, ,>
-- Description:	<Description, ,>
-- =============================================
CREATE FUNCTION [dbo].[Fn_GetRSqure]
(
	-- Add the parameters for the function here
	@data SpearmanPara READONLY
	,@Slope DECIMAL(18,6)
	,@const DECIMAL(18,6)
)
RETURNS DECIMAL(18,6)
AS
BEGIN
	
	DECLARE @r DECIMAL(18,6);

	SELECT @r = 1 - ( CASE WHEN SUM(ysqure) <> 0 THEN SUM(cancha) / SUM(ysqure) ELSE 1 END) FROM 
	(
		SELECT ((x*@Slope + @const) - y) * ((x*@Slope + @const) - y) AS cancha
		, (y - Avgy) * (y - Avgy)  AS ysqure
		FROM 
		(
			select AVG(Y) OVER() AS Avgy,* FROM @data
		)xx
	) x
	
	--SET @r = (SELECT COUNT(*) FROM @data );

	-- Return the result of the function
	RETURN @r;

END
go

