-- =============================================
-- Author:		<Author,,Name>
-- Create date: <Create Date,,>

-- Description:	<Description,,>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_AllQuery_List_Forward]
    @ID VARCHAR(50) = '' ,
    @ResultType VARCHAR(50) = 'PigmentBK' -- 结果类型
    ,
    @Action VARCHAR(50) = '上'
AS
    BEGIN
 
        DECLARE @CodeType VARCHAR(50) = 'ID';   -- 编号类型      
        DECLARE @CodeValue VARCHAR(50) = @ID;  -- 编号取值  
        DECLARE @PageIndex VARCHAR(5) = '1';  
        DECLARE @PageSize VARCHAR(5) = '20';  
        DECLARE @Series VARCHAR(5) = '1';  --粒子系列
        DECLARE @OrderFields VARCHAR(50) = '';  
        DECLARE @EmpID VARCHAR(50) = '1';
        DECLARE @TalbeName VARCHAR(MAX) = '';  
        DECLARE @WhereValue VARCHAR(MAX) = '';
        DECLARE @SelectValue VARCHAR(MAX) = ''; 
        PRINT '@ResultType: '+@ResultType + '  @CodeType: '+@CodeType;
        IF ( @ID <> ''
             AND @Action = '上'
           )
            BEGIN
                SET @CodeType = @ResultType;
                IF ( @ResultType = 'Oil' )
                    BEGIN
                    PRINT '设置ResultType='''
                        SET @ResultType = '';
                    END
                ELSE
                    IF ( ( SELECT   Last
                           FROM     dbo.AllQuaryPara
                           WHERE    SpType = @ResultType
                         ) <> 0 )
                        BEGIN
                        
                            SET @ResultType = ( SELECT  SpType
                                                FROM    dbo.AllQuaryPara
                                                WHERE   ID = ( SELECT   Last
                                                               FROM     dbo.AllQuaryPara
                                                               WHERE    SpType = @ResultType
                                                             )
                                              );
                          
                        END;
            END;
        ELSE
            IF ( @ID <> ''
                 AND @Action = '下'
               )
                BEGIN
                    SET @CodeType = @ResultType;
                    
                    IF ( ( SELECT   Next
                           FROM     dbo.AllQuaryPara
                           WHERE    SpType = @ResultType
                         ) <> 9 )
                        BEGIN
                            IF ( @ResultType <> 'SinCapsule' OR @ResultType <> 'TestPiece')
                                SET @ResultType = ( SELECT  SpType
                                                    FROM    dbo.AllQuaryPara
                                                    WHERE   ID = ( SELECT   Next
                                                                   FROM     dbo.AllQuaryPara
                                                                   WHERE    SpType = @ResultType
                                                                 )
                                                  );
                            ELSE IF(@ResultType = 'SinCapsule')
                                SET @ResultType = 'SinCapsule'
								ELSE IF(@ResultType = 'TestPiece')
                                SET @ResultType = 'TestPiece'
                                              
                        END;
               
                END;
                ELSE if(@ID='')
                begin
                SET @ResultType=''
                SET @CodeType=''
                end
        PRINT '最终结果： '+@ResultType + @CodeType;
  
        EXEC dbo.Sp_Analysister_AllQuery_List @CodeType, -- varchar(50)
            @CodeValue, -- varchar(50)
            @ResultType, -- varchar(50)
            @PageIndex, -- varchar(5)
            @PageSize, -- varchar(5)
            @OrderFields, -- varchar(50)
            @EmpID;  -- varchar(50)
	
	 
    END;
go

