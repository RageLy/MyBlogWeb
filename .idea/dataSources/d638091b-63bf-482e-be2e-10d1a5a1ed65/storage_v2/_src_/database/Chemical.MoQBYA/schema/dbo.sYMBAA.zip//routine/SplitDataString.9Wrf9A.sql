-- =============================================
-- Author:		白冰
-- Create date: 2016-06-01
-- Description:	拆分颜料字符串为标准颜料组合
-- Input：		1602MW3001-003
-- Output:		1602MW3001, 1602MW3002, 1602MW3003
-- =============================================
CREATE FUNCTION [dbo].[SplitDataString]
(	
	-- Add the parameters for the function here
	@DataString varchar(MAX) = '1602MW3001-003'
)
RETURNS @Result TABLE (id INT IDENTITY, string varchar(MAX))
AS
BEGIN
	declare @splitIndex int = 0
	SET @splitIndex = CHARINDEX('-', @DataString)
	
	IF @splitIndex <> 0 
	BEGIN
		DECLARE @left NVARCHAR(20)= LEFT(@DataString, @splitIndex - 1)
		DECLARE @right NVARCHAR(20)= right(@DataString, LEN(@DataString) - @splitIndex) 
		
		declare @startNumStr NVARCHAR(20) = RIGHT(@left, LEN(@right))
		DECLARE @startPreStr NVARCHAR(20) = LEFT(@left, LEN(@left)-LEN(@right))
		
		SET @startNumStr = SUBSTRING(@startNumStr, 
									PATINDEX('%[wkWK]%', @startNumStr)+1, 
											LEN(@startNumStr) - PATINDEX('%[wkWK]%', @startNumStr))
	
		DECLARE @start INT = CONVERT(INT, @startNumStr)
		DECLARE @end INT = CONVERT(INT, @right)
		DECLARE @index INT = @start
		
		WHILE @index <= @end
		BEGIN
			DECLARE @numStr NVARCHAR(20) =  right('00000'+cast(@index as varchar) ,LEN(@right))
			INSERT @Result VALUES(@startPreStr + @numStr)
			SET @index += 1
		END
	END
	ELSE
	BEGIN
		INSERT @Result VALUES(@DataString)
	END
	RETURN
END
go

