

-- =============================================
-- Author:  <hjl>
-- Create date:<2017-11-14>
-- Description:<读取分析器的条件 condition>
-- =============================================




CREATE PROCEDURE [dbo].[sp_Dim_GetDimsConditon]
      @tag  varchar(50)='WeldTime' -- 标识符
 as 
 Begin

set nocount on;
	
	
	
	-- condition  和 humcondition 都拼接得到
	select CASE WHEN selectdim = 'Dim7' THEN 'Dim7:Y:this10' 
	ELSE REPLACE(REPLACE(GDDim+selectdim,'Dim7,','Dim7:Y:this10%'),',',':%') + ':' END AS condition
	,CASE WHEN selectdim = 'Dim7' THEN 'Dim7:'+ CAST(year(getdate()) - 10 as varchar(4)) + '-01-01至今'
	ELSE REPLACE(REPLACE(GDDim+selectdim,'Dim7,','Dim7:' + CAST(year(getdate()) - 10 as varchar(4)) + '-01-01至今%'),',',':%') + ':' END AS humcondition
	,GDDim+selectdim AS selectdim
	FROM Tbl_AnsCom_SelfDims
	where tag = @tag;
	
	--select 'Dim7:Y:this10%DimWelderID:%DimBTime:%DimRstType:' as condition,
	--'Dim7:2007-01-01至今%DimWelderID:%DimBTime:%DimRstType:' AS humcondition,
	--'Dim7,DimWelderID,DimBTime,DimRstType' AS selectdim
    
 End
go

