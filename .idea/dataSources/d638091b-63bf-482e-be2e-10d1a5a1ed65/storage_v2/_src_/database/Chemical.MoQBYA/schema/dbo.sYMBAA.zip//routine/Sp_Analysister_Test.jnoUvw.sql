



-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年11月3日                                                
-- Descript: 主分析器sp，分配调用哪个sp
-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_Test]
  @condition VARCHAR(MAX)='Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-78,-80,-82%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1'
 ,@OtherCond VARCHAR(MAX) ='温度与产值%温度8%时间%胶囊产值%line%平均值%胶囊产值%数量'
 ,@Type VARCHAR(10) = '图' -- '图' or '列表' or '明细'
 ,@OrderFields VARCHAR(50) = 'id'
 ,@SpName VARCHAR(50) = 'SinCapsule'
 ,@EmpID INT = 1

 -- 以下参数只在出明细时使用
 ,@PageIndex VARCHAR(5)='1'
 ,@PageSize VARCHAR(5)='10'
 ,@XValue VARCHAR(50) = ''
 ,@DSValue VARCHAR(50) = ''
--------------------@OtherCond不选择双Y时，传参要求：'温度与产值%温度8%时间%胶囊产值%line%平均值%%'
AS
BEGIN

---------------------------------------------------------------------- 验证参数 ---------------------------------------------------------            
	    
    SET NOCOUNT ON;

	IF ( @SpName = '' OR @SpName IS NULL)
	BEGIN
		SELECT 'Spname 参数传递有误，不能为空！'
		RETURN;
	END
	--PRINT @SpName
	IF not EXISTS ( SELECT 1 FROM Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName )
	
	BEGIN
		SELECT '配置表中找不到该spname！'
		RETURN;
	END
	--PRINT @SpName
---------------------------------------------------------------------
    DECLARE @ChatType VARCHAR(50) = ''           -- 图形名称                
	
	DECLARE @OtherCondTbl TABLE            
    (            
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)            
	 )            
  
    INSERT INTO @OtherCondTbl
		SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')
    
	SET @ChatType = ( SELECT String FROM @OtherCondTbl WHERE ID = 5)
	  
    IF ( @ChatType = '' OR @ChatType IS NULL)
	BEGIN
		SELECT 'OtherCond 参数传递有误，ChatType 不能为空！'
		RETURN;
	END
    
    IF(@ChatType = 'doubley')
    BEGIN	
		EXEC Sp_Analysister_Y2
		 @condition = @condition
		,@OtherCond = @OtherCond
		,@Type = '图'
		,@SpName = @SpName
		RETURN;
	 END
     
     -- 如果是散点图，直接转入散点图分析sp
     IF(@ChatType = 'scatter')
	 BEGIN	
		EXEC Sp_Analysister_scatter
		 @condition = @condition
		,@OtherCond = @OtherCond
		,@Type = '图'
		,@SpName = @SpName
		RETURN;
	 END
	 
	 -- 如果是箱线图，直接转入箱线图备用分析sp
     IF(@ChatType = 'boxline')
	 BEGIN	
		EXEC Sp_Analysister_BoxLine_lineBak
		 @condition = @condition
		,@OtherCond = @OtherCond
		,@Type = '图'
		,@SpName = @SpName
		RETURN;
	 END
	 
	 ELSE 
		EXEC Sp_Analysister_Stad_Test
		 @condition = @condition
		,@OtherCond = @OtherCond
		,@Type = '图'
		,@SpName = @SpName
		       
END
go

