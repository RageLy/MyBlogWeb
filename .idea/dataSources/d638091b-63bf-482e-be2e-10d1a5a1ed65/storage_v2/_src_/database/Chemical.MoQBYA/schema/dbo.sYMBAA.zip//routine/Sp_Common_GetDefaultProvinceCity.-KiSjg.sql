

/*
刘轶 2016-01-22  查询默认省市县
*/
CREATE PROCEDURE [dbo].Sp_Common_GetDefaultProvinceCity 
as
begin

declare @LiveProvince varchar(100) = '',@LiveCity varchar(100) = ''
select @LiveProvince = SettingValue from Tbl_config_SystemSetting where SettingName = '默认省'
select @LiveCity = SettingValue from Tbl_config_SystemSetting where SettingName = '默认市'


select @LiveProvince as LiveProvince,@LiveCity as LiveCity

end
go

