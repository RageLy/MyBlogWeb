-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-28>
-- Description:	<员工类别保存>
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Com_EmpType_Save]
	@EmpTypeID varchar(500)='',
	@EmpTypeName varchar(500)=''
as 
Begin 
set nocount on
if @EmpTypeName = ''
begin
	select '类别名称不能为空！'
	return
end
if exists(select 1 from dbo.Tbl_Com_EmployeeType where EmpTypeName=@EmpTypeName and EmpTypeID!=@EmpTypeID)
begin
	select '员工类别不能重复！'
	return
end
if(@EmpTypeID<>'')
begin

	update Tbl_Com_EmployeeType set EmpTypeName=@EmpTypeName  where 
	EmpTypeID=@EmpTypeID
	select '0'

end
else
begin

	insert into Tbl_Com_EmployeeType (EmpTypeName) values (@EmpTypeName)
	select '0'


end
end
go

