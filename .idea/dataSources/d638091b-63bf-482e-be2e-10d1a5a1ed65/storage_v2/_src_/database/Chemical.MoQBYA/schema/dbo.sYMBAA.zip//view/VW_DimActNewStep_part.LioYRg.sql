Create View VW_DimActNewStep_part
AS
SELECT  -1 AS Id ,
'全部集合'AS Name ,
'1' AS istrue ,
'属性集合' 选项集合类型
 FROM    Tbl_AnsCom_DIimToTable AS b
 WHERE   DimNum = 'DimActNewStep'
 UNION ALL
 SELECT  x.ID AS Id ,
 CAST(x.Step AS VARCHAR(20)) AS Name ,
'0' AS istrue ,
'基础刻度' 选项集合类型
 FROM Tbl_AnsCom_DIimToTable b
 CROSS JOIN ( SELECT DISTINCT 
Step ,ID
 FROM Bs_Base_Step  WHERE Step IS NOT NULL ) x
 WHERE DimNum = 'DimActNewStep'

------------------------------------------
go

