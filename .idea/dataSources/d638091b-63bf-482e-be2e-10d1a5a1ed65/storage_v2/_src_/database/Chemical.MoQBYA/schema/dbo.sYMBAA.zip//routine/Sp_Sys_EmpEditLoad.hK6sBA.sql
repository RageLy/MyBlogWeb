      
-- =============================================              
-- Description: <员工资料 新增编辑加载>          
-- =============================================           
CREATE procedure [dbo].[Sp_Sys_EmpEditLoad]      
 @EmpID  varchar(50) = ''         
as          
begin          
     
  select                                        
   cast(a.EmpID as varchar(500)) [EmpID]                                        
,EmpName  
,EmpNo  
,Sex  
,Birth  
,Address  
,Telephone  
,CardID  
,UserID  
,Rmark  
,DateLeave  
,DateFrom  
,Status  
,ZJM  
into #Result                                    
from Tbl_Com_Employee a      
  
 where (a.EmpID = @EmpID )      
     
IF(@EmpID = '')    
BEGIN    
INSERT INTO #Result (Sex   ,Status
) VALUES('男','在职')     
END    
    
SELECT * FROM #Result    
                    
       
end
go

