






-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年11月18日
-- Edit Date: 2016年11月18日                                                
-- Descript: 分析器结果的趋势分析sp

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_Analysister_TrendAna]
  @condition VARCHAR(MAX)='Dim7:Y:this10%DimDouJNGHL:-1%DimDouLJspan:-1%DimDouPH:-1%DimDouPhTemp:-1%DimDouSpeed400:-1%DimDouSpeed500:-1%DimDouTemp25:-1%DimDouTemp41:-1%DimDouTemp8:-1%DimOilDensity:-1%DimOilSTension:-1%DimOrganicAvgBK:-1%DimOrganicAvgW:-1%DimOrganicPerW:-1%DimZetaPerW:-1%DimDouLJ:1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28|29|30|31|32|33|34|35|36|37|38|39|40|41|42|43|44|45|46|47|48|49|50|51|52|53|54|55|56|57|58|59|60|61|62|63|64|65|66|67|68|69|70%DimDouLW:-1'
 ,@OtherCond VARCHAR(MAX) ='%粒径%粒径span%L白%line%平均值%L黑%平均值'
 ,@dataSource T_TrandAna_DataSource READONLY
 ,@AnaName VARCHAR(50) = 'DouCapsule'

AS
BEGIN

---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            

    DECLARE @SiftValue VARCHAR(MAX);
    SET @SiftValue=REPLACE(@condition,'|',',');
          
    DECLARE @XName VARCHAR(50) = ''              -- 横轴维度名称                
    DECLARE @DSName VARCHAR(50) = ''             -- 分组维度名称                
    DECLARE @YName VARCHAR(50) = ''              -- @OtherCond  传入的Y轴名称                

    -- 现有OtherCond解析方式  PS：近期可能 配置传入的参数方式会变 则在这个地方修改                
	
    DECLARE @OtherCondTbl TABLE            
    (
		ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY            
		,String NVARCHAR(50)
	 )
	 
    INSERT INTO @OtherCondTbl
    SELECT  String FROM dbo.f_splitSTR(@OtherCond, '%')
    
    SET @XName = ( SELECT String FROM @OtherCondTbl WHERE ID = 2 )
    SET @DSName = ( SELECT String FROM @OtherCondTbl WHERE ID = 3 )
    SET @YName = ( SELECT String FROM @OtherCondTbl WHERE ID = 4)

	DECLARE @CDimG VARCHAR(50) = ''              -- 循环中的当前G维度               
    DECLARE @DSValue VARCHAR(50) = ''             -- G维度名称
    DECLARE @index int = 1  
     -- OtherCond解析完毕       


	-- 删除同样的计算中之前已经计算过的结果
	DELETE FROM T_TrendAna_Result WHERE AnaName = @AnaName AND SiftValue = @SiftValue AND DimX = @XName AND DimG = @DSName AND DimY = @YName

-------------------------------------------------------------------- 预处理完毕 ----------------------------------------------------------------------------------            
    
	-- 给结果排序加编号

	SELECT ROW_NUMBER() OVER(ORDER BY DimG) AS n,DimG INTO #G
	FROM
	(
		SELECT DISTINCT DimG FROM @dataSource
	) x
	
	WHILE (@index <= (select COUNT(*) FROM #G))
	BEGIN

		SELECT ROW_NUMBER() OVER(ORDER BY DimX) AS n, DimX,YValue INTO #T FROM @dataSource WHERE DimG = (select DimG FROM #G WHERE n = @index)
	    ORDER BY DimX

	-- 第一段从源数据结果中匹配
	

		SELECT ROW_NUMBER() OVER(ORDER BY n) AS n,DimX AS Value,Trend  INTO #T1
		FROM (
		SELECT CASE WHEN a.YValue - b.YValue > 0 THEN -1
					WHEN a.YValue - b.YValue < 0 THEN 1
					ELSE 0 END
			AS Trend
			,a.*
		FROM #T a Left JOIN #T b ON a.n + 1 = b.n
		) x
		
		
		-- 第二次匹配找出所有拐点

		SELECT ROW_NUMBER() OVER(ORDER BY an) AS nn,* INTO #T2 FROM 
		(
			SELECT a.n AS an,a.value AS avalue,a.Trend AS aTrend,b.n AS bn,b.value AS bvalue,b.Trend AS bTrend
			FROM #T1 a Full JOIN #T1 b ON a.n + 1 = b.n 
			WHERE ABS(a.Trend - b.Trend) > 1 or a.Trend is null or b.Trend is null
		) x
		
		SELECT @DSValue = DimG FROM #G WHERE n = @index;
		

		INSERT INTO dbo.T_TrendAna_Result
				(
				  AnaName,
				  DimX ,
				  DimY ,
				  DimG ,
				  DimGValue ,
				  SiftValue ,
				  BeginValue ,
				  EndValue ,
				  Trend ,
				  Continucount ,
				  info
				)
		SELECT @AnaName,@XName,@YName,@DSName,@DSValue,@SiftValue
		,a.bvalue AS BeginValue,isnull(b.bvalue,b.avalue) AS EndValue,case when a.bvalue>=0 then a.bTrend else a.bTrend*(-1) end as Trend
		,isnull(b.bn,b.an) - a.bn AS Continucount,''
		FROM #T2 a inner JOIN #T2 b ON a.nn + 1 = b.nn
		ORDER BY a.nn
        
		DROP TABLE #T
		DROP TABLE #T1
		DROP TABLE #T2

		SET @index = @index + 1
	END
	
END
go

