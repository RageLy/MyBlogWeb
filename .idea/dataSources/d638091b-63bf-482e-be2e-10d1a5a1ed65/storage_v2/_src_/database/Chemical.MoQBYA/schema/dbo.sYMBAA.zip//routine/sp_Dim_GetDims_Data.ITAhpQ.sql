CREATE proc [dbo].[sp_Dim_GetDims_Data]  
    @DimStr  varchar(250) = 'DimTem'  
as  
 declare @DimName varchar(50),@Sql varchar(max)  
   
 declare c cursor fast_forward for  
 select string FROM Split(@DimStr,',')  
  
 open c;  
 fetch next from c into @DimName;  
   
 while @@FETCH_STATUS = 0  
  begin  
  
   set @Sql = 'select * from vw_DimData_'+@DimName 

   exec(@Sql)  
   
   fetch next from c into @DimName;  
  end  
 close c;  
 deallocate c;
go

