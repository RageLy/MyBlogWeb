



  
  
-- =============================================                                                            
-- Description: <根据维度名称在字符串中获取相应的维度>   获取纬度解析后的表                                                   
-- =============================================                               
CREATE PROC [dbo].[Sp_Com_Getdimensions]
    @SiftValue VARCHAR(MAX) = 'Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-1%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1' ,   --条件字符串  获取由逗号分隔的表名                            
    @EmpID VARCHAR(400) = '1'
AS
    BEGIN
    SET NOCOUNT ON ;
    
    SET @SiftValue = REPLACE(@SiftValue, '|', ',')                               
--------------------------------------------------解析字符串------------------------------------------------------------------                       

	CREATE TABLE #AnalyzeTb
	( 
	id VARCHAR(max) ,
	name VARCHAR(max)
	)       
	
	-- 专门御用解析时间表的临时表             
	CREATE TABLE #AnalyzeTbTime
	(                
	id VARCHAR(max) ,                
	name VARCHAR(max) ,                
	begindate VARCHAR(max),                
	enddate VARCHAR(max)                
	)
    
	DECLARE @char VARCHAR(MAX)                      
	DECLARE @reverse VARCHAR(MAX)                      
	DECLARE @start INT ,@end INT                      

---------------------------------------------------------------解析字符串完成------------------------------------------------------------------                       
   
    
    DECLARE @tableCount INT = 0 ,                
    @sql VARCHAR(MAX)= ''                            
   --,@TNames varchar(200) = '' -- 临时表名字符串组                                                      
            ,@DimIndex INT = 0           -- 维度索引，在循环中指明第几个维度                            
            ,@DimName VARCHAR(max) = '' --维度名称，指明循环中当前操作的维度                            
            ,@ViewName VARCHAR(max) = '' -- 维度视图名称                            
            ,@ColumnName VARCHAR(max) = '' -- 维度视图第三列列名                            
			,@IsRange BIT = '0'  -- 是否需要解析成范围值
			
     -- 计算表的个数  
    SET @tableCount = ( LEN(@SiftValue) - LEN(REPLACE(@SiftValue, 'Dim','')) ) / 3
    
    -- 循环插入表格
    SET @DimIndex = 1
    
    WHILE ( @tableCount > 0 )                
	BEGIN
        SET @DimName = dbo.[GetDimHead](@SiftValue, @DimIndex)                            
        
		-- 从维度表获取维度对于表名
        SELECT @ViewName = 'vw_' + ViewName + '_PartAll',@IsRange = ISNULL(IsRange,0) FROM Tbl_AnsCom_DIimToTable WHERE DimNum = @DimName;   
        
		-- 获取单个表名
        IF ( @DimName <> '' )
        BEGIN
        
			-- 如果是dim7 时间维度，专门另外处理
			IF CHARINDEX('Dim7', @DimName) > 0
            BEGIN 
               CREATE TABLE #timeTemp
               (
                id INT ,
                beginDate DATETIME ,
                endDate DATETIME ,
                beginDate_Ly DATETIME ,
                endDate_Ly DATETIME ,
                beginDate_Lp DATETIME ,
                endDate_Lp DATETIME
                )
                DECLARE @TimeSql VARCHAR(MAX);
                SET @TimeSql = STUFF(( SELECT ','+ CAST(string AS VARCHAR(500)) FROM dbo.GetDim(@SiftValue, @DimName) FOR XML PATH('')), 1, 1, '')            
                --时间参数 例：'Dim:7:Y:2013,Y:2012'
                
                EXEC [Sp_Com_GetUp_link_time] @SiftValue = @TimeSql,@tableNames = '#timeTemp';
                SET @sql += ' insert into #time select * from #timeTemp'
            
            END
            
            -- 如果是其它的非Dim7维度统一处理
            ELSE
            BEGIN
            
				
                -- 如果不需要解析范围
               IF(@IsRange = 0)
				SET @sql += '
						insert into #' + @DimName + ' (VWID,ID,Name) select distinct b.VWID,b.ID,b.Name FROM 
						GetDim(''' + @SiftValue + ''',''' + @DimName + ''') as a
						inner join ' + @ViewName + ' as b on a.string = b.VWID  ';
               
               -- 需要解析范围值的
               ELSE
				SET @sql += '
						insert into #' + @DimName + ' (VWID,ID,Name,beginvalue,endvalue) select distinct b.VWID,b.ID,b.Name,b.beginvalue,b.endvalue
						FROM GetDim(''' + @SiftValue + ''',''' + @DimName + ''') as a
						inner join ' + @ViewName + ' as b on a.string = b.VWID  ';
            
            
            
            END
            
			--[Sp_Com_Getdimensions_test]
			-- 一个维度解析完毕
         END                            
         
		--循环用参数
         SET @DimIndex = @DimIndex + 1                            
         SET @tableCount = @tableCount - 1  
   -- 循环完毕
   END
   
   --print @sql;
   EXEC(@sql);
   
END
go

