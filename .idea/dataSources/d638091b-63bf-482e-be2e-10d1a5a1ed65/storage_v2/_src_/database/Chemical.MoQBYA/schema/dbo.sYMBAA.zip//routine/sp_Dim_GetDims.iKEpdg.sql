



-- =============================================           
-- Description: <根据传入的dimnames,每个dim返回一个dim视图 和dim_level表>      
-- =============================================        
CREATE proc [dbo].[sp_Dim_GetDims]    
    @DimStr  varchar(max) = 'DimOrganicAvgW,DimOrganicAvgBK,DimOrganicfcBK,DimOrganicfcW,DimDouAF0001'
as
 declare @DimLevel varchar(50), @ViewName varchar(50), @Sql varchar(max);
 
 declare c cursor fast_forward for
 select b.DimLevel,b.ViewName FROM Split(@DimStr,',') a INNER JOIN dbo.Tbl_AnsCom_DIimToTable b ON a.string = b.DimNum ORDER BY a.StartIndex
 
 open c;
 fetch next from c into @DimLevel,@ViewName;
 while @@FETCH_STATUS = 0
  begin
	
    set @Sql = 'select * from vw_'+@ViewName+'_Part'          
	exec(@Sql)
	
	select StartIndex AS CharID,string AS CharName from Split(@DimLevel,',')
    fetch next from c into @DimLevel,@ViewName;
  end
 close c;
 deallocate c;
go

