-- =============================================
-- Author:		<曹乐平>
-- Create date: <2014-06-23>
-- Description:	<删除职位名称>
-- =============================================
CREATE PROCEDURE [dbo].Sp_Com_PoliticalStatus_Del
	@KeyValue  varchar(50)='',
	@TableName  varchar(50)='',
    @KeyName  varchar(50)=''
AS
BEGIN
	SET NOCOUNT ON;


 
if (select COUNT(*) from dbo.Tbl_Com_Employee where PoliticalStatusID=@KeyValue )>0
begin
	select '该记录已被员工管理引用，不能被删除'

end	
else
begin
	delete dbo.Tbl_Com_PoliticalStatus where PoliticalStatusID=@KeyValue
	select '0'
END

END
go

