


-- =============================================
-- Author:		白冰
-- alter date: <2013-07-23>
-- Description:	<根据起始时间得出 时间名称>
-- =============================================
CREATE FUNCTION [dbo].[GetTimeName_SpecialID]
    (
      @BeginDateID BIGINT ,    -- 开始时间ID， 2000 表示2000年，200001表示2000年1月
      @EndDateID BIGINT     -- 结束时间
    )
RETURNS VARCHAR(50)
AS
    BEGIN
        DECLARE @result VARCHAR(50);
        SET @result = NULL;
   
        DECLARE @BeginDateString VARCHAR(50)
        DECLARE @EndDateString VARCHAR(50)
   
        IF @BeginDateID < 200000
            SET @BeginDateString = CAST(@BeginDateID AS VARCHAR(4)) + '年'
        ELSE
            IF 200000 < @BeginDateID
                AND @BeginDateID < 20000000
                SET @BeginDateString = LEFT(CAST(@BeginDateID AS VARCHAR(10)),
                                            4) + '年'
                    + SUBSTRING(CAST(@BeginDateID AS VARCHAR(10)), 5, 2) + '月'
            ELSE
                SET @BeginDateString = LEFT(CAST(@BeginDateID AS VARCHAR(10)),
                                            4) + '年'
                    + SUBSTRING(CAST(@BeginDateID AS VARCHAR(10)), 5, 2) + '月'
                    + SUBSTRING(CAST(@BeginDateID AS VARCHAR(10)), 7, 2) + '天'
                    
                    
        IF @EndDateID < 200000
            SET @EndDateString = CAST(@EndDateID AS VARCHAR(4)) + '年'
        ELSE
            IF 200000 < @EndDateID
                AND @EndDateID < 20000000
                SET @EndDateString = LEFT(CAST(@EndDateID AS VARCHAR(10)), 4)
                    + '年' + SUBSTRING(CAST(@EndDateID AS VARCHAR(10)), 5, 2)
                    + '月'
            ELSE
                SET @EndDateString = LEFT(CAST(@EndDateID AS VARCHAR(10)), 4)
                    + '年' + SUBSTRING(CAST(@EndDateID AS VARCHAR(10)), 5, 2)
                    + '月' + SUBSTRING(CAST(@EndDateID AS VARCHAR(10)), 7, 2)
                    + '天'
                    
                    
                    
        IF @BeginDateID <> @EndDateID
            SET @result = @BeginDateString + '至' + @EndDateString
        ELSE
            SET @result = @BeginDateString
            
            
            
        RETURN @result

    END
go

