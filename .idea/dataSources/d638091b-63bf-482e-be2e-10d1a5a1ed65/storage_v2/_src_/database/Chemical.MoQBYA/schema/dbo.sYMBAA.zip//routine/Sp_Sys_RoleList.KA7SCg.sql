-- =============================================         
-- Description: <角色列表管理>     
-- =============================================      
CREATE PROCEDURE [dbo].[Sp_Sys_RoleList]      
 @PageIndex varchar(50)='1'    
 ,@PageSize varchar(50)='205'    
 ,@OrderFields varchar(50)='RoleID desc'    
AS      
BEGIN      
       
if @OrderFields = ''    
 set @OrderFields = 'RoleID desc'    
select RoleID    
 ,RoleName    
 ,case when (select COUNT(*) from Tbl_Sys_Tactics o 
							 LEFT join Tbl_Sys_RoleTactics o1 on o.TacticsID=o1.TacticsID 
							 where o1.RoleID=Tbl_Sys_Role.RoleID and MenuID is not null)>0     
  then '√' else 'Х' end HadRole    
 ,case when isnull(QueryRange,0)=0 then '仅自己' else '全部' END as QueryRange    
 ,RoleDesc,CanSeePhone    
 into #Result    
 from Tbl_Sys_Role    

declare @pageCount int =@@ROWCOUNT 
    
exec Sp_Sys_Page '#Result',@OrderFields,@pageCount,@PageIndex,@PageSize          
    
END
go

