                  
/*                  
刘轶  2015-2-3 本月至今                  
*/                  
CREATE proc [dbo].[Sp_Com_DefaultMonthBeginDate]           
@Type VARCHAR(200) = ''                   
as                    
BEGIN          
IF(@Type = '今天')          
BEGIN          
 select 'BeginDate' BeginDate                                
 ,'EndDate' EndDate                                  
 union all                                  
 select 'varchar 200'                               
 ,'varchar 200'                                   
 union all                                  
 --select substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)                          
 select Convert(varchar(10),GETDATE(),23),Convert(varchar(10),GETDATE(),23)               
END  
else if(@Type = '明天')     
begin  
  select 'BeginPredictCarDate' BeginPredictCarDate                                
  ,'EndPredictCarDate' EndPredictCarDate                                  
  union all                                  
  select 'varchar 200'                               
  ,'varchar 200'                                   
  union all                                  
  --select substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)                          
  select Convert(varchar(10),DateAdd(DD,1,GETDATE()),23),Convert(varchar(10),DateAdd(DD,1,GETDATE()),23)    
end      
else if(@Type = '空')        
begin        
 select 'BeginDate' BeginDate                                
 ,'EndDate' EndDate                                  
 union all                                  
 select 'varchar 200'                               
 ,'varchar 200'                                   
 union all          
 select '',''        
end         
ELSE          
BEGIN                    
select                 
'BeginDate' BeginDate                          
,'EndDate' EndDate             
,'BeginConTurnOverDate' BeginConTurnOverDate                          
,'EndConTurnOverDate' EndConTurnOverDate                  
                          
union all                            
select 'varchar 200'                         
,'varchar 200'             
,'varchar 200'                         
,'varchar 200'                   
                          
union all                            
--select substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)                    
select substring(Convert(varchar(10),GETDATE(),23),0,8)+'-01'                
  ,CONVERT(varchar(50),GETDATE(),23)            
  ,substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)          
 End                      
END
go

