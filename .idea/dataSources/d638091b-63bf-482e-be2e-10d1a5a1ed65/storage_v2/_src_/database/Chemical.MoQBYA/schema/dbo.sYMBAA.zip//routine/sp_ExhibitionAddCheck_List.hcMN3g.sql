      
-- =============================================                                        
-- Author:  刘轶          
-- Create date: <Create Date,2014年6月4日 >                                  
-- Description: 展厅新增客户                                                                     
-- =============================================       
CREATE proc [dbo].[sp_ExhibitionAddCheck_List]            
@PageSize  varchar(50)='500'                    
,@PageIndex varchar(50)='1'             
,@OrderFields varchar(50)='ReciveEmp desc'                       
,@BeginDate varchar(10)=''                        
,@SerchEmp_S varchar(50)=''                        
,@IsStandard_S varchar(50)=''        
,@EmpID varchar(50)='1'                    
as                
begin             
if(@BeginDate='')      
begin      
 set @BeginDate =CONVERT(varchar(10), GETDATE(),23)      
end      
if(@OrderFields = '')
begin
	set @OrderFields= ' ReciveEmp desc '
end 
      
--配置中的前3天平均标准      
declare @3dayAvgAdd decimal(18,2) = 0      
select @3dayAvgAdd=Value from Tbl_Config_SysConfig where [TYPE] = '3dayAvgAdd'      
      
select string into #Range_Temp from dbo.GetEmpQueryRange(@EmpID)             
--获取格式化表头             
declare @sql varchar(max)                                                         
set @sql= 'select ''n'' 序号                                       
 ,''ReciveEmp'' 销售员                        
 ,''Last3Add'' as [【'+SUBSTRING(CONVERT(varchar(10),dateadd(day,-3, @BeginDate),23),6,5)+'】新增]                     
 ,''Last2Add'' as [【'+SUBSTRING(CONVERT(varchar(10),dateadd(day,-2, @BeginDate),23),6,5)+'】新增]         
 ,''Last1Add'' as [【'+SUBSTRING(CONVERT(varchar(10),dateadd(day,-1, @BeginDate),23),6,5)+'】新增]        
 ,''IsStandard'' 是否达标                                                                 
 ,''TodayAdd'' 今日新增    
 ,''EmpID''  EmpID                                                              
Union all                                                     
select ''varchar,500''                         
 ,''varchar,500''                                           
 ,''varchar,500''                         
 ,''varchar,500''                         
 ,''varchar,500''                                  
 ,''varchar,500''                                                                  
 ,''varchar,500''     
 ,''varchar,500'' '       
                                
exec(@sql)         
            
select CustomerID,ReciveEmpID,CONVERT(datetime,CONVERT(varchar(10),MIN(cometime),23)) as ComeTime      
into #NewCustomer      
from Tbl_PreS_ReciveCome group by CustomerID,ReciveEmpID      
having MIN(cometime)>=dateadd(day,-3, @BeginDate) and MIN(cometime)<dateadd(day,1, @BeginDate)      
      
select distinct a.EmpName as ReciveEmp      
 ,(select COUNT(1) from #NewCustomer where ReciveEmpID = a.EmpID and ComeTime = dateadd(day,-3, @BeginDate)) as Last3Add      
 ,(select COUNT(1) from #NewCustomer where ReciveEmpID = a.EmpID and ComeTime = dateadd(day,-2, @BeginDate)) as Last2Add      
 ,(select COUNT(1) from #NewCustomer where ReciveEmpID = a.EmpID and ComeTime = dateadd(day,-1, @BeginDate)) as Last1Add      
 ,CONVERT(nvarchar(10),a.CPlan) as IsStandard      
 ,(select COUNT(1) from #NewCustomer where ReciveEmpID = a.EmpID and ComeTime = @BeginDate) as TodayAdd      
 ,a.EmpID     
 into #TempResult from  Tbl_Com_Employee as a      
 inner join #Range_Temp as c on a.EmpID = c.string      
 inner join Tbl_Com_EmployeeBusiness AS b on a.BusinessId = b.BusinessId      
 left join Tbl_Com_EmployeeState as d on a.EmployeeStateID = d.EmployeeStateID      
 where (b.BusinessName = '电销' or b.BusinessName = '展厅销售顾问')      
 and ISNULL(d.EmployeeStateName,'')!='离职'      
      
       
update #TempResult set IsStandard =       
 case when convert(numeric(18,2), (Last3Add+Last2Add+Last1Add))/3 >= IsStandard      
 then '达标' else '未达标' end      
       
select * into #Result from #TempResult      
where ReciveEmp like '%'+@SerchEmp_S+'%'       
 and (@IsStandard_S='' or IsStandard=@IsStandard_S)      


exec [Sp_Sys_Page] @tblName='#Result',@fldName=@OrderFields,@rowcount=@@rowcount,                     
                         @PageSize=@PageSize, @PageIndex=@PageIndex            
      
--select * from #NewCustomer order by ComeTime      
      
end
go

