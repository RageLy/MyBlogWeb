-- =============================================      
-- Author:  <刘轶>      
-- Create date: <2014-7-7>      
-- Description: <出明细的存储过程数量以外的CompareType拼接sql>      
-- =============================================      
 
CREATE function [dbo].[GetChartMax](  
@num INT
)    
returns varchar(max)               
AS                       
BEGIN	   
DECLARE @result INT
IF(LEN(@num/5)=1 AND @num <45)
BEGIN
	SELECT @result=(@num/5 +1 )*5
END
ELSE
BEGIN
	DECLARE @charnum VARCHAR(50)
	SET @charnum =CAST(@num AS VARCHAR(50))
	IF( SUBSTRING(@charnum,2,1)<5)
	SELECT @result=LEFT(CAST(SUBSTRING(@charnum,1,1) AS VARCHAR(50))  +'5000000000',LEN(@num))
	ELSE 
	BEGIN
		SELECT @result=LEFT(CAST(SUBSTRING(@charnum,1,1)+1 AS VARCHAR(50)) +'000000000',LEN(@num))
	END	
END
	return @result
end
go

