  
-- =============================================        
-- Author:  杨艺       
-- Create date: 2014-08-19        
-- Description: 出图的存储过程返回title        
-- =============================================        
   
CREATE PROC [dbo].[sp_Com_Analysis_GetCht_Title](    
@Title   varchar(max)='暂无'  
,@OtherCond  varchar(max)='使用默认%使用默认%保险渗透率%11%数量'    
,@SiftValue  varchar(max)='Dim19:99999%Dim7:Y:2013%Dim20:1000%Dim4:1000'  
,@Unit varchar(max)=''
,@YName varchar(max) ='' 
)      
                 
AS                         
BEGIN           
 --拆分X,Y,图类型等参数                
 declare @OtherCondTbl TABLE(                  
  ID INT IDENTITY(1,1) NOT NULL PRIMARY KEY                 
  ,String Nvarchar(50)                
 )                
 declare @XName nvarchar(50)--自定义X轴                
 ,@DSName nvarchar(50)--自定义数据分组                
             
 ,@CharName nvarchar(50)  --图表                
 ,@CompareType nvarchar(50) --比较类型              
                 
 insert into @OtherCondTbl                
 select String from dbo.f_splitSTR(@OtherCond,'%')                
 set @XName = (select String from @OtherCondTbl where ID = 1)                
 set @DSName = (select String from @OtherCondTbl where ID = 2)                
               
 set @CharName = (select String from @OtherCondTbl where ID = 4)                
 set @CompareType = (select String from @OtherCondTbl where ID = 5)   

 declare @Sql varchar(max)=''   
 ----更新排序字段#FinalResult   
 --if(@XName='星期')  
 --begin  
 -- set @sql += ' update #FinalResult  
 --  set OrderX =case when XName =''星期日'' then 0   
 --  when XName =''星期一'' then 1  
 --  when XName =''星期二'' then 2  
 --  when XName =''星期三'' then 3  
 --  when XName =''星期四'' then 4  
 --  when XName =''星期五'' then 5  
 --  when XName =''星期六'' then 6  
 --  else 1 end '  
 --end  
 --else if(@DSName='星期')  
 --begin  
 -- set @sql += ' update #FinalResult  
 --  set OrderDS =case when DSName =''星期日'' then 0   
 --  when DSName =''星期一'' then 1  
 --  when DSName =''星期二'' then 2  
 --  when DSName =''星期三'' then 3  
 --  when DSName =''星期四'' then 4  
 --  when DSName =''星期五'' then 5  
 --  when DSName =''星期六'' then 6  
 --  else 1 end '  
 --end  
 ----如果横轴为时间 这个时候替换ID为字符串  
 --if charindex('Dim7',[dbo].GetDimHead(@SiftValue,2))>0   
 --begin  
 -- set @sql += ' update a set a.XName= CONVERT(nvarchar,b.beginDate,23)+''至''+CONVERT(nvarchar,b.endDate,23)  
 --  from #FinalResult a  
 --  inner join #time b on a.XName = b.ID '  
 --end  
 ----如果数据分组为时间 这个时候替换ID为字符串  
 --if charindex('Dim7',[dbo].GetDimHead(@SiftValue,3))>0   
 --begin  
 -- set @sql += ' update a set a.DSName= CONVERT(nvarchar,b.beginDate,23)+''至''+CONVERT(nvarchar,b.endDate,23)  
 --  from #FinalResult a  
 --  inner join #time b on a.DSName = b.ID '  
 --end  

 --set @Sql+= ' select distinct DSName,OrderDS from #FinalResult order by OrderDS  '  
 ----标题部分  
 --declare @Unit varchar(255)    
 --SET @Unit =(SELECT top 1 isnull(unit,'') FROM GetOtherCondTbl where Name = @YName and CompareType=@CompareType)   
 --SET @YName +=(SELECT top 1 isnull(SHOWNAME,'') FROM Tbl_Sys_CompareType where Name = @CompareType)  
 
 ----饼图只输出3列
 --if(@CharName='Pie2D' or @CharName = 'Pie3D')                
 --begin   
 --	set @Sql+= ' select OrderX,XName,result from  #FinalResult order by OrderX '           
 --end 
 --else
	-- begin
	-- --行转列  
	--  --set @Sql+=''
	-- set @Sql+= dbo.RowToColumn('#FinalResult','DSName','result','OrderX,XName','OrderX,[ ]','OrderDS')      
 --end 
    
	
 --输出title1  
 --字符串中定义title
 set @Sql+= ' declare @Title   varchar(255) '
 declare @DimNum varchar(50),@TableName varchar(50)
 set @DimNum = dbo.[GetDimHead](@SiftValue,1) --第一个dim
 --临时表的 表名称 和 name
 select @TableName = TableName from Tbl_AnsCom_DIimToTable where DimNum = @DimNum 

 --set @FilterName = REPLACE(@FilterName,'''','''''')
 if charindex('Dim7',@DimNum)>0   
 begin
	 set @Sql+= ' set @Title=(select top 1 CONVERT(nvarchar,beginDate,23)+''至''+CONVERT(nvarchar,endDate,23) from '+@TableName+')+'' '' '
	 set @Sql+= ' if(select COUNT(1) from '+@TableName+' where CONVERT(nvarchar,beginDate,23)+''至''+CONVERT(nvarchar,endDate,23) !=(select top 1 CONVERT(nvarchar,beginDate,23)+''至''+CONVERT(nvarchar,endDate,23) from '+@TableName+') )> 0                
				  begin                
				   set @Title+=(select top 1 CONVERT(nvarchar,beginDate,23)+''至''+CONVERT(nvarchar,endDate,23) from '+@TableName+' where CONVERT(nvarchar,beginDate,23)+''至''+CONVERT(nvarchar,endDate,23) !=(select top 1 CONVERT(nvarchar,beginDate,23)+''至''+CONVERT(nvarchar,endDate,23) from '+@TableName+'))             
				   set @Title=@Title+''等 ''                
				  end   '
 end	
 else
 begin
	 set @Sql+= ' set @Title=(select top 1 Name from '+@TableName+')+'' '' '
	 set @Sql+= ' if(select COUNT(1) from '+@TableName+' where Name !=(select top 1 Name from '+@TableName+') )> 0                
				  begin                
				   set @Title+=(select top 1 Name from '+@TableName+' where Name !=(select top 1 Name from '+@TableName+'))             
				   set @Title=@Title+''等 ''                
				  end   '
 end
 ----饼图增加单位        
 --if(@CharName='Pie2D' or @CharName = 'Pie3D')                
 --begin  
 --	set @Sql+= ' set @Title+=''('+@Unit+')''   '    
 --end 
              
          
	
                  
 set @Sql+= ' select @Title AS Title,'''+isnull(@YName,'')+''' AS YName,'''+isnull(@Unit,'')+''' AS Unit'  
  
  EXEC(@sql)
    
end
go

