



                                           
CREATE PROCEDURE [dbo].[Sp_Dim_TySearch]                                                                                    
@EmpID VARCHAR(500)=''
,@SerchPara VARCHAR(500)=''  -- 此参数由框架自动传入，不在XML中配置
AS
BEGIN

  SELECT ROW_NUMBER() OVER (ORDER BY CodeType) AS id,CodeType FROM (
        SELECT DISTINCT Used AS CodeType FROM Tbl_AnsCom_DIimToTable
        WHERE Used IS NOT NULL
  ) AA
  
END
go

