
/*    
刘轶 2015-09-16   函数       
*/    
CREATE FUNCTION [dbo].[fn_IsNumeric]    
(    
@pString VARCHAR(8000)    
)    
RETURNS bit    
AS    
BEGIN    
 DECLARE @vJudge int    
 SET @vJudge = 0    
 SELECT @vJudge =     
 CASE
 WHEN ISNUMERIC(@pString) = 0 THEN 1    
 WHEN PATINDEX('%[^-|+0-9.|-|+]%', LOWER(@pString)) <> 0 THEN 1    
 WHEN LOWER(@pString) = '-' THEN 1  
 WHEN LOWER(@pString) = '+' THEN 1  
 WHEN LOWER(@pString) = '.' THEN 1    
 WHEN PATINDEX('%[^-|+0-9.|-|+]%', LOWER(@pString)) = 0 THEN 0   
 END    
 RETURN @vJudge    
END
go

