-- =============================================
-- Author:		白冰
-- Create date: 2016-06-20
-- Description:	获取用户角色列表
-- =============================================
CREATE PROCEDURE [dbo].[Sp_DataManagement_Get_Role_List]
	-- Add the parameters for the stored procedure here
AS
BEGIN
    SELECT '0' AS ID, '请选择' AS NAME 
    UNION
    SELECT DISTINCT RoleID AS ID, RoleName AS Name FROM tbl_sys_role	
END
go

