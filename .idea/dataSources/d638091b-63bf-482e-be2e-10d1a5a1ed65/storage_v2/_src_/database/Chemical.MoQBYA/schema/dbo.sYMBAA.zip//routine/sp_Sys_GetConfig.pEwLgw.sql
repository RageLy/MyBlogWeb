-- =============================================  
-- Description: 网站获取系统设置  
-- =============================================  
CREATE PROC [dbo].[sp_Sys_GetConfig]  
AS  
BEGIN  
SELECT * FROM dbo.Tbl_Sys_SystemSetting  
END
go

