-- =============================================
-- Author:		白冰
-- Create date: 2016-06-20
-- Description:	保存用户数据到数据库，包括新增和编辑
-- =============================================
CREATE PROCEDURE [dbo].[Sp_Permission_User_Save_2]
	-- Add the parameters for the stored procedure here
    @UserID NVARCHAR(5) = '' ,
    @UserName NVARCHAR(50) = '' ,
    @UserAccount NVARCHAR(50) = '' ,
    @RoleID NVARCHAR(5) = '' ,
    @EmpID NVARCHAR(5) = '1'
AS
    BEGIN
        IF ( @UserName = '' )
            BEGIN    
                SELECT  '用户姓名不能为空！'    
                RETURN
            END  

        IF EXISTS ( SELECT  1
                    FROM    Tbl_Sys_User
                    WHERE   UserName = @UserName
                            AND UserID != @UserID )
            BEGIN    
                SELECT  '用户姓名不能重复！'    
                RETURN
            END  

        IF EXISTS ( SELECT  1
                    FROM    Tbl_Sys_User
                    WHERE   UserAccount = @UserAccount
                            AND UserID != @UserID )
            BEGIN    
                SELECT  '帐号不能重复！'    
                RETURN
            END  
     
        IF ( @RoleID = '0' )
            BEGIN    
                SELECT  '必须为账号选择角色！'    
                RETURN
            END  
    
        IF ( @UserID IS NULL
             OR @UserID = ''
           )
            BEGIN
                -- 新增插入
                INSERT  INTO dbo.Tbl_Sys_User
                        ( UserAccount ,
                          UserName ,
                          OperatorID
                        )
                VALUES  ( LTRIM(RTRIM(@UserAccount)) , -- UserAccount - varchar(50)
                          LTRIM(RTRIM(@UserName)) , -- UserName - varchar(200)
                          @EmpID  -- OperatorID - nvarchar(5)
                        )
        
                DECLARE @insertUserID BIGINT = @@IDENTITY
            
                -- 插入用户角色关系    
                INSERT  INTO dbo.Tbl_Sys_UserRoleRelation
                        ( RoleID, UserID )
                VALUES  ( @RoleID, -- RoleID - int
                          @insertUserID  -- UserID - int
                          )
                
                -- 插入用户雇员信息，如果不插入web界面不能获取操作菜单
                INSERT  INTO dbo.Tbl_Com_Employee
                        ( EmpName ,
                          UserID 
                        )
                VALUES  ( LTRIM(RTRIM(@UserName)) ,
                          @insertUserID
                        )
                  
            END
        ELSE
            BEGIN
                -- 更新现有数据
                IF @UserAccount <> ''
                    BEGIN
                        UPDATE  dbo.Tbl_Sys_User
                        SET     UserAccount = @UserAccount ,
                                UserName = @UserName ,
                                OperatorID = @EmpID
                        WHERE   UserID = CAST(@UserID AS INT)

                        UPDATE  dbo.Tbl_Sys_UserRoleRelation
                        SET     RoleID = CAST(@RoleID AS INT)
                        WHERE   USERID = CAST(@UserID AS INT)
                    END
                ELSE
                -- 当把用户账号置空表示移除用户角色
                    BEGIN
                        DELETE  dbo.Tbl_Sys_User
                        WHERE   UserID = CAST(@UserID AS INT)
                        DELETE  dbo.Tbl_Sys_UserRoleRelation
                        WHERE   UserID = CAST(@UserID AS INT)
                        DELETE  dbo.Tbl_Com_Employee
                        WHERE   UserID = CAST(@UserID AS INT)
                    END
     
            END
        
        SELECT  '0'
    END
go

