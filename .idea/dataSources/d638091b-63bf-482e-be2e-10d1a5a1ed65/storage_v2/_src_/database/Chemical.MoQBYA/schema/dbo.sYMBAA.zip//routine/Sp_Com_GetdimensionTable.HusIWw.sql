







  
  
-- =============================================  
-- Description: 根据维度SiftValue填充分析器中的所对应的维度表 #Dims
-- hjl 2016 7 19   
-- =============================================  
CREATE PROC [dbo].[Sp_Com_GetdimensionTable]  
    @SiftValue VARCHAR(MAX) = 'Dim7:Y:this10%DimSinYX:-1%DimSinFu:-1%DimSinTemp41:-1%DimSinSpeed580:-1%DimSinOutValue:-100%DimSinTemp8:-1%DimSinTemp25:-1%DimSinSpeed:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-1%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1'--条件字符串  获取由逗号分隔的表名  
 ,@XName varchar(500)='转速'  
 ,@DsName varchar(500)='温度8'  
  
AS  
    BEGIN  
    SET NOCOUNT ON ;  
      
    SET @SiftValue = REPLACE(@SiftValue, '|', ',')                                 

    DECLARE @tableCount INT = 0  
   ,@sql VARCHAR(MAX)= ''  
            ,@TableName VARCHAR(max) = ''  -- 具体单个的表名  
            ,@DimIndex INT = 0           -- 维度索引，在循环中指明第几个维度  
            ,@DimName VARCHAR(max) = ''  --维度名称，指明循环中当前操作的维度  
            ,@DimChName VARCHAR(max) = ''  --维度的中文名称  
            ,@DimValues VARCHAR(max) = '' -- 维度的取值  
            ,@DimAllValue VARCHAR(max) = '' -- 维度的全部集合的取值
			,@DimOrderSql VARCHAR(max) = '' -- 维度在拼接字符串中的排序的字符串   
			,@DimYsql VARCHAR(max) = ''  
			,@IsRange VARCHAR(max) = ''   -- 是否是范围型维度
		
     
     -- 计算维度的个数  
    SET @tableCount = LEN(@SiftValue) - LEN(REPLACE(@SiftValue, '%','')) + 1;  
   
    -- 循环插入表格
    SET @DimIndex = 1;
    
    WHILE ( @tableCount > 0 )  
	BEGIN  
        SET @DimName = dbo.[GetDimHead](@SiftValue, @DimIndex);  
        SET @DimValues = Rtrim(Ltrim(dbo.GetDimValue(@SiftValue,@DimName)));  
        
        
        
        SELECT  @DimChName =  Name_ch  
        -- 2017.11修改，如果传入的是空值，则自动赋值为全部集合 
			,@DimValues = Case when @DimValues = '' Then AllValue ELSE @DimValues END
			,@DimAllValue = AllValue   
			,@DimOrderSql = ISNULL(AtOrderSql,'')
			,@DimYsql = AtYSql  
			,@IsRange = IsRange  
		
		FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = @DimName;  
        
		--SELECT   Name_ch  
		--	, AllValue   
		--	,AtOrderSql  
		--	,AtYSql  
		--	,IsRange  
		--FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = @DimName; 
		
        -- 时间维度为特殊维度，必然需要，这里先不处理  
        IF( @DimName <> 'Dim7' )  
        BEGIN  
     
		   SET @sql += '  
		   Insert into #Dims   
		   SELECT  ''' + @DimName + '''
		   ,''' + ISNULL(@DimValues,'') + '''
		   ,''' + ISNULL(@DimChName,'') + '''
		   ,CASE WHEN ''' + ISNULL(@DimChName,'') + ''' = ''' + @XName + ''' THEN ''X''     
			  WHEN ''' + ISNULL(@DimChName,'') + '''  = ''' + @DsName + ''' THEN ''G''   
			  WHEN ''' + ISNULL(@DimValues,'') + '''  <> ''' + ISNULL(@DimAllValue,'') + ''' THEN ''F''   
			  ELSE ''ND'' END  
		   , ''' + ISNULL(@DimOrderSql,'')  + '''   
		   , ''' + ISNULL(@DimYsql,'')  + '''  
		   , ''' + ISNULL(@IsRange,'')  + ''';'
		  
		  END  

  --循环用参数  
        SET @DimIndex = @DimIndex + 1;  
        SET @tableCount = @tableCount - 1;  
   -- 循环完毕  
   END  
     
   --print @sql;  
   EXEC(@sql);  
     --SELECT *FROM #Dims
END
go

