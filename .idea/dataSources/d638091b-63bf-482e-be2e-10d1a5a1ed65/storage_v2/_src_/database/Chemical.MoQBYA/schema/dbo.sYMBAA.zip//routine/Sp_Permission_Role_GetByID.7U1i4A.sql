-- =============================================  
-- Author:  <曹乐平>  
-- Create date: 2014年6月24日 
-- Description: <获取角色>  
-- =============================================  
CREATE PROCEDURE [dbo].[Sp_Permission_Role_GetByID]   
 @RoleID varchar(500)='-1'
AS  
BEGIN  
 SET NOCOUNT ON;  

   select RoleID
       ,RoleName
       ,QueryRange
       ,CanSeePhone
       ,RoleDesc   
   from Tbl_Sys_Role where RoleID = @RoleID

END
go

