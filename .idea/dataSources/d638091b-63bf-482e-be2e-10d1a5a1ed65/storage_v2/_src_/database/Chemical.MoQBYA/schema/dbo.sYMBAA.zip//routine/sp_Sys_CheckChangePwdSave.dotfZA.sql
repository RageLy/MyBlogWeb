-- =============================================       
-- Description: <判断旧密码是否正确 新密码两次是否一致>     
-- =============================================    
CREATE PROCEDURE [dbo].[sp_Sys_CheckChangePwdSave]    
 @UserPasswordpwd varchar(500)='',    
 @OldPasswordpwd varchar(500)='',    
 @UserPasswordV1pwd varchar(500)='',    
 @UserID varchar(500)=''     
 as     
 Begin     
set nocount on    
    
   if( @OldPasswordpwd='')    
   begin    
      select '旧密码不能为空'    
      return     
   end    
   if( @UserPasswordpwd='')    
   begin    
      select '新密码不能为空'    
      return     
   end    
      
     if( @UserPasswordV1pwd='')    
   begin    
      select '确认密码不能为空'    
      return     
   end    
  if(@UserID<>'' and @UserPasswordpwd<>'' and @OldPasswordpwd<>'' and @UserPasswordV1pwd <>'' )    
  begin    
     if exists(select * from dbo.Tbl_Sys_User where UserID=@UserID and UserPassword=@OldPasswordpwd)    
    begin    
      if(@UserPasswordV1pwd<>@UserPasswordpwd)    
      begin    
        select '新密码与确认密码不一致,请重新输入'    
      end    
      else     
      begin    
         update dbo.Tbl_Sys_User set UserPassword=@UserPasswordpwd where UserID=@UserID    
         select '修改成功'    
      end    
            
      end    
     else    
     begin    
       select '原密码输入不正确,请重新输入'    
     end    
    end    
         
   end
go

