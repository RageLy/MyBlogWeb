








-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2017年7月18日
-- Edit Date: 2017年7月18日
-- Descript: 自动计算中寻找数据条数

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_AutoAna_SerchData]
  @SiftValue VARCHAR(MAX)='DimDDLps:56%DimSinTemp8:22%DimSinTemp25:51%DimSinTemp41:27%DimSinSpeed:51%DimSinSpeed580:173%DimOilViscosity:129%DimYXLJ05:60%DimYXLJ09:102%DimOilSeries:1%DimOilDensity:0'
 ,@SpName VARCHAR(50) = 'SinCapsule' -- '图' or '列表' or '明细' '仅计算' -- 这个模式是只放入趋势自动计算里面
 ,@XDim  VARCHAR(50) = 'SinCapsule'
 ,@YDim  VARCHAR(50) = 'SinCapsule'
 
AS
BEGIN
		-- 处理维度临时表
    CREATE TABLE #Dims
	  (
		DimName varchar(50)
		,DimValues varchar(max)
		,ChName varchar(50)
		,Isneed varchar(50)
		,DimOrdersql varchar(50)
		,DimYsql varchar(50)
		,isrange varchar(50)
	  );
     
     EXEC [Sp_Com_GetdimensionTable]
     @SiftValue = @SiftValue
	,@XName = ''
	,@DsName = '';
     
    ALTER TABLE #Dims ADD IsnullV INT ;


	UPDATE a SET IsnullV = CASE WHEN b.Value = 0 THEN 1 ELSE 0 END
	FROM #Dims a INNER JOIN
	(
		SELECT SUBSTRING(string,1,CHARINDEX(':',string) - 1) AS DimNum,SUBSTRING(string,CHARINDEX(':',string) + 1,Len(string)) AS Value FROM dbo.Split(@SiftValue,'%')
	) b ON a.DimName = b.DimNum
	
	--SELECT * FROM #Dims;
	
	DECLARE @Sql VARCHAR(MAX) = '';

	SET @sql += ( SELECT 'CREATE TABLE #' +  DimName + 
					-- 非范围维度类型3列
					CASE WHEN isrange = 0 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''');'
					-- 范围维度类型5列
						 WHEN isrange = 1 THEN '(VWID INT ,[ID] INT , Name NVARCHAR(500) DEFAULT '''',BeginValue DECIMAL(18,2), EndValue DECIMAL(18,2));'		
					END
		FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH('') );

		DECLARE @NeedSiftvalue VARCHAR(MAX)= '';
	 -- 此处拼接需要解析的维度字符串作为 Siftvalue 送入维度解析
	 
	 -- 用 Dims 临时表拼接需要解析的 维度字符串
	 SET @NeedSiftvalue = ( SELECT  '%' + DimName + ':' + DimValues FROM #Dims WHERE Isneed <> 'ND' FOR XML PATH(''));
	 
	 -- 如果有老时间维度的，则加入老时间维度，如果没有则不加,并去除掉第一个 %
	 SET @NeedSiftvalue = CASE WHEN CHARINDEX('Dim7',@SiftValue) <> 0 THEN 'Dim7:' + dbo.GetDimValue(@SiftValue,'Dim7') + @NeedSiftvalue 
	 ELSE SUBSTRING(@NeedSiftvalue,2,LEN(@NeedSiftvalue))  END ;

	 -- 解析维度
	 SET @sql += ' EXEC [dbo].[Sp_Com_Getdimensions] @SiftValue = ''' + @NeedSiftvalue + ''', @EmpID = ' + CAST( 1 AS varchar(50)) + ';';
	 
	 -- 给 #Dim 中IsnullV 赋值
	
    -- 数据源sql段
    DECLARE @TName VARCHAR(500);
    SELECT @TName = JoinTables FROM dbo.Tbl_AnsCom_AnaSpConfig WHERE SpName = @SpName;
    
    DECLARE @INNERJOIN VARCHAR(max) = '';
	SET @INNERJOIN = ( SELECT ' INNER JOIN #' +  DimName + ' AS ' + DimName + ' on ' + 
			-- 如果是范围性维度则使用 范围筛选 实例：‘ DDLps.BeginValue <= data_YX.Conductivity AND DDLps.EndValue > data_YX.Conductivity ’
		CASE WHEN isrange = 1 THEN DimName + '.BeginValue <= ' + DimYsql + ' AND ' + DimName + '.EndValue > ' + DimYsql
			-- 如果是非范围性维度则使用 ID对等 实例： AF0001.ID = AF.ID
		ELSE DimName + '.ID = ' + DimYsql END
		FROM #Dims WHERE Isneed <> 'ND' AND IsnullV = 0 FOR XML PATH(''));
	
	
    -- 用FOR XML PATH 拼接后会将 '>' 、 '<' 两个符号转意成为 '&gt;' 和 '&lt;' ，所以将其替换回来
    SET @INNERJOIN = REPLACE(REPLACE(@INNERJOIN,'&lt;','<'),'&gt;','>') ;
  
	--SELECT @INNERJOIN
	DECLARE @Where VARCHAR(max) ;
	SET @Where = ( SELECT ' AND ' + DimYsql + ' IS NULL'
		FROM #Dims WHERE Isneed <> 'ND' AND IsnullV = 1 FOR XML PATH(''));
    
	IF(@Where IS NULL)
		SET @Where = ''
	
	--SELECT ('Select * FROM ' + @TName + @INNERJOIN + ' WHERE 1=1' + @Where);
	
		-- 拼接 @Select 段
    DECLARE @Select VARCHAR(max) = '';
    
    SET @Select += ISNULL((select AtYSql + ' AS [X值:'+ Name_ch + '],'
    FROM Tbl_AnsCom_DIimToTable WHERE DimNum = @XDim ),'')
    
    SET @Select += ISNULL((select AtYSql + ' AS [Y值:'+ Name_ch + ']'
    FROM Tbl_AnsCom_DIimToTable WHERE DimNum = @YDim ),'')
    
    SET @Select += ISNULL( ( SELECT ',' + DimName + '.Name AS ' + ChName
		FROM #Dims WHERE Isneed <> 'ND' AND IsnullV = 0 FOR XML PATH('')),'');
	
	SET @Select += ISNULL( ( SELECT ',Null AS ' + ChName
		FROM #Dims WHERE Isneed <> 'ND' AND IsnullV = 1 FOR XML PATH('')),'');
	
	DECLARE @OrderBy VARCHAR(max) = '';
	SELECT @OrderBy = AtYSql FROM Tbl_AnsCom_DIimToTable WHERE DimNum = @XDim
    
	--SELECT  @Select;
	
	--SELECT  @OrderBy;
	
	EXEC   (@Sql  + 'Select ' + @Select + ',* FROM ' + @TName + @INNERJOIN + @Where + ' Order By ' + @OrderBy);

END
go

