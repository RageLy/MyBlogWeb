


-- =============================================
-- Author:		贺俊龙
-- alter date: <2014-04-02>
-- Description:	<根据维度名称在字符串中获取相应的维度>
-- =============================================
CREATE function [dbo].[GetDimValue](
@SiftValue   varchar(Max),   --待分拆的字符串
@DimName varchar(max)     -- Dim名称 Dim4
)returns varchar(max)
as
BEGIN

   declare @result varchar(max)
   if(@SiftValue='')
      set @result='' 
    
   declare @temp table
   (
     String varchar(max)
   )  
      
   if(charindex('%',@SiftValue)<0)
      set @result = replace(@SiftValue,@DimName+':','')
   ELSE
   
   BEGIN
   
       insert into @temp
       select String from dbo.f_splitSTR(@SiftValue,'%')
       
       select @result=String from @temp
       where CHARINDEX(@DimName+':',String) <> 0
       
       set @result = replace(@result,@DimName+':','')
   End
   
   return @result;

end
go

