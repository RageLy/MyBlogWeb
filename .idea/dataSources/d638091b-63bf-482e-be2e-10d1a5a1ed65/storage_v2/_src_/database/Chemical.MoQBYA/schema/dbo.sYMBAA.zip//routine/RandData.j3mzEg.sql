CREATE function RandData( 
@a int, 
@b int) 
returns decimal(38,0) 
as 
begin 
declare @r decimal(38,0) 
select @r=cast(re*(@b-@a)+@a as decimal(38,0)) from myview 
return(@r) 
end
go

