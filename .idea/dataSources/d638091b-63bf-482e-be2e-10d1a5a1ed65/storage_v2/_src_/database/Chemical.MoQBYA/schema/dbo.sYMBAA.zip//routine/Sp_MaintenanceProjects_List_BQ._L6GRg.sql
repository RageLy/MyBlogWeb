          
          
          
          
          
CREATE PROCEDURE [dbo].[Sp_MaintenanceProjects_List_BQ]          
@PageIndex varchar(50)='1'                                                                                     
,@PageSize varchar(50)='5'                                                                                     
,@OrderFields varchar(50)=''              
,@Name varchar(50)=''              
,@CarSeriesId varchar(50)=''              
,@IsBanState varchar(50)=''   
,@LogEmpID varchar(50)='1'           
          
AS          
          
BEGIN          
          
SET NOCOUNT ON;                          
--设置默认排序                                          
if(LEN(@OrderFields)=0)                                      
begin                                                
set @OrderFields=' cast(LogEditTime as int )desc'                                      
end                
          
--维修套餐查询          
          
 SELECT         
 Id AS ID         
  ,Name          
  ,CarSeriesName  
  ,Cast(mp.CarSeriesId as Int)  as CarSeriesID         
  ,Remark          
  ,cast (case when IsBan = '1' then '是' else '否' end as varchar(50)) BanName  
  ,Cast(mp.IsBan as Int) as IsBan         
  ,LogEditTime          
  ,LogEditEmpName   
  ,@LogEmpID as LogEmpID         
 into #MaintenanceProjects          
 FROM Tbl_Base_MaintenanceProjects mp        
 left join Tbl_Com_Employee e on mp.CreateUser = e.EmpID           
 WHERE 1=1          
 AND (@Name = '' OR Name LIKE '%' + @Name + '%')          
 AND (@CarSeriesId = '' OR CarSeriesId = @CarSeriesId)
 AND (@IsBanState = '' OR IsBan = @IsBanState)          
          
declare @pageCount int =@@ROWCOUNT                
          
 if(@pageCount = 0)                                
begin                    
 insert into #MaintenanceProjects values(0,null,null,null,null,'',0,NULL,NULL,null)                    
end                    
                 
 --调用通用分页                    
                    
exec Sp_Sys_Page '#MaintenanceProjects',@OrderFields,@pageCount,@PageIndex,@PageSize               
END
go

