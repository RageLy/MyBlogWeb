-- =============================================
-- Author:  <曹乐平>
-- Create date:<2014-06-14>
-- Description:<存储过程调整>
-- =============================================

CREATE PROCEDURE [dbo].[Sp_Com_Dept_Del]
      @KeyValue  varchar(50)='',
      @TableName  varchar(50)='',
      @KeyName  varchar(50)=''

 as 
 Begin 

set nocount on

if(exists( select * from Tbl_Com_Employee where DeptID=@KeyValue))
begin
	select '该部门已在员工表引用，不能删除！'
	return
end
else
begin

	delete from Tbl_Com_Dept  where DeptID=@KeyValue
	select '0'

end
      
 End
go

