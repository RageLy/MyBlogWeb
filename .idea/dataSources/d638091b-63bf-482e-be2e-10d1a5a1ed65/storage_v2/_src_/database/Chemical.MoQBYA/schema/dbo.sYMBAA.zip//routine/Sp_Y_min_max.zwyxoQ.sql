







CREATE PROCEDURE [dbo].[Sp_Y_min_max](
@maxY decimal(18,2) ='1163823' --最大值
,@minY decimal(18,2) ='635390' --最小值
)
AS

BEGIN

declare
@MAY decimal(18,2) ---输出最大Y值
,@MIY decimal(18,2) ---输出最小Y值
,@kedu decimal(18,3) --刻度
,@na int
,@ni int

set @kedu=(@maxY-@minY)/5

declare @YTbl TABLE
(
  Yma decimal(18,2)
  ,Ymi decimal(18,2)
 )

set @na=CEILING(@maxY/5)
set @ni=FLOOR(@minY/5)


 
if (@minY/5=0 or @ni>1)
 set @MIY=(@ni-1)*5
 else set @MIY=@ni*5

 if(@minY/10<=10 and @minY/10>1)
 set @MIY=(FLOOR(@minY/10))*10
 
 if(@minY/10>10 and @minY/10<=100)
  set @MIY=(FLOOR(@minY/100))*100

 if(@minY/10>100 and @minY/10<=1000)
  set @MIY=(FLOOR(@minY/1000))*1000
  
 if(@minY/10>1000 )
  set @MIY=0



if (@maxY<=5)
 set @MAY=5
else 
  if (@maxY<=10)
  set @MAY=10
else
  if (@maxY/10<=10 and @maxY/10>1)
  set @MAY=(CEILING(@maxY/10))*10

  if(@maxY/10>10 and @maxY/10<=100)
  set @MAY=(CEILING(@maxY/100))*100

  if(@maxY/10>100 and @maxY/10<=1000)
   set @MAY=(CEILING(@maxY/200))*200
   
  if (@maxY/10>1000)
      begin
      declare @n int ---乘方
      set @n=1
      print '=============='
	  while (@maxY/power(10,@n))>10
	  begin 
	   print '~~~~~~~~~~~~~'
	   set @n += 1
	   print @n
	  end
	  print '***************'
	  set @MAY=(CEILING(@maxY/power(10,@n)))*(power(10,@n))
	  set @MIY=0
	  end
   /**
  if(@maxY/10>100 and @maxY/10<=1000)
   set @MAY=(CEILING(@maxY/200))*200
   **/

if(@kedu<1 and @minY>=5)
 set @MIY=FLOOR(@minY/5)*5
 if(@kedu<1 and @minY>=5)
 set @MAY=CEILING(@maxY/5)*5

--if(@maxY-@minY<5)
--set @MIY=FLOOR(@minY)
--set @MAY=CEILING(@maxY)

------------------------------------
if(@maxY/10<100)
 begin 
   set @MIY=FLOOR((@minY-@kedu))
   set @MAY=CEILING((@maxY+@kedu))
 end
------------------------------------

insert into @YTbl
values(@MAY,@MIY)
select * from @YTbl
 end
go

