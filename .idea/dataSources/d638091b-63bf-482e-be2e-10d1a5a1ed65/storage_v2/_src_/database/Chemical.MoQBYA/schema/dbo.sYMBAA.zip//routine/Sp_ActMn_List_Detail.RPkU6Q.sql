

-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 柱图、折线图两个图形的标准分析器sp

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_ActMn_List_Detail]
    @Code NVARCHAR(100) = '' ,
    @Step INT = 0 ,
    @OrderFields VARCHAR(100) = '' ,
    @SpName VARCHAR(50) = 'SinCapsule' ,
    @EmpID INT = 1 ,

 -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15'
AS
    BEGIN
        DECLARE @tarCode NVARCHAR(100)= '';
        DECLARE @orgpoint1 INT;
        DECLARE @orgpoint2 INT;

        DECLARE @num INT= 1;
        CREATE TABLE [#ResultOK]
            (
              [StepStep] INT ,
              [ActMnOrg1ActPoint] INT ,
              [ActMnTarSmCode1ID] INT ,
              [ActMnTarSmCode1] NVARCHAR(500) ,
              [ActMnOrgID2] INT ,
              [ActMnOrgSmCode2] NVARCHAR(500) ,
              [ActMnOrgID1] INT ,
              [ActMnOrgSmCode1] NVARCHAR(500) ,
              [ActMnCode] NVARCHAR(20)
            );
        CREATE TABLE #result
            (
              id INT IDENTITY(1, 1) ,
              Code NVARCHAR(50) ,
              step INT ,
              orgPoint1 INT ,
              orgPoint2 INT
            );
        INSERT  INTO #result
                ( Code ,
                  step ,
                  orgPoint1 ,
                  orgPoint2
                )
                SELECT  Code ,
                        step ,
                        Org1ActPoint ,
                        Org2ActPoint
                FROM    dbo.Bs_Act_MNByOutCode
                WHERE   TarSmCode1 = @Code;
        WHILE ( @num < = ( SELECT   COUNT(*)
                           FROM     dbo.Bs_Act_MNByOutCode
                           WHERE    TarSmCode1 = @Code
                         ) )
            BEGIN
                SET @Step = ( SELECT    step
                              FROM      #result
                              WHERE     id = @num
                            );
                SET @tarCode = ( SELECT Code
                                 FROM   #result
                                 WHERE  id = @num
                               );
                SET @orgpoint1 = ( SELECT   orgPoint1
                                   FROM     #result
                                   WHERE    id = @num
                                 );
                SET @orgpoint2 = ( SELECT   orgPoint2
                                   FROM     #result
                                   WHERE    id = @num
                                 );
                PRINT @tarCode;
                PRINT @orgpoint1;
                PRINT @orgpoint2;
---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            


	-- 如果有其它需要用 #时间表的必须在这里添加
	
                DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段                     
      
                DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	

	
	
-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              
                IF ( @tarCode IS NULL )
                    BEGIN
   
                        SELECT  'Name' AS '提示'
                        UNION ALL
                        SELECT  'varchar(500)'; 
   
                        SELECT  '未知此化合物组成' Name;
                    END;
                ELSE
                    BEGIN

	-- 处理select语句
	
                        SET @InnerSelect = ( SELECT ',' + TableName + '.['
                                                    + CoName + '] AS '
                                                    + TableName + CoName
                                             FROM   Tbl_AnsCom_DIimToTable
                                             WHERE  CHARINDEX(',' + @SpName
                                                              + ',', SpType) > 0
                                                    AND IsDimBan = 'False'
                                             ORDER BY ShowIndex
                                           FOR
                                             XML PATH('')
                                           );
	
                        SET @InnerSelect = SUBSTRING(@InnerSelect, 2,
                                                     LEN(@InnerSelect));


   -- 构造列名
   
                        DECLARE @CoChNames VARCHAR(MAX);
   
                        SET @CoChNames = ( SELECT   ',''' + TableName + CoName
                                                    + ''' AS [' + Name_ch
                                                    + ']'
                                           FROM     Tbl_AnsCom_DIimToTable
                                           WHERE    CHARINDEX(',' + @SpName
                                                              + ',', SpType) > 0
                                                    AND IsDimBan = 'False'
                                           ORDER BY ShowIndex
                                         FOR
                                           XML PATH('')
                                         );
	
                        DECLARE @Varchar500s VARCHAR(MAX);
   
                        SET @Varchar500s = ( SELECT ',''Varchar 500'''
                                             FROM   Tbl_AnsCom_DIimToTable
                                             WHERE  CHARINDEX(',' + @SpName
                                                              + ',', SpType) > 0
                                                    AND IsDimBan = 'False'
                                             ORDER BY ShowIndex
                                           FOR
                                             XML PATH('')
                                           );
                        SET @sql += 'select * from (';
                        DECLARE @queryStr NVARCHAR(200)= ''; 
                        SET @queryStr += '
        
    select ActMn.*  from (SELECT  ' + ( SELECT  ISNULL(SqlKey, '') + ' '
                                        FROM    dbo.Tbl_AnsCom_AnaSpConfig
                                        WHERE   SpName = @SpName
                                      );
                     
                        DECLARE @TarSmID1 INT= 0;
                        SET @TarSmID1 = ( SELECT    OrgID1
                                          FROM      Bs_Act_MNByOutCode
                                          WHERE     Code = @tarCode
                                                    AND Org1ActPoint = @orgpoint1
                                                    AND Org2ActPoint = @orgpoint2
                                        );
          
                        DECLARE @FromSql VARCHAR(MAX) = ( SELECT
                                                              JoinTables + ' '
                                                              + ISNULL(BaseTable,
                                                              '')
                                                          FROM
                                                              Tbl_AnsCom_AnaSpConfig
                                                          WHERE
                                                              SpName = @SpName
                                                        );

                        DECLARE @BottomSql NVARCHAR(MAX)= ISNULL(@InnerSelect,
                                                              '') + '  FROM '
                            + @FromSql;

                        SET @sql += @queryStr + @BottomSql
                            + ' where ActMn.Code=''' + @tarCode
                            + ''' and ActMn.Org1ActPoint=' + CAST(@orgpoint1 AS NVARCHAR(2))
                            + ' and ActMn.Org2ActPoint=' + CAST(@orgpoint2 AS NVARCHAR(2))
                            + ') ActMn UNION ALL';
                        SET @TarSmID1 = ( SELECT    OrgID1
                                          FROM      dbo.Bs_Act_MNByOutCode
                                          WHERE     Code = @tarCode
                                                    AND Org1ActPoint = @orgpoint1
                                                    AND Org2ActPoint = @orgpoint2
                                        );
                        --PRINT @TarSmID1;
                        --PRINT @sql;
        
                        WHILE ( @Step > 1 )
                            BEGIN
				
            
            
                                SET @sql += @queryStr + @BottomSql
                                    + ' where ActMn.TarSmCode1ID='
                                    + CAST(@TarSmID1 AS NVARCHAR(10))
                                    + ') ActMn Union All ';
          
                                SET @Step = @Step - 1;
                                SET @TarSmID1 = ( SELECT DISTINCT
                                                            OrgID1
                                                  FROM      dbo.Bs_Act_MNByOutCode
                                                  WHERE     TarSmCode1ID = @TarSmID1
                                                );
                                --PRINT @TarSmID1;
                            END;
  
                        SET @sql = LEFT(@sql, LEN(@sql) - 10) + ') a ';
                        PRINT @sql;
                        SET @num = @num + 1;
                        INSERT  INTO #ResultOK
                                ( ActMnCode ,
                                  ActMnOrgSmCode1 ,
                                  ActMnOrgID1 ,
                                  ActMnOrgSmCode2 ,
                                  ActMnOrgID2 ,
                                  ActMnTarSmCode1 ,
                                  ActMnTarSmCode1ID ,
                                  ActMnOrg1ActPoint ,
                                  StepStep 
                                )
                                EXEC ( @sql
                                    );
                    END;
            END;
              --PRINT @sql;
			-- 默认使用时间排序
        IF ( @OrderFields IS NULL
             OR @OrderFields = ''
           )
            SET @OrderFields = 'StepStep,ActMnOrgID1,ActMnOrg1ActPoint,ActMnOrgID2';

        EXEC(' SELECT ''n'' AS 序号' + @CoChNames + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s);
        DECLARE @totalRow INT = ( SELECT    COUNT(1)
                                  FROM      #ResultOK
                                );
        EXEC dbo.Sp_Sys_Page @tblName = #ResultOK, @fldName = @OrderFields,
            @rowcount = @totalRow, @PageIndex = @PageIndex,
            @PageSize = @PageSize, @SumType = 0, @SumColumn = '',
            @AvgColumn = ''; 
  
   
  

        
        
       
                --EXEC(@sql + @Pagesql);
           
       
        --PRINT @sql + @Pagesql; 
	
    END;
go

