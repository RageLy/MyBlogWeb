
  
-- =============================================                                                            
-- Description: <根据维度名称和字符串填充对应的维度表>      
-- 此版本为基本的服务，解析虚拟                                                
-- =============================================                               
CREATE PROC [dbo].[Sp_Com_Getdimension_VSum]                
    @SiftValue VARCHAR(MAX) = 'DimSinOutValue:-102|-202|-302|-402|8|9%DimSinFu:-1%DimSinTemp8:-1%DimSinTemp25:-1%DimSinTemp41:-1%DimSinSpeed:-1%DimSinSpeed580:-1%DimSinYX:-1%DimSinLJ:-1%DimSinJNGHL:-1%DimSinCR:-1%DimSinLBK:-1%DimSinLW:-1%DimSinDeltaBK:-1%DimSinDeltaW:-1%DimSinPH:-1%DimSinDDLps:-1%DimSinNDcp:-52|-54|-56|-58|-60|-62|-64|-66|-68|-70|-72|-74|-76|-78|-80|-82|-84|-86|-88|-90|-92|-94|-96|-98|-100|-102|-104|-106|-108|-110|-112|-114|-116|-118|-120|-122|-124|-126|-128|-130|-132|-134|-136|-138|-140|-142|-144|-146|-148|-150|-152|-154|-156|-158|-160|-162|-164|-166|-168|-170|-172|-174|-176|-178|-180|-182|-184|-186|-188|-190|-192|-194|-196|-198|-200|-202|-204|-206|-208|-210|-212|-214|-216|-218|-220|-222|-224|-226|-228|-230|-232|-234|-236|-238|-240|-242|-244|-246|-248|-250%DimSinAF0001:-1%DimSinAF0003:-1%DimSinLJspan:-1%DimSinPhTemp:-1%DimYXPH:-1%DimYXLJ05:-1%DimYXLJ09:-1%DimJNSINSFLJ:-1' ,   --条件字符串  获取由逗号分隔的表名                            
    @EmpID VARCHAR(400) = '1'                         
AS
BEGIN
    
    IF (@SiftValue IS NULL )
		RETURN;
	
	-- 按照百分号拆分维度进入临时表
	SELECT * INTO #Temp FROM dbo.Split(@SiftValue,'%');

	-- 定义要使用的变量字符串
	DECLARE @string VARCHAR(max) = '';  -- 游标获取的记录
	DECLARE @DimName VARCHAR(100) = ''; -- 维度名称
	DECLARE @DimValues VARCHAR(max) = '';  -- 维度的取值字符串
	
	-- 定义要使用的中间语句字符串
    DECLARE @sql VARCHAR(max) = '';  -- 执行插入维度表数据的sql语句
    DECLARE @tablename VARCHAR(max) = ''; -- 要插入的维度表的名称 
    
    --定义游标
    DECLARE temp_Cursor CURSOR
	FOR (SELECT string FROM #Temp) ;  -- 提取每一个维度的参数用于计算
	OPEN temp_Cursor; --打开游标
	
	FETCH NEXT FROM temp_Cursor INTO @string
	WHILE @@FETCH_STATUS = 0
	BEGIN
		SET @DimName = SUBSTRING(@string,0,CHARINDEX(':',@string));
		SET @DimValues = SUBSTRING(@string,CHARINDEX(':',@string) + 1 , LEN(@string) - 1);
		--SELECT @DimName,@DimValues;
		
		-- 从配置表得到对应维度的零时表名称
		SELECT @tablename = TableName FROM dbo.Tbl_AnsCom_DIimToTable WHERE DimNum = @DimName;
		
		SET @sql =  ' INSERT INTO ' + @tablename + '(ID,Name) SELECT p.ID,p.NAME
		 FROM Split(''' + @DimValues +''' ,''|'') x inner join vw_' + @DimName + '_Part p on p.ID = x.string ' ;
		
		PRINT @sql;
		--EXEC @sql;
		
		FETCH NEXT FROM temp_Cursor INTO @string; --读取下一行数据
	END
	
	CLOSE temp_Cursor; --关闭游标
	DEALLOCATE temp_Cursor; --释放游标

 --   SET @SiftValue = REPLACE(@SiftValue, '|', ',')                               
	                       
	--CREATE TABLE #AnalyzeTb
	--(
	--	id VARCHAR(max) ,
	--	name VARCHAR(max)
	--)

	--DECLARE @char VARCHAR(MAX)
	--DECLARE @reverse VARCHAR(MAX)
	--DECLARE @start INT ,@end INT
    
          
	--WHILE ( 1 = 1 )
	--BEGIN
	
	--	SET @start = CHARINDEX('filter', @SiftValue)                      
	--	SELECT @end = CHARINDEX('endfilter', @SiftValue)                      
	--	SET @char = SUBSTRING(@SiftValue, @start + 7, @end - @start - 8)                      
	-- -- select @SiftValue,@char,@start+7,@end-@start-8                      


	--	SET @reverse = REVERSE(LEFT(@SiftValue, @start))                      
	--	SET @reverse = REVERSE(LEFT(@reverse,CHARINDEX('miD', @reverse) + 2))                      
	--	SET @reverse = LEFT(@reverse, CHARINDEX(':', @reverse) - 1)                      
	-- --select @char,@reverse

	--	IF CHARINDEX('Dim7', @reverse) > 0                
	--	BEGIN                      
	--		TRUNCATE TABLE #AnalyzeTbTime                      
	--		INSERT  INTO #AnalyzeTbTime EXEC dbo.sp_Dim_7_Level_3_web @char               
	--		select * from  #AnalyzeTbTime       
	--  --      PRINT 'aaaaaaaaaaaaaa下面是@char'          
	--  --PRINT @char          
	                            
	--		SET @char = ( SELECT    id + ','                
	--					  FROM      #AnalyzeTbTime                
	--					  WHERE     id NOT IN ( 'id', 'int' )                
	--	   FOR XML PATH('')                
	--					)             
	                                       
	--		SET @char = LEFT(@char, LEN(@char) - 1)                      
	--  --select SUBSTRING(@SiftValue,@start,@end-@start+9)                    
	------------------替换字符串----------------                      
	--		SET @SiftValue = STUFF(@SiftValue, @start,@end - @start + 9, @char)                      
	--  --print @SiftValue                      
	--	END                      
	--	ELSE                
	--	BEGIN                      
	--		TRUNCATE TABLE #AnalyzeTb                      
	--  --select @char ,@reverse                      
	--		INSERT  INTO #AnalyzeTb EXEC dbo.sp_Dim_Common_Level_3_web @char,@reverse                      
	                
	--  --select * from #AnalyzeTb              
	            
	--		SET @char = ( SELECT    id + ','                
	--					  FROM      #AnalyzeTb                
	--					  WHERE     id NOT IN ( 'id', 'int' )                
	--			FOR XML PATH('')                
	--					)  
	--		SET @char = LEFT(@char, LEN(@char) - 1)                      
	--  --select SUBSTRING(@SiftValue,@start,@end-@start+9)                      
	------------------替换字符串----------------                      
	--		SET @SiftValue = STUFF(@SiftValue, @start,@end - @start + 9, @char)                      
	--  --print @SiftValue
	--	END

END
go

