              
/*              
刘轶  2014-10-31 查询列表默认添加查询条件为今天              
*/              
CREATE proc [dbo].[Sp_Com_DefaultGetDate]      
  @ID VARCHAR(50) = ''              
as                
BEGIN      
IF(@ID = '2')    
BEGIN    
   select 'BeginDate' BeginDate                      
 ,'EndDate' EndDate                        
 union all                        
 select 'varchar 200'                     
 ,'varchar 200'                         
 union all                        
 --select substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)                
 select '',''        
 -- substring(Convert(varchar(10),DateAdd(MM,-1,GETDATE()),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)       
END     
ELSE    
BEGIN              
 select 'BeginDate' BeginDate                      
 ,'EndDate' EndDate                        
 union all                        
 select 'varchar 200'                     
 ,'varchar 200'                         
 union all                        
 --select substring(CONVERT(varchar(50),GETDATE(),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)                
 select Convert(varchar(10),GETDATE(),23),Convert(varchar(10),GETDATE(),23)          
 -- substring(Convert(varchar(10),DateAdd(MM,-1,GETDATE()),23),0,8)+'-01',CONVERT(varchar(50),GETDATE(),23)    
END                 
END
go

