-- =============================================
-- Author:		<hmw>
-- Create date: <2017-11-30>
-- Description:	<分区统计明细数据查看>
-- =============================================
--EXEC [Sp_Analysister_JWDetail] 3,'Work','',1,20
CREATE PROCEDURE [dbo].[Sp_Analysister_JWDetail]
    @ID INT,
    @SpName NVARCHAR(20),
    @OrderFields NVARCHAR(20),
    @PageIndex VARCHAR(5) = '1',
    @PageSize VARCHAR(5) = '15'
AS
BEGIN
    DECLARE @InnerSelect NVARCHAR(MAX) = '';
	DECLARE @ErrorRecord NVARCHAR(MAX) = '';
	--IF((SELECT  ISNULL(TableName,'') + ISNULL(CoName,'')
 --       FROM Tbl_AnsCom_DIimToTable
 --       WHERE CHARINDEX(',' + @SpName + ',', SpType) > 0 AND SUBSTRING(CoName,1,9)!='FromSelfY')='')
	--	BEGIN
	--	SET @ErrorRecord += '数据源配置出错,查询SELECT JoinTables
 --                                       FROM Tbl_AnsCom_AnaSpConfig
 --                                       WHERE SpName = ''' + @SpName
 --                                   + '''结果为空 ,可能导致报错,请检查;';
 --               INSERT INTO dbo.ErrorRecord (   SpName ,
 --                                               ErrorInfo ,
 --                                               ExecSql ,
 --                                               Createdate
 --                                           )
 --               VALUES (   'Sp_Analysister_JWDetail' , -- SpName - nvarchar(50)
 --                          @ErrorRecord ,           -- ErrorInto - nvarchar(1000)
 --                          'Exec Sp_Analysister_JWDetail @ID='''
 --                          + @ID + ''',@OrderFields='''
 --                          + @OrderFields + ''',@SpName''' + @SpName
 --                          + ''',@PageIndex=''' + @PageIndex
 --                          + ''',@PageSize=''' + @PageSize + '''',
 --                          GETDATE()                -- ExecSql - nvarchar(1000)
 --                      );
	--	 RETURN;
 --       end
    SET @InnerSelect =
    (
        SELECT ',' + TableName + CoName
        FROM Tbl_AnsCom_DIimToTable
        WHERE CHARINDEX(',' + @SpName + ',', SpType) > 0 AND SUBSTRING(CoName,1,9)!='FromSelfY'
        ORDER BY ShowIndex
        FOR XML PATH('')
    );


    DECLARE @CoChNames VARCHAR(MAX);

    SET @CoChNames =
    (
        SELECT ',''' + TableName + CoName + ''' AS [' + Name_ch + ']'
        FROM Tbl_AnsCom_DIimToTable
        WHERE CHARINDEX(',' + @SpName + ',', SpType) > 0 AND SUBSTRING(CoName,1,9)!='FromSelfY'
        ORDER BY ShowIndex
        FOR XML PATH('')
    );

    DECLARE @Varchar500s VARCHAR(MAX);

    SET @Varchar500s =
    (
        SELECT ',''Varchar 500'''
        FROM Tbl_AnsCom_DIimToTable
        WHERE CHARINDEX(',' + @SpName + ',', SpType) > 0 AND SUBSTRING(CoName,1,9)!='FromSelfY'
        ORDER BY ShowIndex
        FOR XML PATH('')
    );
    SET @InnerSelect = SUBSTRING(@InnerSelect, 2, LEN(@InnerSelect));
    DECLARE @sql NVARCHAR(MAX) = 'SELECT ID,' + @InnerSelect + ' into #Result FROM dbo.DetailResult
    WHERE RowID = '              + CAST(@ID AS NVARCHAR(3));
    PRINT @sql;

    --IF (@OrderFields IS NULL OR @OrderFields = '')
    --    SET @OrderFields = REPLACE(@TimeName,'.','');

    EXEC (' SELECT ''n'' AS 序号' + @CoChNames + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s);
    --EXEC(@sql)
    SET @OrderFields = 'ID desc';
   DECLARE @Pagesql VARCHAR(MAX)
        = '  DECLARE @totalRow int = (Select count(1) FROM #Result) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#Result''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''''
  ,@AvgColumn = ''''
 '  ;
 EXEC(@sql+@Pagesql)
END;
go

