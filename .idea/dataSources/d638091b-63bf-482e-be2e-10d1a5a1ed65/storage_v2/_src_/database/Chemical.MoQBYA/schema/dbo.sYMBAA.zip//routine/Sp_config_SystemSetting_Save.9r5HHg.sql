  
  
  
  
  
CREATE PROC [dbo].[Sp_config_SystemSetting_Save]    
@SettingID VARCHAR(50)='',    
@SettingValue VARCHAR(50)='',    
@EmpID   varchar(50)=''    
AS    
BEGIN    
  
  
if(@SettingValue = '' OR @SettingValue = '0')  
BEGIN  
 SELECT '设置值不能为空!'  
 return  
END  
  
  
  
DECLARE @CheckType VARCHAR(50), @EditType VARCHAR(50),@EmpName VARCHAR(50)=''    
    
SELECT @EditType=EditType    
,@CheckType=CheckType    
FROM Tbl_config_SystemSetting    
WHERE  SettingID =@SettingID     
    
IF(@EditType='文本输入' AND @CheckType ='数字' AND dbo.fn_IsNumeric(@SettingValue) = 1)    
BEGIN    
SELECT '设置值格式不正确,请输入数字！'    
RETURN    
END    
SELECT @EmpName =EmpName FROM dbo.Tbl_Com_Employee WHERE EmpID = @EmpID    
    
UPDATE Tbl_config_SystemSetting SET SettingValue =@SettingValue     
,LogEditEmpName = @EmpName    
,LogEditTime =GETDATE()    
WHERE SettingID =@SettingID    
    
SELECT '0'    
END
go

