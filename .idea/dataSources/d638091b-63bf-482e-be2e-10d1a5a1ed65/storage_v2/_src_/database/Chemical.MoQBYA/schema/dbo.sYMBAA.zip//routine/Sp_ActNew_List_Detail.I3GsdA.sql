

-- =============================================                          
-- Author: hjl                                          
-- Create Date: 2016年7月18日
-- Edit Date: 2016年7月18日                                                
-- Descript: 柱图、折线图两个图形的标准分析器sp

-- =============================================                 

CREATE PROCEDURE [dbo].[Sp_ActNew_List_Detail]
    @Code NVARCHAR(100) = '' ,
    @Step INT = 0 ,
    @OrderFields VARCHAR(100) = '' ,
    @SpName VARCHAR(50) = 'SinCapsule' ,
    @EmpID INT = 1 ,

 -- 以下参数只在出明细时使用
    @PageIndex VARCHAR(5) = '1' ,
    @PageSize VARCHAR(5) = '15'
AS
    BEGIN
        DECLARE @tarCode NVARCHAR(100)= '';
		
        SET @Step = ( SELECT    Step
                      FROM      dbo.Bs_Act_New
                      WHERE     TarSmCode1 = @Code
                    );
        SET @tarCode = ( SELECT Code
                         FROM   dbo.Bs_Act_New
                         WHERE  TarSmCode1 = @Code
                       );
        
---------------------------------------------------------------------- 预处理步骤 准备参数变量 ---------------------------------------------------------            


	-- 如果有其它需要用 #时间表的必须在这里添加
	
        DECLARE @InnerSelect VARCHAR(MAX) = ''; -- 用于拼接@Sql中 Y轴的取表字段                     
      
        DECLARE @sql VARCHAR(MAX) = '';  -- 最终执行提取与计算数据的 sql语句
	

	
	
-------------------------------------------------------------- 基础数据计算 -------------------------------------------------------------              
        IF ( @tarCode is NULL)
            BEGIN
   
                SELECT  'Name' AS '提示'
                UNION ALL
                SELECT  'varchar(500)'; 
   
                SELECT  '未知此化合物组成' Name;
            END;
        ELSE
            BEGIN

	-- 处理select语句
	
                SET @InnerSelect = ( SELECT ',' + TableName + '.[' + CoName
                                            + '] AS ' + TableName + CoName
                                     FROM   Tbl_AnsCom_DIimToTable
                                     WHERE  CHARINDEX(',' + @SpName + ',',
                                                      SpType) > 0
                                            AND IsDimBan = 'False'
                                     ORDER BY ShowIndex
                                   FOR
                                     XML PATH('')
                                   );
	
                SET @InnerSelect = SUBSTRING(@InnerSelect, 2,
                                             LEN(@InnerSelect));


   -- 构造列名
   
                DECLARE @CoChNames VARCHAR(MAX);
   
                SET @CoChNames = ( SELECT   ',''' + TableName + CoName
                                            + ''' AS [' + Name_ch + ']'
                                   FROM     Tbl_AnsCom_DIimToTable
                                   WHERE    CHARINDEX(',' + @SpName + ',',
                                                      SpType) > 0
                                            AND IsDimBan = 'False'
                                   ORDER BY ShowIndex
                                 FOR
                                   XML PATH('')
                                 );
	
                DECLARE @Varchar500s VARCHAR(MAX);
   
                SET @Varchar500s = ( SELECT ',''Varchar 500'''
                                     FROM   Tbl_AnsCom_DIimToTable
                                     WHERE  CHARINDEX(',' + @SpName + ',',
                                                      SpType) > 0
                                            AND IsDimBan = 'False'
                                     ORDER BY ShowIndex
                                   FOR
                                     XML PATH('')
                                   );
                SET @sql += 'select * into #ResultOK from (';
                DECLARE @queryStr NVARCHAR(200)= ''; 
                SET @queryStr += '
        
    select ActNew.*  from (SELECT  ' + ( SELECT ISNULL(SqlKey, '') + ' '
                                         FROM   dbo.Tbl_AnsCom_AnaSpConfig
                                         WHERE  SpName = @SpName
                                       );
                DECLARE @TarSmID1 INT= 0;
                SET @TarSmID1 = ( SELECT    OrgSmID1
                                  FROM      Bs_Act_New
                                  WHERE     Code = @tarCode
                                );
                DECLARE @FromSql VARCHAR(MAX) = ( SELECT    JoinTables + ' '
                                                            + ISNULL(BaseTable,
                                                              '')
                                                  FROM      Tbl_AnsCom_AnaSpConfig
                                                  WHERE     SpName = @SpName
                                                );

                DECLARE @BottomSql NVARCHAR(MAX)= ISNULL(@InnerSelect, '')
                    + '  FROM ' + @FromSql;

                SET @sql += @queryStr + @BottomSql + ' where ActNew.Code='''
                    + @tarCode + ''') ActNew UNION ALL';
                SET @TarSmID1 = ( SELECT    OrgSmID1
                                  FROM      dbo.Bs_Act_New
                                  WHERE     Code = @tarCode
                                );
      	 
                WHILE ( @Step > 1 )
                    BEGIN
				
            
            
                        SET @sql += @queryStr + @BottomSql
                            + ' where ActNew.TarSmID1='
                            + CAST(@TarSmID1 AS NVARCHAR(10))
                            + ') ActNew Union All ';
                --PRINT 'ss'
                        SET @Step = @Step - 1;
                        SET @TarSmID1 = ( SELECT DISTINCT
                                                    OrgSmID1
                                          FROM      dbo.Bs_Act_New
                                          WHERE     TarSmID1 = @TarSmID1
                                        );
                    END;
  
        
                SET @sql = LEFT(@sql, LEN(@sql) - 10) + ') a ';
        
              --PRINT @sql;
			-- 默认使用时间排序
                IF ( @OrderFields IS NULL
                     OR @OrderFields = ''
                   )
                    SET @OrderFields = 'StepStep,ActNewOrgSmID1,ActNewOrgActLoaction,ActNewOrgSmID2';

  
                DECLARE @Pagesql VARCHAR(MAX) = 'DECLARE @totalRow int = (Select count(1) FROM #ResultOK) ;
  EXEC dbo.Sp_Sys_Page @tblName = ''#ResultOK''                        
  ,@fldName = ''' + @OrderFields + '''                               
  ,@rowcount = @totalRow   
  ,@PageIndex = ' + @PageIndex + '    
  ,@PageSize = ' + @PageSize + '    
  ,@SumType = 0
  ,@SumColumn = ''  
  ,@AvgColumn = ''  
 ';  
   
  

        
        
                EXEC(' SELECT ''n'' AS 序号' + @CoChNames + ' UNION ALL SELECT ''Varchar 500''' + @Varchar500s);
                EXEC(@sql + @Pagesql);
            END;
       
        PRINT @sql + @Pagesql; 
	
    END;
go

