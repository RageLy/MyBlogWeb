
/****************************************************
创建人:hmw
创建时间:2017-07-25
描述：距离度量问题的实现过程
其他：
****************************************************/

--EXEC [PercentResult] 'Coating','MsOverND','ScJP'
CREATE PROCEDURE [dbo].[Sp_Analysister_DistancePercent]
    @SpType NVARCHAR(20) ,
    @DimNum NVARCHAR(50) ,
    @YColumn NVARCHAR(50) ,
    @Name_ch NVARCHAR(50) ,
    @DimY NVARCHAR(50) ,
    @DimType BIT ,
    @DimKey NVARCHAR(50)
AS
    BEGIN
        PRINT @YColumn + ' ' + @DimNum + ' ' + @DimY;
        PRINT 'TB: ';
        PRINT @DimType;
        DECLARE @sql NVARCHAR(MAX)= '';
        
        SET @YColumn = ( SELECT SUBSTRING(@YColumn,
                                          CHARINDEX('.', @YColumn) + 1,
                                          LEN(@YColumn) - CHARINDEX('.',
                                                              @YColumn))
                       );
        SET @sql += ( SELECT    'WITH a AS (select ' + DistanceTypeStrEsp + ' ,'
                                + @DimNum + ' AS X from tbl_Result),'
                                + CHAR(10)
                      FROM      Tbl_BaseSetDistance
                      WHERE     DimNum = @DimY
                    );
                    --PRINT '第一次打印：'+@sql
                    
        --------------------------------------------------剔除无效的结果---------------------------------------------------------------
        SET @sql += 'b AS ( SELECT  * FROM  a
                                 WHERE  a.GY IS NOT NULL and X is not NULL
                                 ),' + CHAR(10);
        IF ( @DimType = 1 )
            BEGIN
        
        --------------------------------------------------生成序列与数量---------------------------------------------------------------
                SET @sql += 'c AS ( SELECT   ROW_NUMBER() OVER ( PARTITION BY GY ORDER BY 
            X ) 编号 ,X 数 ,COUNT(*) OVER ( PARTITION BY GY ) 数量 ,GY FROM b),'
                    + CHAR(10);

        --------------------------------------------------计算箱线图数据---------------------------------------------------------------
                SET @sql += 'd AS ( SELECT   最小值 ,
                                上四分位数 ,
                                中位数 ,
                                下四分位数 ,
                                最大值 ,
                                九五分位数 ,
                                五分位数 ,
                                MiddleValue.GY ,
                                MiddleValue.数量
                       FROM     ( SELECT    MAX(数) 中位数 ,
                                            GY ,
                                            数量 
                                  FROM      c
                                  WHERE     编号 = ROUND((CONVERT(FLOAT, 数量)+1)*0.5,0)
                                  GROUP BY  GY ,
                                            数量
                                ) MiddleValue' + CHAR(10);
                                
                SET @sql += 'LEFT JOIN ( SELECT  MAX(数) 最大值 ,
                                                    GY
                                            FROM    c
                                            GROUP BY GY
                                          ) MaxValue ON MaxValue.GY = MiddleValue.GY
                                LEFT JOIN ( SELECT  MIN(数) 最小值 ,
                                                    GY
                                            FROM    c
                                            GROUP BY GY
                                          ) minValue ON minValue.GY = MiddleValue.GY
                                LEFT JOIN ( SELECT  MAX(数) 下四分位数 ,
                                                    GY
                                            FROM    c
                                            WHERE   编号 = ROUND((CONVERT(FLOAT, 数量)+1)*0.25,0)
                                            GROUP BY GY
                                          ) UpFourValue ON UpFourValue.GY = MiddleValue.GY
                                LEFT JOIN ( SELECT  MAX(数) 上四分位数 ,
                                                    GY
                                            FROM    c
                                            WHERE   编号 = ROUND((CONVERT(FLOAT, 数量)+1)*0.75,0)
                                            GROUP BY GY
                                          ) DownFourValue ON DownFourValue.GY = MiddleValue.GY
                                LEFT JOIN ( SELECT  MAX(数) 五分位数 ,
                                                    GY
                                            FROM    c
                                            WHERE   编号 = (CASE WHEN ROUND(( CONVERT(FLOAT, 数量)
                                                         + 1 ) * 0.05, 0)<数量 THEN CEILING(( CONVERT(FLOAT, 数量)
                                                         + 1 ) * 0.05) ELSE ROUND(( CONVERT(FLOAT, 数量)
                                                         + 1 ) * 0.05, 0)  END)
                                            GROUP BY GY
                                          ) FiveValue ON FiveValue.GY = MiddleValue.GY
                                LEFT JOIN ( SELECT  MAX(数) 九五分位数 ,
                                                    GY 
                                            FROM    c
                                            WHERE   编号 = (CASE WHEN ROUND(( CONVERT(FLOAT, 数量)
                                                         + 1 ) * 0.95, 0)>数量 THEN FLOOR(( CONVERT(FLOAT, 数量)
                                                         + 1 ) * 0.95) ELSE ROUND(( CONVERT(FLOAT, 数量)
                                                         + 1 ) * 0.95, 0)  END)
                                            GROUP BY GY
                                          ) NineFiveValue ON NineFiveValue.GY = MiddleValue.GY
                     )' + CHAR(10);
            ---------------------------------------------计算占比-----------------------------------------------------------------
                SET @sql += 'INSERT INTO dbo.TempResult
        ( CoName,
          DimNum,
          GY,
          MinValue,
          FiveValue,
          DownFourValue,
          MiddleValue,
          UpFourValue,
          NineFiveValue,
          MaxValue,
          Num,
          YDimNum)
          select  '''+@Name_ch+''',
                  '''+@DimKey+''',
                  GY,
                  最小值 ,
                  五分位数 ,
                  下四分位数 ,
                  中位数 ,
                  上四分位数 ,
                  九五分位数 ,
                  最大值 ,
                  数量,'''+@DimY+''' from d
             '
         
            END;
        ELSE
            IF ( @DimType = 0 )
                BEGIN
       --------------------------------------------------求取各自数量---------------------------------------------------------------
                    SET @sql += ' c AS ( SELECT   CountX ,
                        CountGY ,
                        x.GY ,
                        x.X
               FROM     ( SELECT    COUNT(X) CountX ,
                                    GY ,
                                    b.X
                          FROM      b
                          GROUP BY  X ,
                                    b.GY
                        ) x
                        INNER JOIN ( SELECT COUNT(b.GY) CountGY ,
                                            GY
                                     FROM   b
                                     GROUP BY b.GY
                                   ) y ON y.GY = x.GY
             ),';
        --------------------------------------------------计算ID各自占比---------------------------------------------------------------
                    SET @sql += ' d AS ( SELECT   ROUND(CAST(c.CountX AS DECIMAL(18, 4)) / c.CountGY, 4) PercentX ,
                        c.X ,
                        c.GY
               FROM     c
             ),';
        ---------------------------------------------ID占比做差-----------------------------------------------------------------
                    SET @sql += '  e AS ( SELECT   ABS(( CASE WHEN y.PercentX IS NULL THEN 0
                                   ELSE y.PercentX
                              END ) - ( CASE WHEN x.PercentX IS NULL THEN 0
                                             ELSE x.PercentX
                                        END )) PercentX ,
                        ( CASE WHEN y.X IS NULL THEN x.X
                               ELSE y.X
                          END ) X ,
                        ( CASE WHEN y.GY IS NULL THEN x.GY
                               WHEN y.GY IS NOT NULL AND x.GY IS NOT NULL THEN 2
                               ELSE y.GY
                          END ) GY
               FROM     ( SELECT    *
                          FROM      d
                          WHERE     GY = 1
                        ) x
                        FULL JOIN ( SELECT  *
                                    FROM    d
                                    WHERE   GY = 0
                                  ) y ON y.X = x.X
               GROUP BY ( CASE WHEN y.GY IS NULL THEN x.GY
                               WHEN y.GY IS NOT NULL AND x.GY IS NOT NULL THEN 2
                               ELSE y.GY
                          END ),
                        ( CASE WHEN y.PercentX IS NULL THEN 0
                               ELSE y.PercentX
                          END ) - ( CASE WHEN x.PercentX IS NULL THEN 0
                                         ELSE x.PercentX
                                    END ) ,
                        ( CASE WHEN y.X IS NULL THEN x.X
                               ELSE y.X
                          END )
             )';
    -------------------------------------------------------求和---------------------------------------------------------------
                    SET @sql += ' INSERT INTO [dbo].[TempResultID]
            ( [CoName] ,
              [X] ,
              [Y] ,
              [CountX] ,
              [CountY] ,
              [PercentData] ,
              [MeasureDistance],
              [DimNum]
            )
   
              SELECT    ''' + @Name_ch + ''',
                        x.X ,
                        (case when x.GY=0 then ''差等'' else ''优等'' end) GY ,
                        z.CountX ,
                        z.CountGY ,
                        x.占比 ,
                        y.距离度量,
                        ''' + @DimKey + '''
              FROM      ( SELECT    Left(d.PercentX,6) 占比 ,
                                    d.X ,
                                    d.GY
                          FROM      d
                        ) x
                        INNER JOIN ( SELECT c.CountX ,
                                            c.CountGY ,
                                            c.GY ,
                                            c.X
                                     FROM   c
                                   ) z ON z.GY = x.GY AND z.X = x.X
                        CROSS JOIN ( SELECT SUM(e.PercentX) 距离度量
                                     FROM   e
                                   ) y; ';
                                   
                END;
                
       
        --SELECT  @sql
      
        PRINT @sql;
        EXEC(@sql);
        
    END;
go

